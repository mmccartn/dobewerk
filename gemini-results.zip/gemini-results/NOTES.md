Prerequisites for Running Surya on Your Other System
On your 32 GB system, you only need:

Python Environment: pip install surya-ocr "numpy<2"
llama-server.exe: Already present in stud-scrape/bin/llama-b12087-bin-win-cpu-x64/.
The 2 Surya GGUF Model Files: Placed directly in stud-scrape/bin/:
surya-2.5.gguf (~1.5 GB)
surya-2.5-mmproj.gguf (~320 MB)
How to Run the Exact Test on Your Other System
To run Leaf 41 of 1929-01 through Surya and output a dedicated JSON file for comparison against Gemini:

cd stud-scrape
python autonomous_extractor.py \
  --year-from 1929 --year-to 1929 \
  --issue 1 \
  --leaf-start 41 --leaf-end 41 \
  --ocr-engine surya \
  --output data/surya_extracted_1929_01_leaf41.json \
  --flags-output data/surya_flags_1929_01_leaf41.json
Comparing the Outputs
After running, you will have the three benchmark files sitting side-by-side in stud-scrape/data/:

data/gemini_pages/.../leaf_0041.json — Gemini Vision (lossless column mode)
data/surya_extracted_1929_01_leaf41.json — Surya OCR (neural ViT mode)
template.yml — Ground truth (62 dogs on Leaf 41)
You can compare them directly or run python report_counts.py --year 1929 to inspect the results.