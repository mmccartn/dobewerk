import * as d3 from 'd3'
import { useEffect, useMemo, useRef } from 'react'
import { displayName, type DogNode } from '../types'

type GraphNode = {
  id: string
  depth: number
  visits: number
  x: number
  y: number
}

type GraphEdge = {
  parent: string
  child: string
  relationship: 'sire' | 'dam'
}

type Props = {
  focusId: string
  nodes: Record<string, DogNode>
  depth: number
  onSelect: (id: string) => void
}

function buildAncestorGraph(focusId: string, nodes: Record<string, DogNode>, maxDepth: number) {
  const graph = new Map<string, GraphNode>()
  const edges = new Map<string, GraphEdge>()
  const queue: Array<{ id: string; depth: number; path: Set<string> }> = [{ id: focusId, depth: 0, path: new Set() }]

  while (queue.length > 0) {
    const current = queue.shift()!
    const node = nodes[current.id]
    if (!node || current.depth > maxDepth || current.path.has(current.id)) continue
    const existing = graph.get(current.id)
    graph.set(current.id, {
      id: current.id,
      depth: Math.min(existing?.depth ?? current.depth, current.depth),
      visits: (existing?.visits ?? 0) + 1,
      x: 0,
      y: 0,
    })
    if (current.depth === maxDepth) continue
    const nextPath = new Set(current.path).add(current.id)
    for (const relationship of ['sire', 'dam'] as const) {
      const parent = node[relationship]
      if (!parent || !nodes[parent]) continue
      edges.set(`${parent}:${current.id}:${relationship}`, { parent, child: current.id, relationship })
      queue.push({ id: parent, depth: current.depth + 1, path: nextPath })
    }
  }

  const layers = new Map<number, GraphNode[]>()
  for (const node of graph.values()) {
    layers.set(node.depth, [...(layers.get(node.depth) ?? []), node])
  }
  for (const [layerDepth, layer] of layers) {
    layer.sort((left, right) => displayName(nodes[left.id]).localeCompare(displayName(nodes[right.id])))
    layer.forEach((node, index) => {
      node.x = 90 + layerDepth * 235
      node.y = 90 + index * 88
    })
  }

  return { nodes: [...graph.values()], edges: [...edges.values()] }
}

export default function PedigreeGraph({ focusId, nodes, depth, onSelect }: Props) {
  const svgRef = useRef<SVGSVGElement>(null)
  const graph = useMemo(() => buildAncestorGraph(focusId, nodes, depth), [focusId, nodes, depth])
  const byId = useMemo(() => new Map(graph.nodes.map((node) => [node.id, node])), [graph])
  const width = Math.max(760, (depth + 1) * 235 + 120)
  const height = Math.max(420, ...graph.nodes.map((node) => node.y + 90))

  useEffect(() => {
    const element = svgRef.current
    if (!element) return
    const svg = d3.select(element)
    const zoom = d3.zoom<SVGSVGElement, unknown>().scaleExtent([0.25, 4]).on('zoom', (event) => {
      svg.select<SVGGElement>('.graph-viewport').attr('transform', event.transform)
    })
    svg.call(zoom).on('dblclick.zoom', null)
    svg.call(zoom.transform, d3.zoomIdentity.translate(24, 24))
    return () => {
      svg.on('.zoom', null)
    }
  }, [focusId, depth])

  return (
    <section className="graph-panel">
      <div className="graph-header">
        <div>
          <p className="eyebrow">Interactive ancestry</p>
          <h2>Pedigree graph</h2>
        </div>
        <p>Drag to pan. Scroll to zoom. Repeated ancestors receive a larger ring.</p>
      </div>
      <div className="graph-canvas">
        <svg ref={svgRef} viewBox={`0 0 ${width} ${height}`} role="img" aria-label="Interactive pedigree graph">
          <g className="graph-viewport">
            {graph.edges.map((edge) => {
              const parent = byId.get(edge.parent)!
              const child = byId.get(edge.child)!
              return <line key={`${edge.parent}:${edge.child}:${edge.relationship}`} className={`edge ${edge.relationship}`} x1={parent.x} y1={parent.y} x2={child.x} y2={child.y} />
            })}
            {graph.nodes.map((graphNode) => {
              const node = nodes[graphNode.id]
              const repeated = graphNode.visits > 1
              return (
                <g key={graphNode.id} className={`graph-node ${node.primary_source} ${repeated ? 'repeated' : ''}`} transform={`translate(${graphNode.x}, ${graphNode.y})`} onClick={() => onSelect(graphNode.id)}>
                  {repeated && <circle className="repeat-ring" r={29 + Math.min(graphNode.visits, 6) * 2} />}
                  <circle className="node-dot" r="25" />
                  <text className="node-name" x="34" y="-3">{displayName(node)}</text>
                  <text className="node-id" x="34" y="16">{node.registration_number ?? node.primary_source}</text>
                  {repeated && <text className="repeat-count" textAnchor="middle" y="5">{graphNode.visits}</text>}
                </g>
              )
            })}
          </g>
        </svg>
      </div>
    </section>
  )
}
