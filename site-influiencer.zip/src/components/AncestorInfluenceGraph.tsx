import * as d3 from 'd3'
import { useEffect, useMemo, useRef, useState } from 'react'
import { displayName, type DogNode } from '../types'

type InfluenceNode = d3.SimulationNodeDatum & {
  id: string
  dog: DogNode
  depth: number
  contribution: number
  paths: number
  radius: number
}

type InfluenceEdge = {
  parent: string
  child: string
  weight: number
}

type Props = {
  focusId: string
  nodes: Record<string, DogNode>
  highlightedIds: Set<string>
  onSelect: (id: string) => void
}

function buildInfluenceGraph(focusId: string, nodes: Record<string, DogNode>) {
  const nodeMap = new Map<string, InfluenceNode>()
  const edgeMap = new Map<string, InfluenceEdge>()
  let frontier = new Map<string, number>([[focusId, 1]])

  for (let depth = 0; depth <= 100; depth += 1) {
    const next = new Map<string, number>()
    for (const [id, weight] of frontier) {
      const dog = nodes[id]
      if (!dog) continue
      const node = nodeMap.get(id)
      if (node) {
        node.contribution += weight
        node.paths += 1
        node.depth = Math.min(node.depth, depth)
      } else {
        nodeMap.set(id, { id, dog, depth, contribution: weight, paths: 1, radius: 0, x: 0, y: 0 })
      }
      if (depth === 100) continue
      for (const relationship of ['sire', 'dam'] as const) {
        const parent = dog[relationship]
        if (!parent || !nodes[parent]) continue
        const edgeKey = `${parent}:${id}`
        const edge = edgeMap.get(edgeKey)
        if (edge) edge.weight += weight
        else edgeMap.set(edgeKey, { parent, child: id, weight })
        next.set(parent, (next.get(parent) ?? 0) + weight / 2)
      }
    }
    frontier = next
  }

  const graphNodes = [...nodeMap.values()]
  const maxContribution = Math.max(...graphNodes.map((node) => node.contribution), 1)
  for (const node of graphNodes) node.radius = 3.5 + Math.sqrt(node.contribution / maxContribution) * 18
  const graphEdges = [...edgeMap.values()].filter((edge) => nodeMap.has(edge.parent) && nodeMap.has(edge.child))
  const byId = new Map(graphNodes.map((node) => [node.id, node]))
  const simulationLinks = graphEdges.map((edge) => ({ source: edge.parent, target: edge.child }))
  const root = byId.get(focusId)
  if (root) {
    root.fx = 0
    root.fy = 0
  }
  const simulation = d3.forceSimulation(graphNodes)
    .force('charge', d3.forceManyBody().strength(-24))
    .force('link', d3.forceLink<InfluenceNode, { source: string; target: string }>(simulationLinks).id((node) => node.id).distance(42).strength(0.35))
    .force('collide', d3.forceCollide<InfluenceNode>((node) => node.radius + 3).strength(0.9))
    .force('radial', d3.forceRadial<InfluenceNode>((node) => Math.min(780, node.depth * 72), 0, 0).strength(0.16))
    .stop()
  simulation.tick(Math.min(180, 70 + graphNodes.length / 20))
  if (root) {
    root.fx = null
    root.fy = null
  }
  return { nodes: graphNodes, edges: graphEdges, rootId: focusId }
}

function fillFor(node: InfluenceNode) {
  if (node.dog.sex === 'Female') return node.dog.primary_source === 'dobequest' ? '#faedf1' : '#f9e4ea'
  if (node.dog.sex === 'Male') return node.dog.primary_source === 'dobequest' ? '#e8f1f7' : '#dcecf5'
  return node.dog.primary_source === 'dobequest' ? '#edf5e9' : '#ffffff'
}

function strokeFor(node: InfluenceNode) {
  if (node.dog.sex === 'Female') return '#a55e76'
  if (node.dog.sex === 'Male') return '#39708d'
  return node.dog.primary_source === 'dobequest' ? '#66874f' : '#2e6079'
}

function pathNodeIds(startId: string, edges: InfluenceEdge[]) {
  const children = new Map<string, string[]>()
  for (const edge of edges) children.set(edge.parent, [...(children.get(edge.parent) ?? []), edge.child])
  const result = new Set<string>()
  const pending = [startId]
  while (pending.length) {
    const id = pending.pop()!
    if (result.has(id)) continue
    result.add(id)
    pending.push(...(children.get(id) ?? []))
  }
  return result
}

export default function AncestorInfluenceGraph({ focusId, nodes, highlightedIds, onSelect }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const zoomRef = useRef<d3.ZoomBehavior<HTMLCanvasElement, unknown> | null>(null)
  const selectionRef = useRef<d3.Selection<HTMLCanvasElement, unknown, null, undefined> | null>(null)
  const [transform, setTransform] = useState(d3.zoomIdentity)
  const [hovered, setHovered] = useState<InfluenceNode | null>(null)
  const graph = useMemo(() => buildInfluenceGraph(focusId, nodes), [focusId, nodes])
  const hoverPaths = useMemo(() => hovered ? pathNodeIds(hovered.id, graph.edges) : new Set<string>(), [graph.edges, hovered])

  const fitGraph = () => {
    const canvas = canvasRef.current
    const selection = selectionRef.current
    const zoom = zoomRef.current
    if (!canvas || !selection || !zoom) return
    const extent = Math.max(...graph.nodes.map((node) => Math.max(Math.abs(node.x ?? 0), Math.abs(node.y ?? 0))), 300)
    const scale = Math.min((canvas.clientWidth - 48) / (extent * 2), (canvas.clientHeight - 48) / (extent * 2), 1)
    selection.call(zoom.transform, d3.zoomIdentity.translate(canvas.clientWidth / 2, canvas.clientHeight / 2).scale(scale))
  }

  const findNodeAt = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current
    if (!canvas) return null
    const bounds = canvas.getBoundingClientRect()
    const x = (clientX - bounds.left - transform.x) / transform.k
    const y = (clientY - bounds.top - transform.y) / transform.k
    return graph.nodes.find((node) => Math.hypot(x - (node.x ?? 0), y - (node.y ?? 0)) <= node.radius + 5 / transform.k) ?? null
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const zoom = d3.zoom<HTMLCanvasElement, unknown>().scaleExtent([0.04, 12]).on('zoom', (event) => setTransform(event.transform))
    const selection = d3.select(canvas)
    zoomRef.current = zoom
    selectionRef.current = selection
    selection.call(zoom).on('dblclick.zoom', null)
    fitGraph()
    return () => {
      selection.on('.zoom', null)
      zoomRef.current = null
      selectionRef.current = null
    }
  }, [focusId, graph.nodes.length])

  useEffect(() => {
    const canvas = canvasRef.current
    const container = containerRef.current
    if (!canvas || !container) return
    const pixelRatio = window.devicePixelRatio || 1
    const width = container.clientWidth
    const height = container.clientHeight || 680
    canvas.width = width * pixelRatio
    canvas.height = height * pixelRatio
    canvas.style.width = `${width}px`
    canvas.style.height = `${height}px`
    const context = canvas.getContext('2d')
    if (!context) return
    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0)
    context.clearRect(0, 0, width, height)
    context.save()
    context.translate(transform.x, transform.y)
    context.scale(transform.k, transform.k)
    const byId = new Map(graph.nodes.map((node) => [node.id, node]))

    for (const edge of graph.edges) {
      const parent = byId.get(edge.parent)
      const child = byId.get(edge.child)
      if (!parent || !child) continue
      const active = hoverPaths.has(parent.id) && hoverPaths.has(child.id)
      context.beginPath()
      context.moveTo(parent.x ?? 0, parent.y ?? 0)
      context.lineTo(child.x ?? 0, child.y ?? 0)
      context.strokeStyle = active ? '#bb7518' : '#58778a'
      context.globalAlpha = active ? 0.9 : 0.22
      context.lineWidth = (active ? 2.2 + Math.log2(1 + edge.weight) : 0.8) / transform.k
      context.stroke()
    }

    for (const node of graph.nodes) {
      const active = hoverPaths.has(node.id)
      context.globalAlpha = hovered && !active ? 0.24 : 1
      context.beginPath()
      context.arc(node.x ?? 0, node.y ?? 0, node.radius, 0, Math.PI * 2)
      context.fillStyle = fillFor(node)
      context.strokeStyle = strokeFor(node)
      context.lineWidth = 1.5 / transform.k
      context.fill()
      context.stroke()
      if (highlightedIds.has(node.id)) {
        context.beginPath()
        context.arc(node.x ?? 0, node.y ?? 0, node.radius + 4 / transform.k, 0, Math.PI * 2)
        context.strokeStyle = '#7b43a1'
        context.lineWidth = 3 / transform.k
        context.stroke()
      }
    }
    context.restore()

    for (const node of graph.nodes) {
      const x = transform.x + (node.x ?? 0) * transform.k
      const y = transform.y + (node.y ?? 0) * transform.k
      const radius = node.radius * transform.k
      if (radius < 8) continue
      const label = node.dog.name ?? 'Unknown dog'
      context.fillStyle = '#173a52'
      context.font = '600 11px Inter, sans-serif'
      context.textAlign = 'center'
      context.textBaseline = 'top'
      context.fillText(label.length > 25 ? `${label.slice(0, 24)}…` : label, x, y + radius + 4)
    }
  }, [graph, highlightedIds, hoverPaths, hovered, transform])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const onPointerMove = (event: PointerEvent) => setHovered(findNodeAt(event.clientX, event.clientY))
    const onPointerLeave = () => setHovered(null)
    canvas.addEventListener('pointermove', onPointerMove)
    canvas.addEventListener('pointerleave', onPointerLeave)
    return () => {
      canvas.removeEventListener('pointermove', onPointerMove)
      canvas.removeEventListener('pointerleave', onPointerLeave)
    }
  }, [graph, transform])

  return (
    <section className="graph-panel canvas-pedigree">
      <div className="graph-header">
        <span>One node per ancestor · Node size: weighted pedigree contribution</span>
        <button onClick={fitGraph}>Fit network</button>
      </div>
      <div className="graph-legend">
        <span><i className="legend-swatch male" /> Male</span>
        <span><i className="legend-swatch female" /> Female</span>
        <span><i className="legend-swatch akc" /> AKC-primary</span>
        <span><i className="legend-swatch dobequest" /> DobeQuest-primary</span>
        <span>Hover a dog to trace its routes to the focus dog</span>
      </div>
      <div className="graph-canvas" ref={containerRef}>
        <canvas ref={canvasRef} onClick={(event) => { const node = findNodeAt(event.clientX, event.clientY); if (node) onSelect(node.id) }} />
        {hovered && (
          <div className="graph-tooltip">
            <strong>{displayName(hovered.dog)}</strong>
            <span>Contribution: {(hovered.contribution * 100).toFixed(2)}%</span>
            <span>Ancestry paths: {hovered.paths}</span>
            <span>Closest generation: {hovered.depth}</span>
          </div>
        )}
      </div>
    </section>
  )
}
