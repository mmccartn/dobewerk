import * as d3 from 'd3'
import { useEffect, useMemo, useRef, useState } from 'react'
import { displayName, type DogNode } from '../types'

type TableState = 'expanded' | 'shared_reference' | 'depth_limited'

type TableNode = {
  id: string
  canonicalId: string
  dog: DogNode
  depth: number
  side: -1 | 0 | 1
  top: number
  bottom: number
  y: number
  x: number
  width: number
  state: TableState
  hasParents: boolean
  paths: number
}

type Props = {
  focusId: string
  nodes: Record<string, DogNode>
  highlightedIds: Set<string>
  onSelect: (id: string) => void
}

const maximumDepth = 100
const rowExtent = 160
const rootWidth = 220
const columnGap = 0

function buildTable(focusId: string, nodes: Record<string, DogNode>) {
  type TreeNode = {
    id: string
    canonicalId: string
    dog: DogNode
    depth: number
    state: TableState
    children: Array<{ relationship: 'sire' | 'dam'; node: TreeNode }>
  }

  const seen = new Set<string>()
  const paths = new Map<string, number>()
  let referenceCount = 0

  const visit = (id: string | null, depth: number, path: Set<string>): TreeNode | null => {
    const dog = id ? nodes[id] : undefined
    if (!dog || !id) return null
    paths.set(id, (paths.get(id) ?? 0) + 1)
    const repeated = path.has(id) || seen.has(id)
    const state: TableState = repeated ? 'shared_reference' : depth === maximumDepth && (dog.sire || dog.dam) ? 'depth_limited' : 'expanded'
    const treeNode: TreeNode = { id: repeated ? `shared:${id}:${++referenceCount}` : id, canonicalId: id, dog, depth, state, children: [] }
    if (repeated || depth === maximumDepth) return treeNode
    seen.add(id)
    const nextPath = new Set(path).add(id)
    for (const relationship of ['sire', 'dam'] as const) {
      const child = visit(dog[relationship], depth + 1, nextPath)
      if (child) treeNode.children.push({ relationship, node: child })
    }
    return treeNode
  }

  const rootTree = visit(focusId, 0, new Set())
  if (!rootTree) throw new Error(`Missing focused dog: ${focusId}`)
  const rawNodes: Array<Omit<TableNode, 'x' | 'width'>> = []

  const project = (treeNode: TreeNode, side: -1 | 0 | 1, top: number, bottom: number) => {
    const rawNode = { ...treeNode, side, top, bottom, y: (top + bottom) / 2, hasParents: treeNode.children.length > 0, paths: paths.get(treeNode.canonicalId) ?? 1 }
    rawNodes.push(rawNode)
    if (!treeNode.children.length) return
    if (treeNode.depth === 0) {
      for (const child of treeNode.children) {
        project(child.node, child.relationship === 'sire' ? -1 : 1, -rowExtent / 2, rowExtent / 2)
      }
      return
    }
    const middle = (top + bottom) / 2
    for (const child of treeNode.children) {
      project(child.node, side, child.relationship === 'sire' ? top : middle, child.relationship === 'sire' ? middle : bottom)
    }
  }

  project(rootTree, 0, -rowExtent / 2, rowExtent / 2)
  const widths = Array.from({ length: maximumDepth + 1 }, (_, depth) => depth === 0 ? rootWidth : rootWidth / 2 ** (depth - 1))
  const offsets = Array.from({ length: maximumDepth + 1 }, () => 0)
  for (let depth = 1; depth <= maximumDepth; depth += 1) offsets[depth] = offsets[depth - 1] + widths[depth - 1] / 2 + columnGap + widths[depth] / 2

  const tableNodes = rawNodes.map((node) => ({ ...node, x: node.side * offsets[node.depth], width: widths[node.depth] }))
  return { root: tableNodes.find((node) => node.depth === 0)!, nodes: tableNodes }
}

function fillFor(node: TableNode) {
  if (node.dog.sex === 'Female') return node.dog.primary_source === 'dobequest' ? '#faedf1' : '#f9e4ea'
  if (node.dog.sex === 'Male') return node.dog.primary_source === 'dobequest' ? '#e8f1f7' : '#dcecf5'
  return node.dog.primary_source === 'dobequest' ? '#edf5e9' : '#ffffff'
}

function strokeFor(node: TableNode) {
  if (node.state === 'shared_reference') return '#cf973c'
  if (node.dog.sex === 'Female') return '#a55e76'
  if (node.dog.sex === 'Male') return '#39708d'
  return node.dog.primary_source === 'dobequest' ? '#66874f' : '#2e6079'
}

export default function PedigreeGraph({ focusId, nodes, highlightedIds, onSelect }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const zoomRef = useRef<d3.ZoomBehavior<HTMLCanvasElement, unknown> | null>(null)
  const selectionRef = useRef<d3.Selection<HTMLCanvasElement, unknown, null, undefined> | null>(null)
  const [transform, setTransform] = useState(d3.zoomIdentity)
  const [hovered, setHovered] = useState<TableNode | null>(null)
  const table = useMemo(() => buildTable(focusId, nodes), [focusId, nodes])

  const fitTable = () => {
    const canvas = canvasRef.current
    const selection = selectionRef.current
    const zoom = zoomRef.current
    if (!canvas || !selection || !zoom) return
    const scale = Math.min(0.85, (canvas.clientWidth - 80) / (offsetForDepth(5, table.nodes) * 2), (canvas.clientHeight - 80) / rowExtent)
    selection.call(zoom.transform, d3.zoomIdentity.translate(canvas.clientWidth / 2, canvas.clientHeight / 2).scale(scale))
  }

  const findNodeAt = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current
    if (!canvas) return null
    const bounds = canvas.getBoundingClientRect()
    const x = (clientX - bounds.left - transform.x) / transform.k
    const y = (clientY - bounds.top - transform.y) / transform.k
    return [...table.nodes].reverse().find((node) => x >= node.x - node.width / 2 && x <= node.x + node.width / 2 && y >= node.top && y <= node.bottom) ?? null
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const zoom = d3.zoom<HTMLCanvasElement, unknown>().scaleExtent([0.002, Number.POSITIVE_INFINITY]).wheelDelta((event) => -event.deltaY * 0.009).on('zoom', (event) => setTransform(event.transform))
    const selection = d3.select(canvas)
    zoomRef.current = zoom
    selectionRef.current = selection
    selection.call(zoom).on('dblclick.zoom', null)
    fitTable()
    return () => {
      selection.on('.zoom', null)
      zoomRef.current = null
      selectionRef.current = null
    }
  }, [focusId])

  useEffect(() => {
    const canvas = canvasRef.current
    const container = containerRef.current
    if (!canvas || !container) return
    const pixelRatio = window.devicePixelRatio || 1
    const width = container.clientWidth
    const height = container.clientHeight || 680
    canvas.width = width * pixelRatio
    canvas.height = height * pixelRatio
    canvas.style.width = `${width}px`
    canvas.style.height = `${height}px`
    const context = canvas.getContext('2d')
    if (!context) return
    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0)
    context.clearRect(0, 0, width, height)
    context.save()
    context.translate(transform.x, transform.y)
    context.scale(transform.k, transform.k)

    const visible = table.nodes.filter((node) => node.width * transform.k >= 1 && (node.bottom - node.top) * transform.k >= 1)

    for (const node of visible) {
      const screenWidth = node.width * transform.k
      const screenHeight = (node.bottom - node.top) * transform.k
      context.globalAlpha = 1
      context.fillStyle = fillFor(node)
      context.fillRect(node.x - node.width / 2, node.top, node.width, node.bottom - node.top)
      if (screenWidth >= 8 && screenHeight >= 8) {
        context.strokeStyle = strokeFor(node)
        context.lineWidth = (node.state === 'shared_reference' ? 1.8 : 1) / transform.k
        context.strokeRect(node.x - node.width / 2, node.top, node.width, node.bottom - node.top)
      }
    }

    for (const node of visible.filter((item) => {
      if (!item.hasParents || item.side === 0 || item.width * transform.k < 14 || (item.bottom - item.top) * transform.k < 14) return false
      return !visible.some((candidate) => candidate.depth === item.depth + 1 && candidate.side === item.side && candidate.top >= item.top && candidate.bottom <= item.bottom)
    })) {
      const edge = node.x + node.side * node.width / 2
      const reach = 30 / transform.k
      const halfHeight = Math.min((node.bottom - node.top) * 0.38, 12 / transform.k)
      context.beginPath()
      context.moveTo(edge, node.y - halfHeight)
      context.lineTo(edge + node.side * reach, node.y)
      context.lineTo(edge, node.y + halfHeight)
      context.closePath()
      context.fillStyle = '#496f8133'
      context.fill()
      context.strokeStyle = '#496f81'
      context.lineWidth = 1 / transform.k
      context.setLineDash([3 / transform.k, 3 / transform.k])
      context.stroke()
      context.setLineDash([])
    }

    for (const node of visible.filter((item) => highlightedIds.has(item.canonicalId) || item.canonicalId === hovered?.canonicalId)) {
      context.strokeStyle = node.canonicalId === hovered?.canonicalId ? '#e0a23d' : '#7b43a1'
      context.lineWidth = 3 / transform.k
      context.strokeRect(node.x - node.width / 2, node.top, node.width, node.bottom - node.top)
    }

    context.restore()

    for (const node of visible.filter((item) => item.state === 'shared_reference')) {
      const left = transform.x + (node.x - node.width / 2) * transform.k
      const top = transform.y + node.top * transform.k
      const screenWidth = node.width * transform.k
      const screenHeight = (node.bottom - node.top) * transform.k
      context.save()
      context.setLineDash([5, 4])
      context.strokeStyle = '#cf973c'
      context.lineWidth = 1.8
      context.strokeRect(left, top, screenWidth, screenHeight)
      context.restore()
    }

    context.fillStyle = '#f8fbfce8'
    context.fillRect(0, 0, width, 24)
    context.strokeStyle = '#d6e2e7'
    context.lineWidth = 1
    context.beginPath()
    context.moveTo(0, 23.5)
    context.lineTo(width, 23.5)
    context.stroke()
    const rulerColumns = [...new Map(table.nodes.map((node) => [`${node.depth}:${node.side}`, node])).values()]
      .map((node) => ({ depth: node.depth, x: transform.x + node.x * transform.k }))
      .filter((column) => column.x >= -24 && column.x <= width + 24)
      .sort((left, right) => left.x - right.x)
    let lastRulerX = -Infinity
    for (const column of rulerColumns) {
      if (column.x - lastRulerX < 30) continue
      context.fillStyle = '#496f81'
      context.font = '700 10px Inter, sans-serif'
      context.textAlign = 'center'
      context.textBaseline = 'middle'
      context.fillText(String(column.depth), column.x, 12)
      lastRulerX = column.x
    }

    for (const node of visible) {
      const left = transform.x + (node.x - node.width / 2) * transform.k
      const top = transform.y + node.top * transform.k
      const screenWidth = node.width * transform.k
      const screenHeight = (node.bottom - node.top) * transform.k
      const label = node.dog.name ?? 'Unknown dog'
      const fontPixels = Math.min(16, screenHeight * 0.58, (screenWidth - 8) / Math.max(label.length * 0.56, 1))
      if (fontPixels < 2) continue
      context.save()
      context.beginPath()
      context.rect(left, top, screenWidth, screenHeight)
      context.clip()
      context.fillStyle = '#173a52'
      context.font = `600 ${fontPixels}px Inter, sans-serif`
      context.textAlign = 'center'
      context.textBaseline = 'middle'
      context.fillText(label, left + screenWidth / 2, top + screenHeight / 2)
      context.restore()
    }
  }, [highlightedIds, hovered, table, transform])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const onPointerMove = (event: PointerEvent) => setHovered(findNodeAt(event.clientX, event.clientY))
    const onPointerLeave = () => setHovered(null)
    canvas.addEventListener('pointermove', onPointerMove)
    canvas.addEventListener('pointerleave', onPointerLeave)
    return () => {
      canvas.removeEventListener('pointermove', onPointerMove)
      canvas.removeEventListener('pointerleave', onPointerLeave)
    }
  }, [table, transform])

  return (
    <section className="graph-panel canvas-pedigree">
      <div className="graph-header">
        <span>Left: paternal · Right: maternal</span>
        <button onClick={fitTable}>Fit table</button>
      </div>
      <div className="graph-legend">
        <span><i className="legend-swatch male" /> Male</span>
        <span><i className="legend-swatch female" /> Female</span>
        <span><i className="legend-swatch akc" /> AKC-primary</span>
        <span><i className="legend-swatch dobequest" /> DobeQuest-primary</span>
        <span><i className="legend-swatch shared" /> Shared lineage shown elsewhere</span>
        <span>Faded wedge: ancestry continues outward</span>
      </div>
      <div className="graph-canvas" ref={containerRef}>
        <canvas ref={canvasRef} onClick={(event) => { const node = findNodeAt(event.clientX, event.clientY); if (node) onSelect(node.canonicalId) }} />
        {hovered && (
          <div className="graph-tooltip">
            <strong>{displayName(hovered.dog)}</strong>
            <span>Generation {hovered.depth}</span>
            <span>Appears through {hovered.paths} ancestry path{hovered.paths === 1 ? '' : 's'}</span>
            <span>{hovered.state === 'shared_reference' ? 'Shared lineage; click to focus its canonical dog' : hovered.state === 'depth_limited' ? 'Known ancestry exists beyond generation 100' : hovered.dog.registration_number ?? hovered.dog.primary_source}</span>
          </div>
        )}
      </div>
    </section>
  )
}

function offsetForDepth(depth: number, nodes: TableNode[]) {
  return Math.max(...nodes.filter((node) => node.depth <= depth).map((node) => Math.abs(node.x) + node.width / 2), rootWidth / 2)
}
