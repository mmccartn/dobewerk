import json
from pathlib import Path

VOL = "sim_american-kennel-club-stud-book-register_1952-12-01_69_7"

def make_dog(name, sex, reg, wh, color, sire_str, dam_str, owner, breeder):
    def split_parent(p):
        p = p.strip()
        if p.endswith("*"):
            return p, None
        tokens = p.split()
        for i, tok in enumerate(tokens):
            if (tok.startswith("W") or tok.startswith("A")) and len(tok) >= 4 and tok[1:].isdigit():
                return " ".join(tokens[:i]), tok
        return p, None

    sire_name, sire_reg = split_parent(sire_str)
    dam_name, dam_reg = split_parent(dam_str)
    return {
        "volume_identifier": VOL,
        "registration_number": reg,
        "registered_name": name,
        "sex": sex,
        "whelped_date": wh,
        "color": color,
        "sire_name": sire_name,
        "sire_registration_number": sire_reg,
        "dam_name": dam_name,
        "dam_registration_number": dam_reg,
        "owner": owner,
        "breeder": breeder,
    }

raw_dogs = [
    # Leaf 76 (12 dogs)
    ("Adelaide v Toddchen (Germany)", "B", "W347853", "5-19-50", "Blk & rd", "Alf v Koppernsee*", "Adda v d Bahrenklause*", "Jacqueline D. S. Bridwell", "Raymond Healy"),
    ("Ahella of Bucks", "B", "W353537", "6-24-50", "Blk & rust", "Ch. Jet v d Ravensburg W43665", "Clarestan Alanda W102291", "Wilmer D. Fretz", "Michael J. Landers"),
    ("Anthem v Ryrod", "B", "W337427", "8-11-49", "Blk & tan", "Ch. Chance Run's Town Talk W55734", "Graihof Morning Star W83773 C.D.", "Harrison J. Hemmerling", "Graham H. & Jeanne M. Luhn"),
    ("Baroness von Morgengrau", "B", "W335996", "8-10-50", "Blk & br", "Jay Dee A979605", "Lona Arnorom A963871", "Gwen V. Tiedeman", "Isabel Marks"),
    ("Baroness van Arnheim", "B", "W342282", "3-15-47", "Blk & tan", "Skeet v Luxembourg W46782", "Bee v Luxembourg W46783", "John H. Webb", "Owner"),
    ("Basko v Schloss Wiblingen (Ger.)", "D", "W341338", "1-11-47", "Blk & br", "Nero v Glashof*", "Alma v d Neckarspitz*", "William Blaine", "Richard Kuhn"),
    ("Beauty v Beavji", "B", "W325159", "7-18-49", "Blk & tan", "Jocko v Berger W23803", "Lady Bevaji W172222", "L. Talbot Sidelinker", "Owner"),
    ("Black Knights' Gretchen", "B", "W345025", "10-12-50", "Blk & rust", "Trail'Em Atlas W54659", "Gretchen of Ludwig Acres A995733", "Mrs. Alice M. Fowler", "Margaret L. Crosset"),
    ("Bonnie of Connell", "B", "W326607", "2-20-51", "Br & rust", "Augustus v Weborg A964721", "Teana v Staufeneck W141601", "Robert Connell", "Eugene Poschinger"),
    ("Bonnie Dale of Dobe Hacienda", "B", "W342680", "12-12-49", "Blk & rust", "Blakie v Howelis W170236", "Athena of Iffland Farm W51666", "Kenneth L. Yereance", "Michael Phillips"),
    ("Brenda Von Carlo", "B", "W326108", "1-12-51", "Blk & tan", "Ch. Brown's Archer W67794", "Jetney v Carlo W122190", "Joseph J. Naryka", "Leo J. Hartnett"),
    ("Brownie v Bevaji", "B", "W325160", "7-18-49", "Br & tan", "Jocko v Berger W23803", "Lady Bevaji W172222", "L. Talbot Sidelinker", "Owner"),

    # Leaf 77 (61 dogs)
    ("Candita", "B", "W340277", "6-7-48", "Blk & tan", "Gayway Don A898450", "Queenie of Paaele W42175", "Oliver H. Pang", "Alfred F. Kong"),
    ("Cast of Showtime", "D", "W337974", "9-24-50", "Blk & tan", "Big Boy of Schon W141497", "Queenie Baroness v Furstenberg W146200", "Raymond T. Engel", "Emil Klutsch"),
    ("Chica Belle", "B", "W342157", "5-7-51", "Blk & rust", "El Chico W193378", "Bonnie Belle W121391", "G. A. Elliff", "Mrs. E. F. Bryan"),
    ("Chocolate Cookie of Reklaw", "B", "W343976", "12-15-50", "Br & rd", "Edel of Reklaw W247338", "Therese of Reklaw W113206", "Mr. & Mrs. R. D. Walker", "Owner"),
    ("Count Setab", "D", "W335246", "12-31-49", "Rd & tan", "Duke Derigburg W166398", "Damayn Star W166399", "C. F. & M. A. Bates", "Marion A. Reading"),
    ("Cyrill v Karlsfeld (Ger.)", "D", "W336992", "5-5-48", "Blk & rust", "Astor v Grafenwink*", "Wanda v d Wertachbrucke*", "Mrs. Edward W. Kubin", "Josef Stampfl"),
    ("Damasyn the Solitaire", "D", "W338040", "3-3-51", "Rd & tan", "Ch. Dictator v Glenhugel A531251", "Ch. Damasyn the Sultry Sister W31045", "Mrs. Bob Adamson", "Owner"),
    ("Doby of Craigdell", "B", "W328283", "10-5-50", "Blk & rust", "Astor v Oberon W215862", "Countess Theda v Wenzel W101961", "Porter Keith", "Ira D. Woodall"),
    ("Ellie v d Elbe", "B", "W344872", "7-30-48", "Blk & tan", "Ch. Emperor of Marienland A512391", "Ch. Belydia v d Elbe A979556", "Adolf E. Bauhof", "Hans Schmidt"),
    ("Frau von Blitz", "B", "W328279", "4-22-50", "Blk & tan", "Damasyn the Marquis W175901", "Freda v Loretz A878240", "D. Bruce Finley", "Scott B. Robinett"),
    ("Freida d Hoffman", "B", "W336556", "2-25-47", "Blk & rust", "Sieg of Huffmanheim A656357", "Honora v Loretz A995538", "D. R. Bolan", "Gladys Thornburg"),
    ("Gretchen's Leilani", "B", "W337363", "5-13-51", "Rd & tan", "High Boy of Tee W135839", "Gretchen v Jones W60520", "B. T. & S. R. Jones", "Owner"),
    ("Hatton's Deddie", "B", "W346390", "10-12-50", "Blk & rust", "Trail 'em Atlas W54659", "Gretchen of Ludwig Acres A995733", "Mr. & Mrs. D. Hatton", "Margaret L. Crosset"),
    ("Hienie von Heidelberg", "D", "W328795", "1-22-51", "Rd & rust", "Benno v Sand Platz W245875", "Imp of Satin W96622", "Ralph E. Powell", "Mona G. Schmidt"),
    ("Iris von Dillonhof", "B", "W339555", "1-25-51", "Blk & rust", "Ras von Munchausen W234868", "Cheetah von Munchausen W234947", "T. D. Dillon", "James J. McDade"),
    ("Karl of Wynlea", "D", "W326646", "1-6-50", "Blk & tan", "Ch. Ximenes of Elblac A988264 C.D.", "Princess of Solitude W25335", "Arthur Andrews", "Ada Andrews"),
    ("Kim Von Hoffman", "D", "W326613", "12-7-50", "Blk & tan", "Ch. Jet v d Ravensburg W43665", "Carwyn's Forever Amber W109382", "Mrs. Robert I. Koch", "Robert S. Hoffman"),
    ("King of Adonis", "D", "W325474", "1-19-51", "Blk & br", "Duke the Onyx Adonis W129522", "Lady Gail Heimwehr W192472", "Josephine A. Carpino", "Anna C. Keith"),
    ("King of Ai-Ann-Ai", "D", "W342123", "8-4-50", "Blk & tan", "Duke of Kenilworth W194923", "Pride W82681", "Phyllis A. Stravato", "Albert G. Aaronson"),
    ("Konigin of Hilltop House", "B", "W342853", "1-1-50", "Rd & rust", "Red Kelly of Doberman Downs W5816", "Tina v Speker W36103", "Mrs. Anna C. Guggenheim", "Paul Cranford"),
    ("Kuno v Bergerhof", "D", "W346389", "6-1-51", "Blk & rust", "Rico v Hagen W94539", "Lady v Bergerhof W317880", "Alice Berger", "Owner"),
    ("Lady de-Vere of Hy-Way", "B", "W329349", "1-22-49", "Blk & tan", "Daphne's Amos A858756", "Delshire Cinder A921030", "Frank H. & Olga M. Stevens", "George C. Simpson"),
    ("Lady Heidi von Sigmund", "B", "W353526", "3-18-50", "Rd & rust", "Lanze v Kurage W37014", "Gypsy's Trolline of Alrajo W127728", "Elizabeth R. Sigmund", "Roberta & Donna Good"),
    ("Lady von Karlarry", "B", "W335798", "12-14-50", "Blk & rust", "Derk v Burnsheim A336434", "Dutchess of Six Gables W162048", "Carl E. Bowen", "Clayton W. Trimble"),
    ("Lady Lorelei", "B", "W323964", "2-20-51", "Br & rust", "Augustus v Weborg A964721", "Teana v Staufeneck W141601", "Bruno Ferri", "Eugene Poschinger"),
    ("Lady Love v Meareshein", "B", "W334022", "12-22-50", "Blk & tan", "Count v Heinrich Luxwaften A522686", "Maida v Tydra W32205", "Larry J. Meares", "Owner"),
    ("Lady of Maedchen v d Jessen", "B", "W332186", "8-17-50", "Blk & tan", "Jo Jo v Guiles W35889", "Maedchan v d Norbelhof W83947", "G. M. & H. H. Pulleyn", "Alice Spina"),
    ("Lady Neubrucken", "B", "W328184", "6-15-50", "Blk & rust", "Pene Prince v Karlsruhe W83082", "Fritzi v d Neubrucken W48414", "W. C. Rhodes", "James S. Boyd"),
    ("Lady of Thendara II", "B", "W329313", "12-24-50", "Blk & tan", "Blitzen III W5695", "Lady of Thendara W32224", "Herbert M. Tillman", "Edna M. Adams"),
    ("Lady Victoria III", "B", "W339493", "6-23-50", "Blk & rust", "Rancho Dobe's Faro W97488", "Tina v Roxanna Kaydean W204379", "Dr. Loyd E. Neely", "Ellen L. Price"),
    ("Leibchen's Beno of Fox Meadow", "D", "W352577", "9-21-44", "Blk & rust", "Fritz v Waltberg A747825", "Liebchen A353076 C.D.X.", "Joseph W. Miley", "Ethel Schulmann"),
    ("Lenzen Safety Latch", "B", "W339494", "5-29-50", "Blk & tan", "Lenzen Gentle Giant W173282", "Sonel v Wagner W104869", "Irene Helstrom", "Owner"),
    ("Leta v Hennefent", "B", "W340548", "5-28-50", "Blk & tan", "Klephti of Jerry Run W2784", "Lena of Mergrahof W181578", "K. O. Hennefent", "Otto J. Pozgay"),
    ("Linwood of Egleanburg", "D", "W333904", "11-7-50", "Rust", "Rudolph of Egleanburg A567792", "Beatrice of Marlynheim A906438", "James E. Stephens", "Dr. & Mrs. J. C. Thomas"),
    ("Madamoiselle Martin", "B", "W342232", "2-1-47", "Blk & tan", "Ch. Hallwyre Home-Grown Bill A787491", "Hexie v Mack Clarehof A980284", "Walter D. Martin, Jr.", "Mrs. Hinton Bradbury"),
    ("Many Oaks Hella v Melcor", "B", "W334352", "6-24-50", "Blk & rust", "Hallwyre Heinrich W83332", "Hallwyre Heidy W151024", "Mrs. Sam S. Haynes", "Dr. D. M. Rumph"),
    ("Maria von Beittnerheim (Can.)", "B", "W363130", "3-18-48", "Blk & tan", "Quo Shmerk von Marienland*", "Arista of Thirlestane*", "Daniel Avrunin", "Martin Birkner"),
    ("Mel-Mo's Farla", "B", "W322175", "4-6-51", "Blk & rust", "Ch. Brown's Achilles W67793", "Too-Me-No's Brown's Melodious W185325", "P. & W. O. Weindell", "Nancy Shy"),
    ("Mirzda von Hertze", "B", "W341699", "4-27-51", "Blk & tan", "Charlemagne von Rubin W79258", "Mirza von Bloemfontein W84619", "Leon W. Zall", "Albert F. Ryckaert"),
    ("Pickering's Pal", "B", "W328284", "7-25-47", "Blk & tan", "Pickering's Whirlwind A712661", "Pickering's Punch W58430", "Spurgeon Pickering", "Owner"),
    ("Princess Pat of Valley View", "B", "W335862", "4-13-49", "Blk & rust", "Town and Country Gentleman A618430", "Duchess v Rideneur A759496", "Patricia A. Newcomer", "Harold B. Hall"),
    ("Princess Heimwehr", "B", "W324087", "1-27-51", "Blk & br", "Duke The Onyx Adonis W129522", "Gretel v Heimwehr W127926", "Frances N. Pedato", "Anna C. Keith"),
    ("Princess von Ross", "B", "W344869", "5-4-50", "Blk & tan", "King v Haufler W53505", "Duchess v Fowler W89325", "Raymond Russell", "George R. Parsons"),
    ("Princess von Verde", "B", "W351256", "1-29-51", "Blk", "Ch. Ivan v Trail W150628", "Princess of Gladstone W186699", "Lois A. Cook", "John T. Gladstone"),
    ("Queen Duchess II", "B", "W328073", "10-8-46", "Blk & tan", "Pincher W13142", "Duchess Lady W14872", "Alexander Radomski", "Margaret Wetjen"),
    ("Rajah of Oakmeadow", "D", "W329325", "6-11-50", "Blk & rust", "Royal Ranger W24384", "Heidi of Sharon A904342", "John E. Schweizer", "John B. Absmeier"),
    ("Rauchsbaum's First Choice", "B", "W335209", "12-9-50", "Rd & rust", "Rougue of Valhalla W130924", "Fylsan v Rauchsbaum W170205", "Clarence L. Beam", "Owner"),
    ("Rebel's Queen", "B", "W333891", "11-2-50", "Blk & br", "Andlauer's Buddie A808345", "Lady Beth W45090", "Arthur M. Cochran", "Kenneth J. Hall"),
    ("Rex of Troll-Val (Canada)", "D", "W336076", "7-14-48", "Blk & tan", "Baron of Troll-On*", "Roxy of Troll-On*", "Richard A. Wonders", "Clifford Scott"),
    ("Rick", "D", "W335296", "7-3-50", "Blk & rd", "Baron Von Rick W205111", "Lady Fleeta of Rusheim W129919", "Daniel W. Mason", "James E. Salotto"),
    ("Rogue of Pontchartrain", "D", "W326665", "7-15-50", "Blk & rd", "Ch. Cy of Dobe-Haven A666745", "Joana of Pontchartrain W5653", "Dorothy Lewis", "Glenn S. Staines"),
    ("Rufus Linconnu", "D", "W322716", "4-17-50", "Rd & rust", "Ch. Curt of Graceheim A678340", "Alrajos Margo W50670", "Ruth Baker", "Ray D. Hopkins"),
    ("Saksi of Red Mill", "B", "W348524", "10-29-48", "Br & rd", "Damasyn Peter MacDuff W64439", "Gretchel of Huntsover W23975", "Robert J. Sharp", "Kay R. Dunning"),
    ("Shuey's Freida Gardian", "B", "W334159", "1-20-51", "Blk & rust", "Mac of Keeline W232582", "Rocky v Hand W314423", "Mrs. J. E. & B. E. Shuey", "Mildred D. McElroy"),
    ("Sparky v Staufeneck II", "D", "W340280", "12-21-50", "Br & rust", "Sparky v Staufeneck W167572", "Tanna v Staufeneck W167705", "Eugene W. Pasch", "Owner"),
    ("Susie of Pont", "B", "W329342", "8-11-50", "Blk & rust", "Ch. Komet of Pontchartrain W5042", "Andante of Pontchartrain W90566", "Raymond B. Pratt", "Glenn S. Staines"),
    ("Toar", "D", "W333359", "5-6-51", "Rd & rust", "Cody W216347", "Posalex v Ur-Adel W215482", "William Harold King", "Arthur T. Maloney"),
    ("Trail Em Top Secret", "D", "W327961", "7-15-51", "Blk & rust rd", "Trail Em Atlas W54659", "Beth of By-A-Brook W38058", "Ralph T. Miller", "William J. Tresidder"),
    ("Tyrand v Blitzen", "D", "W329125", "4-25-49", "Br & tan", "Blitz v Wildenstein A475925", "Victoria II A637330", "Ina Rother", "Hans Vinz"),
    ("Wittland's Donna", "B", "W349189", "10-26-50", "Blk & tan", "Ch. Wittland's Black King A955389", "Iris W101752", "Leo Wittenberg", "Owner"),
    ("Zorro", "B", "W342944", "11-8-48", "Blk & tan", "Prinz Rote of Rensa A808488", "Judy von Heimdall A991782", "Charles S. Soiset", "Mrs. W. F. Lawson"),
]

dogs = [make_dog(*row) for row in raw_dogs]

if __name__ == "__main__":
    out_path = Path(__file__).resolve().parent / "data" / "verified_1952_12.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(dogs, f, indent=2, ensure_ascii=False)
    print(f"Verified {len(dogs)} dogs written to {out_path}")
