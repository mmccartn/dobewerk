import json
from pathlib import Path

VOL = "sim_american-kennel-club-stud-book-register_1953-03_70_1"

def make_dog(name, sex, reg, wh, color, sire_str, dam_str, owner, breeder):
    def split_parent(p):
        p = p.strip()
        if p.endswith("*"):
            return p, None
        tokens = p.split()
        for i, tok in enumerate(tokens):
            if (tok.startswith("W") or tok.startswith("A")) and len(tok) >= 4 and tok[1:].isdigit():
                return " ".join(tokens[:i]), tok
        return p, None

    sire_name, sire_reg = split_parent(sire_str)
    dam_name, dam_reg = split_parent(dam_str)
    return {
        "volume_identifier": VOL,
        "registration_number": reg,
        "registered_name": name,
        "sex": sex,
        "whelped_date": wh,
        "color": color,
        "sire_name": sire_name,
        "sire_registration_number": sire_reg,
        "dam_name": dam_name,
        "dam_registration_number": dam_reg,
        "owner": owner,
        "breeder": breeder,
    }

raw_dogs = [
    ("Alexia von Danzig", "B", "W343767", "1-13-49", "Rd & rust", "Arno of von Kaufhold W78830", "Miss Ginger v Rogers W57246", "Joseph J. Picconi", "Verna A. Rogers"),
    ("Asko v d Dreilanderecke (Ger.)", "D", "W382503", "4-23-51", "Rd & br", "Erko v Willersee*", "Brunny v d Taubermuhle*", "Dr. & Mrs. W. O. Ball", "Stefan Bummer"),
    ("Bakisae's Rusty", "B", "W355122", "5-10-49", "Blk & tan", "Darien Dillock W1172", "Joe's Jinx W40910", "Andy Bakisae", "Jos Sapienza, Jr."),
    ("Baron von Heimlich", "D", "W353980", "1-4-51", "Blk & tan", "Barron of Ellindo Norr W191987", "Fraulein II W107840", "Elvira Seals", "James M. Seals"),
    ("Baron Hermann of Fraser", "D", "W374197", "1-16-48", "Blk & br", "Roland of Ponchartrain A815786", "Queenie Dagg W66822", "Hermann A. Jacob", "David M. Dagg"),
    ("Buck II", "D", "W327966", "6-12-51", "Blk & rd", "Dorian of Moorpark W74480", "Rip Schon Dame W164855", "Lola Kay Amacher", "Carmen R. Griffin"),
    ("Captain Blitz", "D", "W371473", "11-10-49", "Blk & tan", "Derek v Dunn W3809", "Chance Run's Blue Day W55731", "W. H. Nevins", "James Jackson"),
    ("Charge von Aleck", "D", "W348996", "9-23-50", "Blk & tan", "Ch. Assault v Aleck W42704 U.D.", "Lady Deborah II W187028", "August T. Wacker", "Walter L. Bales"),
    ("Cinderella's Jet v d Kammer", "D", "W377566", "11-14-51", "Blk & tan", "Baron v Germania W233304", "Liny Greibbturn W180664", "Mrs. H. von der Kammer-Brugger", "Lily M. Foregger"),
    ("Cisco v Brisk", "D", "W375092", "7-21-51", "Blk & rust", "Red Buck v Brisk W190210", "Peppy Sue v Aleck W229211", "Blanche G. Smith", "Harold R. Stern"),
    ("Contessa Valda Nolle", "B", "W337470", "8-28-51", "Blk & br", "Banquo II W219793", "Melissa v Weppener W121487", "Mrs. Lawrence J. Novero", "Arthur Gilman"),
    ("Cosima Bambi", "B", "W345579", "4-7-50", "Blk & rust", "Fidor v Eiffel W66867", "Duchess Bambi W159126", "John P. Burr", "Hortense Helen Teply"),
    ("Countess Maritza IV", "B", "W355824", "5-27-49", "Blk & rd", "Arno v Ain-Wal W52737", "Norbury Dutchess W105626", "L. L. & J. R. Metivier", "Frederick W. Norton"),
    ("Cyrano von Pillheim", "D", "W359950", "2-28-50", "Br & rust", "Ch. Apache v Eoghanviola W45757", "Annette v Myerheim W669", "L. Y. Dyrenforth, Jr.", "John P. Garber"),
    ("Del Prete's Shema", "B", "W349921", "7-1-50", "Blk & rust", "Ch. Asta's Ace A768781", "Kerrigan's Kiki W189091", "Vivian Nettie Delprete", "Matilda C. Kerrigan"),
    ("Doris v Bad Heidelberg (Ger.)", "B", "W377567", "1-4-47", "Blk & tan", "Nero v Glashof*", "Wera v Bad Heidelberg*", "Steve M. Heidelberg", "Lena Breithaupt"),
    ("El Baron de Sabado", "D", "W343223", "6-2-51", "Blk & tan", "Lance v Koenigsheim A865689", "La Negra de Rancho Chico W1990", "Allan J. Gilmore", "Owner"),
    ("Elliott's Sigfried v Gerdts", "D", "W358292", "6-24-51", "Blk & rust", "Runa's Blu Lucky of Tac-Mar W208191", "Runa's Red Logi of Tac-Mar W205799", "J. R. Elliott", "Runa McCool"),
    ("Escort's Cortette", "B", "W332957", "4-12-51", "Blk & rust", "Ch. Kilburn Escort A947073 C.D.", "Gayway Gretchen W79659", "Mary & Curtin Leser", "R. C. & H. S. Allen"),
    ("Frau Prissy Gal of Ka Mitch", "B", "W365358", "4-16-51", "Blk & rust", "Herr Mikel's Pete of Kamitch W294659", "Molly of Kamitch W294658", "Mrs. Elaine Perkins", "Mrs. Kathryn Mitchell"),
    ("Freida Paula v Starheim", "B", "W364686", "12-17-51", "Blk & tan", "Baron v Starheim W147147", "Queenin d von Stohlhein W260762", "Bird W. Porter", "Mrs. M. P. Dondanville"),
    ("Fresco's Obdenago v Palanka", "D", "W334750", "5-2-50", "Blk & tan", "Freya's Fresco v Palanka W177966", "Ferris Elf v Palanka A804840", "G. L. Rambo", "Miss Julie Roy"),
    ("Gretchen von Groton", "B", "W353493", "7-6-51", "Blk & tan", "Ch. Jet v d Ravensburg W43665", "Lady Margaret W160934", "Edgar W. Davis", "Richard J. Berry"),
    ("Hiekle's Dobie", "D", "W367477", "8-29-51", "Blk & rust", "Baron Fritz Berhugel A824084", "Cobra of Dobemar W149264", "Mrs. Bert Hickle, Jr.", "Hong Sing Pon"),
    ("Hilda v Weisenberger", "B", "W342655", "1-11-51", "Blk & rust", "Hallwyre Herr Meikel W85087", "Lady Patsy Sonoseego W137822", "Mrs. Rufus W. Black", "J. G. Young"),
    ("Imetros von Stoffregen", "D", "W370626", "11-7-50", "Blk & rust", "Ch. Acho v Gesellschaft A850715", "Halmarr's Happy Girl W44800", "Barbara M. Stoffregen", "Fred L. Stoffregen"),
    ("Jezebel v Cervanes", "B", "W342367", "8-8-51", "Blk & tan", "Major M W60194", "Cissi v Cervanes W156006", "Shirley R. Moore", "Roland E. Sivyer"),
    ("Labelle Bonnie Blue", "B", "W339670", "5-28-49", "Rd & rust", "Astor v d Bahrenklause*", "Peggy Bell Owen A814349", "Mrs. Gilbert Du Vernay", "Harold T. Owen"),
    ("Lady von der Byron II", "B", "W322501", "5-4-51", "Blk & tan", "Bruce's Byron von der Heide W136375", "Lady Zo W123678", "Henry Prchal", "Wm. E. Fager"),
    ("Lady Gretchen IX", "B", "W343385", "7-27-51", "Blk & tan", "Gehrig Eisenhower A958281", "Princess Gretel v Gallant A971853", "Ella Mae Ames", "James Dannelly"),
    ("Lew Kays Laren", "B", "W372076", "10-17-48", "Rd & rust", "Duke of Hedgecrest W14658", "Meyerene of Starkanhart W38048", "P. E. South", "Norbert L. Meyer"),
    ("Madame Amacher", "B", "W327965", "6-12-51", "Rust & rd", "Dorian of Moorpark W74480", "Rip Schon Dame W164855", "Mrs. Otto Amacher", "Carmen R. Griffin"),
    ("Major Swartz", "D", "W366219", "2-15-50", "Rd", "Ch. Ardexter v d Valtheim W38881", "Katrinka v Dresden W40701", "George F. Nasser", "Blanche L. Figley"),
    ("Merry Eric", "D", "W352350", "2-24-51", "Blk & br", "Baron Jan van Gelder A924094", "Merry Gretchen W230809", "John O. Merrill", "Owner"),
    ("Perriland's Gretal", "B", "W344870", "2-22-50", "Blk & rust", "Eric II v Palanka A674886", "Hillmont's Rocketti W68649", "Robert E. Perry", "Marie Ruth Palm"),
    ("Redfern's Quizzy", "B", "W375049", "12-16-51", "Blk & tan", "Bingo v Allstark W95567", "Redfern's U-Ella W110489", "Leroy A. Bachman", "Owner"),
    ("Rio von Munchausen", "D", "W321453", "2-24-51", "Blk & rust", "Thumper of Runicast A803447", "Spotlight v Bloomingburg W185982", "T. D. Dillon", "Owner"),
    ("Roxann von Horst", "B", "W339267", "4-3-51", "Blk & rust", "Ch. Doberman Down's Dendy's El Cid W153851", "Quassel of Craigdell W153315", "C. A. & V. L. King", "Charles Bell"),
    ("Rustic Thunderjet", "D", "W328320", "11-10-51", "Blk & tan", "Stormcrest's Aegis the Shield W154253", "Rustic Adagio W177292", "George F. Kiser", "Owner"),
    ("Sally v Gretchen v Mahler", "B", "W367286", "7-21-51", "Lvr & tan", "Rusty of Ward W173570", "Gretchen v Mahler A891922", "Thomas W. Wilkins", "Ben E. Sherman"),
    ("Schwartzen Donder", "D", "W366198", "9-30-48", "Blk & tan", "Bosun A729476", "Carlena's Flashing Star W58824", "Alfred A. Pate", "Peggy G. Pate"),
    ("Sophisticated Lady", "B", "W373845", "6-11-50", "Blk & tan", "Rags W65292", "Lady Vickie W2584", "Mrs. Sally Nevins", "Thomas M. Kennedy"),
    ("Soria's King Boy", "D", "W377195", "1-28-46", "Blk & tan", "Alfred the Great A722931", "Lady v Dinhoff A858140", "Felix P. Soria", "Martin A. Martinez"),
    ("Squire William", "D", "W375050", "12-16-51", "Blk & tan", "Bingo v Allstark W95567", "Redfern's U-Ella W110489", "Leroy A. Bachman", "Owner"),
    ("Trudy of Bevaji", "B", "W325163", "8-21-50", "Blk & tan", "Jocko v Berger W23803", "Lady Bevaji W172222", "Mary R. Malatesta", "L. Talbot Sidelinker"),
    ("Wright's Princess Reta", "B", "W361097", "6-2-50", "Blk & rust", "Prince Curt of Cruces A945485", "Quotation of Doberman Downs W15568", "H. A. Wright", "Cecil M. Elliott"),
    ("Zim Duke", "D", "W322971", "9-20-48", "Lvr", "Ch. Abud v Samills A598554", "Vicki of Springdale W48981", "Walter R. Zimmerman, Jr.", "Anita R. Hicken"),
]

dogs = [make_dog(*row) for row in raw_dogs]

if __name__ == "__main__":
    out_path = Path(__file__).resolve().parent / "data" / "verified_1953_03.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(dogs, f, indent=2, ensure_ascii=False)
    print(f"Verified {len(dogs)} dogs written to {out_path}")
