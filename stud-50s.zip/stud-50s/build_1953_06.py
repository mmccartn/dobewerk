import json
from pathlib import Path

VOL = "sim_american-kennel-club-stud-book-register_1953-06_70_2"

def make_dog(name, sex, reg, wh, color, sire_str, dam_str, owner, breeder):
    def split_parent(p):
        p = p.strip()
        if p.endswith("*"):
            return p, None
        tokens = p.split()
        for i, tok in enumerate(tokens):
            if (tok.startswith("W") or tok.startswith("A")) and len(tok) >= 4 and tok[1:].isdigit():
                return " ".join(tokens[:i]), tok
        return p, None

    sire_name, sire_reg = split_parent(sire_str)
    dam_name, dam_reg = split_parent(dam_str)
    return {
        "volume_identifier": VOL,
        "registration_number": reg,
        "registered_name": name,
        "sex": sex,
        "whelped_date": wh,
        "color": color,
        "sire_name": sire_name,
        "sire_registration_number": sire_reg,
        "dam_name": dam_name,
        "dam_registration_number": dam_reg,
        "owner": owner,
        "breeder": breeder,
    }

raw_dogs = [
    # Leaf 84 (16 dogs)
    ("Allure of Thunderrock", "B", "W399702", "8-12-48", "Blk & rd", "Anzac v Neubrucken A649703", "Arvidale's Dawn A885191", "Robert L. Williams", "Owner"),
    ("Anderhof's Polonaize", "B", "W328909", "10-29-51", "Blk & tan", "Ch. Rancho Dobe's Presto W57335", "Fresco's Electra v Palanka W253513", "R. Robertson & H. M. Andersen", "Henry M. Andersen"),
    ("Aufdemberg v Reemon", "D", "W355226", "12-10-51", "Blk & tan", "Rontylees Signet W196557", "Marienland's Echoing W133160", "Aufdemberg Kennels", "Mrs. Mary E. Riemann"),
    ("Baroness of Arrowview", "B", "W352373", "7-1-51", "Rd & rust", "Jon of Mar-Walk W265936", "Princess Maggie Dick W85237", "Frances M. Cascinai", "Virgil L. Martin"),
    ("Baroness Banwal of Reklaw", "B", "W324574", "9-28-51", "Blk & tan", "Ch. Sinbad of Reklaw A933805", "Duchess v Graf W13941", "Walter Banaszek", "George Burrow"),
    ("Beau Taurus von Eisenhower", "D", "W383575", "5-23-51", "Blk & rust", "Beau-Lo's Bart W151364", "Greta Marlene W242523", "Constance C. Eisenhower", "Mrs. Ellen E. De Lautre"),
    ("Blitz of Fred-N-Aud's", "D", "W384563", "12-31-50", "Blk & rust", "Marienland's Bodo v d Elbe A947505", "Doberman Downs' Chorus Girl W149969", "Audrey M. Bliss", "Owner"),
    ("Brin L Block", "D", "W396329", "3-15-50", "Br & tan", "Damasyn Sirocco W97654", "Damasyn Brown Taffeta W87639", "M. J. & D. L. Block", "Dr. Sidney Stern"),
    ("Buddy von Carlsen", "D", "W323396", "12-16-49", "Blk & rust", "Ch. Charlie Boy v d Rheinperle W28284", "Duchess-Lady W14872", "B. R. Motors & B. Rosen", "Eugene Steinhart"),
    ("Deuce von Orendorf", "D", "W383561", "1-4-50", "Blk & rust", "Dan Ridder v Scheppke W11962", "Gessner's Freda W78944", "Aaron E. Tribbett, Sr.", "Fred Scheppke"),
    ("Dictator v d Gruenwald", "D", "W376020", "7-28-51", "Blk & tan", "Ch. Landgraf v d Ansbornquelle W95710", "Princess Satan von Englesburg W227271", "J. M. & M. Cancro", "Dorothy M. Hyde"),
    ("Dobie's Lady Chi-Chi Askin", "B", "W332985", "5-4-51", "Blk & tan", "Eric v Boening W254557", "Blitz' Dobie W210069", "Louise & Elsie Askin", "Joseph A. Ragusin"),
    ("Duchess of Sun Valley", "B", "W364479", "8-5-51", "Rd & rust", "Duke of Leelanan A728194", "Dobeville's Kweenie W16875", "C. S. Johnson", "Ben C. Isgrig"),
    ("Duchess Wilhelmina II", "B", "W341862", "5-12-51", "Blk & tan", "Brown Beige and Beautiful W258618", "Countess Trollene of Gor-Anne W74420", "Mr. & Mrs. G. V. Underwood, Jr.", "Harold E. Krantz"),
    ("Dutchess XIII", "B", "W325301", "4-28-51", "Blk & tan", "Frederick v Maschoff W215946", "Judy v Rottenberg W210271", "Ezra V. Ray", "Marion R. Kinne"),
    ("Dutchess v Gruenwald", "B", "W371874", "1-16-51", "Blk & tan", "Corker of Pontchartrain W143388", "Hanchen W104867", "Fred Mathewson", "Howard L. Heiney"),

    # Leaf 85 (54 dogs)
    ("Dutchess of Memphis", "B", "W389864", "7-2-51", "Rd & rust", "Rhett v Kushner II W126810", "Babe II W108043", "L. P. Beaver, Sr.", "Charles R. Monroe"),
    ("Ebony Lassie", "B", "W373825", "5-21-49", "Blk & tan", "Blitzen III W5695", "Puggsie Davis W74447", "Mrs. L. Frank Arner", "Edna M. Adams"),
    ("El Dorado Copper", "D", "W351849", "10-24-51", "Rd & rust", "Ch. Victor of Driscollwood W61285", "El Dorado Renee W185365", "Mrs. Ben McCourt", "Owner"),
    ("El Dorado Joaquin", "D", "W351848", "11-27-50", "Blk & rust", "Illo of Jerry Run A876115", "El Dorado Dulce W115085", "Mrs. Ben McCourt", "Della L. Wright"),
    ("Fiumano Chief", "D", "W382399", "3-25-47", "Blk & rust", "Thumper of Runicast A803447", "Lady v Bergundy W72103", "Dominick Fiumano", "Thomas D. Dillon"),
    ("Fleet Maiden", "B", "W398066", "3-2-51", "Blk & rust", "Ch. Curt of Graceheim A678340", "Mischievous Maid W58705", "Marion L. Roberts", "Larry Hopkins"),
    ("Frau Reba von Griffin", "B", "W373888", "6-12-51", "Rust & rd", "Dorian of Moorpark W74480", "Rip Schon Dame W164855", "Mrs. Carmen R. Griffin", "Owner"),
    ("Frederica von Stoltzenvoss", "B", "W372991", "10-10-50", "Blk & tan", "Josef v Stolzenvoss A801999", "Eichel v Rupprechtheim A457109", "Arthur E. Mackinstry", "Elmer Wheeler"),
    ("Frieda Hellsgate of Elam", "B", "W329599", "7-13-50", "Blk & tan", "Skipper of Elam W71040", "Peggy v Hellsgate A995429", "John G. Cranford", "Bartlett Q. Holt"),
    ("Gatha von Collinshoff", "D", "W331694", "11-9-51", "Blk & rust", "Ch. Duke v d Ravensburg III W127973", "Gretl v Reverdy W136942", "R. L. & F. B. Williamson", "V. H. Urey & C. R. Collins"),
    ("Greta of Hillworth", "B", "W392778", "6-2-51", "Blk & rust", "Herr Miekel's Pete of Kamitch W294659", "Hallwyre Heidy W151024", "Mrs. Clyde Hill", "Dr. D. M. Rumph"),
    ("Gretta v Neckert", "B", "W370803", "6-30-51", "Blk & rust", "Prince v Neckert W65140", "Gretta v Phluger A850903", "Kenneth W. Voreis", "Owner"),
    ("Gustav von Birchenhof", "D", "W380390", "8-25-49", "Blk & tan", "Smokey v Swarzwaldperle W7494", "Mona v Brunnenkalte A611217", "Kenneth O. Caldwell", "R. Harvey Caldwell"),
    ("Jady v Chicaro", "B", "W349318", "9-13-51", "Blk & rust", "Rommel v Boggs Hoff A899998", "Judy v Samills W74687", "Dick Bell", "Wesvern I. Neff"),
    ("Jasper of Hughes", "D", "W355681", "11-3-51", "Blk & tan", "Boy VI W160193", "Duches of Washington W203005", "Runetta Hughes", "Gabriel Washington"),
    ("Joseph v Trail", "D", "W368095", "10-25-51", "Rd & tan", "Darko v Lewis W112060", "Lady v Ulmer W300274", "Jim Alspach", "Don E. Lewis"),
    ("Karols King Kim", "D", "W340507", "4-22-47", "Blk & tan", "Doc of Gertrude W30780", "Anna Victorious W5357", "Albert S. Lineberry", "Mabel D. White"),
    ("King of Morris Avenue", "D", "W381321", "9-26-51", "Blk & tan", "Rex of River Terrace W28969", "Star Baby of Von Kay W21575", "John Fischer", "Edmund T. Vanderbeck"),
    ("Kurt von Golkin", "D", "W348656", "4-5-52", "Blk & rust", "Golkin's Byng von der Heide W136374", "Roeslein Rot v d Heide II W274596", "Leonard E. Cooper", "William A. Weinberg"),
    ("Kushner's Gretchen", "B", "W396925", "6-7-51", "Blk & rust", "Rhett v Kushner II W126810", "Rhodes' Penalita W83075", "P. Lee & J. Jones", "Charlie T. Rhodes"),
    ("Laddie v Neuenahr", "D", "W381569", "1-29-50", "Blk & tan", "Baron v Kent W70916", "Lady Janet v Neuenahr A921523", "William E. Arnold", "Peter Joseph Rodriquez"),
    ("Lady Linda Simbauer", "B", "W385461", "5-17-48", "Blk & tan", "D's Rusty Lad W936", "Fay v Shonfeld W12799", "Henry L. Smith", "Hermann Ullmann"),
    ("Lady Tao of Gor-Anne", "B", "W370225", "1-6-47", "Rd & tan", "Peck A595164", "Countess Trollene of Hawke A956047", "Guy Feighner", "Earle G. Hawke"),
    ("Lady of Toska", "B", "W392400", "5-1-50", "Blk & rust", "Kurt v Blenzheim W41355", "Toska v Olandol II A962410", "Mrs. Thelma Jenull", "Edward D. McCall"),
    ("Lenzie's Cindy", "B", "W366213", "4-15-50", "Blk & tan", "El Dorado's Redi Romeo W138150", "Lady of Sunlan W20638", "Ernesteen Lenzie", "Fred Farley"),
    ("Lisa von Dahl", "B", "W361096", "6-17-50", "Br", "Charlemagne v Rubin W79258", "Freda v Springfontein W160818", "William F. Mack", "Albert F. Ryckaert"),
    ("Llissa of Dorjon", "B", "W375261", "8-16-51", "Blk & rust", "Representative of Dobe Haven A830270", "Baroness Bonnie Tatjana W269617", "Mrs. Doris E. Tapscott", "Mrs. Andrew B. Knudsen"),
    ("Madamoiselle Coquette", "B", "W355654", "7-9-51", "Blk & rust", "Adobe of Gracewood W139978", "Baile's Nono Miss Nikki W184792", "Mrs. Alva B. Bailes", "Owner"),
    ("Maschoff II", "D", "W325326", "12-5-50", "Blk & tan", "Frederick v Maschoff W215946", "Toska-T W127305", "Ezra V. Ray", "Mrs. Joe W. Sanders"),
    ("Miss Darla of Santa Lorraine", "B", "W355123", "6-6-49", "Blk & tan", "Fritz v d Snicklefritz W103811", "Blynken v Reck A886012", "Stanley W. Henderson", "D. R. & K. T. Britney"),
    ("Molly von Marjoe", "B", "W374274", "1-20-50", "Blk & rust", "Ian of Linfield W42487", "Beauty VII W10872", "J. M. & M. L. George, Jr.", "Charles E. Kern"),
    ("Patches of Highland", "B", "W365361", "4-3-51", "Blk & rust", "Ch. Doberman Down's Dendy's El Cid W153851", "Quassel of Craigdell W153315", "Walter Gene Kelley", "Charles Bell"),
    ("Patsy v Fairhill", "B", "W353445", "8-19-51", "Blk & tan", "Beau v Halfritz W260055", "Noble Lady of Frankfort W151095", "Hans H. Lohmann", "Robert J. Serridge"),
    ("Princess Nina", "B", "W323053", "9-4-51", "Blk & tan", "Eric A842513", "Hilda of Strassburg W61561", "Mrs. Joseph Fararo", "William Schowlow"),
    ("Queen of Morris Avenue", "B", "W381320", "9-26-51", "Blk & tan", "Rex of River Terrace W28969", "Star Baby of von Kay W21575", "John Fischer", "Edmund T. Vanderbeck"),
    ("Rajah v Burni-Villa", "D", "W383542", "6-19-51", "Blk & rust", "Weichardt's Goldvein W118155", "Edelgard v Weichardt W42273", "Emil L. Zanutto", "Clarice Nickels"),
    ("Randolph Kapena Kia'i", "D", "W382387", "10-16-49", "Blk & br", "Panina of Puna Anana W11206", "Bibo Momi Gal W68665", "Perry B. McAnear", "Raymond E. Salsbery"),
    ("Red Lady of Von Zeman", "B", "W326316", "11-15-49", "Blk & rust", "Sir Prince of Von Zeman W160233", "Katy v Eugen W155827", "Tremayne Hornbeck", "C. D. Stinnett, Jr."),
    ("Red Max of Cypress", "D", "W335718", "1-29-51", "Rd", "Ch. Ivan v Trail W150628", "Princess of Gladstone W186699", "R. R. & J. Reagan", "John T. Gladstone"),
    ("Rita of Mar-Walk", "B", "W387447", "12-24-50", "Rd & rust", "Jon of Mar-Walk W265936", "Princess Maggie Dick W85237", "Virgil L. Martin", "Owner"),
    ("Satans Black Mystery", "B", "W356668", "8-7-51", "Blk & rust", "Ch. Torn's Regardless W159649", "Too-Me-No's Admiralette W200756", "Don Bennett", "Robert R. Zellermayer"),
    ("Schone Zauberin", "B", "W376733", "1-5-52", "Blk & tan", "Waldo Valdivostok W87907", "Vola Hesse W128580", "T. A. & B. Kitchen", "R. Q. Minze"),
    ("Schwarz Prinz", "D", "W346650", "10-14-50", "Blk & tan", "Rhoary Dhu W251780", "Selecta v Swartzkrop W105552", "William S. Webster", "Rita E. Bradburn"),
    ("Shone von Rogue", "D", "W379749", "5-9-51", "Blk & tan", "Ch. Valor v Treuenherzen W88004", "Shasta v Pitt W37945", "Mrs. Ernesteen Lenzie", "Frances Dunson"),
    ("Sir Topper", "D", "W351821", "6-7-51", "Blk & rust", "Rhett v Kushner II W126810", "Rhodes' Penalita W83075", "D. E. & P. W. Pruitt", "Charlie T. Rhodes"),
    ("Sir Whirlwind of Key West", "D", "W344934", "1-14-52", "Blk & tan", "Prince Charming III W290864", "Lady Babs II W90961", "Mr. & Mrs. John Gavilan", "Meredith F. Whillock"),
    ("Skeltons' Tiber T", "D", "W376147", "5-13-51", "Rd rust", "Smith's Dictator Tito W64611", "Too-Me-No's Sheaba W149534", "P. R. Skelton", "Weldon D. Morgan"),
    ("Sparkle Schwarz", "B", "W367523", "4-10-50", "Blk & rust", "Nimitz W78520", "Black Lady W174417", "D. I. Donathan", "C. C. Roberts"),
    ("Steb's Sergeant", "D", "W355655", "7-14-51", "Blk & tan", "Ch. Jet v d Ravensburg W43665", "Jane's Lady W218289", "Natalie G. Stebbins", "Eleanor H. Shopis"),
    ("Tomodachi Rocco", "D", "W374124", "10-30-51", "Blk & tan", "Ch. Rancho Dobe's Presto W57335", "Schatzi II W233671", "Dr. William B. Hancock", "Owner"),
    ("Topper of Soltau", "D", "W379823", "7-31-47", "Blk & rust", "Peter v Sharhof W28972", "Nanrich Greta A927623", "Werner F. Timm", "James C. Gallagher"),
    ("Troll's Blue", "D", "W399121", "12-14-50", "Bl & rust", "Damasyn The Khan W65138 C.D.X.", "Barbarina of Westrill W80856", "Troll Kennels", "Owner"),
    ("Ventura A Colonel", "D", "W330598", "9-8-50", "Blk & tan", "Ch. Rancho Dobe's Goth W17377 C.D.", "Ch. Ventura Gypsey W65625 C.D.X.", "Mr. & Mrs. W. I. Templeton", "Vera A. Templeton"),
    ("Venus of Woodlawn", "B", "W377990", "9-14-51", "Blk & tan", "Damasyn The Nightwind W20039", "Lady Gretchen of Arlington W182898", "F. A. & L. M. Taylor", "Ann H. Sharp"),
]

dogs = [make_dog(*row) for row in raw_dogs]

if __name__ == "__main__":
    out_path = Path(__file__).resolve().parent / "data" / "verified_1953_06.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(dogs, f, indent=2, ensure_ascii=False)
    print(f"Verified {len(dogs)} dogs written to {out_path}")
