import json
from pathlib import Path

VOL = "sim_american-kennel-club-stud-book-register_1953-09_70_3"

def make_dog(name, sex, reg, wh, color, sire_str, dam_str, owner, breeder):
    def split_parent(p):
        p = p.strip()
        if p.endswith("*"):
            return p, None
        tokens = p.split()
        for i, tok in enumerate(tokens):
            if (tok.startswith("W") or tok.startswith("A")) and len(tok) >= 4 and tok[1:].isdigit():
                return " ".join(tokens[:i]), tok
        return p, None

    sire_name, sire_reg = split_parent(sire_str)
    dam_name, dam_reg = split_parent(dam_str)
    return {
        "volume_identifier": VOL,
        "registration_number": reg,
        "registered_name": name,
        "sex": sex,
        "whelped_date": wh,
        "color": color,
        "sire_name": sire_name,
        "sire_registration_number": sire_reg,
        "dam_name": dam_name,
        "dam_registration_number": dam_reg,
        "owner": owner,
        "breeder": breeder,
    }

raw_dogs = [
    # Leaf 126 (12 dogs)
    ("Achina Di Milano (Italy)", "B", "W415652", "4-1-48", "Blk & tan", "Gabrys Del Cimbro*", "Astra II*", "Jack R. Meffert", "Achille Duranti"),
    ("Anita v Carl Hesterhof", "B", "W328281", "9-25-51", "Blk & rust", "Ch. Meadowmist Elegy W153473", "Ch. Damasyn the Tassi W84982", "Carl Hester", "Owner"),
    ("Arizona's Big Chief", "D", "W373838", "1-1-52", "Blk & tan", "Prince George Vladimir W209114", "Princess Dollinkurt W171766", "Mrs. Ethel Corriveau", "Delbert Douglas"),
    ("Arkansas Sis", "B", "W397750", "8-15-51", "Blk & rust", "Kirk v Heilbronner Hof A972408", "Connie Carla of Oxboro W261318", "Clifton R. Payne", "Don Pearson"),
    ("Arras v Flandreau (Germany)", "D", "W411360", "2-4-52", "Blk & rd", "Alex v Ostersee*", "Britta v Alt-Hendesse*", "W. H. & C. J. Tants", "I. V. Gulbranson"),
    ("Baroness Augusta von Paulus", "B", "W364111", "5-13-51", "Blk & tan", "Baron Fredric of Freistadt W66273", "Lady von Perry W254475", "Lydia Marsili", "John E. Semler"),
    ("Baron Omar v Gruenwald", "D", "W397486", "8-7-51", "Blk & tan", "Ch. Landgraf v d Ansbornquelle W95710", "Celia W191953", "Mrs. E. C. Porter", "Wm. J. Snyder"),
    ("Barry von Munchausen", "D", "W416432", "5-21-48", "Blk & rust", "Thumper of Runicast A803447 C.D.", "Arnette v Ochsnerhof W76410", "Herman M. Steneck", "Thomas D. Dillon"),
    ("Beowulf's Gaiety", "B", "W322532", "8-21-51", "Blk & tan", "Ch. Beowulf v d Ravensburg W138219", "Ch. Elblac's Electra W34855 C.D.X.", "Charles H. Paschall", "C. H. & A. P. Paschall"),
    ("Big Shot of Half Acre", "D", "W410918", "6-20-52", "Blk & rust", "Prinz Jaxen of Marlls Crest W158051", "Duchess Alys of Dallas W196868", "James R. Pfaff", "Owner"),
    ("Blaze v Heimwehr", "D", "W341989", "3-18-52", "Blk & rust", "Fritz XVII W18555", "Beauty v Heimwehr W223518", "Perry Kornhauser", "Anthony E. Letizia"),
    ("Blitz Elsa Hignett", "B", "W395258", "9-1-49", "Blk & tan", "Eric of Trenton W64676", "Cassandra Omie W131631", "Elsa M. C. Hignett", "Oma M. Atkinson"),

    # Leaf 127 (73 dogs)
    ("Bordo v d Angelburg of Westphalia (Switz.)", "D", "W373726", "2-25-50", "Blk & tan", "Casso v Kleinwaldheim*", "Hertha v d Brunoburg*", "Francis F. H. Fleitmann", "Bernh. Vienenkotter"),
    ("Boy Joy", "D", "W404690", "3-19-51", "Blk & rust", "Toby VI W188", "Ginger XI W118541", "Gregory Spano", "Mildred Wilbanks"),
    ("Buckshot v Rumpus", "D", "W408708", "4-1-50", "Blk & tan", "Baron Graf v Rumpus W4127", "Heidi von Rumpus W400496 9-53", "Jimmie Burr", "Mrs. J. C. Young & Mrs. Wm. S. Shields, Jr."),
    ("Candy III", "B", "W322912", "10-19-51", "Blk & tan", "Scout W272889", "Wheaties W139201", "Kathryn Walcott", "Anna Morgan"),
    ("Candy Maid", "B", "W399133", "4-8-52", "Blk & tan", "Danny Boy Orion W182148", "Candy II W8014", "Henry F. Roder", "Owner"),
    ("Carlena's Yogi", "D", "W408120", "5-9-48", "Rd & rust", "Bruiser A693744", "Carlena's Frau W17171", "Aurelia Endredy", "Mike & Mignon Smith"),
    ("Carol's Helmet Von Leifreid", "D", "W321681", "1-4-52", "Blk & tan", "Ch. Helmut v Klosterholz W85794", "Ch. Carol's Cissi v Weiss W106482", "Chester Pulaski", "E. L. Knickerbocker"),
    ("Charmer v d Dalsig", "B", "W403340", "4-26-49", "Blk & rust", "Hallwyre Hallmark W83335", "Mitchell's Dale A852486", "Gerald E. Barney", "George Joseph Porpeglia"),
    ("Charneil of Catton's Crest", "B", "W395768", "12-20-50", "Blk & tan", "Von Tizler W65815", "Duchess of Imperial W193198", "Neil L. Catton", "John R. Eisenbrey"),
    ("Clein's Queenie", "B", "W413226", "7-15-49", "Br & tan", "Cherokee King A544780", "Brown Lady W132373", "Edward Clein", "Robert W. Appel"),
    ("Cochran's Lady", "B", "W418892", "2-8-52", "Blk & tan", "Alaric v Gotterdammerung W217487", "Ebony v Stain W320317", "Wadsworth D. Cochran", "Stuart R. Rogell"),
    ("Cruiser von Teracoe", "D", "W390132", "1-31-52", "Blk & rust", "Ch. Baptiste's War Major A890906", "Baptiste's Berta W52266", "Nelson P. Thayer", "Owner"),
    ("Czarina Alexandra", "B", "W331545", "4-27-52", "Br & tan", "Shamrock's Baron Barth W180178", "Heidi von Strasbourg W331542 12-52", "Arthur Colletti", "Samuel Colletti"),
    ("Dainty Fraulein Corbett", "B", "W410570", "7-23-51", "Blk & rust", "Wilhelm of Schwalbach W157969", "Illisa v Luxon W175821", "Edward L. Cox", "Mr. & Mrs. W. K. Lashley"),
    ("De-Lisle's Chum", "B", "W397850", "5-16-48", "Blk & br", "Chief v Burse II W33364", "Ward's Chum W67744", "Anne De Lisle", "Aletha E. Ward"),
    ("Diane Duchess v Tantsenhaus", "B", "W411361", "3-8-51", "Blk & rust", "Fritz v d Tantsenhaus W247339", "Duchess Diane v Tantsenhaus W247340", "William H. Tants", "Owner"),
    ("Dietrich Ave", "B", "W397287", "7-9-52", "Blk & tan", "Duke of Oakdale W347393 12-52", "Duchess Inez v Tilling W328168 12-52", "Joseph J. Dietrich", "Frederick A. Doreo"),
    ("Dina v Schloss (Germany)", "B", "W363604", "3-28-51", "Blk & rd", "Klaus v d Neckarstrasse*", "Dina v Brandenstein*", "Nina B. Adams", "Peter Penker"),
    ("Doba von Windhugel", "B", "W396312", "5-13-52", "Blk & tan", "Heidel v Escort W81187", "Lorelei of Windyhill W306454", "E. H. Linford, Jr.", "Mr. & Mrs. David P. Evans"),
    ("Dobe-Villa's Jettie", "B", "W414675", "7-13-51", "Blk & rust", "Dobe-Villa's Sir Echo W275518", "Dobe-Villa's Diana W64931", "Joseph Settig", "Harrison J. Hemmerling"),
    ("Doby's Black Magic", "B", "W347882", "3-4-52", "Blk & rust", "Dragoner v Schwarzperle W20418", "Doby of Craigdell W328283 12-52", "John W. Currey", "Porter Keith"),
    ("Draga v Romberg (Germany)", "B", "W401366", "12-1-49", "Blk & rust", "Alex v Kleinwaldheim*", "Britta v Oesterried*", "George Delayne von Reich", "Hanna Reiners"),
    ("Driesbach's Buster", "D", "W402035", "6-18-50", "Blk & rd", "Doby of Andreas W114580", "Duchess v Gruenwald III W187530", "Charles Edward Driesbach", "Harold E. Davis"),
    ("Duchess von Munchausen", "B", "W416431", "6-26-50", "Blk & rust", "Major von Munchausen W178782", "Spotlight von Bloomingburg W185982", "Ethel Agunzo", "Thomas D. Dillon"),
    ("Duchess of Silver", "B", "W387059", "12-16-51", "Blk & rust", "Ch. Lucky Silver of Terry Run W8060", "Gypsyanna v Haunschmidt W252252", "George E. Moles", "Leslie L. Smith"),
    ("Duchess Star", "B", "W406187", "7-2-50", "Blk & tan", "Ch. Wittland's Black King A955389", "Star Sapphire W41834", "Vincent Pravato", "Robert Innace"),
    ("Duke von Alexia of Jarwat (Canada)", "D", "W331426", "5-19-49", "Blk & tan", "The Duke of Hambourg*", "Sue von Alexia of Jarwat*", "Richard W. Weis", "Ethel Hawkins"),
    ("Duke of Kahaumakaawe", "D", "W405597", "5-4-48", "Blk & tan", "Gerry v Weschenmoser A907997", "Mapuana of Puna Anana W24982", "Charles E. Steves", "James D. Fulp, Jr."),
    ("Elsa von Tannen Wald", "B", "W325635", "2-14-52", "Blk & rust", "Too-Me-No's Splendore W163930", "Esta v d Brokenshire W208976", "Gus C. Maxwell", "Gus J. Burandt"),
    ("Empress Ada von Vogt", "B", "W415367", "2-24-49", "Blk & rust", "Dow's Roland of Marienland A890735", "Princess Hilda v Franhohen W145400", "Marjorie Rita Clymer", "Mrs. Andrew Knudsen"),
    ("Eric the Duke of Sussette", "D", "W330782", "2-27-52", "Blk & br", "Dukey Boy of Fairhope A443380", "Sussette from Waidsmanslust W243438", "Clarence G. Richter", "Fred Krueger"),
    ("Eric the Red X", "D", "W407463", "12-6-51", "Rd & rust", "Bucky Kemp Hiawatha W62037", "Maureen's Satin W123561", "Kathleen W. Sinner", "Mrs. James E. Connolly"),
    ("Eros V (Italy)", "D", "W415651", "4-25-48", "Blk & tan", "Gabrys Del Cimbro*", "Aitanga II*", "Jack R. Meffert", "Avv. Bottini"),
    ("Faetche's Schaatze", "B", "W344871", "12-6-48", "Blk & rust", "Eljobara's Emir A983079", "Vaudean's Rising Star W96133", "Albert Faetche, Jr.", "Carl A. Sudbury"),
    ("Feda", "B", "W322027", "11-16-48", "Blk & rust", "Bob's Brother W138694", "Queen of Peter Pan W22201", "Mrs. Harry Byrne", "Rufus Paul Garner"),
    ("Filiberto's Duchess of Tamarack", "B", "W404235", "11-12-51", "Blk & tan", "Ch. Beltane of Tamarack W191489", "Gwen of Elmhurst A838609", "Peter C. Filiberto", "Leo Wittenberg"),
    ("Folly", "B", "W329934", "12-1-51", "Blk & tan", "Blue Boy v Wetzel W76229", "Lady Victoria II W260686", "Mr. & Mrs. Y. W. Eversole", "Mrs. Robert A. Henson"),
    ("Fraulein von Krieghund", "B", "W413691", "3-18-51", "Blk & rust", "Rocky v Heilbronner Hof W146511", "Markell's Mitzie W246217", "John Victor Mickman", "Carl R. Markell"),
    ("Fraulein Torchy Chase", "B", "W410950", "12-30-51", "Blk & tan", "Cesar Salgado W125627", "Susie Bly W283676", "Kathleen Chase", "Robert C. Bly"),
    ("Fritz of Darr-Eda", "D", "W389889", "4-28-51", "Blk & tan", "Frederick v Maschoff W215946", "Judy v Rottenberg W210271", "Darrel L. Ransdell", "Marion R. Kinne"),
    ("Fritz von Kuban", "D", "W339444", "6-15-51", "Blk & tan", "Kirk v Heilbronner Hof A972408", "Dorsch's Linda W125251", "Janet K. Aske", "William G. Kuban"),
    ("Glensan's Wendi", "B", "W412017", "3-25-51", "Rd & rust", "Herr Gallant Fellow W142046", "Damasyn the Barbary Bon-Bon W182125", "Mrs. Olin N. King", "Mrs. J. R. Underwood"),
    ("Go for Broke Ranger", "D", "W381143", "7-9-51", "Blk & rust", "Dragoner v Schwarzperle W20418", "Lise of Craigdell W181723", "Emery J. Chobody", "Mary Sanford Brown"),
    ("Gretchen von Venablitz", "B", "W417829", "10-22-51", "Blk & tan", "Baron v Venablitz W59201", "Georgia Peach A797871", "Mrs. Wm. A. Venable", "Owner"),
    ("Guardetta of Riviera", "B", "W322729", "3-10-51", "Blk & rust", "Fritz v Ribbentrop III A971867", "Freda v Wessling W93915", "Mrs. Fred L. Thornton", "F. J. Wessling"),
    ("Gypsy Fraulein Thielen", "B", "W381135", "7-23-51", "Blk & rust", "Wilhelm of Schwalbach W157969", "Illisa v Luxon W175821", "C. A. Bivens & T. C. Ketner", "W. K. & M. Lashley"),
    ("Gypsy Maria", "B", "W402205", "3-23-52", "Blk & tan", "Albert v Willman W96657", "Vallie W246629", "Duncan A. McNaughton", "Jack R. Casselberry"),
    ("Heidi von Rumpus", "B", "W400496", "7-19-48", "Blk & tan", "Andlauer's Buddy A808345", "Jeanne W154824", "Mrs. J. C. Young & Mrs. W. S. Shields, Jr.", "Frank M. Hoskins"),
    ("Heidi Storm of Tac-Mar", "B", "W324186", "11-8-50", "Blk & rust", "Too-Mee-No's Mustange W154865", "Princess Katrinka W150609", "K. F. Smoller", "Catherine Griswold"),
    ("Henretta", "B", "W400322", "7-2-51", "Rd & rust", "Rhett v Kushner II W126810", "Babe II W108043", "John L. Williams", "Charles R. Monroe"),
    ("Hercules of Laughlin Lodge", "D", "W411830", "4-11-52", "Blk & rust", "Kurt Meine Schwartz Liebe W158654", "Gryf von Schwartzenwald W49994", "Laura Belle Laughlin", "Owner"),
    ("Jenta", "B", "W383663", "10-29-51", "Blk & tan", "Vernhof's Red Shaddo v Behymer W56862", "Vernhof's Vernette W33456", "Adolph Larsen", "Helen S. Edwards"),
    ("Jezebel III", "B", "W364534", "10-30-51", "Blk & tan", "Ch. Rancho Dobe's Presto W57335", "Schatzi II W233671", "Bob L. Yeary", "Dr. William B. Hancock"),
    ("Judy Treeseia of Rhienlander", "B", "W357436", "7-14-50", "Blk & rust", "Potsdam v Rheinlander A912206", "Edith of Treeseia W1089", "Reginald R. Woodall", "Mrs. Willard L. Sanders"),
    ("Julie", "B", "W326775", "8-23-51", "Blk & tan", "Ch. Assault v Aleck W42704 U.D.", "Dark Valor Girl W113296", "Arthur A. Salzman", "Joyce E. Gunning"),
    ("Juno IV", "B", "W426501", "11-22-49", "Blk & tan", "Tombigbee Teuton W33114", "Lady Anna W40571", "Rogest W. Dively", "Byron S. McGuire"),
    ("Katrinka v Maschoff", "B", "W359042", "4-23-52", "Blk & tan", "Akela v Sonneheim W152464", "Konigin of Jerry Rum W2778", "Mary Warner", "Gus Mascari"),
    ("Kerr's Hope", "B", "W363745", "9-17-51", "Blk & rust", "Ch. Rancho Dobe's Presto W57335", "Penelope v Steinhardt W92109", "Harold W. Kerr", "Frisco Mari"),
    ("Kitchawan's Witty of Kilburn", "D", "W377455", "5-14-52", "Blk & rust", "Ch. Dacki v d Elbe W78438", "Ch. Kitchawan's Acquila W154926", "John G. Noruk", "Kithchawan Kennels"),
    ("Kriss von Karon", "B", "W403050", "9-25-51", "Blk & tan", "Kemo v Mencken W201299", "Lady Margaret III W253547", "Viola M. & John W. Moore", "Ronald O. Patrick"),
    ("Lady Agnes", "B", "W373864", "11-16-51", "Blk & rust", "Prince Riefe W108218", "Duchess of Gregory Haus W214210", "L. A. Showalter", "Orie R. Lukens"),
    ("Lady Braaterdam of Highlands", "B", "W371241", "6-21-51", "Rust", "Flame's Faust v Nosretto W160912", "Boots Braaterdam W193777", "Vincent T. Magrini", "Frank Henderson"),
    ("Lady Dobee", "B", "W339818", "6-2-51", "Br & rust", "Too-Me-No's Rajah W109197", "Too-Me-No's Miranda W154860", "Robert S. Wefler", "Dr. Robert E. Frierson"),
    ("Lady Hildegarde of Za-Ca", "B", "W346081", "1-13-52", "Blk & br", "Helios II of Pontchartrain W128492", "Duchess Diena of Gor-Anne W61565", "Anthony & Viola Liuzzo", "Carl & Zari Branch"),
    ("Lady Kristina", "B", "W363770", "4-3-52", "Blk & rust", "Laury's Kolonel Kris W113446", "Nena Lady Rocco W216350", "David Simon", "John S. Curcio"),
    ("Lady Teaka of Milton", "B", "W364570", "12-13-51", "Br & tan", "Frederick of Milton W92126", "Roxena v d Tantsenhaus W229888", "Katherine Mark", "Marguerite Young"),
    ("Larkstone Laddie", "D", "W380769", "1-5-52", "Blk & rust", "Waldo Valdivostok W87907", "Vola Hesse W128580", "Richard E. Powell", "R. Q. Minze"),
    ("Lenchen von Halle", "B", "W332919", "9-18-49", "Blk & rust", "Count Rudolph W89106", "Didi v Huntsdorf W31068", "John J. Pinchock", "William & Paulette Dressler"),
    ("Likki Vanderhoof", "B", "W333809", "7-9-51", "Blk & tan", "Adobe of Gracewood W139978", "Baile's Nono Miss Nikki W184792", "Mr. & Mrs. John Cibik", "Mrs. Alva Boyce Bailes"),
    ("Linda von de Geest", "B", "W345884", "7-12-51", "Blk & rust", "Ch. Oberon of Jerry Run W131478", "Nela v Tamara W166822", "William T. McKay, Jr.", "Marie Hadenfeldt"),
    ("Lisa of Nohoneni", "B", "W322012", "4-12-51", "Blk & rust", "Ch. Kilburn Escort A947073 C.D.", "Gayway Gretchen W79659", "Ray A. & Virginia S. Webb", "Robert C. & Helene S. Allen"),
    ("Lissa Von Smithdobe", "B", "W364109", "7-23-51", "Blk & rust", "Wilhelm of Schwalbach W157969", "Illisa v Luxon W175821", "C. B. & Jeanette K. Smith", "Mr. & Mrs. W. K. Lashley"),
    ("Machts Nichts Aus von Trolite", "D", "W342045", "2-26-51", "Blk", "Troll's Indian Chief W97586", "Trolite's Princess Leilani W230934", "Daniel E. Richardson", "William W. Ho"),

    # Leaf 128 (37 dogs)
    ("Many Oaks Cora v Mets", "B", "W367426", "6-2-51", "Blk & rust", "Herr Miekel's Pete of Kamitch W294659", "Hallwyre Heidy W151024", "Travis Rumph", "Dr. D. M. Rumph"),
    ("Meina of Marienwood", "B", "W391422", "6-6-51", "Blk & rust", "Fronshia of Northwood W292886", "Clodia of Marienwood W107983", "J. C. & D. M. Muller", "William S. Brown"),
    ("Miller's Donna Illissa", "B", "W423583", "7-1-50", "Blk & rust", "Ch. Asta's Ace A768781", "Kerrigan's Kiki W189091", "Bina M. Miller", "Matilda C. Kerrigan"),
    ("Mrs. Rex", "B", "W404332", "3-25-52", "Blk & tan", "Prince Kurt W48064", "Jodi W24082", "H. Radway Matz II", "Ann L. Raines"),
    ("Necker's Tiger III", "D", "W348159", "9-7-51", "Blk & rd", "Admiral v Neckerheim W8495", "Pandora of Dawn W275978", "Willy C. Necker", "Mr. & Mrs. H. S. Newsom"),
    ("Olson's Amber Ingrid", "B", "W366446", "8-23-50", "Rd & rust", "Cal v Lure W226674", "Princess Ingrid Sigrid Sonja W129949", "Ed B. Olson", "Owner"),
    ("Patricia IV", "B", "W343383", "6-7-51", "Blk & rust", "General v Bellheim A859458", "Deborah of Glenn Acres W228901", "Dr. R. A. Malmberg", "Jean N. Watrous"),
    ("Princess von Aga", "B", "W406098", "10-29-51", "Blk & tan", "Vernhof's Red Shaddo v Behymer W56862", "Vernhof's Vernette W33456", "Bernard R. Kelly", "Helen S. Edwards"),
    ("Princess of Springhead", "B", "W378083", "9-3-50", "Blk & tan", "Hendry's Captain W2605", "Queen of Peter Pan W22201", "Howard P. Best", "Clarence Baker"),
    ("Queen Catherine II", "B", "W333575", "2-16-52", "Blk & tan", "Ch. Delegate v d Elbe W70773", "Countess Jocelyn W204155", "R. C. & C. C. Schultz", "John J. Cunningham"),
    ("Queen of East Glen", "B", "W353298", "3-29-51", "Blk & br", "Air Patrol of Sioux Lodge W19154", "Judy of Del-Old A810166", "Lawrence B. Schroen", "Arthur E. Forste"),
    ("Queenie v Rumpus", "B", "W408710", "10-16-50", "Blk & tan", "Baron Graf v Rumpus W4127", "Heidi von Rumpus W400496 9-53", "G. G. Passmore", "Mrs. Jack C. Young & Mrs. Wm. S. Shields, Jr."),
    ("Rhonda von Ariendorf", "B", "W332252", "7-23-51", "Blk & rust", "Ch. Dacki v d Elbe W78438", "Ericka von Areindorf W270213", "P. Warren Kidwell", "Lewis S. Penland"),
    ("Rita Maggie Sigfried", "B", "W372524", "8-6-49", "Blk & tan", "Jettchen's Sigfried A468115", "Angola v Fasanenheim A766171", "June R. Parker", "Fred M. Miner"),
    ("Rudolph's Freda", "B", "W327346", "12-22-51", "Blk & rust", "Reber Grugur of Texas W131404", "Lund's Duchess W283684", "Rudolf Lund", "Eric L. Lund"),
    ("Ruff Strong Hignett", "D", "W401462", "7-22-51", "Rd & tan", "Rolf v Wagner W45819", "Rongstad's Gipsy Rose Lee W182791", "Elsa M. C. Hignett", "Oma Atkinson"),
    ("S An D's Bambi", "D", "W405590", "6-25-50", "Blk & tan", "Rusty of Jason Wood W45678", "Regan of Pontchartrain W14843", "John Miller", "Helen S. Jaffray"),
    ("Satan II of Rusty of Ward", "D", "W359030", "7-21-51", "Lvr, tan & br", "Rusty of Ward W173570", "Gretchen v Mahler A891922", "R. L. & M. F. Graham", "Ben E. Sherman"),
    ("Sergeant Duke", "D", "W416901", "9-6-47", "Blk & tan", "Dorn A840609", "Lady Maxie of Miami W46231", "Bennett T. Kennedy", "Mrs. J. G. Russin"),
    ("Shial Atarah", "B", "W356841", "3-1-52", "Blk & tan", "Bob v Nigg W204809", "Black Dawn II W276212", "George W. Nigg", "Owner"),
    ("Sindee Doby", "B", "W388891", "10-20-51", "Blk, br & tan", "Doby VIII W143487", "Miss Sindee v Weppler W160058", "George E. Bryant", "Marcel Bouchez"),
    ("St. Helena Lady", "B", "W399040", "10-28-48", "Bl & tan", "Rocket v Swartzkrop W112976", "Fawn v Palanka W112975", "Mr. & Mrs. P. O. McDanel", "Roy R. Trempy"),
    ("Stormking von Betheim", "D", "W348832", "5-23-52", "Blk & tan", "Ch. Rancho Dobe's Storm W179626", "Liebschen of Kenwood W116291", "Elizabeth H. Oakie", "Owner"),
    ("Sultan v Thor", "D", "W322945", "1-4-52", "Blk & rust rd", "Czar v Ripper W53546", "Kristina v Nordmann W49456", "Mrs. T. Glenn Wright", "Owner"),
    ("Tangwald Buttons", "B", "W409491", "5-10-51", "Blk & tan", "Damsyn The Tang W11054", "Carla v Shacklet W135373", "Mrs. Baron I. Shacklette", "Owner"),
    ("Tanya King", "B", "W324634", "11-10-50", "Br & rust", "Cocoa W177475", "Thora v Duenewald W33623", "Saterial King", "Aldworth L. Sampson"),
    ("Tarzan v Reichsadel", "D", "W416425", "6-19-50", "Blk & tan", "Kizer v Litz W11643", "Germantown Dresden Lady W32760", "L. F. Taylor", "John A. Schaar"),
    ("Tauzieher Blitzen", "D", "W409748", "4-30-47", "Blk & tan", "Ferry v Tauzieher A752716", "Deborah v d Tauzieher A630616", "Alvin A. & Jean W. Wolf", "William H. Tants"),
    ("Teena of Lone Maple", "B", "W345913", "5-4-51", "Blk & rust", "Major of Mergrahof W159048", "Gardell of Elmwood W182723", "Alice Ellingwood", "Martha W. Wolfred"),
    ("Thomas Dober Villanova II", "D", "W390104", "3-25-48", "Blk & tan", "Schoen v Martz A907654", "Black Satin Lady W14939", "L. J. Reicher", "Arthur J. Crann"),
    ("Tinnie", "B", "W419188", "11-11-51", "Blk & rust", "Ch. Cy of Dobe-Haven A666745", "Feda W322027 9-53", "Mrs. Clementine Byrne", "Owner"),
    ("Tito v Romerhof", "D", "W403975", "4-12-49", "Blk & rust", "Cheeko v Romerhof W93328", "Trudy v Romerhof W54398", "Frank P. Caniglia", "Owner"),
    ("Treudel von Reldnahc", "B", "W411075", "12-3-51", "Blk & rust", "Leif v Frueh W39098", "Ora v d Steuben W25959", "Alys Chandler", "Walter T. Hayter"),
    ("Tutzer's Hildegard", "B", "W396301", "4-11-51", "Blk & rust", "Kurt Meine Schwartz Liebe W158654", "Gryf v Schwartzenwald W49994", "Henry Tutzer", "Mrs. Laura Belle Laughlin"),
    ("Weitzel's Frieda", "B", "W381898", "9-22-51", "Blk & tan", "Sunny v Feichinger W237668", "Lady Queen III W197527", "A. K. Weaver", "Thomas B. Conger"),
    ("Westfield Nelly", "B", "W427114", "11-25-51", "Blk & rust rd", "Kilburn Jolly W58462", "Eve of Morland W287433", "William Poganitz", "John J. Moore"),
    ("Wright's Duke Red Rowdy", "D", "W335691", "11-27-51", "Rd & rust", "Prince Kole of Gor Anne W300308", "Hedda von Kiel W282174", "Alton D. Wright", "M. W. & D. E. Paige"),
]

dogs = [make_dog(*row) for row in raw_dogs]

if __name__ == "__main__":
    out_path = Path(__file__).resolve().parent / "data" / "verified_1953_09.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(dogs, f, indent=2, ensure_ascii=False)
    print(f"Verified {len(dogs)} dogs written to {out_path}")
