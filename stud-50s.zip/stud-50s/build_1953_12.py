import json
from pathlib import Path

VOL = "sim_american-kennel-club-stud-book-register_1953-12_70_4"

def make_dog(name, sex, reg, wh, color, sire_str, dam_str, owner, breeder):
    def split_parent(p):
        p = p.strip()
        if p.endswith("*"):
            return p, None
        tokens = p.split()
        for i, tok in enumerate(tokens):
            if (tok.startswith("W") or tok.startswith("A")) and len(tok) >= 4 and tok[1:].isdigit():
                return " ".join(tokens[:i]), tok
        return p, None

    sire_name, sire_reg = split_parent(sire_str)
    dam_name, dam_reg = split_parent(dam_str)
    return {
        "volume_identifier": VOL,
        "registration_number": reg,
        "registered_name": name,
        "sex": sex,
        "whelped_date": wh,
        "color": color,
        "sire_name": sire_name,
        "sire_registration_number": sire_reg,
        "dam_name": dam_name,
        "dam_registration_number": dam_reg,
        "owner": owner,
        "breeder": breeder,
    }

raw_dogs = [
    # Leaf 131 (69 dogs)
    ("Anni von Hamar", "B", "W350439", "7-10-52", "Blk & tan", "Fritz von Cornelia W247662", "Karla von Hamar W247566", "Mrs. Winnie McLaughlin", "George D. Hamar"),
    ("Antonia v Bradford", "B", "W417657", "5-29-51", "Blk & rust", "Ch. An-Joe's Anthon W33231", "Burma v Blackwoods W93083", "Richard M. Kahle", "Paul B. Johnston"),
    ("Artus v Carl Hesterhof", "D", "W328280", "9-25-51", "Blk & rust", "Ch. Meadowmist Elegy W153473", "Ch. Damasyn The Tassi W84982", "Muriel H. Breit", "Carl Hester"),
    ("Aton Olandol von Deacon", "D", "W330709", "12-31-50", "Blk & tan", "Deacon W228944", "Mitzie v Olandol W154309", "M. B. & C. Melton", "Fred M. Wilbanks"),
    ("Babee", "D", "W347692", "4-5-52", "Blk & tan", "Gessner's Rebel W116960", "Walton's Duchess Dawn W204337", "George T. Collins", "Donald G. Walton"),
    ("Baron von Carlo", "D", "W351376", "8-13-46", "Blk & tan", "Ryff v Carlo A905336", "Schotsia v d Coral A988358", "Shirley Sailors", "Jessie M. Carr"),
    ("Baron von Krugenheimer", "D", "W436713", "4-7-51", "Blk & tan", "Baron v Haberhaus W141454", "Cecilie Van Mierlingen W244726", "Mary Arrietta", "Ase Norgard"),
    ("Baron Steiner von Brew", "D", "W345293", "4-7-52", "Blk", "Stuka v Arizona W131562", "Froliche Frau W141074", "Mr. & Mrs. L. D. McLaws", "Thomas O. Rowleym"),
    ("Beauty De Rose", "B", "W426498", "5-5-48", "Blk & tan", "Mack of Bolce-Field W47184", "Jitters v Locarno W61579", "Anthony De Rose", "Arthur A. Goldfin"),
    ("Black Zinda Duches", "B", "W435975", "6-7-51", "Blk & tan", "Baron of Jeda W301098", "Holda's Duchess W301097", "W. R. Tedder", "Larry E. Harris"),
    ("Blitzen v Bassewitz III", "D", "W417325", "1-20-45", "Blk & rust", "Blitzen v Bassewitz II A454375", "Greta v Blomberg A700995", "John B. Pace", "Harold W. Blomberg"),
    ("Boice Hill Farm's Heidi", "B", "W435945", "11-11-51", "Blk & rust", "Ch. Asta's Ace A768781", "Westora's Rascal W121385", "Elsie D. Dunlap", "Albert Pennett"),
    ("Chinde Joani Natoni", "D", "W430496", "5-25-51", "Br & blk", "Blazie Duke A886002", "Heasty's Dinah of Pampass Villa W61691", "B. M. Brush", "Wilbur D. Heasty"),
    ("Cleopatra of Selbyville", "B", "W422650", "10-5-51", "Blk & rust", "Baron Satan of Westhofen W199545", "Rhumba v Bismarck W122097", "George J. Hohmeier", "Arthur E. Lane"),
    ("Coffee of Saddle River", "B", "W331165", "9-1-51", "Rd", "Zhu Kov of Andreas W289483", "Lassie of Johnsonburg W287440", "Jess A. Kaufmann, Jr.", "Felix J. Pekari"),
    ("Count Eric von Josef", "D", "W337274", "4-26-48", "Blk & rd", "Rufus v Strachof A555018", "Princess Delva v Schwalk A795072", "William C. McHenry", "Arthur F. Bublitz"),
    ("Countess Satana von Dilger", "B", "W363440", "2-9-52", "Blk & tan", "Prince of Wales A574505", "Meisterhand v Adalheim W304974", "Mrs. Floyd Hoel", "David H. Thomas"),
    ("Count Serge v Hohenzollern", "D", "W426140", "10-30-48", "Blk & tan", "Hugo v Papending A559876", "Grofine v Hohenzollern W56166", "Carl A. Hilger, Jr.", "Richard W. Phelan"),
    ("Crebs' Daisy Belle", "B", "W326475", "8-4-50", "Blk & tan", "Crebs' Johnny A871619", "Crebs' Judy Girl II W136804", "Fred Defourneau", "Hugh E. Crebs"),
    ("Dal Robbins Deidre", "B", "W400754", "1-4-52", "Br & rust", "Banner of Tamarack W191488", "Messinger's Leisa W167125", "Veronica M. Stabb", "Owner"),
    ("Damasyn The Golden Guilder", "D", "W380609", "10-19-52", "Br & rust", "Damasyn The Solitaire W338040 12-52", "Damasyn The April Rain W31038", "Thomas R. Gabler", "Helen F. Kamerer"),
    ("Del Prete's Deborah", "B", "W349922", "1-14-52", "Blk & rust", "Aufdemberg's Saucy Brigadier W204128", "Aufdemberg's Tia W229749", "Vivian Nettie DelPrete", "Aufdemberg Kennels"),
    ("Diana v Felsengrund", "B", "W430124", "8-27-49", "Blk & tan", "Duke of Hedgecrest W14658", "Barbel v Felsengrund*", "Elise Disselhoff", "Owner"),
    ("Dinah von Wodin", "B", "W406774", "5-29-51", "Blk & rust", "Aufdemberg's Saucy Brigadier W204128", "Greta von Wodin W182456", "Frank J. Laventhall", "Helen C. Wodin"),
    ("Dionysos of Sunset", "D", "W360841", "7-15-52", "Br & rust", "Ch. Kurt K of Halmerr A950249", "April of Sunset W139318", "Charles Berry", "George Hollos"),
    ("Dubarry", "B", "W341950", "12-12-50", "Blk & tan", "Von Glenbayern of Gay Acres W58121", "Molka v Berger W23804", "Daisy E. Stumpf", "Estelle C. Mason"),
    ("Duchess Carolina", "B", "W423010", "3-31-51", "Blk & rust", "Ch. Doberman Downs' Dandy's El Cid W153851", "Countess Jena W155666", "Richard T. Copenbarger", "Richard E. Doying"),
    ("Duchess Hotspur II", "B", "W339861", "6-11-51", "Blk & br", "Arne v Stefen W69847", "Ebony Girl W231162", "Ann V. Fredericks", "Clara A. Dixon"),
    ("Duchess von Malonedorf", "B", "W375174", "9-8-50", "Blk & tan", "Pinz v Leitz W84853", "Duchess v Tayno W64162", "L. D. Malone", "Carl B. Ehman"),
    ("Duchess of Schwazwald", "B", "W395666", "12-28-51", "Blk & rust", "Blackie v Sausenburg W101810", "Tippie III W203257", "August F. Nuccitelli", "Owner"),
    ("Duchess v Wiercrest", "B", "W430294", "9-27-49", "Rd & rust", "Red v Burgholz W184635", "Betty v Guderian W1107", "Norman Ziemann", "Owner"),
    ("Duke of Cowskin", "D", "W388375", "3-23-52", "Br & rust", "Ch. Torn's Desert Gold W232168", "So Inquisitive Bertha W162198", "Richard Simmons", "Lawrence L. Carlisle"),
    ("Dusky Boy", "D", "W374212", "10-20-51", "Tan & blk", "Doby VIII W143487", "Miss Sindee v Weppler W160058", "Henry Marlow", "Marcel Bouchez"),
    ("Ebon Kurt v Collinshoff", "D", "W368293", "11-9-51", "Blk & rust", "Ch. Duke v d Ravensburg III W127973", "Gretl v Reverdy W136942", "W. A. Sadler", "V. H. Urey & C. R. Collins"),
    ("Ebony v Horwick", "D", "W437828", "3-30-48", "Blk & tan", "Escort v Hilparth A924594", "Lady Rudi v Schillinghoff A772452", "Gilbert C. Faigel", "Horace Leach"),
    ("Edenderry Lady Deborah", "B", "W416549", "11-15-51", "Blk & tan", "Blitz v Neckerheim W179004", "Edenderry Red Rusty W297946", "Dwight L. Johnson", "Owner"),
    ("Elblac's Traveler", "D", "W348413", "2-20-52", "Blk & rust", "Ch. Elblac's Blitz W34808 C.D.", "Armadale Adara W195133", "Elio Fratini", "Laurence & Dora Worthen"),
    ("El Dorado Tanya", "B", "W337263", "10-24-51", "Rd & rust", "Ch. Victor of Driscollwood W61285", "El Dorado Renee W185365", "Wm. F. Hennessey", "Mrs. Ben McCourt"),
    ("Eric von Henderbergh", "D", "W403646", "5-3-51", "Bl & rust", "Too-Me-No's Mustange W154865", "Hilda Lou v Hendenbergh II W154518", "Alex K. Barger", "Ray Webster"),
    ("Erick Cargo", "D", "W413521", "11-9-48", "Blk & tan", "Kurt v Stockhausen W76679", "Erick Girl W2449", "Phillip P. Ringsborg", "Emanuel R. Anderson, Sr."),
    ("Flambeau Rolf", "D", "W327478", "1-19-52", "Blk & rust", "Barth v d Valtheim W139683", "Miss Gretchen of Sedgefield W100664", "Robert Van Nostrand", "Mary H. Gorsuch"),
    ("Flash von Wagholdt", "D", "W372251", "6-13-52", "Rd & tan", "Baron Kurt von Arnholdt W292883", "Mona Lise Flak von Wagner W248731", "W. Reed Walker", "Kenneth M. Eccleston"),
    ("Fraulein Muetzel", "B", "W391148", "7-5-49", "Blk & rust", "Ritz Mack v Duschenes W40395", "Duchess of Redland II W47215", "George Pfundstein", "Austin Fields"),
    ("Fraulien von D'Allen", "B", "W438893", "7-21-50", "Blk & rust", "Barth v d Voltheim W139683", "Sophia v Loretz W19218", "M. H. & J. Allen, Jr.", "Mary H. Gorsuch"),
    ("Freda von Rubin", "B", "W324386", "10-1-50", "Blk & tan", "Charlemagne v Rubin W79258", "Mirza v Bloemfontein W84619", "K. D. & J. D. Sanchez", "Albert F. Ryckaert"),
    ("Fricka von Tannen Wald", "B", "W325633", "2-14-52", "Blk & rust", "Too-Me-No's Splendore W163930", "Esta v d Brokenshire W208976", "B. W. Cox, Jr.", "Gus J. Burandt"),
    ("Fritz's Jesse's Bonn", "D", "W430820", "9-19-51", "Blk & rust", "Fritz v Brauer W15600", "Bonn of Amerikeim W158458", "Mr. & Mrs. V. R. DeValle", "Katharine L. Krayenhogen"),
    ("Giesela v Klosterholz II", "B", "W413109", "10-1-51", "Blk & tan", "Westphalia's Cavalier W29904", "Maedchen v Klosterholz W176125", "John H. Flathmann", "Steve Halas"),
    ("Gudmundson's Cisco Kid", "D", "W448105", "8-10-48", "Blk & rust", "Rancho Dobe's Largo W57337", "Chinota De Topp W33154", "Levi Gudmundson", "Vera T. Lancaster"),
    ("Hanna's Rex Diabolo", "D", "W431147", "7-28-52", "Blk & rust", "Trail Em Winaway W255171", "Black Knights' Gretchen W345025 12-52", "Hanna Flechsig", "Mrs. Alice M. Fowler"),
    ("Hans von Eckart", "D", "W408992", "5-1-50", "Rust & tan", "Clark's Rusty Boy W62800", "Ommi of Kahaumakaawe W92399", "Henry Giugni", "William F. Simon"),
    ("Heidi VIII", "B", "W407374", "6-28-45", "Blk & mhgy", "Bob's Red Kyke A694718", "Holly of Baldwinsville A872343", "Charles Joy", "Justin W. Mignault"),
    ("Helgra Petroff von Molna", "D", "W438158", "2-9-50", "Blk & tan", "Eric v Paulraine W39603", "Kollenburg's Gretel W73513", "Louis Bruno", "Kurt P. Dreizner"),
    ("Holly of Butternut Gables", "B", "W431352", "6-20-47", "Blk & tan", "Bruno of Lyra W214654", "Heidi VIII W407374 12-53", "James F. Scanlon, Jr.", "Charles Joy"),
    ("Homakonn Gold Athena", "B", "W419434", "4-30-52", "Br & rust", "Ch. Torn's Desert Gold W232168", "Damasyn The Chestnut Circe W42829", "A. C. Conner", "Owner"),
    ("Homakonn Red-Red-Red", "B", "W341127", "4-30-52", "Br & rust", "Ch. Torn's Desert Gold W232168", "Damasyn The Chestnut Circe W42829", "Roy G. Warren", "A. C. Conner"),
    ("Honey Belle", "B", "W365966", "11-14-51", "Blk & rust", "Ch. Patton's Potentate W60526", "Patton's Cinderella v Pless W218906", "P. C. & R. Kurlytis", "D. N. Cameron"),
    ("Honey's Domino", "D", "W371278", "9-16-52", "Blk & tan", "Troll's Choice W97587", "Coral Queen W262893", "Gwendolyn Quinn", "Ransom D. Kenny"),
    ("Hulsey's Dinah", "B", "W408973", "5-26-51", "Blk & tan", "William Irving Hi Max W252609", "Lady Alice Volandol W262417", "J. W. Hulsey", "J. S. Humphrey"),
    ("Illissa von Stoffregen", "B", "W322454", "11-7-50", "Blk & rust", "Ch. Acho v Gesellschaft A850715", "Helmerr's Happy Girl W44800", "Fred L. Stoffregen", "Owner"),
    ("Interceptor II", "D", "W334422", "12-30-51", "Blk & tan", "Cesar Salgado W125627", "Susie Bly W283676", "Robert C. Bly", "Owner"),
    ("Jennifer of Crystalbrook", "B", "W431592", "6-15-51", "Rd & rust", "Ch. Apollo v Oderau A756315", "Annette of Crystalbrook W73936", "George C. Goerling", "Leonore F. Goerling"),
    ("Jill V", "B", "W413514", "5-7-51", "Blk & rust", "El Chico W193378", "Bonnie Belle W121391", "Noel Allen Bryan", "Mrs. B. F. Bryan"),
    ("King von Remmel", "D", "W348690", "8-11-49", "Blk & tan", "Pickering's Whirlwind A712661", "Pickering's Punch W58430", "Donald R. Alverson", "Spurgeon Pickering"),
    ("Kurt of Main", "D", "W418644", "3-29-51", "Blk & rust", "Grafson of Laughlin Lodge W120409", "Gryf v Schwartzenwald W49994", "Allen O. Pfander", "Laura Belle Laughlin"),
    ("Lady Cinderella", "B", "W421934", "8-1-50", "Blk & rust", "Lucky Rex of San Diego W192057", "Lady Lee Ann W190020", "Raymond Francis Da Metz", "James E. Calkins"),
    ("Lady Dawn MacBeth", "B", "W400609", "6-12-49", "Blk & tan", "Benno v Sandplatz*", "Trishka W54552", "M. F. & B. I. McClelland", "R. M. & D. M. Ayers"),
    ("Lady Emma von Garrett", "B", "W326802", "12-9-51", "Rd & rust", "Major von Garrett W190947", "Karla v Reichman W69590", "Denis S. Garrett", "Earl C. Richmond"),
    ("Lady Hiedi", "B", "W438904", "7-7-51", "Blk & rust", "Hallwyre Hektor W121389", "Greta v Olandol W167167", "Mrs. R. C. Hanger", "Mrs. Robert C. Jenkins"),

    # Leaf 132 (46 dogs)
    ("Lady v Hillderhause", "B", "W332158", "12-26-51", "Blk & rust", "Timothy v Tutzing W11657", "Nancy of Munchausen W193286", "Al Granata", "Erminia J. Hill"),
    ("Lady Pinkerton", "B", "W426948", "9-11-50", "Blk & tan", "Count De Allegro W127146", "Susan's Anna Fredricka W153268", "Jean C. Brawner", "Owner"),
    ("Lady Star of Mannerhein", "B", "W336084", "12-17-51", "Blk & tan", "Baron v Starheim W147147", "Queenie D von Stohlhein W260762", "Betty Cummings", "Mrs. Martha P. Dondanville"),
    ("Little Lass", "B", "W403464", "8-27-52", "Blk & tan", "Golkin's Byng von der Heide W136374", "Lady Fawn W53658", "George T. Collins", "Robert A. McDowell"),
    ("Livingston's Abigail", "B", "W425153", "9-10-49", "Blk & tan", "Kilburn Gosh W6138", "Lady Livingston W66870", "Stanley O. Livingston", "Owner"),
    ("Lorelei of Fairview", "B", "W322458", "11-7-50", "Br & tan", "Kaiser v D'Alessandro W54683", "Diane v Red Bank W162731", "Charles E. Nurrenberg", "Dominic Dalessandro"),
    ("Lor Val's Smoky", "D", "W396942", "7-28-50", "Blk & tan", "Barron of Ellindo Norr W191987", "Mona of Bree Derrs W221731", "Earl W. Valentine", "Eleanor F. Morris"),
    ("Madchen Dobbi v Staufeneck", "B", "W423025", "3-14-52", "Blk & rust", "Pepper Bing der Groaner W149777", "Teana v Staufeneck W141601", "Judith B. Weiss", "Eugene Poschinger"),
    ("Maiger", "D", "W355247", "4-24-50", "Blk & tan", "Klephti of Jerry Run W2748", "Brownie's Ginger W150530", "John W. Hostetler", "Henery M. Brown"),
    ("Major of Bronxville", "D", "W350831", "1-6-52", "Blk & rust", "Ch. Jet v d Ravensburg W43665", "Damasyn The Huntress W218739", "John N. Holland", "Owner"),
    ("Mar-Lo-Del's Huney", "B", "W433856", "8-21-52", "Blk & rust", "Arras v Stolzenfels W298360", "Lady De-Vere of Hy-Way W329349 12-52", "William M. Marvel", "Frank H. & Olga M. Stevens"),
    ("Marta von Adelhof", "B", "W444336", "6-23-52", "Blk & tan", "Kurt Meine Schwartz Liebe W158654", "Esse v Wagner A985559", "John B. Moore", "Ernell B. & J. Gordon Miller"),
    ("McCaesar Cobb", "D", "W416424", "10-7-50", "Blk & rust", "Too-Me-No's Rajah W109197", "Too-Me-No's Claudette W68089", "Arthur B. Cobb", "Dr. Robert C. Frierson"),
    ("Medchen", "B", "W380501", "2-27-52", "Blk & br", "Duckey Boy of Fairhope A443380", "Sussette from Waidsmanslust W243438", "Anthony P. Bero", "Fred Krueger"),
    ("Mel-Mo's Duchess", "B", "W348975", "4-6-51", "Blk & rust", "Ch. Brown's Achilles W67793", "Too-Me-No's Brown's Melodious W185325", "Wendel J. Shuely", "Nancy Shy"),
    ("Mickey's Duchess Gruenwald", "B", "W330872", "10-29-50", "Blk & rust", "Ch. Votan v Gruenwald II A869642", "Parker's Tanya W90151 W185325", "Mildred A. Harvell", "Russell E. Parker"),
    ("Mickey von Washwille", "D", "W408944", "11-11-49", "Blk & tan", "Lucky v Pippin A862771", "Gretchen v Buttz W145308", "Winthrop T. Williams", "Lester Buttz"),
    ("Mistress Cerberus", "B", "W382814", "12-11-51", "Blk & tan", "Parrott's Count Prancer W291863", "Nubbins of Maplebend W167268", "Iona Carolyn Henderson", "William H. Baker"),
    ("Nathan v Wurttemberg (Ger.)", "D", "W408473", "1-13-50", "Blk & rd", "Alex v Kleinwaldheim*", "Lore v Wurttemberg*", "Ludwig A. Gessner", "Karl Volz"),
    ("Nick of Time", "D", "W340925", "11-12-51", "Blk & tan", "Beltane of Tamarack W191489", "Gwen of Elmhurst A838609", "William Jakes", "Leo Wittenberg"),
    ("Norah of Wynlea", "B", "W365437", "6-22-52", "Blk & tan", "Karl of Wynlea W326646 12-52", "Pauline of Wynlea W185448", "Arthur Andrews", "Owner"),
    ("Parker's Duchess", "B", "W362254", "8-26-52", "Blk & rust", "Rebel Grgur of Texas W131404", "Rebel's Queen W333899 12-52", "J. K. & M. H. Parker", "Arthur M. Cochran"),
    ("Patton's Ponder of Torn", "D", "W401893", "2-8-52", "Blk & rust", "Ch. Torn's Desert Gold W232168", "Ch. Meadowmist Berenike W28361", "James D. Patton", "W. G. Roach"),
    ("Penelope of Greene Acres", "B", "W374130", "7-8-52", "Mhgy & tan", "Budweiser of Charneil Manor W57892", "Karlena's Velvetteen W212437", "Archie D. Greene, Jr.", "Howard I. North"),
    ("Pepper's Cagey Chris", "D", "W403324", "7-2-51", "Blk & tan", "Kilburn Ideal W57698", "Pepper's Annette W98061", "Mrs. C. F. Barron", "Mr. & Mrs. Claude Shelton"),
    ("Perrys' Gretel", "B", "W364046", "12-22-51", "Blk & rust", "Rhett v Kushner II W126810", "Rhodes' Penalita W83075", "Mr. & Mrs. R. A. Perry", "Charlie T. Rhodes"),
    ("Prince Arturo De Supremo", "D", "W420968", "5-26-52", "Blk & rust", "Too-Me-No's Supremo W163926", "Too-Me-No's Peggy Contessa W16509", "Arthur J. Bellone", "John O. Busick II"),
    ("Putnamville Bonnie", "B", "W348090", "5-26-52", "Blk & tan", "Ch. Rancho Dobe's Storm W179626", "Ch. Elblac's Dorcas W34841", "John Didio", "Beth S. Chaves"),
    ("Queen Helena", "B", "W385757", "6-2-52", "Rd", "Fritz v Inka v Duke W154458", "Basel v Chief v Curt Wilsona A955802", "Abraham J. Carter, Jr.", "Erwin Jesse Ullery"),
    ("Quiet Acres Princess Sari", "B", "W435925", "4-4-51", "Blk & rust", "Steuben's Prinz Kurt A873492", "Karen von Stroom W195210", "Gladys G. Whyte", "R. D. & E. Van Scoyk"),
    ("Roxanna of Maedchen", "B", "W411148", "3-10-52", "Blk & tan", "Graf v Barrington W45252", "Lady of Maedchen v d Jessen W332186", "Francis M. Wells", "Gordon & Helen H. Pulleyn"),
    ("Sable's Spice von Lichtfuss", "B", "W388144", "8-23-51", "Blk & rust", "Aroch v Lichtfuss W113570", "Sibylle v Hinkle W95574 C.D. 12-52", "Philip J. Sableski", "Mrs. R. C. Thomas"),
    ("Sabre von Brelie", "D", "W347364", "9-11-50", "Blk & rust", "Rico v Hagen W94539 C.D.", "Diana von der Heide W162001 C.D.", "Irvine L. Manning", "Edward H. Hauslein"),
    ("Sari", "B", "W401621", "11-14-51", "Blk & rust", "Baron v Germania W233304", "Liny Greiffturn W180664", "George Crespo", "Lily M. Foregger"),
    ("Shelly II", "B", "W383283", "8-29-52", "Blk & br", "Heidelberg-Schloss' Kurt W27884", "Shelly of Haven W177384", "T. E. Smith", "Robert L. Lancaster"),
    ("Sir Key v Steuben", "D", "W411149", "4-6-48", "Blk & rust", "Sir Richard v Steuben A689212", "Duchess v Graf W13941", "Francis M. Wells", "George Burrow"),
    ("Sir Oliver II", "D", "W353105", "9-25-51", "Blk & tan", "Kemo v Mencken W201299", "Lady Margaret III W253547", "K. D. & J. D. Sanchez", "Ronald O. Patrick"),
    ("Sonny H Ashhoff", "D", "W436355", "10-30-51", "Blk & tan", "Blitz v Hoff W133505", "Lady Frieda v Heyse W52444", "R. A. Henderson", "Mrs. A. F. Warren"),
    ("Staton's Brenda of Tac-Mar", "B", "W404272", "10-25-51", "Blk & rust", "Indian Warrior of Tac-Mar W77885", "Redi Hi Jinks W155748", "Catherine Staton", "Mary A. Tackwell"),
    ("Subbi", "D", "W400222", "10-19-51", "Blk & rust", "Graf von Boring W288670", "Gretchen v Dober W107574", "George Trad", "Ferdinand J. John"),
    ("Tampa Toy", "B", "W366270", "4-8-52", "Blk & tan", "Danny Boy Orion W182148", "Candy II W8014", "Floyd W. Johns, Sr.", "Henry F. Roder"),
    ("Todd's Lady Ann", "B", "W416511", "8-26-52", "Blk & rust", "Rebel Grgur of Texas W131404", "Rebel's Queen W333899 12-52", "Charles R. Todd", "Arthur M. Cochran"),
    ("Trude Fang Starrine", "B", "W335693", "1-17-52", "Blk & rust", "Hallwyre Handy Jewel A662600", "Pepeta Richardson W247858", "Mr. & Mrs. L. D. O'Neal", "William R. Wilson, Jr."),
    ("Unaka's Tenskwatawa", "D", "W355035", "7-28-52", "Blk & rust", "Ch. Damasyn The Virginian W4664", "Tonka of Unaka W183120", "Mrs. A. C. Hyder", "Helen B. McAfee"),
    ("Valley's Venus", "B", "W430819", "10-29-51", "Blk & tan", "Vernhof's Red Shaddo v Behymer W56862", "Vernhof's Vernette W33456", "Mr. & Mrs. V. R. DeValle", "Helen S. Edwards"),
    ("Wilhelmina von Aleck", "B", "W326821", "4-21-51", "Blk & rust", "Ch. Assault v Aleck W42704 U.D.", "Hatty v Rupprechtheim W3580", "Mary Willard Shea", "Mr. & Mrs. David L. Palmer"),
]

dogs = [make_dog(*row) for row in raw_dogs]

if __name__ == "__main__":
    out_path = Path(__file__).resolve().parent / "data" / "verified_1953_12.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(dogs, f, indent=2, ensure_ascii=False)
    print(f"Verified {len(dogs)} dogs written to {out_path}")
