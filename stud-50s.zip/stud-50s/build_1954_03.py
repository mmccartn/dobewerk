import json
from pathlib import Path

VOL = "sim_american-kennel-club-stud-book-register_1954-03_71_1"

def make_dog(name, sex, reg, wh, color, sire_str, dam_str, owner, breeder):
    def split_parent(p):
        p = p.strip()
        if p.endswith("*"):
            return p, None
        tokens = p.split()
        for i, tok in enumerate(tokens):
            if (tok.startswith("W") or tok.startswith("A")) and len(tok) >= 4 and tok[1:].isdigit():
                return " ".join(tokens[:i]), tok
        return p, None

    sire_name, sire_reg = split_parent(sire_str)
    dam_name, dam_reg = split_parent(dam_str)
    return {
        "volume_identifier": VOL,
        "registration_number": reg,
        "registered_name": name,
        "sex": sex,
        "whelped_date": wh,
        "color": color,
        "sire_name": sire_name,
        "sire_registration_number": sire_reg,
        "dam_name": dam_name,
        "dam_registration_number": dam_reg,
        "owner": owner,
        "breeder": breeder,
    }

raw_dogs = [
    # Leaf 142 (5 dogs)
    ("Aida's Beth", "B", "W329510", "4-23-52", "Blk & rust", "Baron Bosco Bo Mac W157413 C.D.", "Pepper's Aida W98062", "John W. & Fleta R. Ruff", "Owner"),
    ("Alex von Strom", "D", "W417233", "10-24-52", "Rd & rust", "Grungebirge Alex W191530", "Greta v Daltex W134556", "C. S. Hansen", "Mrs. E. C. Eklund"),
    ("Alma v Stifthub (Germany)", "B", "W385890", "1-22-46", "Rd & rust", "Nestor v Simmenau*", "Ester v Furstenlager*", "Harrison J. Hemmerling", "Fred Meyers"),
    ("Ari Dobe's Soja", "B", "W352002", "3-1-52", "Blk & tan", "Ch. Rancho Dobe's Primo W57334", "Harbaugh's Black Satin W209234 C.D.", "Priscilla M. Bouchey", "Owner"),
    ("Arve's Judy", "B", "W369365", "2-8-52", "Rd & rust", "Rex of Troll-Val W336076 12-52", "Frau Laax v Robenhausen W100771", "James Tilley", "Richard A. Wonders"),

    # Leaf 143 (73 dogs)
    ("Baroness Blue", "B", "W383777", "6-2-52", "Bl & rust", "Dictator's Knabe W199591", "Gretchen v Blitz II W276261", "Richard L. White", "Sandy Cecil Ward"),
    ("Baron Hans von Brinkerhof", "D", "W393279", "9-30-51", "Blk & tan", "Gayriff of Rancho Debeck W225315", "Lady of Rancho Debeck W101494", "Ann E. Lock", "Joseph F. Debeck"),
    ("Beauty of Bronxville", "B", "W350832", "1-6-52", "Blk & rust", "Ch. Jet v d Ravensburg W43665", "Damasyn The Huntress W218739", "John N. Holland", "Owner"),
    ("Bella Donna II", "B", "W342494", "12-30-51", "Blk & tan", "Andlauer's Buddie A808345", "Cordier's Gretle W284844", "J. J. Ambrose", "Talmage M. Heitman"),
    ("Beowulf's Gamblera", "B", "W322534", "8-21-51", "Blk & tan", "Ch. Beowulf v d Ravensburg W138219", "Ch. Elblac's Electra W34855 C.D.X.", "R. H. Macy & Co., Inc.", "C. H. & Ann P. Paschall"),
    ("Bernie's Duchess", "B", "W451671", "9-6-50", "Blk & tan", "Rags W65292", "Rocky IV W199661", "Bernice Rafuse", "Nicholas A. Consolazio"),
    ("Bette's Sue", "B", "W359818", "3-26-52", "Blk & rust", "Ch. Brown's Achilles W67793", "Casper's Alice W88956", "William Palmer", "Harry A. Steinmeyer, Jr."),
    ("Blitzen VII", "D", "W361827", "8-12-51", "Blk & tan", "Blitzen III W5695", "Puggsie Davis W74447", "Arnold Glassberg", "Edna M. Adams"),
    ("Blitz v Schorrheim", "B", "W389939", "6-2-52", "Blk & tan", "Blue v d Hoff W246171", "Lizzie W288303", "Genevieve Avent", "Walter A. Shore, Jr."),
    ("Bonny Schoenherr", "B", "W336136", "1-16-51", "Blk & tan", "Pete of Cal-Lure W139406", "Jessy of Mergrahof W148169", "Floyd E. Williams", "Owner"),
    ("Brown's Falstaff", "D", "W335255", "4-27-52", "Blk & rust", "Ch. Kilburn Cameron A971404", "Ch. Brown's Belinda W147363", "Irma G. Ackerman", "Eleanor D. Brown"),
    ("Butz v Manley (Germany)", "B", "W432732", "6-2-48", "Blk & rd", "Alex v d Burg Schadeck*", "Astrid v Manley*", "George F. Scruggs", "Leverne Manley"),
    ("Chauqueta", "B", "W346112", "11-20-51", "Blk & tan", "Duke Korze W1179", "Trixie Lee W310451", "Mervin Dale Jones", "Sidney Hawkins"),
    ("Chrisandy's Blitz Krieb", "D", "W346329", "3-19-52", "Blk & tan", "Ch. Jet v d Ravensburg W43665", "Damasyn The Magic Murmur W87545", "John Joseph Seffert", "A. J. & Christine T. Morin"),
    ("Christina von Fuchsberg", "B", "W362792", "5-5-52", "Blk & br", "Toto v Fuchsberg W135723", "John's Gretchen of Galveston W270692", "Aurelia Lee Hall", "John H. Davis"),
    ("Christine Flak von Rolf", "B", "W357498", "6-13-52", "Rd & tan", "Baron Kurt von Arnholdt W292883", "Mona Lise Flak von Wagner W248731", "W. W. Farley", "Kenneth M. Eccleston"),
    ("Circus Town Queen", "B", "W447010", "7-20-52", "Rd & rust", "Grungebirge Alex W191530", "Hilda v Weisenberger W342655 3-53", "Z. W. Kitchens", "Mrs. Rufus W. Black"),
    ("Coigne's Galaxy Gold", "B", "W362116", "5-18-52", "Rust & tan", "Ch. Torn's Desert Gold W232168", "Coigne of Dobemar W149262", "William H. Olton", "C. D. Livesay & Mrs. H. C. Rundle"),
    ("Contessa v Trail", "B", "W459960", "12-29-52", "Blk & tan", "Joseph v Trail W368095 6-53", "Lady Tessa v Gallant W12337", "Rudolf M. Valenzuela", "James C. Alspach"),
    ("Count Rudolph von Luckner II", "D", "W428873", "1-20-50", "Blk & rust", "Count Rudolph von Luckner W191567", "Lady Fala II W161917", "Archie A. Cook", "Joseph M. Clark"),
    ("Courtland Courageous v Kirk", "D", "W386062", "7-24-52", "Blk & rust", "An-Joe's Dasher W210232", "Leiber Gretchen W109212", "Mrs. Paul E. Schaffner", "Thomas F. Kirk"),
    ("Crusader v d Rhinegold", "D", "W332742", "4-5-52", "Blk & tan", "Ch. Ardexter v d Valtheim W38881", "Ch. Asta v d Rhinegold W52699", "Hale Phares", "Rhinegold Kennels"),
    ("Damasyn The Little Red Surrey", "B", "W395148", "9-12-51", "Br & tan", "Ch. Agitator of Doberland W162677", "Ch. Damasyn The Sultry Sister W31045", "Mrs. Bob Adamson", "Owner"),
    ("Damasyn The Loyal Lock", "D", "W385302", "10-31-52", "Br & tan", "Damasyn The Solitaire W338040 12-52", "Damasyn The Lush Liani W260018", "Polly & Al Rossman", "Mrs. Bob Adamson"),
    ("December's Miss Desi of Bri-Bre", "B", "W440368", "12-9-52", "Blk & rust", "Too-Me-No's Man o' War W154864", "Lorilee of Bri-Bre W271241", "Anna Bennett", "Lillieann Larsen"),
    ("Deelinda's Queen Nancy", "B", "W424237", "2-13-52", "Blk & tan", "Big Boy v Krueger W2071", "Countess III W255091", "Bobby Maxwell", "Kenneth L. Grant"),
    ("Dick's Martha", "B", "W336836", "2-16-52", "Blk & rust", "Marty v Bojak W223944", "Tor v Eitzen W297099", "Richard A. Wonders", "Mr. & Mrs. J. L. Carter, Jr."),
    ("Dodie II", "B", "W343311", "11-4-51", "Blk & rust", "Rexford of Herron Acres W221593", "Talao Merabruce W183382", "Troy Dortch", "James B. Reigle"),
    ("Dorga", "B", "W393672", "7-15-52", "Blk & rust", "Rebel Grgur of Texas W131404", "Lund's Duchess W283684", "A. C. Madsen", "Eric L. Lund"),
    ("Duchess Greta", "B", "W450933", "8-27-52", "Blk & tan", "Kemo v Mencken W201299", "Heidy Ettalene W288045", "Marjorie R. Zeller", "George & Mary P. Stokes"),
    ("Duchess Walkurdammerung", "B", "W450921", "6-17-52", "Blk & tan", "Conga v Stolzenfels W283442", "Lady Lou Walkurdammerung W296925", "Clifton C. Kemp", "Owner"),
    ("Duchess Watterhaus", "B", "W333713", "11-19-51", "Bl & tan", "Kelmut v d Seltzerhaus W199977", "Princess Patricia Spegal W44455", "Ed. L. Hopfinger", "Dr. E. P. Watt"),
    ("Duchess von Wier Strasse", "B", "W452915", "4-3-50", "Blk & rust", "Red v Burgholz W184635", "Betty v Guderian W1107", "R. M. Vandenberg", "Norman Ziemann"),
    ("Duke of Elma", "D", "W459659", "12-23-47", "Br & rust", "Too-Me-No's Roland W53154", "Too-Me-No's Margo W56791", "Rudolph L. Olbrich", "Mrs. Clinton O. Tolliver"),
    ("Dutch IV", "B", "W391596", "4-9-51", "Br & tan", "Bambi's Red Boy W103769", "Cindy v Noswal W141599", "R. L. Olbrich", "Beatrice F. Lawson"),
    ("Eastom's Cadorna", "D", "W340737", "7-16-52", "Blk & rust", "Aracen of Jan-Har W195301", "Valarie of Marhue W130822", "Mr. & Mrs. Major J. Horney", "Mr. & Mrs. George Eastom"),
    ("Eekay's Lady Betty", "B", "W342176", "8-15-51", "Rust & tan", "Hell Diver A904214", "Diver's Inspiration W152381", "Edith E. Kirzinger", "H. Zimmerman"),
    ("Elfred's Donna Maria", "B", "W395528", "10-3-52", "Blk & rust", "Roger v Franconia W296651 C.D.", "Countess Birthday Schroeder W150821", "Fred & Ellen Hoffmann", "Irmgard L. Schroeder"),
    ("Empress Rotahahn", "B", "W468456", "10-24-51", "Rd & rust", "Ch. Victor of Driscollwood W61285", "El Dorado Renee W185365", "Emma G. Hahn", "Mrs. Ben McCourt"),
    ("Eugenia of Lanarra", "B", "W328258", "12-5-51", "Blk & tan", "Ch. Helmut v Klosterholz W85794", "Gloriosa of Blue Top W153905", "Albert Petrozza", "Lars Waage"),
    ("Freda von Liebesheim", "B", "W452859", "6-5-46", "Blk & rust", "Tita's Sergeant v Koenigsheim A700515", "Kathy of Vernhof A819780", "C. & M. Strakbein", "Mr. & Mrs. Henry Hoffmann"),
    ("Fredricka", "B", "W428338", "3-16-52", "Blk & rust", "Blitzen VI W298961", "Freda v Haas W77273", "Ernest Schwarzenbach", "Jean V. Apperson"),
    ("Frieda von Schlegel", "B", "W470106", "3-15-52", "Blk & tan", "Lynam's Prince Laddie W104755", "Ch. Gessner's Scarlet W20682", "W. J. Kelly", "Mr. & Mrs. Alfred E. Dorsch"),
    ("Frydek of Tac-Mar", "B", "W336356", "10-25-51", "Blk & rust", "Indian Warrior of Tac-Mar W77885", "Redi Hi Jinks W155748", "Harold E. Riegger", "Mary A. Tackwell"),
    ("Gayview's Bonita", "B", "W378586", "7-11-52", "Blk & rust", "Gayview's Black Duke W170435", "Elsa v d Elbe W164567", "William H. Capellaro", "Gayview Kennels"),
    ("Geraldine Bell", "B", "W391489", "11-6-52", "Blk & rust", "Ali Baba of Margyde W81847", "Penny Marqueta W165989", "Charles Chandler", "William Lohmoller"),
    ("Gessner's Susie", "B", "W438595", "6-5-49", "Blk & tan", "Ch. Alcor v Millsdod A561744", "Ch. Gessner's Scarlet W20682", "Ludwig A. Gessner", "Mr. & Mrs. Alfred E. Dorsch"),
    ("Greta Denhoffer", "B", "W336428", "1-18-52", "Blk & tan", "Rommel v Boggs Hoff A899998", "Queen Wilhelmine W152800", "Jack B. Phelps", "Mrs. George Hecht"),
    ("Gretchen von Ebony", "B", "W385556", "10-20-51", "Blk & rust", "Black Jonny W291916", "Ria v Montrose W272450", "B. A. Roll", "Mrs. Lora K. Stewart"),
    ("Gretchen v Janz", "B", "W389113", "7-8-52", "Blk & rust", "Fritz v Janz W46470 C.D.X.", "Lotti v Luxonheim W48225", "Marcella K. Albone", "James B. Janes"),
    ("Gretel of Green Acres", "B", "W384738", "5-18-52", "Blk & tan", "Kurt v Ecton W157351", "Barbel v Felsengrund W311502", "Freda V. Ritchey", "Elise Disselhoff"),
    ("Hanna's Lady Katherine", "B", "W415302", "8-6-52", "Blk & rust", "Orbleu of Jerry Run W131476", "Pixie of Jerry Run W141170", "Hanna Flechsig", "Owner"),
    ("Hans of Heigenbloch", "D", "W448400", "3-26-50", "Rd", "Red Knight of Cherokee W41679", "Duchess of Heigenbloch W135869", "Francis M. Cahill", "J. Leonard Dixon"),
    ("Hayes' Duchess of Texas", "B", "W425949", "8-26-52", "Blk & rust", "Rebel Grgur of Texas W131404", "Rebel's Queen W333899 12-52", "John W. Hayes, Jr.", "Arthur M. Cochran"),
    ("Hook's Mike", "D", "W469606", "8-31-52", "Bl & tan", "Ch. Kafriet v d Seltzerhaus W199976", "Aida von Burgau W271635", "Richard H. Hooks", "Owner"),
    ("Illeena von Stoffregen", "B", "W322455", "11-7-50", "Blk & rust", "Ch. Acho v Gesellschaft A850715", "Helmerr's Happy Girl W44800", "Barbara M. Stoffregen", "Fred L. Stoffregen"),
    ("Jan-A-Da War King", "D", "W453749", "6-1-49", "Blk & tan", "Baptiste's War King W51733", "Jan-A-Da Lady W139790", "David S. Sheridan", "Owner"),
    ("Jennie's Duke", "D", "W388935", "8-18-51", "Blk & tan", "Dobie of Stardust W179249", "Duchess Diablo W194935", "Genevieve Avent", "Frances Y. Pearson"),
    ("Jet of Andreas", "D", "W460172", "9-1-51", "Blk & rust", "Zhu Kou of Andreas W289483", "Lassie of Johnsonburg W287440", "Mabel M. Duke", "Felix Pekari"),
    ("Jezebel Frau Ichneumon", "B", "W334514", "2-26-52", "Blk & rust", "Ikos von der Haas W249242", "Aval's Frau Gretchen W48873", "Benjamin Thomas", "Rufus J. Bond"),
    ("Jiggs von Blitz", "D", "W439531", "12-28-51", "Blk & tan", "Blitz v Leuven A713299", "Christie II W224346", "L. & L. Berndt", "Opal R. Crouch"),
    ("Judy of Pontchartrain", "B", "W457276", "3-20-51", "Blk & rust", "Ch. Cy of Dobe-Haven A666745", "Su-Zan of Pontchartrain W55861", "Beverly Allen", "Glenn S. Staines"),
    ("Just Hope", "B", "W391149", "5-10-49", "Blk & tan", "Sir Rhinelander W100643", "Caroldon's Beatrix W15665", "D. J. Williams, Jr.", "C. H. Rinard & L. W. Lowe"),
    ("Kassal von Ross", "B", "W397243", "8-21-52", "Blk & tan", "Stuka v Arizona W131562", "Princess von Ross W344869 12-52", "J. L. Storer", "Raymond Russell"),
    ("Kenscott's Lucky Belle", "B", "W330917", "5-21-52", "Blk & rust", "Flicka's Lucky v Traumland W154939", "Aufdemberg's Flair W239960", "Mr. & Mrs. Wm. D. Mackay", "Leonard M. & Esta Fischer"),
    ("Keyo", "D", "W424444", "1-19-52", "Blk & tan", "Baron VIII W101872", "Tena's Blue Girl W102319", "Quinton Akers", "Christina J. Marlette"),
    ("Kilburn Sandra", "B", "W455783", "7-2-51", "Blk & rust", "Ch. Kilburn Ideal W57698", "Pepper's Annette W98061", "H. Buresch", "Mr. & Mrs. Claude Shelton"),
    ("King Gaius of Orleans", "D", "W353127", "8-22-51", "Blk & br", "Excalibur's Thrust W127090", "Marg of Arcola W84186", "F. J. & Mrs. K. Sallustro", "Marvin E. Causey, Jr."),
    ("Kipper II", "B", "W330040", "4-21-51", "Blk & rust", "Ch. Assault v Aleck W42704 U.D.", "Hatty v Rupprechtheim W3580", "Luetta M. Strickland", "Mr. & Mrs. David L. Palmer"),
    ("Krickenburger", "D", "W430610", "6-2-51", "Br & rust", "Albert v Willman W96657", "Too-Me-No's Mimic W200634", "Beryl White", "Owner"),
    ("Krist v Ain-Wal", "D", "W384003", "9-6-51", "Blk & tan", "Kurtz v Ain-Wal W52738", "Marlena's Gretchen W146984", "Mrs. Bernice V. Rafuse", "Norman A. Crawshaw"),
    ("Kurt von Adelhof", "D", "W391517", "6-23-52", "Blk & tan", "Kurt Meine Schwartz Liebe W158654", "Esse v Wagner A985559", "R. S. & D. H. Bruno", "Ernell B. & J. Gordon Miller"),
    ("Lady Alice of Troutman", "B", "W406981", "12-1-51", "Blk & rust", "King of the Pines W222234", "Queen of the Pines W238581", "Thomas R. Griffin", "George W. Neff"),

    # Leaf 144 (62 dogs)
    ("Lady Bronya v Hendenbergh", "B", "W356067", "5-3-51", "Blk & rust", "Too-Me-Noo's Mustange W154865", "Hilda Lou v Hendenbergh II W154518", "Sylvia G. Webster", "Ray Q. Webster"),
    ("Lady of the Cliff", "B", "W334574", "3-3-52", "Blk & rust", "Prinz Jory of Marlls Crest W158052", "Cora von Strausberg W251821", "Robt. S. Gordon", "Brigitte G. Crockett"),
    ("Lady Devreau", "B", "W364003", "4-16-51", "Blk & rust", "Baron von Dougle of Craigdell W164433", "Black Beauty IV W171742", "John D. Reavis", "Clara M. Rylant"),
    ("Lady Dictatrix", "B", "W329536", "12-11-51", "Blk & rust", "Roland of Pleasant Acres W79834", "Damasyn The Concertina W22626", "A. B. Stubbs", "Garland T. Loy"),
    ("Lady Ebony VIII", "B", "W412354", "4-22-52", "Blk & rust", "Cyrill v Karlsfeld W336992 12-52", "Lady Ebony III W112588", "Mrs. Walter Foster", "Mrs. Edward W. Kubin"),
    ("Lady Ginger of Stuart", "B", "W346555", "11-16-51", "Rd & tan", "Prince Riefe W108218", "Duchess of Gregory Haus W214210", "Raymond D. Smith", "Orie R. Lukens"),
    ("Lady von Hall", "B", "W432873", "6-20-49", "Blk & rust", "Franz v Lewishof W75093", "Spreeta of Tee W132274", "Arthur B. Hall", "Violet A. Thomas"),
    ("Lady Rindi De Spang", "B", "W429862", "9-23-50", "Rd & rust", "Clark's Rusty Boy W62800", "Ulaula Kuuipo E Hawaii W157690", "Ray F. Spencer", "Frank T. Clark"),
    ("Lady Star Mannerheim", "B", "W411366", "12-17-51", "Blk & tan", "Baron v Starheim W147147", "Queenie D. von Stohlhein W260762", "Irene M. Neth", "Mrs. Martha T. Dondanville"),
    ("Ladys Sumire San", "B", "W354654", "3-3-52", "Blk & tan", "Kimble v Matildenau W87714", "Lady Hays W38921", "Charles E. & Lily Y. Allan", "Levin W. Parker"),
    ("Lady Tamara of Nassau", "B", "W358799", "6-21-51", "Blk & rust", "Duke of Levittown W265559", "Gayview's Black Warrior W150584", "Ruth M. Lange", "Herman Ostermeier"),
    ("Lady of Tassman", "B", "W433282", "6-14-52", "Blk & tan", "Count Skipper W181186", "Lady Monette of Bovercin W143004", "Vincent Newhouse", "Robert W. Dutmers"),
    ("Linc MacKenzie", "D", "W418525", "2-12-46", "Blk & tan", "Ch. Palanka's Hawkins v Eschen A527870", "Arrah v Reck A825145", "D. R. MacKenzie", "Thomas J. Barrett"),
    ("Lornacres' Bliss", "B", "W453740", "4-20-52", "Blk & rust", "Ch. Brown's Christopher W237857", "Black Cloud of White Pines W149846", "H. S. Stevens", "Owner"),
    ("Mariendahl's Herbert von Hoff", "D", "W440313", "4-2-52", "Blk & rust", "Fritz v Hanau W96986", "Frieda v Stauffeneck W261870", "Helen S. Hoff", "Albert C. Herbert"),
    ("Maxine Flo-Ed of Tac-Mar", "B", "W416412", "3-25-52", "Blk & tan", "Hugo v Loretz A972055", "Dinah VI W211393", "Mrs. Florence Thompson", "Adolph Zlab"),
    ("Mel-Mo's Gingersnap", "B", "W323115", "4-6-51", "Blk & rust", "Ch. Brown's Achilles W67793", "Too-Me-No's Brown's Melodious W185325", "Mrs. Hollis Honefenger", "Nancy Shy"),
    ("Miss Tenny of Val Verde", "B", "W330731", "1-13-52", "Rd", "Brown's Brigadier W147361", "Meadowmist Brenda W28364", "J. B. Dunn", "R. E. Alcorn"),
    ("Mitz Fraulein", "B", "W421732", "4-20-52", "Blk & tan", "Esquire v See Tarzi W83714", "Clein's Queenie W413226 9-53", "B. H. Lee", "Edward Clein"),
    ("Mitzi Girl", "B", "W392686", "10-10-52", "Blk & tan", "Caesar v Willman W202980", "Mimi W309486", "Dan Stathos, Jr.", "Howard S. Lewis, Jr."),
    ("Mountaintop's Topsy", "B", "W424528", "4-19-52", "Blk & tan", "Rontyelee Mountain-Top W196558", "Viki von Obol W297540", "Angelo Armando", "Rhoda W. Obolensky"),
    ("Parkwood's Bronze Lady", "B", "W351276", "8-31-50", "Rd & rust", "Herr Gallant Fellow W142046", "Damasyn The Barbary Bon-Bon W182125", "L. N. Scheuermann", "Mrs. John Underwood"),
    ("Patricka von Ricker", "B", "W436920", "7-2-52", "Blk & tan", "Dazzle v Bulger W151267 C.D.", "Duchess v Rames W246150", "Lyle Ricker", "Warren M. & Dollie M. Rames"),
    ("Pete Petro", "D", "W337005", "12-4-51", "Mhgy & gldn", "Tiny Jelen W197202", "Ina May W272665", "Pete C. Petropulos", "Berniece Dakin MacDonald"),
    ("Philipp's Pride", "B", "W434430", "3-1-51", "Blk & rust", "Ch. Patton's Potentate W60526", "Countess Allan W172210", "Edward M. Philipp", "Edward G. Allan"),
    ("Phips v Dubneleh", "D", "W341934", "6-18-52", "Blk & rust", "Zvorykin's Citation W207615", "Lady of Dobe Hacienda W102361", "Bud William R. Foulk", "Owner"),
    ("Pokoamogas", "D", "W389148", "5-17-52", "Blk & rust", "Carwyn's Gallant W149496", "Bakisae's Rusty W355122 3-53", "Daniel Ford", "Andy Bakisae"),
    ("Potty's Duke", "D", "W449816", "4-22-50", "Blk & rust", "Dobe-Villa's Dandy W149689", "Alberta v Eckert A931369", "Harry G. Morrison", "Dobe-Villa Kennels"),
    ("Prince Eric von Frankfort", "D", "W463264", "8-19-51", "Br & blk", "Beau v Halfritz W260055", "Noble Lady of Frankfort W151095", "Baron Maximilian Waldeck", "Robert J. Serridge"),
    ("Prince Rudolf von Bublitz", "D", "W452035", "5-1-52", "Rd & tan", "Count Eric von Josef W337274 12-53", "Princess Delva v Schwalk A795072", "Arthur F. Bublitz", "Owner"),
    ("Princess Barbara of Val Verde", "B", "W330730", "1-13-52", "Rd", "Brown's Brigadier W147361", "Meadowmist Brenda W28364", "R. E. Alcorn", "Owner"),
    ("Princess v Florence", "B", "W455823", "2-23-50", "Blk & rust", "Diablo De Feliz W11736", "Hedy von der Heide W99621", "Joseph O. Passler", "Seraphin J. Brish"),
    ("Princess Katrinka II", "B", "W388253", "10-5-51", "Blk & rust", "Baron Satan of Westhofen W199545", "Rhumba v Bismarck W122097", "Raymond W. Rhodes", "A. E. Lane"),
    ("Princess v Maschoff", "B", "W369841", "4-23-52", "Blk & tan", "Akela v Sonneheim W152464", "Konigin of Jerry Run W2778", "Preston L. Bishop", "Gus Mascari"),
    ("Prinz von Wanderlust", "D", "W436052", "4-11-52", "Blk & rust", "Ch. Amar of Wesley's W23810", "Erna v d Ansbornquelle W301952", "Gerald R. Morris", "Owner"),
    ("Rebecca of Early-Win", "B", "W446544", "10-15-50", "Blk & tan", "Ch. Cunningham's Baron Award W27668", "Magnivon of Shelimac W80980", "James Garel", "Judith C. Peters"),
    ("Red Baron of Marwayne", "D", "W356866", "2-27-52", "Rd & rust", "Ch. Kurt K of Halmerr A950249", "Gay Gretel v Wilruth W170021", "Mrs. Wayne B. Barrow", "Owner"),
    ("Rocket of Romulus", "D", "W417623", "9-12-52", "Blk & tan", "Duke of Lindengrus W262964", "Miss Susie II W301495", "Darwin Wessels", "Owner"),
    ("Romans Girl", "B", "W371397", "6-28-52", "Blk & rust", "Ch. Dacki v d Elbe W78438", "Damasyn The Gypsy Gina W260015", "Leroy Wm. Neibich", "Carson C. & Mary H. Myers"),
    ("Roxy Heath", "D", "W452397", "4-21-46", "Blk & rust br", "Erlheim's Ramesses A859351", "Bonnie-Lou v Palanka A626797", "Mr. & Mrs. Harry C. Heath", "Owner"),
    ("Ruth's Duke of Indego", "D", "W441956", "11-20-51", "Blk & tan", "Duke Korzc W1179", "Trixie Lee W310451", "Ruth O. Jones", "Sidney Hawkins"),
    ("Scrapper von Flournoy", "D", "W439533", "3-1-52", "Blk & br", "Bob von Nigg W204809", "Black Dawn II W276212", "Cedric Flournoy", "George W. Nigg"),
    ("Senta v Felsengrund", "B", "W463901", "8-27-49", "Blk & rust", "Duke of Hedgecrest W14658", "Barbel v Felsengrund*", "Elise Disselhoff", "Owner"),
    ("Seppl der Braunlich", "D", "W331935", "3-2-51", "Cht & rust", "Ehre's Troll Royal W186606", "Cotesworth's Creole Maid W49788", "Robert D. Maclay", "Thomas A. Hardy"),
    ("Shiflet's Southern Belle", "B", "W457527", "12-25-52", "Blk & tan", "Torns Kings General W40262", "Lady Hexe von Fuchsberg W317950", "Mr. & Mrs. Ralph F. Shiflet", "Mr. & Mrs. W. L. Lindsey"),
    ("Shotzie Domstadt", "B", "W433871", "1-6-50", "Blk & tan", "Eric v Vilhelm W105500", "Zimba v Vilhelm W105489", "Elmore Taylor", "Mrs. Kay V. Heidemann"),
    ("Sir Thomas of Troutman", "D", "W406982", "4-20-52", "Blk & tan", "Lutz v Reverdy W136939", "Antona of Mardelbar W263943", "Thomas R. Griffin", "Less S. Goodwin"),
    ("Summer Salt", "B", "W374926", "6-30-52", "Blk & rust", "Duke of Doberheim W283813", "Christie II W224346", "Mrs. Reno Vanhatala", "Opal R. Crouch"),
    ("Sussi von Friesen", "B", "W338881", "5-12-52", "Bl & rust", "Potsdam v Rheinlander A912206", "Edith of Treesela W1089", "Paul Friesen III", "Mrs. Willard L. Sanders"),
    ("Tarbaby v Trausnitz", "B", "W352718", "4-5-52", "Blk & rust", "Gero v Capricorn W107639", "Maggi v Trausnitz W106489", "Mrs. S. R. Wiley", "Samuel Menscher"),
    ("Thunderstorm von Betheim", "D", "W348831", "5-23-52", "Blk & tan", "Ch. Rancho Dobe's Storm W179626", "Liebschen of Kenwood W116291", "E. P. Yates", "Elizabeth H. Oakie"),
    ("Towne Ro Jean War-Jan", "B", "W364020", "9-15-51", "Blk & rust", "Gieser Hi Duke A826388", "Freda v Hass W77273", "John W. Sullivan", "Jean V. Apperson"),
    ("Trail Em Mona", "B", "W461822", "9-2-50", "Blk & rust rd", "Ch. Meadowmist Elegy W153473", "Trail'Em Black Beauty W130239", "Naomi St. John", "Ralph T. Miller"),
    ("Valeri Hull of Laughlin Lodge", "B", "W358941", "9-19-50", "Blk & rust", "Grafson of Laughlin Lodge W120409", "Gryf v Schwartzenwald W49994", "W. E. & D. B. Hull", "Laura Belle Laughlin"),
    ("Victoria of Lindengrus", "B", "W374198", "3-28-52", "Rd", "Ch. Punjab of Lindengrus A992182", "Sheba of Engelstolz W32598", "H. A. & M. E. Jacob", "Walter & Sophie Lindner"),
    ("Von Rueter's High Gold", "B", "W335122", "5-28-52", "Rd & rust", "Gustav v Willenberg W221561", "Von Rueter's Marcia W258129", "Mr. & Mrs. R. H. Jones", "Owner"),
    ("Wade's Prince Mike", "D", "W340898", "11-10-51", "Rd & tan", "Tipler's Quartermaster A963804", "Texas Lady of Danelagen A946477", "Mrs. Aileen C. Perry", "Mrs. J. D. Magee"),
    ("Westerholz Falko", "D", "W342801", "5-28-52", "Bl & rust", "Ch. Kama of Westphalia A702330", "Pebbles W110647", "Vito Penny", "Owner"),
    ("Weygadt Greta", "B", "W439510", "12-21-50", "Br & rust", "Arnfried of Adailia A944780", "Brenda of Weygadt W194273", "Monroe C. Werkheiser", "Owner"),
    ("Wolfes' Pride Doby", "B", "W423523", "10-20-51", "Blk & rust", "Doby VIII W143487", "Sindee v Weppler W160058", "Lewis L. Wolfe", "Marcel Bouchez"),
    ("Wonder's Prince II", "D", "W417007", "4-30-52", "Rd & rust", "Prince Wonders W84118", "Duchess of Oesterreich W267681", "Richard A. Wonders", "Owner"),
    ("Zelda von Zaudern Geholze", "B", "W441465", "9-4-52", "Blk & tan", "Amigo von Zaudern Geholze W183019", "Tayne of Draper W163829", "Marjorie M. Youngblood", "Marjorie M. Moseley"),
]

dogs = [make_dog(*row) for row in raw_dogs]

if __name__ == "__main__":
    out_path = Path(__file__).resolve().parent / "data" / "verified_1954_03.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(dogs, f, indent=2, ensure_ascii=False)
    print(f"Verified {len(dogs)} dogs written to {out_path}")
