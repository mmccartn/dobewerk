import json
from pathlib import Path

VOL = "sim_american-kennel-club-stud-book-register_1955-12_72_5"

def make_dog(name, sex, reg, wh, color, sire_str, dam_str, owner, breeder):
    def split_parent(p):
        p = p.strip()
        if p.endswith("*"):
            return p, None
        tokens = p.split()
        for i, tok in enumerate(tokens):
            if (tok.startswith("W") or tok.startswith("A")) and len(tok) >= 4 and tok[1:].isdigit():
                return " ".join(tokens[:i]), tok
        return p, None

    sire_name, sire_reg = split_parent(sire_str)
    dam_name, dam_reg = split_parent(dam_str)
    return {
        "volume_identifier": VOL,
        "registration_number": reg,
        "registered_name": name,
        "sex": sex,
        "whelped_date": wh,
        "color": color,
        "sire_name": sire_name,
        "sire_registration_number": sire_reg,
        "dam_name": dam_name,
        "dam_registration_number": dam_reg,
        "owner": owner,
        "breeder": breeder,
    }

raw_dogs = [
    # Leaf 152 (16 dogs)
    ("Admiral Tuffy of Solbo", "D", "W514689", "12-12-53", "Blk & rust", "Torkel v Zorn of Solbo W142349", "Dobeking Allena W309166", "Margit M. Anderson", "Courtney W. Phelps"),
    ("Alexa v d Jet", "B", "W483213", "10-10-53", "Rd & tan", "Crusader v d Rhinegold W332742 3-54", "Willow of Pontchartrain W151798 C.D.", "Barbara D. Tibus", "Joseph E. Tibus"),
    ("Alma F Dandessa", "B", "W496459", "2-10-54", "Blk & tan", "Red Daemon of Dendor W268569", "Elblac's Dark Dancer W208748", "Phillips Brooks", "Marion J. Studley"),
    ("Antonius von Vulcan", "D", "W367383", "8-2-52", "Blk & rust", "Ch. Kurt von Vulcan W280669", "Mel-Mo's Farla W322175 12-52", "Harvey A. Hurst, Jr.", "P. L. & W. O. Weindell"),
    ("Arby's Blue Bonnet", "B", "W342855", "3-30-51", "Bl & tan", "Bambi's Red Boy W103769", "Arby v Noswal W158487", "Beatrice F. Lawson", "Owner"),
    ("Arnoville's Queenie", "B", "W511293", "1-26-54", "Blk & rust", "Rontyelee Mountain-Top W196558", "Aufdemberg's Imp W388561 6-54", "Arnoville Kennels", "Henri B. Atkins"),
    ("Asta's Boots III", "B", "W565452", "7-13-51", "Blk & tan", "Victor the Great W150124", "Asta's Boots A826910", "Theodore W. Scott", "Owner"),
    ("Aufdemberg's Trump", "D", "W543619", "8-10-54", "Br & rust", "Ch. Bordo v d Angelburg of Westphalia W373726 9-53", "Aufdemberg's Image W284402", "Aufdemberg Kennels", "Gloria Quintana"),
    ("Aufdemberg's Winsome", "B", "W473377", "1-21-54", "Blk & rust", "Ch. Bordo v d Angelburg of Westphalia W373726 9-53", "Aufdemberg's Saucy Bettina W204131", "Aufdemberg Kennels", "Owner"),
    ("Aufdemberg's Xerxes", "D", "W493978", "2-25-54", "Blk & rust", "Ch. Bordo v d Angelburg of Westphalia W373726 9-53", "Aufdemberg's Tia W229749", "William L. Steiner", "Aufdemberg Kennels"),
    ("Aufdemberg's Zest", "D", "W527519", "7-15-54", "Blk & rust", "Ch. Bordo v d Angelburg of Westphalia W373726 9-53", "Aufdemberg's Lanna W325605 12-54", "Edward A. Rovner", "Aufdemberg Kennels"),
    ("Baldur v Walmarhafen", "D", "W337517", "4-20-52", "Blk & rust", "Ch. Kama of Westphalia A702330", "Alda v Westerholz W154209", "Caroline K. Hackett", "Walmarhafen Kennels"),
    ("Baron von Bruno III", "D", "W393909", "12-22-52", "Blk & tan", "Chrisandy's Jet Ace W277897", "Buffalo von Saenger W310311", "Dennis Kardaris", "Douglas Sanger"),
    ("Belle des Chataigniers", "B", "W422835", "5-15-53", "Br", "Ch. Westerholz Cito v Horwick W263112", "Mimi v Nilstrum W73859", "Edgar A. Smith", "H. & T. Masson"),
    ("Black Dawn III", "B", "W441210", "3-18-53", "Blk & rust", "Ch. Dagobert v Ahrtal W226789", "Shana Kaylee W244225", "Kitty Boyer", "Miss Marie Lee"),
    ("Bonnie von Erda", "B", "W609477", "5-30-53", "Blk & rust", "Duke v Reverdy W136936", "Bretwalda the Valkyrie W303906", "Gerow Garrison", "L. F. Cordeaux, Jr."),

    # Leaf 153 (74 dogs)
    ("Brenda of Doggone Acres", "B", "W496039", "7-22-53", "Blk & rust", "Blitzen v Bassewitz III W417325 12-53", "Duchess v Huffmanheim W253551", "Marjorie A. Stanberry", "John B. Pace"),
    ("Britta of Reichaus", "B", "W409666", "2-28-53", "Blk & rust", "Damasyn the Rake W124990", "Draga v Romberg W401366 9-54", "Mr. & Mrs. R. L. Schmitt", "George De Layne von Reich"),
    ("Brunhilde von Schlegel", "B", "W596492", "9-8-53", "Br & rust", "Erik von Englewood W216018", "Hazel von Englewood W216016", "F. C. & V. M. Hedges", "Philip A. Morrison"),
    ("Carlo of Easterholz", "D", "W429037", "6-14-53", "Blk & rust", "Kama of Westphalia A702330", "Ch. Aleta v d Burghalde W107589", "Dennis W. Mahoney", "Owner"),
    ("Cherry Bend's Big Red", "D", "W473371", "1-2-54", "Rd & rust", "Rocky v Heilbronner Hof W146511", "Terrie Du von W354040 6-54", "Robert & Marianne Dunn", "Marianne E. Dunn"),
    ("Cherry Bend's Chiquita", "B", "W473369", "1-2-54", "Blk & rust", "Rocky v Heilbronner Hof W146511", "Terrie Du von W354040 6-54", "Eulalie M. Brobaugh", "Marianne E. Dunn"),
    ("Clover Patch's Redda", "B", "W458303", "7-13-53", "Rd & rust", "Damasyn the Storm Signal W288919", "Boice Hill Farm's Heidi W435945 12-53", "Frank G. Varela, Jr.", "Elise D. Dunlap"),
    ("Commando of Dendor", "D", "W521481", "5-15-54", "Blk & rust", "Ch. Duke v d Ravensburg III W127973", "Illana of Dendor W268567", "Dorothy O'Connell", "Owner"),
    ("Count Blitzen von Rocke", "D", "W335313", "11-5-51", "Blk & tan", "Radar of Scotheim W210422", "Princess Edna Hilda von Rocke W233629", "Richard M. Flannery", "Owner"),
    ("Cynthia's Rusty Boots", "B", "W629205", "4-7-52", "Blk & rust", "Stuka v Arizona W131562", "Froliche Frau W141074", "Noel B. Fisher", "Thomas O. Rowley"),
    ("Ch. Damasyn the Fiery Filly", "B", "W338042", "4-7-52", "Rd & tan", "Damasyn the Solitaire W338040 12-52", "Damasyn the April Rain W31038", "Karen Kamerer", "H. F. Karmerer & Mrs. B. Adamson"),
    ("Dana of Noel", "B", "W534679", "1-4-53", "Blk & rust", "Ch. Brown's Achilles W67793", "Noel's Holi Loki W249088", "Doctor Keith Mahnken", "Mrs. N. W. Schulte"),
    ("Dictators Countess Candice", "B", "W392857", "6-9-52", "Blk & tan", "Duke Kirt of Strumwind W203010", "Gretchen v Malcon W154324", "Harold A. Ahlskog", "F. E. & H. M. Conrad"),
    ("Dietsche von der Alt-Stadt", "D", "W544884", "6-19-54", "Rust & br", "Rougue of Valhalla W130924", "Baroness von Morgengrau W335996 12-52", "Emil Grimmer", "Gwendolyn V. Tiedemann"),
    ("Dobie Robinson", "B", "W578845", "9-11-53", "Blk & br", "Count Black W278139", "Fricka von Tannen Wald W325633 12-53", "Troy Robinson", "B. W. Cox, Jr."),
    ("Duchess of Andover", "B", "W470559", "7-3-52", "Blk & tan", "Southland's Pride W148750", "Maedchen v Rening W75923 C.D.X.", "J. R. & D. J. Munsey", "W. F. & B. J. Rening"),
    ("Duchess von Helmholtz", "B", "W495477", "10-29-53", "Blk & tan", "Fritz von Frieteag W336967 6-54", "Priscilla of Cross Hill W100845", "LeRoy R. Hardy", "Thomas M. Watts, Jr."),
    ("Duke of Fraser", "D", "W585119", "8-14-53", "Rd", "Baron Hermann of Fraser W374197 3-53", "Victoria of Lindengrus W374198 3-54", "Joseph Sochowski", "H. A. & M. E. Jacob"),
    ("Dutch von Luxenburg", "D", "W343689", "4-3-52", "Mhgy", "Chris' Riki v Willman W202981", "Yohembin v Leitz W120825", "Mrs. W. L. Deason", "Mrs. Earl Harris, Jr."),
    ("Egor v d Loeffelstelz", "D", "W475136", "7-20-53", "Blk & tan", "Ch. Meadowmist Empire W102309", "Hedwig v Rupprechtheim W3582 C.D.", "Paul C. Esenwein", "Owner"),
    ("Ehre's Quitezo", "D", "W332210", "4-13-52", "Blk & rust", "Ch. Kilburn Nudge W149363", "Ehre's Troll Ronoh W186611", "Don F. Nisbet", "Ehre Kennels"),
    ("Elblac's Zalina", "B", "W533268", "3-7-54", "Blk & rust", "Ch. Delegate v d Elbe W70773", "Elblac's Oriana W200193", "Dr. & Mrs. J. H. Cutler", "Elblac Kennels"),
    ("Elblac's Zarco", "D", "W533264", "3-7-54", "Blk & rust", "Ch. Delegate v d Elbe W70773", "Elblac's Oriana W200193", "E. T. D. Jones", "Elblac Kennels"),
    ("Empress v Rotawald", "B", "W629057", "12-5-53", "Rust & tan", "Rick v Lewis W154159 C.D.", "Duchess Greta W450933 3-54", "Jack C. Hodge", "Marjorie R. Zeller"),
    ("Erik v d Morgansonne", "D", "W539541", "6-22-54", "Blk & tan", "Vernhof's Bontemps W33452", "Wardeans Princess Pat W503655 12-54", "Edgar H. Cook", "Beverly J. Cadrobbi"),
    ("Fraulein Gluckskind", "B", "W528407", "10-12-53", "Bl", "Pat von Ochnerhoff W312926", "Candy III W322912 9-53", "Janet P. Boyd", "Kathryn Walcott"),
    ("Frau Poser of Corpus", "B", "W500374", "7-7-51", "Blk & rust", "Captain Pfeiffer W110402", "Frau Sheila von Pfeiffer W264873", "Robert H. Blair", "Charles V. Pfeiffer"),
    ("Fritzen von Blanca", "B", "W610246", "3-30-54", "Rd & rust", "Kurt von Perro W435725 9-54", "Gusta von Blanca W420357 9-54", "Chas. H. Davis, Jr.", "Owner"),
    ("Fulton's Jug", "D", "W600377", "3-31-52", "Blk & rust", "Felix v Guard A704756", "Tipton's Kay of Mosheim W49499", "Fulton Place", "Edward Tipton"),
    ("Galahan's Kit", "D", "W413599", "2-13-53", "Blk & rust", "Ch. Rancho Dobe's Primo W57334", "Karla of Kahala W107355", "Donald C. Allyn", "Christine Hamilton"),
    ("Gilda of Careyland", "B", "W479690", "4-24-53", "Blk & br", "Ch. Rancho Dobe's Storm W179626", "Toni W300758", "Mrs. Gertrude Panorgios", "Owner"),
    ("Graaf von Lissabon", "D", "W589603", "7-7-54", "Blk & tan", "Rex of Wahouma W66497", "Lady Devreau W364003 3-54", "James R. Argo", "John D. Reavis"),
    ("Greta Garbo", "B", "W547616", "9-13-53", "Blk & tan", "Knickenburger W430610 3-54", "Greta VII W41971", "Ethel Mae Hagg", "Mrs. J. T. Blackwell"),
    ("Gretchen-Doc", "B", "W608966", "5-5-52", "Blk & tan", "Beau-Lo's Bart W151364", "Stern Blitzen v Abbott W187562", "Mrs. A. A. Wycoff", "Wilma R. Abbott"),
    ("Heidel von Wagner", "B", "W446317", "6-27-53", "Blk & tan", "Chief v Luftwege W122580", "Mollie v Wagner W112055", "Iona Waiwaiole", "Gilbert H. Thiel"),
    ("Heidi of Gertrude", "B", "W462314", "4-22-47", "Blk & rust", "Doc of Gertrude W30780", "Anna Victorious W5357", "A. M. Garreu", "Mabel D. White"),
    ("Heidi of Temple Crest", "B", "W519830", "7-7-53", "Blk & rust", "Heidel v Escort W81187", "Lorelei of Windyhill W306454", "M. E. Temple & Estate of B. E. Temple", "Mrs. William M. Culliton"),
    ("Hexe II of Lynnfellow", "B", "W493889", "11-23-53", "Rd & tan", "Sir Beau W476116 6-54", "Countess May II W329618 6-54", "Joe M. Gonzalez", "Vivian W. Moss"),
    ("Hi-Tower's Lady Hexe von Nell", "B", "W505103", "12-25-52", "Blk & tan", "Torns Kings General W40262", "Lady Hexe von Fuchsberg W317950", "B. A. Roll", "Mr. & Mrs. W. L. Lindsey"),
    ("Iraglen's Abba", "B", "W599405", "5-15-54", "Blk & rust", "Ventura a Colonel W330598 6-53", "Westwind's Cerise W411524 9-54", "Joseph Schneider", "Helen C. Oliver"),
    ("Janna von der Jan", "B", "W498507", "4-10-54", "Blk & tan", "Damasyn the Khan W65138 C.D.X.", "Trolite's Vesta W258287", "Elsie & Ernest I. Beck", "Jeanette Davis"),
    ("Jean II von Dermer", "B", "W457032", "8-13-53", "Blk & rust", "Butz De Ruken W129411", "Tina VIII W228482", "George Dermer", "Philip Renshon"),
    ("Jill of Twin Cove", "B", "W568695", "5-16-54", "Rd br", "Budi von Burgau W333585 3-55", "Princess of Staufeneck W562308 3-55", "Norman Swerdel", "Elizabeth C. D'Augustine"),
    ("Jolly Jinx De Brazoria", "B", "W521024", "12-2-52", "Br & tan", "Teri De Brazoria W312199", "Linnie W140813", "Jack L. Deason", "Malcom P. Houston"),
    ("Kia Ora's Arctic Storm", "D", "W395112", "1-26-53", "Blk & rust", "Ch. Rancho Dobe's Storm W179626", "Countess Chee Chee v Huff W175384", "R. J. & P. S. Dixon", "Owner"),
    ("Kitts' Tana von Vokers", "B", "W561477", "8-30-54", "Blk", "Morrow's Rugged Rocket W394436 12-54", "Greta of Hillworth W392778 6-53", "J. W. & M. L. Kitts", "Mrs. Clyde Hill"),
    ("Kleopatra v Etheim", "B", "W428155", "3-8-53", "Blk & rust", "Trail Em Top Secret W327961 12-52", "Pixie of Jerry Run W141170", "Walter Miethe", "Hanna Flechsig"),
    ("Kuehl's Onligirl", "B", "W585593", "7-19-54", "Blk & br", "Black Major II W501365 12-54", "Gretchen of Hoganderhus W489549 12-54", "Georgia L. Kuehl", "Samuel P. Hogander"),
    ("Kurt Rotenmantel von Torn", "D", "W596937", "3-21-54", "Br & rust", "Ch. Shmerk's Pride von Torn W253938", "Torn's Black Rose W161065", "Herman F. Allen", "William G. Roach & Ed Gaines"),
    ("Lady Beth of Borojim", "B", "W354017", "6-14-52", "Blk & tan", "Count Skipper W181186", "Lady Monette of Bovercin W143004", "A. H. & L. V. Anderson", "Robert W. Dutmers"),
    ("Lady Betsy of Highland", "B", "W590135", "4-28-54", "Blk & tan", "Richter v Stefen W246316", "Valley Rancho Kotchie W259165", "Terry R. Cervantes", "H. Gene Christner"),
    ("Lady of Cudez", "B", "W520280", "12-14-53", "Rd", "Pluto III W451045 6-54", "Duchess v Natgar W71685", "Alfred Mastromauro", "Michael A. Capone"),
    ("Lady Rusty", "B", "W403276", "11-13-52", "Br & rust", "Westerholz Cito v Horwick W263112", "Masur's Juno W180748", "Leo & Eva Besen", "Charles Masur"),
    ("Lady Turner Goldeno", "B", "W579816", "6-28-54", "Blk & tan", "Vernhof's Squanto W231425", "Lady von Strassburg W402506 9-54", "Ann B. Turner", "Herta & Wylie P. Frazee"),
    ("Lady Voncel of Leverett", "B", "W558836", "1-12-54", "Blk & tan", "Ch. Shmerks' Pride von Torn W253938", "Neno W307530", "J. R. & M. I. McKenzie", "Mr. & Mrs. J. M. Leverett"),
    ("Leebeck's Little Vixen", "B", "W522803", "2-6-54", "Blk & tan", "Ch. Shmerks' Pride von Torn W253938", "Westwind's Band W383610 6-54", "Edd Davis", "Mrs. Claude Bates, Jr."),
    ("Lieb v Sheiba Rioheim", "B", "W449591", "2-28-53", "Blk & tan", "Duke v Ormoc W69030", "Leib v Heilbronner Hof W100975", "A. B. Rios, Jr.", "Andrew Womack"),
    ("Liesel von Hansa", "B", "W501510", "2-1-54", "Blk & tan", "Rontyelee Mountain-Top W196558", "Princess von Hansa W293182", "Robert Pounding", "Irene V. Sparrow"),
    ("Lillard's Angel", "B", "W537228", "5-26-54", "Blk & tan", "Rougue of Valhalla W130924", "Duchess Cappi W303208", "Emil Grimmer", "Joseph L. Waisman"),
    ("Lorelei of Santa Lorraine", "B", "W481462", "3-9-53", "Blk & tan", "Schwarz Prinz W346650 6-53", "Miss Darla of Santa Lorraine W355123", "Thomas H. Campbell", "Stanley W. Henderson"),
    ("Lucky Starr", "B", "W442129", "7-31-53", "Blk, tan & wh", "Haley's Assault W194243", "Ebony Debutante W273017 6-53", "Mrs. Nell M. McCullough", "Mrs. F. G., C. & G. Anderson"),
    ("Lutterloh's Redwick", "D", "W555170", "6-29-53", "Rd & tan", "Ador W290374", "Orestes Jill W241779", "Edgar B. Lutterloh", "Owner"),
    ("Lyon-Crest's Black Brenda", "B", "W428407", "4-22-53", "Blk & rust", "Ch. Blascor's Ichabod Inky W168373", "Queen Sukoonya Daragaiya W218599 C.D.X.", "Anna P. Dowlin", "Lyon-Crest Kennels"),
    ("Maggie", "B", "W590600", "1-4-54", "Blk & tan", "Bryjon's Gero v Gesellschaft W381954", "Doberman Downs' Chorus Girl W149969", "Mrs. Fannie L. Miner", "Audrey M. Bliss"),
    ("Major of Paradise Island", "D", "W504760", "10-18-53", "Blk & tan", "Ch. Blascor's Ichabod Inky W168373 6-54", "Dutchess of Paradise Island W379873 6-54", "Mrs. Wallace A. Betzina", "Mrs. Joseph Kealoha"),
    ("Master Sargent v Rotawald", "D", "W629056", "1-3-51", "Blk & tan", "Shuemaker's Red Fritz W193778", "Shuemaker's Lady Dona W119102", "Jack C. Hodge", "Margaret Shuemaker"),
    ("Mona's Hot Cinder", "B", "W426894", "5-13-53", "Blk & rust", "Pegasus Red Sabre W291716", "Pert v Kinnaman W171324 C.D.", "Ramona Schaeffer", "Dorothy M. Kinnaman"),
    ("Oberon v Ahrtal", "D", "W516170", "6-17-54", "Blk & rust", "Ch. Kilburn Ideal W57698", "Ch. Friederun v Ahrtal W303611", "P. Warren Kidwell", "Tess Henseler"),
    ("Pancho of Banwal", "D", "W416082", "3-4-53", "Blk & tan", "Chico of Reklaw W135127", "Baroness Banwal of Reklaw W324574 6-53", "Walter Banaszek", "Owner"),
    ("Pan-Doh-Ra", "B", "W398926", "3-23-52", "Br & rust", "Sigmund Karl d Imperatur W52855", "Lady Angelica W119054", "Steve Suto", "Samuel A. Muir"),
    ("Penelope Van Plaas", "B", "W442804", "4-24-52", "Blk & rust", "Beo Wolf v Graff W311000", "Tobbie Tobias v Simbouer W93640", "Jessamae Sembower", "Owner"),
    ("Penny Amio", "B", "W599344", "6-9-53", "Blk & tan", "Blaze v Heimwehr W341989 9-53", "Baroness Augusta von Paulus W364111", "Domenick C. Lancieri", "Lydia A. Marsili"),
    ("Prince of Northbrook", "D", "W462180", "7-29-53", "Blk & tan", "Graf v Solln W140459", "Cassie of Beau-Lux W152159 C.D. 9-53", "G. W. & L. M. Wert", "Francis C. Buckley"),

    # Leaf 154 (31 dogs)
    ("Princess Alana v Stoffregen", "B", "W428796", "6-20-52", "Blk & rust", "Ch. Acho v Gesellschaft A850715", "Marlene of Greydale W155317", "Barbara M. Stoffregen", "Owner"),
    ("Princess Maria III", "B", "W503145", "4-10-53", "Blk & tan", "Prinz Canaline W283190", "Gypsy Maria W402205 9-53", "Charles C. Weige", "Duncan A. McNaughton"),
    ("Princess Troy of Flame", "B", "W498335", "10-15-53", "Rd & rust", "Chartreuse of Pontchartrain W98029", "Princess Flame Gstattenberg W323118 9-54", "Joseph Sochowski", "Ruth P. Frank"),
    ("Queen of Elmhurst", "B", "W617967", "10-30-51", "Rust br", "King of Cologne W193018", "Duchess v Wien W60254", "Joseph G. Beck", "Joseph Zuschmann"),
    ("Renotte", "B", "W489000", "1-5-54", "Blk & tan", "Too-Me-No's Carlo v Dentinger W94164", "Town and Country Carnival W49886", "Fred P. Schell, Jr.", "Owner"),
    ("Rita von Blitz II", "B", "W402479", "6-2-52", "Bl gr", "Dictator's Knabe W199591", "Gretchen v Blitz II W276261", "Burch B. Vickery", "Sandy Cecil Ward"),
    ("Rollo's Rodney Van Plaas", "D", "W538300", "4-21-53", "Blk & rust", "Ch. Walire's Rollo W92503", "Tobbie Tobias v Simbauer W93640", "Jessamae Sembower", "Owner"),
    ("Royal Earring Valtheim", "B", "W355426", "5-19-52", "Blk & rust", "Ardexter v d Valtheim W38881", "Princess v Rhein II W108087", "M. R. & J. G. Martinez", "Dorothy Schreffler"),
    ("Rudolph von Heppenheim", "D", "W434198", "5-2-53", "Blk & tan", "Blakie v Howells W170236", "Dobe-Villa's Jettie W414675 9-53", "Kurt Reinhold", "Joseph Sittig"),
    ("Rusty Red Squaw", "B", "W522600", "8-13-53", "Rd & br", "Mike's Red Duke W149611 C.D.X.", "Sally Had W87371", "Edwin Guzell", "Joseph J. Hadraba"),
    ("Sanmahr's Apollo", "D", "W487565", "1-14-54", "Blk & rust", "Flambeau Rolf W327478 12-53", "Haida of Sanmahr W181223", "J. W. & M. L. Kitts", "Dale G. Sanders"),
    ("Scotlande's Lady Eda", "B", "W404885", "3-1-53", "Blk & rust", "Phylax v Frauenworth W316903", "Cormichael's Ilse W283043", "G. W. & L. M. Wert", "H. E. & M. D. Scott"),
    ("Squire of Fluvanna", "D", "W583218", "7-26-52", "Rust & br", "Ch. Sinbad of Reklaw A933805", "Bonnie of Connell W326607 12-52", "Carolynne J. Schutz", "Robert Connell"),
    ("Stark's Black Beauty", "B", "W518584", "5-31-54", "Blk & tan", "Blitzen of Valhalla W452933 9-54", "Wanda v Trausnitz W499951 9-54", "B. L. & S. Stark", "Mary Schiessl"),
    ("Steb's Captain Treble", "D", "W574306", "9-17-54", "Blk & rust", "Ch. Dortmund Delly's Colonel Jet W313819", "Damasyn the Easter Bonnet W288915", "Peggy R. Lewis", "Natalie G. Stebbins"),
    ("Steb's Sheba", "B", "W545598", "2-1-54", "Blk & tan", "Ch. Ravensburg Atomic W285267", "Princess Nina W323053 6-53", "Richard E. De Nazario", "Natalie C. Stebbins"),
    ("Stormy Dawn of Solbo", "B", "W431023", "7-14-53", "Blk & rust", "Ch. Rancho Dobe's Storm W179626", "Ch. Marc's Diana of Solbo W32723", "Margit M. Anderson", "Owner"),
    ("Tangwald Graf von Arbo", "D", "W425003", "4-29-53", "Blk & tan", "Damasyn the Tang W11054", "Carla v Shacklet W135373", "Mrs. Baron I. Shacklette", "Owner"),
    ("Tangwald Grafin Alisa Freya", "B", "W511092", "4-19-54", "Rd & tan", "Damasyn the Tang W11054", "Carla v Shacklet W135373", "Mrs. Baron I. Shacklette", "Owner"),
    ("Trail'em Red Robin von Hugo", "B", "W530648", "11-28-53", "Rd & rust", "Garry v Klosterholz W5409 C.D.", "Trail'em Flash W130238", "B. L. Van B. Ueltzen", "Ralph T. Miller"),
    ("Trenz Kassel", "D", "W422818", "6-26-53", "Br & tan", "Duke v Altenberg W65905", "Czarina Alexandra W331545 9-53", "Robert McBurnett", "Arthur Colletti"),
    ("Tulsa's Black Satin", "B", "W474911", "4-19-53", "Blk", "Valiant George W265757", "Duchess Hotspur II W339861 12-53", "James J. Dickinson", "Ann V. Fredericks"),
    ("Ursanna's Amy v Kelva", "B", "W442094", "6-16-53", "Br & tan", "Ch. Delegate v d Elbe W70773", "Alma von Adelerbe W196738", "John R. Truse", "John P. Urso"),
    ("Ch. Ventura B Diablo", "D", "W451960", "3-18-53", "Blk & tan", "Ventura A Colonel W330598 6-53", "Rancho Dobe's Manana W138915 U.D.", "Mr. & Mrs. R. M. Willey", "Mr. & Mrs. W. I. Templeton"),
    ("Vixen of Macra", "B", "W594961", "3-14-54", "Rd & rust", "Peter v Gruenwald A869641", "Putzie of Hiegenbloch W255489", "Hugh M. Craven", "J. Leonard Dixon"),
    ("Walyo De Casa Befi", "D", "W550901", "3-23-54", "Br & tan", "Helgra Petroff von Molna W438158 12-53", "Bambi v Mulna A972472", "John Befi", "Domenick C. Lancieri"),
    ("West Begins Countess", "B", "W446879", "9-28-53", "Blk & rust", "Shmerks' Pride von Torn W253938", "Darkee's Hi-Jerri W94881", "J. B. Dickey", "E. A. Black"),
    ("Westerholz Fyfy", "B", "W342803", "5-28-52", "Blk & rust", "Ch. Kama of Westphalia A702330", "Pebbles W110647", "Vito Penny", "Owner"),
    ("Westwind's Jasbo", "D", "W574746", "12-23-53", "Blk & rust", "Salto v Glashof*", "Ehre Maria of Westwind W332213 9-54", "Richard W. Burns", "G. H. Hayes & V. W. Hoskins"),
    ("Westwind's Rastus", "D", "W514241", "10-22-53", "Blk & rust", "Ch. Sheik of Wilmaur W240743", "Westwind's Lira W340224 9-54", "Kenneth McAleer", "V. Hoskins"),
    ("Wildwood's Copper Cognac", "D", "W496885", "3-5-54", "Rd & rust", "Ch. Eric v Allstark W29491", "Missy's Lizette of Wildwood W314502", "Retha A. Bezdek", "Owner"),
    ("Wright's Chris Re", "D", "W447391", "11-1-52", "Blk & rust", "Hallwyre Here's Chick W47417", "Wright's Princess Reta W361097 3-53", "A. Christofferson, Jr.", "Harold A. Wright"),
]

dogs = [make_dog(*row) for row in raw_dogs]

if __name__ == "__main__":
    out_path = Path(__file__).resolve().parent / "data" / "verified_1955_12.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(dogs, f, indent=2, ensure_ascii=False)
    print(f"Verified {len(dogs)} dogs written to {out_path}")
