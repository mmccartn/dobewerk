# AKC Stud Book Archive Downloader

Inventories and downloads public OCR and provenance files for *The American Kennel Club Stud Book Register* from the Internet Archive collection `pub_american-kennel-club-stud-book-register`.

No Internet Archive account or credentials are needed. The tool uses the public Advanced Search API to discover collection items and the Metadata API to obtain each item's available files.

## Files retained

Each volume is stored under `data/volumes/<Internet Archive identifier>/`.

- `*_djvu.xml` is the primary source for future record parsing. It preserves page and word-level OCR structure.
- `*_djvu.txt` is a convenient flattened OCR text copy for search and exploratory processing. It is downloaded by default, but can be excluded.
- `*_meta.xml`, `*_scandata.xml`, `*_page_numbers.json`, and `*_files.xml` retain item, page, and file-inventory provenance.

`data/manifest.json` is the resumable plain-JSON inventory. It records the Archive identifier and metadata, remote file properties, local paths, download status, and local SHA-256 digests. A transient metadata error is retained as `metadata_request_failed` for that item, so a later inventory run can retry it without losing the rest of the manifest.

## Usage

Run commands from this directory.

```bash
python stud_book_archive.py inventory --follow-next-items
python stud_book_archive.py download
```

The public collection search omits some `printdisabled` issues. `--follow-next-items` follows each item's `next_item` metadata link to inventory those otherwise hidden issues. To extend an already inventoried public collection beyond December 1961 without re-inventorying every visible issue, start from the final public identifier:

```bash
python stud_book_archive.py inventory \
  --identifier sim_american-kennel-club-stud-book-register_1961-12_78_12 \
  --follow-next-items
```

To refresh metadata for every existing manifest record and follow every available `next_item` branch, including links absent from the initial public collection search, run:

```bash
python stud_book_archive.py follow-links
```

If a traversal is interrupted, resume after its last safely saved identifier:

```bash
python stud_book_archive.py follow-links --start-after <identifier>
```

Run only one command that writes `data/manifest.json` at a time; do not run `download`, `inventory`, `discover`, or `follow-links` concurrently.

The link chain ends in December 1968. The `discover` command probes the observed monthly identifier pattern through the Metadata API, accepts an item only when its identifier, `sim_pubid`, date, volume, issue, and DjVu XML match, and marks accepted records as `identifier_pattern` in the manifest:

```bash
python stud_book_archive.py discover --year-from 1969 --year-to 2004
```

Build and download a small test subset first:

```bash
python stud_book_archive.py inventory --year-from 1930 --year-to 1930
python stud_book_archive.py download --year-from 1930 --year-to 1930
```

Restrict an inventory or download to one known Internet Archive item:

```bash
python stud_book_archive.py inventory --identifier sim_american-kennel-club-stud-book-register_1930-01-01_47_1
python stud_book_archive.py download --identifier sim_american-kennel-club-stud-book-register_1930-01-01_47_1
```

To refresh Archive metadata immediately before downloading:

```bash
python stud_book_archive.py download --refresh-inventory
```

To keep structured XML and provenance files without flattened OCR text:

```bash
python stud_book_archive.py download --without-text
```

Downloads are validated against the Archive-reported file size, written atomically, and recorded after each file. Re-running `download` skips files whose local SHA-256 and size match the manifest. Failed files are retried on a later run. Files marked private by Internet Archive, or denied with HTTP 401/403, are recorded as `unavailable` and skipped without aborting other downloads.

Use `--delay` to increase the pause between Archive requests and `--retries` to adjust retry attempts. The defaults are a 0.5-second pause and three retries.

## Parser research

The parser tools preserve page-aware OCR provenance and are intentionally limited to inspection and candidate extraction while layouts are being characterized.

```bash
python parser/inspect_stud_book.py \
  sim_american-kennel-club-stud-book-register_1926-01-31_43_1 \
  --search "DOBERMAN" --context 3
```

The initial `monthly_1926_v0` profile recognizes likely record starts in the 1926 monthly layout and writes reviewable JSONL candidates. It retains source item/page/line ranges, original OCR text, raw parent strings, raw birth dates, confidence, and warnings; it does not yet resolve dogs or create the pedigree graph.

```bash
python parser/extract_monthly_1926.py \
  sim_american-kennel-club-stud-book-register_1926-01-31_43_1 \
  --page 50 \
  --output data/parser-output/1926-page-50.jsonl
```
