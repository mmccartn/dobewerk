import re

def clean_ocr(text: str) -> str:
    """Clean common OCR scanning noise that impacts record parsing."""
    t = text.replace(chr(8217), "'").replace(chr(8216), "'")

    # Heal hyphenated word line-wraps across line breaks or spaces:
    # e.g. "Ken- nels" -> "Kennels", "Bowers- ton" -> "Bowerston", "Schwal- bennest" -> "Schwalbennest"
    t = re.sub(r"\b([A-Za-z]{2,})\s*-\s*\n?\s*([a-z]{2,})\b", r"\1\2", t)

    # Clean stray OCR underscores in names and text:
    # e.g. "BERTHA V_STROSSEN" -> "BERTHA V STROSSEN", "DOLPH _V_D" -> "DOLPH V D"
    t = re.sub(r"(?<=[A-Za-z0-9])_(?=[A-Za-z0-9])", " ", t)
    t = re.sub(r"\s+_\s+", " ", t)
    t = re.sub(r"_+", "", t)

    # Join line-wrapped registration numbers across hyphens, spaces, and stray margin symbols
    t = re.sub(r"\(\s*(\d{3})\s*[,.\-\s]+(?:\s*|[\W\d_a-zA-Z]{0,4}\s*)(\d{3})\s*\)", r"(\1,\2)", t)

    # Fix brackets scanned as 'J' e.g. [EANETTE -> JEANETTE
    t = re.sub(r"\n\s*\[([A-Z])", r"\nJ\1", t)
    t = re.sub(r"\n\s*[l|.]\s+([A-Z]{3,})", r"\n\1", t)

    # Registration on a line by itself immediately following sex bracket
    t = re.sub(r"\(([DBE8F]{1,2})\s*f?\s*(?:\n\s*|\s*)[(\[]+([0-9\s,\-*.]+)[)\]]+", r"(\\1) (\\2)", t)
    return t
