#!/usr/bin/env python3
"""Curated direct extractor for Doberman Pinschers in Stud Book Vol 47 Iss 1 (Jan 1, 1930)."""

import json
import re
from pathlib import Path

# Section 1: Printed Page 44, Column 2 (18 dogs)
COL1_TEXT = """
AJAX V TORREZ (D) (713,682)—Mr. and Mrs. E. C. Torrez. (Br) Ernest C. Torrez, Chicago, Ill. (Wh) Feb. 22, 1929. Blk & tn. By Claus v Sigalsburg (600,529, Vol. 44) out of Burga v Torrez (628,206, Vol. 45).
ALTO V TORREZ (D) (713,439)—Mr. and Mrs. E. C. Torrez. (Br) Ernest C. Torrez, Chicago, Ill. (Wh) Feb. 22, 1929. Blk & tn. By Claus v Sigalsburg (600,529, Vol. 44) out of Burga v Torrez (628,206, Vol. 45).
ALYSE V SIGALSBURG (B) (712,472)—M. S. Harrison. (Br) Ernest C. Torrez, Chicago, Ill. (Wh) Feb. 22, 1929. Blk & tn. By Claus v Sigalsburg (600,529, Vol. 44) out of Burga v Torrez (628,206, Vol. 45).
ASTA V DANKWARDERODE (B) (714,983)—J. W. Oltmanns. (Br) Bruno Fechner, Germany. (Wh) Apr. 27, 1923. Blk & rd. By Ador v Mydlinghofen out of Afra v d Hofburg by Jack v Stubbenhaus out of Ledy Weirauch by Marko v Warteberg out of Lotte II Gersbach; Jack v Stubbenhaus by Graf Waldo v d Strengbach out of Gretel v Dusselthal. Ador v Mydlinghofen by Bob v Rhein Erft out of Lotte v d Hof by Jack v Stubbenhaus out of Lotte II Gersbach; Bob v Rhein Erft by Roland Gersbach out of Dinorah v Hornegg.
ASTA V EDJO (B) (713,233)—William Searle. (Br) Joseph C. Blauner, Clifton, N. J. (Wh) Nov. 20, 1925. Blk & tn. By Apollo v Schuetzneck (462,894, Vol. 42) out of Esther v Burgfried (453,438, Vol. 42).
BAUER'S JOY (B) (716,313)—Henry Bauer. (Br) Edward Rose, Queens Village, L. I., N. Y. (Wh) Feb. 27, 1929. Blk, tn mkgs. By Prinz Carlo of Westphalia (517,068, Vol. 43) out of Mona Dora Zoic (412,715, Vol. 41).
BEAUTY V HOMEHILL (B) (716,212)—Mrs. G. A. Rentschler, Hamilton, Ohio. (Br) Owner. (Wh) Nov. 11, 1927. Blk with br mkgs. By Lux v d Blankenburg (571,492, Vol. 44) out of Lady v Homehill (565,329, Vol. 44).
BEAUTY V SEDREVLA (B) (713,492)—Karl P. Graeuwen, Annadale, S. I., N. Y. (Br) Owner. (Wh) Aug. 28, 1928. Blk & tn. By Fritz v Edjo (605,709, Vol. 44) out of Maus v Sedrevla (671,985, Vol. 46).
BEDA V BOHLMAN (B) (715,346)—Glenn S. Staines. (Br) R. C. Reko, Mason City, Ia. (Wh) Dec. 16, 1928. Blk, rd mkgs. By Erlo v d Roemerhof (468,297, Vol. 42) out of Asta v Wiesenfels (683,357, Vol. 46).
BETTY OF WILMETTE (B) (713,304)—William C. Black. (Br) Spencer Otis, Jr., Barrington, Ill. (Wh) Nov. 5, 1926. Rd & tn. By Dragon v Hindendorff (379,450, Vol. 40) out of Gisela v Bayern (502,580, Vol. 43).
BIENE V MEISENHEIN (B) (713,943)—Chas. Herrmann. (Br) Mrs. Elmer Schweninger, Cincinnati, Ohio. (Wh) Sept. 7, 1928. Blk & tn. By Boone v Sigalsburg (658,766, Vol. 45) out of Hamer's Peggy (587,825, Vol. 44).
BINKS (D) (712,217)—Massena Clark. (Br) Harold A. Peck, Albany, N. Y. (Wh) Oct. 16, 1928. Rd & tn. By Benno v Roemerhof (517,073, Vol. 43) out of Chummy (648,332, Vol. 45).
BLITZ V SIGALSBURG (D) (715,138)—S. E. Ochsner, Milwaukee, Wis. (Br) Owner. (Wh) July 1, 1929. Blk & tn. By Claus v Sigalsburg (600,529, Vol. 44) out of Bella v Stolzenberg (337,253, Vol. 39).
BUBINE V GRAMMONT (B) (714,185)—Emilio Marino. (Br) Nicholas Lovece, Brooklyn, N. Y. (Wh) May 27, 1929. Blk & tn. By Edelblut of Arkeden (619,599, Vol. 45) out of Uriana v Waldeck (702,562, Vol. 46).
BURSCHEL V BOHLMAN (D) (714,496)—Edwin J. Randall. (Br) R. C. Reko, Mason City, Ia. (Wh) Dec. 16, 1928. Blk & rd mkgs. By Erlo v d Roemerhof (468,297, Vol. 42) out of Asta v Wiesenfels (683,357, Vol. 46).
CLAUS V HOMEHILL (D) (716,213)—Mrs. G. A. Rentschler, Hamilton, Ohio. (Br) Owner. (Wh) Nov. 11, 1927. Blk with br mkgs. By Lux v d Blankenburg (571,492, Vol. 44) out of Lady v Homehill (565,329, Vol. 44).
CLAUS V STROH (D) (712,122)—Arthur Haberstroh. (Br) Abraham Van De Griek, L. I., N. Y. (Wh) July 2, 1926. Blk & tn. By Claus v d Spree (412,661, Vol. 41) out of Betty v d Hermesburg (496,682, Vol. 43).
CONDE DANILO DE FREYOL (D) (712,426)—R. A. Freyol, Detroit, Mich. (Br) Owner. (Wh) Nov. 6, 1928. Blk & rd. By Figaro v Sigalsburg (647,311, Vol. 45) out of Nuttall's Beauty (608,304, Vol. 44).
"""

# Section 2: Printed Page 44, Column 3 (20 dogs)
COL2_TEXT = """
CONSEDINE'S BALTO (D) (714,091)—C. H. Consedine. (Br) Merton Reed, McKean, Pa. (Wh) Feb. 28, 1929. Rd. By Perry's Hooso v St. Sebald (546,165, Vol. 43) out of Hermine of Mickburn (550,425, Vol. 43).
DIETHELM V CHANTRE (D) (712,210)—Thomas J. McCaffrey. (Br) R. A. Snyder, Oklahoma City, Okla. (Wh) July 22, 1928. Br & rd. By Diethelm v Stresow (480,476, Vol. 42) out of Asta v Kalkental (556,019, Vol. 43).
DORIS OF ARIZONA (B) (713,765)—L. D. Hemman, Phoenix, Ariz. (Br) Owner. (Wh) Jan. 26, 1929. Blk, rust rd. By Judge of Pontchartrain (636,369, Vol. 45) out of Diane of Arizona (639,136, Vol. 45).
ELSBETH OF GRASSINGTON (B) (712,291)—Frederick Wheeler. (Br) J. Austin Bucknall, Detroit, Mich. (Wh) Apr. 29, 1927. Blk & rd. By Westphalia Dyno v Wiesengrund (365,520, Vol. 40) out of Gisela of Pontchartrain (649,685, Vol. 45).
EMIR LENTULUS (D) (714,460)—Frank Blattler. (Br) Gottfried Liechti, Switzerland. (Wh) May 5, 1925. Blk & rd. By Axel Kirchbuhl out of Dely v d Barenburg by Edelblut v Jagerhof out of Miss Berneck by Max Heidenstein out of Helda Lentulus; Edelblut v Jagerhof by Prinz Modern v Ilm Athen out of Tatjana v Jagerhof. Axel Kirchbuhl by Axel v Hindendorff out of Buddy Hambuhl by Max Hambuhl out of Helda Lentulus; Axel v Hindendorff by Zeus Parthengrund out of Asta Starkenburg.
FEDOR V BOHLMAN (D) (713,344)—William E. Johnson. (Br) G. C. Burr, Detroit, Mich. (Wh) Jan. 12, 1928. Blk & tn. By Benno v d Glucksburg (605,000, Vol. 44) out of A Betty of Pontchartrain (439,036, Vol. 41).
FRITZ V BARON (D) (716,435)—Waldo E. Gehring. (Br) Marshall F. Bidwell, South Windsor, Conn. (Wh) Aug. 5, 1929. Rd, tn mkgs. By Gretchen Flash (638,956, Vol. 45) out of Rozeta v Baron (714,011, Vol. 47).
FRITZIE V SCHEFF (B) (713,105)—H. E. A. Doxsee, Jr. (Br) Henry J. Mirbach, Syracuse, N. Y. (Wh) Jan. 27, 1927. Blk & tn. By Tango v Ostersee (421,813, Vol. 41) out of Blanka v Roemerwall (426,934, Vol. 41).
FRITZ V SIGALSBURG (D) (715,137)—S. E. Ochsner, Milwaukee, Wis. (Br) Owner. (Wh) July 1, 1929. Blk & tn. By Claus v Sigalsburg (600,529, Vol. 44) out of Bella v Stolzenberg (337,253, Vol. 39).
GAVAN V STARKANHART (D) (714,861)—F. C. Bowles, Hartville, Ohio. (Br) Owner. (Wh) Sept. 15, 1928. Blk & rd. By Figaro v Sigalsburg (647,311, Vol. 45) out of Rena v Starkanhart (607,477, Vol. 44).
GODELINDE V WITTMUND (B) (714,982)—J. W. Oltmanns. (Br) Albert Schmitte, Germany. (Wh) Dec. 1, 1924. Blk & rd. By Fredi v Jungborn out of Hertha v Ostersee by Salto v Rottal out of Freya v Ostersee by Waldo v d Strengbach out of Wanda Knoll; Salto v Rottal by Roland v d Haide out of Brunhild v Silberberg. Fredi v Jungborn by Astor v Schwalbennest out of Hertha v Ostersee by Salto v Rottal out of Freya v Ostersee; Astor v Schwalbennest by Lux v d Blankenburg out of Desi v Atlantic.
GRETCHEN V EARL (B) (712,123)—Harry P. Earl. (Br) John W. Gage, Monticello, Ill. (Wh) May 7, 1929. Br, rust rd mkgs. By Peter v Roemerhof (616,494, Vol. 45) out of Schwarze Dame (672,699, Vol. 46).
HILDA V SKYEL FISK OER (B) (713,104)—Wilhelmina Silberbauer. (Br) W. J. Ross, Los Angeles, Calif. (Wh) Mar. 8, 1928. Blk & tn. By Eric v Barry (542,592, Vol. 43) out of Princess Dagmar of Denmark (694,126, Vol. 46).
HUERTA V D HORSTBURG (B) (712,028)—Mary C. Wilson. (Br) Ralph T. Miller, W. Philadelphia, Pa. (Wh) Nov. 11, 1927. Blk, rust rd mkgs. By Trail 'Em Horstburg (545,469, Vol. 43) out of Asta v d Frankenfurt (627,856, Vol. 45).
HUGO V D BACH (D) (714,800)—Naomi Hewitt. (Br) Arthur W. Macdonald, Buzzards Bay, Mass. (Wh) Feb. 16, 1928. Blk & tn. By Frederick v d Beck Bach (539,975, Vol. 43) out of Ella v Telless (708,997, Vol. 46).
JACQUELINE OF SPRING VIEW (B) (715,109)—H. E. Stickel. (Br) D. A. Raney, Eaton, Ohio. (Wh) Oct. 29, 1926. Blk & rd brn. By Ariovist v Nibelungenhort (524,279, Vol. 43) out of Mickey of Preble (501,187, Vol. 43).
JERRY OF ARIZONA (D) (713,766)—L. D. Hemman, Phoenix, Ariz. (Br) Owner. (Wh) Jan. 26, 1929. Blk & rust rd. By Judge of Pontchartrain (636,369, Vol. 45) out of Diane of Arizona (639,136, Vol. 45).
JIGGS (D) (715,649)—J. W. Bodley. (Br) Bert Young, Granville, Ohio. (Wh) Aug. 4, 1929. Rd. By Arno v Hohenburg (574,221, Vol. 44) out of Alice Blue Gown (492,047, Vol. 42).
KENTUCKY COLONEL (D) (715,396)—R. A. Goodner. (Br) C. A. Duncan, Paris, Ky. (Wh) Aug. 22, 1929. Blk & tn. By Edmund v Nibelungenhort (419,285, Vol. 41) out of Leedsie v Rottal (393,410, Vol. 40).
KONIG ERICH V D SCHUTZENECK (D) (714,567)—Earle H. Smith. (Br) Walter E. Riggs, Greenville, Ohio. (Wh) Nov. 24, 1928. Blk & tn. By Apollo v d Schuetzeneck (462,894, Vol. 42) out of Ruth v Oldensburg (478,789, Vol. 42).
"""

# Section 3: Printed Page 45, Column 1 & 2 (24 dogs: 23 in col 1, 1 in col 2)
COL3_TEXT = """
LADDIE V CORSAIR (D) (715,970)—B. Clarke. (Br) Mrs. Bernhard Wiesel, West New York, N. J. (Wh) June 29, 1929. Blk & tn. By Arno v Edjo (689,776, Vol. 46) out of Ella v Roemerhof (711,032, Vol. 46).
LADY BELLA V BLANDENBURG (B) (714,799)—Raymond Brown. (Br) J. A. Finnicum, Columbus, Ohio. (Wh) Sept. 19, 1928. Blk, tn mkgs. By Leuthold of Pontchartrain (629,194, Vol. 45) out of Bella of Pontchartrain (578,596, Vol. 44).
LADY V BURGFRIED (B) (712,488)—S. E. Hershey. (Br) John Schofield, Elverson, Pa. (Wh) Aug. 19, 1928. Blk & tn. By Armin v Burgfield (430,843, Vol. 41) out of Countess v Burgholz (449,862, Vol. 42).
MAUDIE (B) (716,441)—R. H. Cummings. (Br) Carl Feuerbacher, Chicago, Ill. (Wh) Oct. 20, 1928. Rd & tn. By Elmar v d Rheinperle (508,311, Vol. 43) out of Dina v d Dreirosenstadt (623,419, Vol. 45).
MITZI V SEDREVLA (B) (713,491)—Mrs. Ile's Graeuwen. (Br) Gus Stoffels, Nutley, N. J. (Wh) Dec. 26, 1928. Rd & tn. By Yvon of Edjo (689,593, Vol. 46) out of Rea of New Jersey (685,584, Vol. 46).
NYMPO FRA DUNCAN (D) (714,010)—G. Sherman. (Br) Walter E. Riggs, Greenville, Ohio. (Wh) Nov. 24, 1928. Blk & tn. By Apollo v d Schuetzeneck (462,894, Vol. 42) out of Ruth v Oldensburg (478,789, Vol. 42).
OXBO BERTA (B) (712,639)—F. C. Fugua, Seattle, Wash. (Br) Owner. (Wh) Feb. 7, 1929. Blk & tn. By Arnold v Minkelried (513,005, Vol. 43) out of Gerti v Hohenschwanau (670,137, Vol. 46).
PAULA GRETEL (B) (713,077)—Arthur L. Edwards. (Br) Benj. F. Earl, Quincy, Mass. (Wh) Nov. 25, 1926. Blk, tn mkgs. By Knight of Tidewater (293,613, Vol. 37) out of Elwin Princess Patsy (545,312, Vol. 43).
PAULI OF PONTCHARTRAIN II (B) (715,345)—Glenn S. Staines. (Br) Frank B. Tanner, Detroit, Mich. (Wh) Sept. 21, 1928. Blk, rd. By Figaro v Sigalsburg (647,311, Vol. 45) out of Lita v Burgholz (671,060, Vol. 46).
PRINCE BARON OF PONTCHARTRAIN (D) (712,155)—G. S. Mawhinney. (Br) Glenn S. Staines, Detroit, Mich. (Wh) Mar. 28, 1929. Blk, rd. By Lux v d Blankenburg (571,492, Vol. 44) out of Freia v d Butersburg of Ardwin (499,561, Vol. 43).
PRINCESS MITZI (B) (715,395)—Mrs. J. Eckle Starnes. (Br) Mignon Preston, Fresno, Calif. (Wh) June 13, 1929. Blk, bronze mkgs. By Guard (700,191, Vol. 46) out of Aimee Semple McPherson (547,816, Vol. 43).
PRINZ LUDWIG OF MIAMI (D) (712,744)—L. S. Crane. (Br) Wm. H. Duffy, Northfield, N. J. (Wh) Apr. 18, 1929. Blk & tn. By Fedor v Buetersburg (539,750, Vol. 43) out of Hildegarde v Doernbach (661,249, Vol. 45).
RIVAL (D) (714,513)—Andrew Nelson. (Br) Oscar L. Simpson, Nashville, Tenn. (Wh) Mar. 29, 1929. Blk & tn. By Ochsner's Son of Rival (612,378, Vol. 45) out of Asta v Nashville (675,400, Vol. 46).
ROZETA V BARON (B) (714,011)—Marshall F. Bidwell, So. Windsor, Conn. (Br) Owner. (Wh) Mar. 20, 1928. Blk, tn mkgs. By Baron v Richtofen (526,664, Vol. 43) out of Adda v Kanonenstadt (534,153, Vol. 43).
SALLY (B) (713,971)—Emily F. Lidster. (Br) Mickburn Kennels, Eldorado, Ill. (Wh) Dec. 31, 1927. Blk & rd. By Red Roof Rowdy (392,482, Vol. 40) out of Arabella of Mickburn (550,427, Vol. 43).
SENTA V TECKLENBURG (B) (713,600)—Hugo Brenninkmeyer. (Br) Anton M. Jaschke, Springfield, Ill. (Wh) Apr. 22, 1927. Blk & tn. By Benno v Burgholz (393,913, Vol. 40) out of Gretta of Mickburn (486,005, Vol. 42).
SOPHIA V JAGERHOF (B) (715,741)—John Caldwell Smith. (Br) E. DeL. Fouque, Media, Pa. (Wh) May 13, 1929. Blk & tn. By Red Roof Rufus (491,422, Vol. 42) out of Babette v Jagerhof (521,089, Vol. 43).
STURKO'S BEAUTY (B) (713,764)—Martin E. Sturko. (Br) Phil Hagerman, Chicago, Ill. (Wh) July 15, 1928. Blk & tn. By Asko v Bolanden (432,279, Vol. 41) out of Princess Bea v Silverberg (403,875, Vol. 41).
TAMAR V TILHAGEN (B) (714,860)—F. C. Bowles, Hartville, Ohio. (Br) Owner. (Wh) Apr. 27, 1928. Blk, rd. By Westphalia Dyno v Wiesengrund (365,520, Vol. 40) out of Arrah v Tilhagen (658,426, Vol. 45).
TENA OF PONTCHARTRAIN (B) (715,343)—William L. Pease. (Br) Glenn S. Staines, Detroit, Mich. (Wh) Feb. 6, 1929. Blk, rd. By Figaro v Sigalsburg (647,311, Vol. 45) out of Neba v Streslau (539,722, Vol. 43).
TOLLA OF PONTCHARTRAIN (B) (715,342)—Glenn S. Staines, Detroit, Mich. (Br) Owner. (Wh) Feb. 6, 1929. Blk, rd. By Figaro v Sigalsburg (647,311, Vol. 45) out of Neba v Streslau (539,722, Vol. 43).
TRAIL 'EM RIFF OF ADONIS (D) (713,763)—Lillian M. Rahner. (Br) Frank X. Simon, Philadelphia, Pa. (Wh) Aug. 1, 1929. Br, rust rd. By Trail 'Em Adonis (709,104, Vol. 46) out of Lady Kwik (707,649, Vol. 46).
VON WEDON'S MAX SCHUESS (D) (716,479)—Walter E. Donovan. (Br) Helene O. Bernard, Brookline, Mass. (Wh) Feb. 20, 1929. Blk & tn. By Edelblut of Westphalia (535,468, Vol. 43) out of Hexie's Marga (535,613, Vol. 43).
VON WEDON'S MOTTE SCHUESS (B) (716,478)—Mrs. Walter E. Donovan. (Br) Helene Bernard, Brookline, Mass. (Wh) Feb. 20, 1929. Rd & tn. By Edelblut of Westphalia (535,468, Vol. 43) out of Hexie's Marga (535,613, Vol. 43).
"""


def split_name_location(s: str) -> tuple[str, str]:
    """Separate entity name from city/state/country location."""
    s = s.strip().rstrip(".")
    if not s or s.lower() == "owner":
        return s, ""
    parts = [p.strip() for p in s.split(",")]
    if len(parts) == 1:
        return parts[0], ""
    elif len(parts) == 2:
        return parts[0], parts[1]
    else:
        if parts[1].strip() in ("Jr.", "Jr", "Sr.", "Sr", "III", "II"):
            name = f"{parts[0]}, {parts[1]}"
            loc = ", ".join(parts[2:])
            return name, loc
        else:
            name = parts[0]
            loc = ", ".join(parts[1:])
            return name, loc


def parse_pedigree(ped_text: str) -> tuple[str, str | None, str, str | None, str | None]:
    """Parse sire, dam, registrations, and extended multi-generation pedigree."""
    text = ped_text.strip()
    # Remove leading By
    text = re.sub(r"^(?:By\s+)+", "", text, flags=re.IGNORECASE).strip()

    # Split on 'out of'
    m = re.match(r"^(.*?)\s+out of\s+(.+)$", text, flags=re.IGNORECASE)
    if not m:
        return text, None, "", None, None

    sire_part = m.group(1).strip()
    dam_part = m.group(2).strip()

    # Multi-generation pedigree attached to dam begins with lowercase ' by '
    extended_ancestry = None
    by_idx = dam_part.find(" by ")
    if by_idx != -1:
        extended_ancestry = dam_part[by_idx + 1:].strip().rstrip(".")
        dam_part = dam_part[:by_idx].strip()

    # Parse sire registration and name
    sire_reg_m = re.search(r"\((\d{3}[\s,]*\d{3})", sire_part)
    sire_reg = re.sub(r"[^\d]", "", sire_reg_m.group(1)) if sire_reg_m else None
    sire_clean = re.sub(r"\(.*?\)", "", sire_part).strip().rstrip(".").rstrip(",")
    sire_clean = re.sub(r"\s+", " ", sire_clean)

    # Parse dam registration and name
    dam_reg_m = re.search(r"\((\d{3}[\s,]*\d{3})", dam_part)
    dam_reg = re.sub(r"[^\d]", "", dam_reg_m.group(1)) if dam_reg_m else None
    dam_clean = re.sub(r"\(.*?\)", "", dam_part).strip().rstrip(".").rstrip(",").strip()
    dam_clean = re.sub(r"\s+", " ", dam_clean)

    return sire_clean, sire_reg, dam_clean, dam_reg, extended_ancestry


def parse_entries(text: str, default_page: int, default_col: int) -> list[dict]:
    entries = []
    lines = [l.strip() for l in text.strip().splitlines() if l.strip()]
    for idx, line in enumerate(lines):
        m = re.match(r"^(.+?)\s*\(([DB])\)\s*\((\d{3},\d{3})\)[—-](.+)$", line)
        if not m:
            raise ValueError(f"Line {idx} did not match pattern: {line}")
        name = m.group(1).strip()
        sex = "Male" if m.group(2) == "D" else "Female"
        reg = m.group(3).replace(",", "")
        rest = m.group(4).strip()

        # Parse owner
        owner_m = re.match(r"^(.*?)\.\s*\(Br\)", rest)
        owner_raw = owner_m.group(1).strip() if owner_m else ""
        owner_name, owner_loc = split_name_location(owner_raw)

        # Parse breeder
        breeder_m = re.search(r"\(Br\)\s*(.*?)\.\s*\(Wh\)", rest)
        breeder_raw = breeder_m.group(1).strip() if breeder_m else ""
        breeder_name, breeder_loc = split_name_location(breeder_raw)

        # Parse whelped date, color, and pedigree
        wh_m = re.search(r"\(Wh\)\s*([A-Za-z]+\.?\s+\d{1,2},\s+\d{4})\.?\s*(.*?)\.\s*By\s*(.+)$", rest, re.IGNORECASE)
        if not wh_m:
            raise ValueError(f"Could not parse (Wh)/Color/By in: {rest}")
        whelped = wh_m.group(1).strip()
        color = wh_m.group(2).strip().rstrip(".")
        pedigree_text = wh_m.group(3).strip()

        sire_name, sire_reg, dam_name, dam_reg, ext_ancestry = parse_pedigree(pedigree_text)

        # Printed page & column
        page = default_page
        col = default_col
        if default_page == 45:
            col = 2 if name == "VON WEDON'S MOTTE SCHUESS" else 1

        record = {
            "registration_number": reg,
            "name": name,
            "sex": sex,
            "color": color,
            "birth_date": whelped,
            "owner": owner_name,
            "owner_location": owner_loc if owner_loc else None,
            "breeder": breeder_name,
            "breeder_location": breeder_loc if breeder_loc else None,
            "sire": sire_name,
            "sire_registration_number": sire_reg,
            "dam": dam_name,
            "dam_registration_number": dam_reg,
            "source": {
                "identifier": "sim_american-kennel-club-stud-book-register_1930-01-01_47_1",
                "volume": 47,
                "issue": 1,
                "date": "1930-01-01",
                "printed_page": page,
                "column": col,
            }
        }
        if ext_ancestry:
            record["extended_ancestry"] = ext_ancestry

        entries.append(record)
    return entries


def main():
    col1 = parse_entries(COL1_TEXT, 44, 2)
    col2 = parse_entries(COL2_TEXT, 44, 3)
    col3 = parse_entries(COL3_TEXT, 45, 1)

    all_records = col1 + col2 + col3
    print(f"Column 1 (p44 col 2): {len(col1)} dogs")
    print(f"Column 2 (p44 col 3): {len(col2)} dogs")
    print(f"Column 3 (p45 col 1 & 2): {len(col3)} dogs")
    print(f"Total extracted: {len(all_records)} dogs")

    out_file = Path(__file__).resolve().parent / "data" / "doberman_1930_01_extracted.json"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    out_file.write_text(
        json.dumps({
            "source": {
                "identifier": "sim_american-kennel-club-stud-book-register_1930-01-01_47_1",
                "volume": 47,
                "issue": 1,
                "date": "1930-01-01",
                "breed": "Pinschers (Doberman)",
                "total_records": len(all_records),
                "columns": {
                    "page_44_col_2": len(col1),
                    "page_44_col_3": len(col2),
                    "page_45_col_1": 23,
                    "page_45_col_2": 1,
                }
            },
            "records": all_records,
        }, indent=2),
        encoding="utf-8"
    )
    print(f"Successfully saved clean output to {out_file}")


if __name__ == "__main__":
    main()
