#!/usr/bin/env python3
"""Batch extract Doberman Pinschers across all downloaded AKC Stud Book volumes (1908-1961+)."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

# Pattern for monthly format records (1926+):
# E.g.: AJAX V TORREZ (D) (713,682)—Mr. and Mrs. E. C. Torrez. (Br) ...
MONTHLY_HEADER = re.compile(
    r"^([A-Z0-9\s\.\'\-_]+?)\s*\(([DB])\)\s*[\(\[]?(\d[\d,\s\-\*]*\d)[\)\]]?[—\-\.\s\?]+(.+)$",
    re.MULTILINE
)

# Pattern for annual format records (1908-1925):
# E.g.: BOB OF GLIMMERGLEN (215,082)—W. Truslow Hyde, Jr. ...
# Under DOGS. or BITCHES. sections
ANNUAL_HEADER = re.compile(
    r"^([A-Z0-9\s\.\'\-_]{3,50}?)\s*[\(\[](\d{3}[\s,]*\d{3})[\)\]][—\-\.\s\?]+(.+)$",
    re.MULTILINE
)

# Breeds that typically follow Doberman Pinschers in Stud Book register alphabetical order
FOLLOWING_BREEDS = [
    "CHANGES OF OWNERSHIP",
    "CHANGE OF OWNERSHIP",
    "TRANSFERS",
    "CANCELLATIONS",
    "CORRECTIONS",
    "BENCH SHOWS",
    "ENGLISH TOY SPANIELS",
    "ESKIMOS",
    "FOXHOUNDS",
    "FRENCH BULLDOGS",
    "GERMAN SHEEPDOGS",
    "GREAT DANES",
    "GREYHOUNDS",
    "GRIFFONS",
    "PINSCHERS (WIRE-HAIRED)",
    "PINSCHER (WIRE-HAIRED)",
    "WIRE-HAIRED PINSCHERS",
    "PINSCHERS (MINIATURE)",
    "PINSCHER (MINIATURE)",
    "PINSCHERS (SCHNAUZER)",
    "PINSCHER (SCHNAUZER)",
    "MINIATURE PINSCHERS",
    "POINTERS",
    "POMERANIANS",
    "POODLES",
    "PUGS",
    "RETRIEVERS",
    "ROTTWEILERS",
    "RUSSIAN WOLFHOUNDS",
    "SAMOYEDES",
    "SCHIPPERKES",
    "SCHNAUZERS",
    "SCOTTISH TERRIERS",
    "SETTERS",
    "SHEPHERD DOGS",
    "ST. BERNARDS"
]


def split_name_location(s: str) -> tuple[str, str | None]:
    """Separate person/kennel name from city/state/country location."""
    s = s.strip().rstrip(".")
    if not s or s.lower() == "owner":
        return s, None
    parts = [p.strip() for p in s.split(",")]
    if len(parts) == 1:
        return parts[0], None
    elif len(parts) == 2:
        return parts[0], parts[1]
    else:
        if parts[1].strip() in ("Jr.", "Jr", "Sr.", "Sr", "III", "II"):
            name = f"{parts[0]}, {parts[1]}"
            loc = ", ".join(parts[2:])
            return name, loc
        else:
            name = parts[0]
            loc = ", ".join(parts[1:])
            return name, loc


def parse_pedigree(ped_text: str) -> tuple[str, str | None, str, str | None, str | None]:
    """Parse sire, dam, registration numbers, and extended ancestry."""
    text = ped_text.strip()
    text = re.sub(r"^(?:By\s+)+", "", text, flags=re.IGNORECASE).strip()

    m = re.match(r"^(.*?)\s+out of\s+(.+)$", text, flags=re.IGNORECASE)
    if not m:
        sire_reg_m = re.search(r"\((\d{3}[\s,]*\d{3})", text)
        sire_reg = re.sub(r"[^\d]", "", sire_reg_m.group(1)) if sire_reg_m else None
        sire_clean = re.sub(r"\(.*?\)", "", text).strip().rstrip(".").rstrip(",")
        return sire_clean, sire_reg, "", None, None

    sire_part = m.group(1).strip()
    dam_part = m.group(2).strip()

    extended_ancestry = None
    by_idx = dam_part.find(" by ")
    if by_idx != -1:
        extended_ancestry = dam_part[by_idx + 1:].strip().rstrip(".")
        dam_part = dam_part[:by_idx].strip()

    sire_reg_m = re.search(r"\((\d{3}[\s,]*\d{3})", sire_part)
    sire_reg = re.sub(r"[^\d]", "", sire_reg_m.group(1)) if sire_reg_m else None
    sire_clean = re.sub(r"\(.*?\)", "", sire_part).strip().rstrip(".").rstrip(",")
    sire_clean = re.sub(r"\s+", " ", sire_clean)

    dam_reg_m = re.search(r"\((\d{3}[\s,]*\d{3})", dam_part)
    dam_reg = re.sub(r"[^\d]", "", dam_reg_m.group(1)) if dam_reg_m else None
    dam_clean = re.sub(r"\(.*?\)", "", dam_part).strip().rstrip(".").rstrip(",").strip()
    dam_clean = re.sub(r"\s+", " ", dam_clean)

    return sire_clean, sire_reg, dam_clean, dam_reg, extended_ancestry


def extract_record_details(
    name: str,
    sex: str,
    reg: str,
    rest_text: str,
    vol_meta: dict[str, Any]
) -> dict[str, Any]:
    """Parse owner, breeder, date, color, and parents from entry text."""
    rest = re.sub(r"\s+", " ", rest_text.strip())

    # Owner
    owner_m = re.search(r"^(.*?)(?:\.|\s)\s*(?:\(Br\)|Breeder[s]?[\,\.]\s*)", rest)
    owner_raw = owner_m.group(1).strip() if owner_m else ""
    owner_name, owner_loc = split_name_location(owner_raw)

    # Breeder
    breeder_m = re.search(r"(?:\(Br\)|Breeder[s]?[\,\.]\s*)(.*?)(?:\.|\s)\s*(?:\(Wh\)|Whelped\s+)", rest)
    breeder_raw = breeder_m.group(1).strip() if breeder_m else ""
    breeder_name, breeder_loc = split_name_location(breeder_raw)

    # Whelped & Color
    wh_m = re.search(
        r"(?:\(Wh\)|Whelped\s+)\s*([A-Za-z]+\.?\s+\d{1,2},?\s+\d{4})\.?\s*(.*?)\.\s*By\s+(.+)$",
        rest,
        re.IGNORECASE
    )
    if wh_m:
        whelped = wh_m.group(1).strip()
        color = wh_m.group(2).strip().rstrip(".")
        pedigree_text = wh_m.group(3).strip()
    else:
        # Fallback date search
        date_fallback = re.search(r"(?:Whelped|\(Wh\))\s*([A-Za-z]+\.?\s+\d{1,2},?\s+\d{4})", rest)
        whelped = date_fallback.group(1).strip() if date_fallback else None
        color = None
        by_fallback = re.search(r"\bBy\s+(.+)$", rest, re.IGNORECASE)
        pedigree_text = by_fallback.group(1).strip() if by_fallback else ""

    sire_name, sire_reg, dam_name, dam_reg, ext_ancestry = parse_pedigree(pedigree_text)

    record: dict[str, Any] = {
        "registration_number": reg,
        "name": name,
        "sex": sex,
        "color": color,
        "birth_date": whelped,
        "owner": owner_name,
        "owner_location": owner_loc,
        "breeder": breeder_name,
        "breeder_location": breeder_loc,
        "sire": sire_name,
        "sire_registration_number": sire_reg,
        "dam": dam_name,
        "dam_registration_number": dam_reg,
        "source": {
            "identifier": vol_meta.get("identifier"),
            "date": vol_meta.get("date"),
            "volume": vol_meta.get("volume"),
            "issue": vol_meta.get("issue"),
        }
    }
    if ext_ancestry:
        record["extended_ancestry"] = ext_ancestry
    return record


def find_doberman_sections(txt: str) -> list[tuple[int, int, str]]:
    """Locate all candidate primary Doberman registration sections in a volume's text."""
    sections = []
    # Match breed heading variants
    heading_patterns = [
        re.compile(r"\n\s*(PINSCHERS\s*\(DOBERMAN\))\s*\n", re.IGNORECASE),
        re.compile(r"\n\s*(DOBERMAN\s*PINSCHERS)\s*\n", re.IGNORECASE),
        re.compile(r"\n\s*(PINSCHERS\s*[—\-]\s*DOBERMAN)\s*\n", re.IGNORECASE),
        re.compile(r"\n\s*(PINSCHER\s*[—\-]\s*DOG\.)\s*\n", re.IGNORECASE),
        re.compile(r"\n\s*(PINSCHERS\s*\n\s*DOGS\.)\s*\n", re.IGNORECASE),
    ]

    all_matches = []
    for pat in heading_patterns:
        for m in pat.finditer(txt):
            all_matches.append((m.start(), m.end(), m.group(1).strip()))

    all_matches.sort(key=lambda x: x[0])

    last_end = 0
    for m_start, m_end, h_name in all_matches:
        if m_start < last_end:
            continue

        start = m_end
        # Verify this is not in "Transfers" or "Show awards" or "Bench shows" or "Changes of Ownership"
        prev_context = txt[max(0, m_start - 1000):m_start].upper()
        if any(k in prev_context for k in ("BENCH SHOWS", "CHAMPIONS OF RECORD", "TRANSFERS", "CHANGES OF OWNERSHIP", "CHANGE OF OWNERSHIP")):
            continue

        # Check immediate 600 characters after heading to ensure it's not a change of ownership
        next_sample = txt[start:start + 600]
        if re.search(r"\bto\s+[A-Z]", next_sample) and ("Ownership" in next_sample or "See pedigree" in next_sample or "pedigree in" in next_sample):
            continue
        if "OWNERSHIP CHANGED" in next_sample.upper():
            continue

        # Find end of section: next breed heading
        end = len(txt)
        for fb in FOLLOWING_BREEDS:
            # Look for breed heading on its own line
            fb_m = re.search(rf"\n\s*{re.escape(fb)}\s*\n", txt[start:start + 250_000], re.IGNORECASE)
            if fb_m:
                cand_end = start + fb_m.start()
                if cand_end < end:
                    end = cand_end

        # If section length is reasonable (at least 200 chars and under 250k chars)
        if 200 < (end - start) < 250_000:
            sections.append((start, end, h_name))
            last_end = end

    return sections


def extract_volume(vol_path: Path, manifest: dict[str, Any]) -> list[dict[str, Any]]:
    """Extract all Doberman registrations from a single volume directory."""
    txt_files = list(vol_path.glob("*_djvu.txt"))
    if not txt_files:
        return []
    txt = txt_files[0].read_text(encoding="utf-8", errors="replace")
    meta = manifest.get("items", {}).get(vol_path.name, {
        "identifier": vol_path.name,
        "date": "",
        "volume": "",
        "issue": ""
    })

    sections = find_doberman_sections(txt)
    if not sections:
        return []

    records = []
    seen_regs: set[str] = set()

    for start, end, heading in sections:
        chunk = txt[start:end]

        # 1. Try Monthly pattern (1926+)
        m_matches = list(MONTHLY_HEADER.finditer(chunk))
        if m_matches:
            for idx, m in enumerate(m_matches):
                name = re.sub(r"\s+", " ", m.group(1).replace("\n", " ")).strip()
                # Clean up leading dots/dashes from OCR
                name = re.sub(r"^[\.\-\s\=]+", "", name)
                sex = "Male" if m.group(2) == "D" else "Female"
                reg = re.sub(r"[^\d]", "", m.group(3))
                if not reg or len(reg) < 5 or reg in seen_regs:
                    continue

                # Content between this match and next match
                chunk_start = m.end(3)
                chunk_end = m_matches[idx + 1].start() if idx + 1 < len(m_matches) else len(chunk)
                rest_content = chunk[chunk_start:chunk_end]

                rec = extract_record_details(name, sex, reg, rest_content, meta)
                seen_regs.add(reg)
                records.append(rec)
            continue

        # 2. Try Annual pattern (1908-1925)
        # Check subheadings for DOGS vs BITCHES
        subsections = []
        dogs_idx = re.search(r"\b(?:DOGS|PINSCHER[—\-]DOG)\b", chunk, re.IGNORECASE)
        bitches_idx = re.search(r"\b(?:BITCHES|PINSCHER[—\-]BITCH)\b", chunk, re.IGNORECASE)

        if dogs_idx and bitches_idx:
            if dogs_idx.start() < bitches_idx.start():
                subsections.append((dogs_idx.end(), bitches_idx.start(), "Male"))
                subsections.append((bitches_idx.end(), len(chunk), "Female"))
            else:
                subsections.append((bitches_idx.end(), dogs_idx.start(), "Female"))
                subsections.append((dogs_idx.end(), len(chunk), "Male"))
        elif dogs_idx:
            subsections.append((dogs_idx.end(), len(chunk), "Male"))
        elif bitches_idx:
            subsections.append((bitches_idx.end(), len(chunk), "Female"))
        else:
            subsections.append((0, len(chunk), "Unknown"))

        for s_start, s_end, default_sex in subsections:
            sub_chunk = chunk[s_start:s_end]
            a_matches = list(ANNUAL_HEADER.finditer(sub_chunk))
            for idx, m in enumerate(a_matches):
                name = re.sub(r"\s+", " ", m.group(1).replace("\n", " ")).strip()
                name = re.sub(r"^(?:DOGS\.|BITCHES\.|PINSCHERS?\b|DOBERMAN\b|ADDENDA\b|\.|\-|\=|\s)+", "", name, flags=re.IGNORECASE).strip()
                name = re.sub(r"^[\.\-\s\=]+", "", name)
                reg = re.sub(r"[^\d]", "", m.group(2))
                if not reg or len(reg) < 5 or reg in seen_regs:
                    continue

                chunk_start = m.end(2)
                chunk_end = a_matches[idx + 1].start() if idx + 1 < len(a_matches) else len(sub_chunk)
                rest_content = sub_chunk[chunk_start:chunk_end]

                rec = extract_record_details(name, default_sex, reg, rest_content, meta)
                seen_regs.add(rec["registration_number"])
                records.append(rec)

    return records


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--volumes-dir", type=Path, default=Path(__file__).resolve().parent / "data" / "volumes")
    parser.add_argument("--manifest", type=Path, default=Path(__file__).resolve().parent / "data" / "manifest.json")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / "data" / "extracted_dobermans.jsonl")
    parser.add_argument("--summary", type=Path, default=Path(__file__).resolve().parent / "data" / "extracted_dobermans_summary.json")
    parser.add_argument("--limit", type=int, default=None, help="Limit number of volumes processed for testing")
    parser.add_argument("--year-from", type=int, default=None, help="Filter starting year")
    parser.add_argument("--year-to", type=int, default=None, help="Filter ending year")
    args = parser.parse_args()

    manifest = json.loads(args.manifest.read_text(encoding="utf-8")) if args.manifest.exists() else {}
    vol_dirs = sorted([d for d in args.volumes_dir.iterdir() if d.is_dir() and any(d.glob("*_djvu.txt"))])

    # Filter years if specified
    filtered_vols = []
    for d in vol_dirs:
        m = re.search(r"(\d{4})", d.name)
        yr = int(m.group(1)) if m else None
        if args.year_from and (yr is None or yr < args.year_from):
            continue
        if args.year_to and (yr is None or yr > args.year_to):
            continue
        filtered_vols.append(d)

    if args.limit:
        filtered_vols = filtered_vols[:args.limit]

    print(f"Processing {len(filtered_vols)} volumes...", flush=True)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    all_extracted_count = 0
    volume_stats = []

    with args.output.open("w", encoding="utf-8") as out_file:
        for idx, vol_dir in enumerate(filtered_vols, start=1):
            records = extract_volume(vol_dir, manifest)
            for rec in records:
                out_file.write(json.dumps(rec) + "\n")
            all_extracted_count += len(records)
            if records:
                print(f"[{idx}/{len(filtered_vols)}] {vol_dir.name}: {len(records)} dogs", flush=True)
                volume_stats.append({
                    "volume": vol_dir.name,
                    "records_count": len(records),
                })
            elif idx % 25 == 0:
                print(f"[{idx}/{len(filtered_vols)}] Checked {idx} volumes (Total dogs so far: {all_extracted_count:,})", flush=True)

    summary_data = {
        "total_volumes_scanned": len(filtered_vols),
        "volumes_with_records": len(volume_stats),
        "total_records_extracted": all_extracted_count,
        "volume_breakdown": volume_stats,
    }
    args.summary.write_text(json.dumps(summary_data, indent=2), encoding="utf-8")
    print(f"\nExtraction complete! Total {all_extracted_count:,} Doberman records written to {args.output}")
    print(f"Summary written to {args.summary}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
