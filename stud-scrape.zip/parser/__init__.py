"""Tools for inspecting and extracting AKC Stud Book OCR."""
