#!/usr/bin/env python3
"""Batch extract 1926 Doberman observations into SQLite and a Markdown summary."""

from __future__ import annotations

import argparse
import json
import sqlite3
from collections import Counter
from pathlib import Path

try:
    from .profiles.monthly_1926_v2 import NAME, extract
except ImportError:
    from profiles.monthly_1926_v2 import NAME, extract

BREED = "Pinschers (Doberman)"
COORDINATE_PAGES = {
    "sim_american-kennel-club-stud-book-register_1926-12-31_43_12": {42},
}


def issue_identifiers(manifest_path: Path) -> list[str]:
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    return sorted(
        identifier
        for identifier, item in manifest["items"].items()
        if str(item.get("date", "")).startswith("1926")
    )


def create_schema(connection: sqlite3.Connection) -> None:
    connection.executescript(
        """
        CREATE TABLE observations (
            id INTEGER PRIMARY KEY,
            source_item TEXT NOT NULL,
            source_page INTEGER NOT NULL,
            source_column INTEGER,
            entry_ordinal INTEGER NOT NULL,
            profile TEXT NOT NULL,
            name TEXT,
            registration_number TEXT,
            sex TEXT,
            birth_date_raw TEXT,
            sire TEXT,
            sire_registration_number TEXT,
            dam TEXT,
            dam_registration_number TEXT,
            confidence REAL NOT NULL,
            warnings_json TEXT NOT NULL,
            record_json TEXT NOT NULL,
            UNIQUE(source_item, source_page, source_column, entry_ordinal)
        );
        CREATE INDEX observations_registration_idx ON observations(registration_number);
        CREATE INDEX observations_sire_registration_idx ON observations(sire_registration_number);
        CREATE INDEX observations_dam_registration_idx ON observations(dam_registration_number);
        """
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=Path("data/manifest.json"))
    parser.add_argument("--volumes-dir", type=Path, default=Path("data/volumes"))
    parser.add_argument("--output", type=Path, default=Path("data/observations/monthly_1926_doberman.sqlite"))
    parser.add_argument("--summary", type=Path, default=Path("data/observations/monthly_1926_doberman_summary.md"))
    parser.add_argument("--replace", action="store_true", help="Replace an existing observation database")
    args = parser.parse_args()

    identifiers = issue_identifiers(args.manifest)
    if not identifiers:
        parser.error("No 1926 items found in manifest")
    if args.output.exists() and not args.replace:
        parser.error(f"Output already exists: {args.output}; use --replace to overwrite it")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        args.output.unlink()
    warning_counts: Counter[str] = Counter()
    issue_counts: dict[str, int] = {}
    connection = sqlite3.connect(args.output)
    try:
        create_schema(connection)
        for issue_index, identifier in enumerate(identifiers, start=1):
            print(f"[{issue_index}/{len(identifiers)}] Extracting {identifier}", flush=True)
            records = extract(
                identifier,
                args.volumes_dir,
                BREED,
                coordinate_pages=COORDINATE_PAGES.get(identifier, set()),
            )
            issue_counts[identifier] = len(records)
            for ordinal, record in enumerate(records, start=1):
                dog = record["dog"]
                parents = record["parents"]
                warnings = record["warnings"]
                warning_counts.update(warnings)
                connection.execute(
                    """
                    INSERT INTO observations (
                        source_item, source_page, source_column, entry_ordinal, profile,
                        name, registration_number, sex, birth_date_raw,
                        sire, sire_registration_number, dam, dam_registration_number,
                        confidence, warnings_json, record_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        identifier,
                        record["source_page"],
                        record.get("source_column"),
                        ordinal,
                        NAME,
                        dog.get("name", ""),
                        dog.get("registration_number", ""),
                        dog.get("sex", ""),
                        dog.get("birth_date_raw", ""),
                        parents.get("sire", ""),
                        parents.get("sire_registration_number", ""),
                        parents.get("dam", ""),
                        parents.get("dam_registration_number", ""),
                        record["confidence"],
                        json.dumps(warnings),
                        json.dumps(record, ensure_ascii=False),
                    ),
                )
        connection.commit()
        total = sum(issue_counts.values())
        warnings_total = sum(warning_counts.values())
        summary = [
            "# 1926 Doberman Batch Summary",
            "",
            f"Profile: `{NAME}`  ",
            f"Issues processed: **{len(identifiers)}**  ",
            f"Observations extracted: **{total}**  ",
            f"Warnings emitted: **{warnings_total}**",
            "",
            "## Observations by issue",
            "",
        ]
        summary.extend(f"- `{identifier}`: {count}" for identifier, count in issue_counts.items())
        summary.extend(["", "## Warning counts", ""])
        summary.extend(f"- `{warning}`: {count}" for warning, count in warning_counts.most_common())
        args.summary.write_text("\n".join(summary) + "\n", encoding="utf-8", newline="\n")
    finally:
        connection.close()
    print(f"Wrote {args.output} and {args.summary}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
