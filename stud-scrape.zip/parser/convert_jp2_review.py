#!/usr/bin/env python3
"""Convert JP2 Stud Book scans into viewable PNG review images."""

from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, nargs="+", help="JP2 image files")
    parser.add_argument("--output-dir", type=Path, default=Path("data/jp2/review"))
    parser.add_argument("--max-width", type=int, default=0, help="Optional downscale width for review")
    args = parser.parse_args()

    if args.max_width < 0:
        parser.error("--max-width must be non-negative")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for input_path in args.input:
        if not input_path.is_file():
            parser.error(f"JP2 image not found: {input_path}")
        with Image.open(input_path) as image:
            review_image = image.copy()
            if args.max_width and review_image.width > args.max_width:
                height = round(review_image.height * args.max_width / review_image.width)
                review_image = review_image.resize((args.max_width, height), Image.Resampling.LANCZOS)
            output_path = args.output_dir / f"{input_path.stem}.png"
            review_image.save(output_path, format="PNG", optimize=True)
            print(f"Wrote {output_path} ({review_image.width}x{review_image.height})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
