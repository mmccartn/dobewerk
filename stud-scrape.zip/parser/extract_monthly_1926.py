#!/usr/bin/env python3
"""Extract reviewable candidate records from the 1926 monthly Stud Book layout."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

try:
    from .inspect_stud_book import OcrPage, iter_pages, resolve_xml_path
except ImportError:
    from inspect_stud_book import OcrPage, iter_pages, resolve_xml_path

ENTRY_PATTERN = re.compile(
    r"^(?P<name>[A-Z][A-Z0-9'’ .,&\-]+?)\s+\(+?(?P<sex>[A-Z]{1,2})\)\s+\((?P<registration>[0-9, .\-]+?)(?P<registration_closer>\)|(?=\s+[A-Z]))[—�-]?\s*(?P<remainder>.*)$"
)
ENTRY_START_PATTERN = re.compile(
    r"(?P<name>[A-Z][A-Z0-9'’ .,&\-]+?)\s+\(+?(?P<sex>[A-Z]{1,2})\)\s+\((?P<registration>[0-9, .\-]+?)(?:\)|(?=\s+[A-Z]))"
)
DAMAGED_ENTRY_START_PATTERN = re.compile(
    r"(?P<name>[A-Z][A-Z0-9'’ .&\-]*\s+[vV]\s+[A-Z][A-Z0-9'’ .&\-]+?)\s*\)\s*,(?=.{0,100}\(?Br\))"
)
OCR_DAMAGED_ENTRY_START_PATTERN = re.compile(
    r"(?P<name>[A-Z][A-Z0-9'’.\-]{2,}(?:\s+[A-Z][A-Z0-9'’ .&\-]+?)+)\s*(?:\([A-Z0-9 .><]{0,6}\)|[),.>])(?=.{0,120}\(?Br\))"
)
STRUCTURAL_ENTRY_LINE_PATTERN = re.compile(
    r"^(?P<name>[A-Z][A-Z0-9'’ .&*\-]+?)\s+\(+[BD]\)(?=\s|$)"
)
BREED_PATTERN = re.compile(r"^[A-Z][A-Za-z'’ .\-]+(?:\s+\([A-Za-z'’ .\-]+\))?$")
BREED_CONNECTIVE_PATTERN = re.compile(r"\b(?:by|out of)\b", re.IGNORECASE)
SEX_SUFFIX_PATTERN = re.compile(r"\s+\([BD]\)$")
WHELPED_PATTERN = re.compile(r"\(Wh\)\s+(?P<date>[A-Z][a-z]+\.?\s+\d{1,2}[,.]\s+\d{4})")
FALLBACK_DATE_PATTERN = re.compile(r"\b(?P<date>[A-Z][a-z]+\.?\s+\d{1,2}[,.]\s+\d{4})")
ENTRY_METADATA_PATTERN = re.compile(
    r"^[^(]+\s+\([A-Z]{1,2}\)\s+\([^)]*\)[—�-]?\s*(?P<owner>.*?)\s*\(Br\)\s*(?P<breeder_location>.*?)\s*\(Wh\)",
    re.IGNORECASE,
)
PARENTS_PATTERN = re.compile(r"\b(?P<intro>By)\s+(?P<sire>.+?)\s+out of\s+(?P<dam>.+)$", re.IGNORECASE)
DAMAGED_PARENTS_PATTERN = re.compile(r"\b(?P<intro>(?:[A-Za-z],|3y|Bv))\s+(?P<sire>.+?)\s+out of\s+(?P<dam>.+)$", re.IGNORECASE)
ROLE_ORDERED_REGISTRATIONS_PATTERN = re.compile(
    r"\((?P<sire_registration>[0-9][0-9, .\-]*),\s*Vol\.?\s*(?P<sire_volume>\d+)\)\s+out of\s+[^()]*?\((?P<dam_registration>[0-9][0-9, .\-]*),\s*Vol\.?\s*(?P<dam_volume>\d+)\)",
    re.IGNORECASE,
)
FALLBACK_PRIMARY_REGISTRATION_PATTERN = re.compile(r"\((?P<registration>[0-9][0-9, .\-]*)\)")
PARENT_REGISTRATION_PATTERN = re.compile(r"(?:\(|\s)(?P<registration>[0-9][0-9, .\-]*)")
PARENT_VOLUME_PATTERN = re.compile(r"\bVol\.?\s*(?P<volume>\d+)\b", re.IGNORECASE)
REGISTRATION_RANGE_PATTERN = re.compile(r"numbers?\s+from\s+(?P<minimum>[0-9,]+)\s+to\s+(?P<maximum>[0-9,]+)", re.IGNORECASE)
SUSPICIOUS_SYMBOL_PATTERN = re.compile(r"[!<>\[\]{}|~`^=+*]")
LONG_SOURCE_TEXT_THRESHOLD = 250

def clean(value: str) -> str:
    return " ".join(value.replace("�", " ").replace("_", " ").replace("[", "").replace("]", "").replace("<", "").replace(">", "").replace("|", "").replace("*", "").split()).strip(" ,.;-")


def registration_number(value: str) -> str:
    digits = re.sub(r"\D", "", value)
    return digits if len(digits) >= 5 else ""


def normalize_sex(marker: str) -> tuple[str, bool]:
    normalized = marker[-1:] if marker[-1:] in {"B", "D"} else ""
    return {"B": "Female", "D": "Male"}.get(normalized, ""), marker != normalized


def registration_range(pages: list[OcrPage]) -> tuple[int, int] | None:
    for page in pages:
        match = REGISTRATION_RANGE_PATTERN.search(" ".join(line.text for line in page.lines))
        if match:
            return int(match.group("minimum").replace(",", "")), int(match.group("maximum").replace(",", ""))
    return None


def repair_line_wrap(value: str) -> str:
    return re.sub(r"(?<=[A-Za-z])\-\s+(?=[a-z])", "", value)


def parent_reference(value: str) -> str:
    repaired = repair_line_wrap(value)
    ancestry_connector = re.search(r"\s+(?:by|out of)\s+|;|:\s*", repaired, re.IGNORECASE)
    immediate_reference = repaired[: ancestry_connector.start()] if ancestry_connector else repaired
    parenthetical = re.search(r"\([^)]*\d[^)]*\)", immediate_reference)
    if parenthetical:
        return clean(immediate_reference[: parenthetical.end()])
    return clean(re.split(r"\.\s+", immediate_reference, maxsplit=1)[0])


def parent_name(value: str) -> str:
    reference = parent_reference(value)
    without_parenthetical = re.sub(r"\s*\(.*$", "", reference)
    return clean(re.split(r"\s+(?=[.,\-]?\d|Vol\.?\b)", without_parenthetical, maxsplit=1, flags=re.IGNORECASE)[0])


def parent_identifier(value: str) -> str:
    match = PARENT_REGISTRATION_PATTERN.search(repair_line_wrap(value))
    return registration_number(match.group("registration")) if match else ""


def parent_volume(value: str) -> str:
    match = PARENT_VOLUME_PATTERN.search(repair_line_wrap(value))
    return match.group("volume") if match else ""


def breed_heading(text: str) -> str:
    if not BREED_PATTERN.fullmatch(text) or ENTRY_PATTERN.match(text):
        return ""
    if len(text) > 36 or BREED_CONNECTIVE_PATTERN.search(text) or SEX_SUFFIX_PATTERN.search(text):
        return ""
    return text if text.isupper() or "(" in text else ""


def entry_from_lines(
    page: OcrPage,
    start: int,
    end: int,
    breed: str,
    volume_range: tuple[int, int] | None = None,
    raw_text: str | None = None,
    fallback_name: str = "",
) -> dict[str, Any] | None:
    raw_lines = [raw_text] if raw_text is not None else [line.text for line in page.lines[start:end]]
    source_text_raw = " ".join(raw_lines)
    text = clean(source_text_raw)
    normalized_text = repair_line_wrap(text)
    match = ENTRY_PATTERN.match(clean(raw_lines[0]))
    if not match and not fallback_name:
        return None
    metadata = ENTRY_METADATA_PATTERN.search(normalized_text)
    whelped = WHELPED_PATTERN.search(normalized_text)
    whelped_fallback = False
    if not whelped:
        whelped = FALLBACK_DATE_PATTERN.search(normalized_text)
        whelped_fallback = whelped is not None
    post_whelped = normalized_text[whelped.end() :] if whelped else ""
    parents = PARENTS_PATTERN.search(post_whelped)
    parent_intro_status = "exact"
    if not parents:
        parents = DAMAGED_PARENTS_PATTERN.search(post_whelped)
        parent_intro_status = "ocr_damaged" if parents else "missing"
    role_ordered_registrations = ROLE_ORDERED_REGISTRATIONS_PATTERN.search(post_whelped) if not parents else None
    fallback_registration = FALLBACK_PRIMARY_REGISTRATION_PATTERN.search(normalized_text) if not match else None
    fallback_sex = re.search(r"\(([BD])\)", normalized_text) if not match else None
    registration = registration_number(match.group("registration")) if match else registration_number(fallback_registration.group("registration")) if fallback_registration else ""
    sex, sex_marker_damaged = normalize_sex(match.group("sex")) if match else normalize_sex(fallback_sex.group(1)) if fallback_sex else ("", False)
    confidence = 0.35 if match else 0.1
    warnings: list[str] = []
    source_anomalies = sorted(set(SUSPICIOUS_SYMBOL_PATTERN.findall(source_text_raw)))
    if "�" in source_text_raw:
        source_anomalies.append("replacement_character")
    if source_text_raw.count("(") != source_text_raw.count(")"):
        source_anomalies.append("unbalanced_parentheses")
    if source_anomalies:
        warnings.append("source_ocr_anomalies")
    if len(text) > LONG_SOURCE_TEXT_THRESHOLD:
        warnings.append("long_source_text")
    if not metadata and "(Br)" in normalized_text:
        warnings.append("metadata_ocr_damaged")
    if whelped_fallback:
        warnings.append("whelped_label_ocr_damaged")
    if sex_marker_damaged:
        warnings.append("sex_marker_ocr_damaged")
    if match and match.group("registration_closer") != ")":
        warnings.append("registration_delimiter_ocr_damaged")
    if fallback_name:
        warnings.append("entry_boundary_ocr_damaged")
    if registration:
        confidence += 0.25
    else:
        warnings.append("registration_number_incomplete_or_unreadable")
    registration_range_status = "not_available"
    if volume_range and registration:
        registration_value = int(registration)
        registration_range_status = "within_range" if volume_range[0] <= registration_value <= volume_range[1] else "outside_range"
        if registration_range_status == "outside_range":
            warnings.append("registration_number_outside_volume_range")
    if whelped:
        confidence += 0.15
    else:
        warnings.append("birth_date_not_found")
    if parents or role_ordered_registrations:
        confidence += 0.15
    else:
        warnings.append("parent_phrase_not_found")
    if parent_intro_status == "ocr_damaged":
        warnings.append("parent_intro_ocr_damaged")
    if role_ordered_registrations:
        warnings.append("parent_names_missing_registrations_recovered")
    sire_source = parents.group("sire") if parents else ""
    dam_source = parents.group("dam") if parents else ""
    sire_registration = (
        parent_identifier(sire_source)
        if parents
        else registration_number(role_ordered_registrations.group("sire_registration")) if role_ordered_registrations else ""
    )
    dam_registration = (
        parent_identifier(dam_source)
        if parents
        else registration_number(role_ordered_registrations.group("dam_registration")) if role_ordered_registrations else ""
    )
    sire_volume = parent_volume(sire_source) if parents else role_ordered_registrations.group("sire_volume") if role_ordered_registrations else ""
    dam_volume = parent_volume(dam_source) if parents else role_ordered_registrations.group("dam_volume") if role_ordered_registrations else ""
    owner = clean(metadata.group("owner")) if metadata else ""
    breeder_location = clean(metadata.group("breeder_location")) if metadata else ""
    parent_start = parents.start() if parents else role_ordered_registrations.start() if role_ordered_registrations else len(post_whelped)
    color = clean(post_whelped[:parent_start])
    return {
        "source_page": page.number,
        "source_line_start": start + 1,
        "source_line_end": end,
        "source_text": text,
        "source_anomalies": source_anomalies,
        "parser_profile": "monthly_1926_v1",
        "volume_registration_range": {"minimum": volume_range[0], "maximum": volume_range[1]} if volume_range else {},
        "confidence": round(min(confidence, 0.4 if fallback_name else 1.0, 0.6 if warnings else 1.0), 2),
        "breed_heading": breed,
        "dog": {
            "name": clean(match.group("name")) if match else clean(fallback_name),
            "registration_number": registration,
            "registration_range_status": registration_range_status,
            "sex": sex,
            "owner_raw": owner,
            "breeder_location_raw": breeder_location,
            "birth_date_raw": whelped.group("date") if whelped else "",
            "color_raw": color,
        },
        "parents": {
            "pedigree_raw": clean(parents.group(0)) if parents else clean(role_ordered_registrations.group(0)) if role_ordered_registrations else "",
            "sire": parent_name(sire_source),
            "sire_registration_number": sire_registration,
            "sire_reference_volume": sire_volume,
            "sire_reference_raw": parent_reference(sire_source),
            "dam": parent_name(dam_source),
            "dam_registration_number": dam_registration,
            "dam_reference_volume": dam_volume,
            "dam_reference_raw": parent_reference(dam_source),
        },
        "warnings": warnings,
    }


def apply_name_correction(record: dict[str, Any], corrections: dict[str, dict[str, str]]) -> None:
    registration = str(record["dog"].get("registration_number", ""))
    correction = corrections.get(registration)
    if not correction or correction["name"] == record["dog"]["name"]:
        return
    record["dog"]["name_ocr_raw"] = record["dog"]["name"]
    record["dog"]["name"] = correction["name"]
    record["dog"]["name_correction_source"] = correction["source"]
    record["warnings"].append("manual_name_correction")
    record["confidence"] = min(record["confidence"], 0.6)


def extract_page(
    page: OcrPage, initial_breed: str = "", volume_range: tuple[int, int] | None = None
) -> tuple[list[dict[str, Any]], str]:
    records: list[dict[str, Any]] = []
    breed = initial_breed
    starts: list[tuple[int, str, str]] = []
    for index, line in enumerate(page.lines):
        text = clean(line.text)
        if heading := breed_heading(text):
            breed = heading
        if ENTRY_PATTERN.match(text):
            starts.append((index, breed, ""))
        elif structural := STRUCTURAL_ENTRY_LINE_PATTERN.match(text):
            starts.append((index, breed, clean(structural.group("name"))))
    for index, (start, record_breed, line_fallback_name) in enumerate(starts):
        end = starts[index + 1][0] if index + 1 < len(starts) else len(page.lines)
        block_text = clean(" ".join(line.text for line in page.lines[start:end]))
        entry_starts = [(match.start(), "") for match in ENTRY_START_PATTERN.finditer(block_text)]
        strict_start_offsets = {start_offset for start_offset, _ in entry_starts}
        entry_starts.extend(
            (match.start(), clean(match.group("name")))
            for match in DAMAGED_ENTRY_START_PATTERN.finditer(block_text)
            if match.start() not in strict_start_offsets
        )
        known_start_offsets = {start_offset for start_offset, _ in entry_starts}
        entry_starts.extend(
            (match.start(), clean(match.group("name")))
            for match in OCR_DAMAGED_ENTRY_START_PATTERN.finditer(block_text)
            if match.start() not in known_start_offsets
        )
        entry_starts.sort()
        if not entry_starts and line_fallback_name:
            entry_starts = [(0, line_fallback_name)]
        for entry_index, (entry_start, fallback_name) in enumerate(entry_starts):
            entry_end = entry_starts[entry_index + 1][0] if entry_index + 1 < len(entry_starts) else len(block_text)
            record = entry_from_lines(
                page,
                start,
                end,
                record_breed,
                volume_range,
                block_text[entry_start:entry_end],
                fallback_name,
            )
            if record:
                records.append(record)
    return records, breed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("volume", help="DjVu XML path or Internet Archive identifier")
    parser.add_argument("--volumes-dir", type=Path, default=Path("data/volumes"))
    output_group = parser.add_mutually_exclusive_group(required=True)
    output_group.add_argument("--output", type=Path, help="Candidate JSONL output path")
    output_group.add_argument("--markdown-output", type=Path, help="Human-readable Markdown review path")
    parser.add_argument("--page", type=int, action="append", help="OCR page to extract; repeatable")
    parser.add_argument("--breed", help="Keep only an exact breed heading, case-insensitively")
    parser.add_argument(
        "--corrections",
        type=Path,
        default=Path("parser/fixtures/manual_name_corrections.json"),
        help="Manual registration-keyed name corrections",
    )
    args = parser.parse_args()

    xml_path = resolve_xml_path(args.volume, args.volumes_dir)
    if not xml_path.is_file():
        parser.error(f"DjVu XML file not found: {xml_path}")
    selected_pages = set(args.page or [])
    if not args.corrections.is_file():
        parser.error(f"Corrections file not found: {args.corrections}")
    corrections = json.loads(args.corrections.read_text(encoding="utf-8"))
    identifier = xml_path.name.removesuffix("_djvu.xml")
    pages = list(iter_pages(xml_path))
    volume_range = registration_range(pages)
    candidates: list[dict[str, Any]] = []
    breed = ""
    requested_breed = args.breed.casefold() if args.breed else ""
    for page in pages:
        records, breed = extract_page(page, breed, volume_range)
        if selected_pages and page.number not in selected_pages:
            continue
        for record in records:
            if requested_breed and record["breed_heading"].casefold() != requested_breed:
                continue
            apply_name_correction(record, corrections)
            record["source_item"] = identifier
            candidates.append(record)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("w", encoding="utf-8", newline="\n") as handle:
            for record in candidates:
                handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        destination = args.output
    else:
        try:
            from .render_review import render_records
        except ImportError:
            from render_review import render_records
        args.markdown_output.parent.mkdir(parents=True, exist_ok=True)
        args.markdown_output.write_text(render_records(candidates), encoding="utf-8", newline="\n")
        destination = args.markdown_output
    print(f"Wrote {len(candidates)} candidate records to {destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
