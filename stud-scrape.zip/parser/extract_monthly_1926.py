#!/usr/bin/env python3
"""Extract reviewable candidate records from the 1926 monthly Stud Book layout."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

try:
    from .inspect_stud_book import OcrPage, iter_pages, resolve_xml_path
except ImportError:
    from inspect_stud_book import OcrPage, iter_pages, resolve_xml_path

ENTRY_PATTERN = re.compile(
    r"^(?P<name>[A-Z][A-Z0-9'’ .,&\-]+?)\s+\((?P<sex>[BD])\)\s+\((?P<registration>[0-9, .\-]+)\)[—�-]?\s*(?P<remainder>.*)$"
)
BREED_PATTERN = re.compile(r"^[A-Z][A-Za-z'’ .\-]+(?:\s+\([A-Za-z'’ .\-]+\))?$")
WHELPED_PATTERN = re.compile(r"\(Wh\)\s+(?P<date>[A-Z][a-z]+\.?\s+\d{1,2},\s+\d{4})")
PARENTS_PATTERN = re.compile(r"\bBy\s+(?P<sire>.+?)\s+out of\s+(?P<dam>.+)$", re.IGNORECASE)


def clean(value: str) -> str:
    return " ".join(value.replace("�", " ").replace("_", " ").split()).strip(" ,.;-")


def registration_number(value: str) -> str:
    digits = re.sub(r"\D", "", value)
    return digits if len(digits) >= 5 else ""


def is_breed_heading(text: str) -> bool:
    return bool(BREED_PATTERN.fullmatch(text)) and not ENTRY_PATTERN.match(text)


def entry_from_lines(page: OcrPage, start: int, end: int, breed: str) -> dict[str, Any] | None:
    raw_lines = [line.text for line in page.lines[start:end]]
    text = clean(" ".join(raw_lines))
    match = ENTRY_PATTERN.match(clean(raw_lines[0]))
    if not match:
        return None
    parents = PARENTS_PATTERN.search(text)
    whelped = WHELPED_PATTERN.search(text)
    registration = registration_number(match.group("registration"))
    confidence = 0.35
    warnings: list[str] = []
    if registration:
        confidence += 0.25
    else:
        warnings.append("registration_number_incomplete_or_unreadable")
    if whelped:
        confidence += 0.15
    else:
        warnings.append("birth_date_not_found")
    if parents:
        confidence += 0.15
    else:
        warnings.append("parent_phrase_not_found")
    return {
        "source_page": page.number,
        "source_line_start": start + 1,
        "source_line_end": end,
        "source_text": text,
        "parser_profile": "monthly_1926_v0",
        "confidence": round(confidence, 2),
        "breed_heading": breed,
        "dog": {
            "name": clean(match.group("name")),
            "registration_number": registration,
            "sex": {"D": "Male", "B": "Female"}[match.group("sex")],
            "birth_date_raw": whelped.group("date") if whelped else "",
        },
        "parents": {
            "sire_raw": clean(parents.group("sire")) if parents else "",
            "dam_raw": clean(parents.group("dam")) if parents else "",
        },
        "warnings": warnings,
    }


def extract_page(page: OcrPage) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    breed = ""
    starts: list[int] = []
    for index, line in enumerate(page.lines):
        text = clean(line.text)
        if is_breed_heading(text):
            breed = text
        if ENTRY_PATTERN.match(text):
            starts.append(index)
    for index, start in enumerate(starts):
        end = starts[index + 1] if index + 1 < len(starts) else len(page.lines)
        record = entry_from_lines(page, start, end, breed)
        if record:
            records.append(record)
    return records


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("volume", help="DjVu XML path or Internet Archive identifier")
    parser.add_argument("--volumes-dir", type=Path, default=Path("data/volumes"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--page", type=int, action="append", help="OCR page to extract; repeatable")
    args = parser.parse_args()

    xml_path = resolve_xml_path(args.volume, args.volumes_dir)
    if not xml_path.is_file():
        parser.error(f"DjVu XML file not found: {xml_path}")
    selected_pages = set(args.page or [])
    identifier = xml_path.name.removesuffix("_djvu.xml")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with args.output.open("w", encoding="utf-8", newline="\n") as handle:
        for page in iter_pages(xml_path):
            if selected_pages and page.number not in selected_pages:
                continue
            for record in extract_page(page):
                record["source_item"] = identifier
                handle.write(json.dumps(record, ensure_ascii=False) + "\n")
                count += 1
    print(f"Wrote {count} candidate records to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
