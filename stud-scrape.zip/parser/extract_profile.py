#!/usr/bin/env python3
"""Extract a Stud Book volume through a named layout profile."""

from __future__ import annotations

import argparse
from pathlib import Path

try:
    from .profiles.monthly_1926_v2 import NAME, extract
    from .render_review import render_records
except ImportError:
    from profiles.monthly_1926_v2 import NAME, extract
    from render_review import render_records


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=[NAME], required=True)
    parser.add_argument("--identifier", required=True)
    parser.add_argument("--breed", required=True)
    parser.add_argument("--volumes-dir", type=Path, default=Path("data/volumes"))
    parser.add_argument("--page", type=int, action="append")
    parser.add_argument("--coordinate-page", type=int, action="append")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    records = extract(
        args.identifier,
        args.volumes_dir,
        args.breed,
        set(args.page or []),
        set(args.coordinate_page or []),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(render_records(records), encoding="utf-8", newline="\n")
    print(f"Wrote {len(records)} records to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
