#!/usr/bin/env python3
"""Inspect page-aware OCR text from an Internet Archive DjVu XML file."""

from __future__ import annotations

import argparse
import re
import sys
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

REGISTRATION_PATTERN = re.compile(r"\b[A-Z]{1,3}\s?\d{4,8}\b")


@dataclass
class OcrLine:
    text: str
    words: list[tuple[str, str]]


@dataclass
class OcrPage:
    number: int
    lines: list[OcrLine]


def local_name(element: ET.Element) -> str:
    return element.tag.rsplit("}", 1)[-1]


def text_for(element: ET.Element) -> str:
    return " ".join("".join(element.itertext()).split())


def lines_for(page: ET.Element) -> list[OcrLine]:
    lines: list[OcrLine] = []
    for line in page.iter():
        if local_name(line) != "LINE":
            continue
        words = [
            (text_for(word), word.get("coords", ""))
            for word in line.iter()
            if local_name(word) == "WORD" and text_for(word)
        ]
        if words:
            lines.append(OcrLine(" ".join(word for word, _ in words), words))
    return lines


def iter_pages(xml_path: Path) -> Iterator[OcrPage]:
    page_number = 0
    for _, element in ET.iterparse(xml_path, events=("end",)):
        if local_name(element) != "OBJECT":
            continue
        page_number += 1
        yield OcrPage(page_number, lines_for(element))
        element.clear()


def resolve_xml_path(value: str, volumes_dir: Path) -> Path:
    candidate = Path(value)
    if candidate.is_file():
        return candidate
    identifier = value
    return volumes_dir / identifier / f"{identifier}_djvu.xml"


def print_page(page: OcrPage, show_coordinates: bool) -> None:
    print(f"\n--- OCR page {page.number} ---")
    for line_number, line in enumerate(page.lines, start=1):
        print(f"{line_number:04d}: {line.text}")
        if show_coordinates:
            print("      " + " | ".join(f"{word} [{coords}]" for word, coords in line.words))


def print_matches(page: OcrPage, pattern: re.Pattern[str], context: int) -> int:
    matches = 0
    for line_number, line in enumerate(page.lines, start=1):
        if not pattern.search(line.text):
            continue
        matches += 1
        start = max(0, line_number - context - 1)
        end = min(len(page.lines), line_number + context)
        print(f"\n--- OCR page {page.number}, match at line {line_number} ---")
        for index in range(start, end):
            marker = ">" if index == line_number - 1 else " "
            print(f"{marker}{index + 1:04d}: {page.lines[index].text}")
    return matches


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("volume", help="DjVu XML path or Internet Archive identifier")
    parser.add_argument("--volumes-dir", type=Path, default=Path("data/volumes"))
    parser.add_argument("--page", type=int, action="append", help="OCR page to print; repeatable")
    parser.add_argument("--search", help="Regular expression to search within OCR lines")
    parser.add_argument("--registration-context", action="store_true", help="Search likely registration numbers")
    parser.add_argument("--context", type=int, default=4, help="Lines around each match (default: 4)")
    parser.add_argument("--coordinates", action="store_true", help="Include DjVu word coordinates")
    args = parser.parse_args()

    if args.context < 0:
        parser.error("--context must be non-negative")
    if args.search and args.registration_context:
        parser.error("Use either --search or --registration-context, not both")
    xml_path = resolve_xml_path(args.volume, args.volumes_dir)
    if not xml_path.is_file():
        parser.error(f"DjVu XML file not found: {xml_path}")
    pattern = re.compile(args.search, re.IGNORECASE) if args.search else REGISTRATION_PATTERN if args.registration_context else None
    requested_pages = set(args.page or [])
    matches = 0
    page_count = 0
    for page in iter_pages(xml_path):
        page_count += 1
        if requested_pages and page.number in requested_pages:
            print_page(page, args.coordinates)
        if pattern:
            matches += print_matches(page, pattern, args.context)
    if requested_pages - set(range(1, page_count + 1)):
        print(f"Requested page outside 1-{page_count}", file=sys.stderr)
        return 1
    if pattern:
        print(f"\nFound {matches} matching OCR lines across {page_count} pages.")
    elif not requested_pages:
        print(f"DjVu XML contains {page_count} OCR pages. Use --page or --search to inspect content.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
