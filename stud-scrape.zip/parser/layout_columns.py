"""Reconstruct OCR reading order from DjVu word coordinates."""

from __future__ import annotations

try:
    from .inspect_stud_book import OcrLine, OcrPage
except ImportError:
    from inspect_stud_book import OcrLine, OcrPage


def line_position(line: OcrLine) -> tuple[int, int]:
    coordinates = [tuple(map(int, coords.split(","))) for _, coords in line.words if coords]
    return min(coord[0] for coord in coordinates), min(coord[1] for coord in coordinates)


def three_columns(page: OcrPage) -> list[OcrPage]:
    positioned = [(line_position(line), line) for line in page.lines if any(coords for _, coords in line.words)]
    if not positioned:
        return []
    width = max(max(coord[0], coord[2]) for _, line in positioned for _, coords in line.words if coords for coord in [tuple(map(int, coords.split(",")))])
    boundaries = (width / 3, 2 * width / 3)
    columns: list[list[tuple[tuple[int, int], OcrLine]]] = [[], [], []]
    for position, line in positioned:
        column = 0 if position[0] < boundaries[0] else 1 if position[0] < boundaries[1] else 2
        columns[column].append((position, line))
    return [
        OcrPage(page.number, [line for _, line in sorted(column, key=lambda item: item[0][1])])
        for column in columns
        if column
    ]
