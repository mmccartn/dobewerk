"""Reusable Stud Book layout profiles."""
