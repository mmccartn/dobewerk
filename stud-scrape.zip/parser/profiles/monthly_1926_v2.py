"""Coordinate-aware layout profile for 1926 monthly Stud Book issues."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

try:
    from ..extract_monthly_1926 import apply_name_correction, extract_page, registration_range
    from ..inspect_stud_book import iter_pages
    from ..layout_columns import three_columns
except ImportError:
    from extract_monthly_1926 import apply_name_correction, extract_page, registration_range
    from inspect_stud_book import iter_pages
    from layout_columns import three_columns

NAME = "monthly_1926_v2"


def corrections(path: Path = Path("parser/fixtures/manual_name_corrections.json")) -> tuple[dict[str, dict[str, str]], set[str]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    return data, set(data.get("_suppress_ocr_names", []))


def extract(
    identifier: str,
    volumes_dir: Path,
    breed: str,
    page_numbers: set[int] | None = None,
    coordinate_pages: set[int] | None = None,
    correction_path: Path = Path("parser/fixtures/manual_name_corrections.json"),
) -> list[dict[str, Any]]:
    xml_path = volumes_dir / identifier / f"{identifier}_djvu.xml"
    if not xml_path.is_file():
        raise FileNotFoundError(xml_path)
    pages = list(iter_pages(xml_path))
    page_by_number = {page.number: page for page in pages}
    volume_range = registration_range(pages)
    correction_data, suppressed_names = corrections(correction_path)
    records: list[dict[str, Any]] = []
    breed_context = ""
    for page in pages:
        if page_numbers and page.number not in page_numbers:
            _, breed_context = extract_page(page, breed_context, volume_range)
            continue
        page_sets = three_columns(page) if coordinate_pages and page.number in coordinate_pages else [page]
        for column_index, page_set in enumerate(page_sets, start=1):
            initial_breed = breed if coordinate_pages and page.number in coordinate_pages else breed_context
            extracted, breed_context = extract_page(page_set, initial_breed, volume_range)
            for record in extracted:
                if record["breed_heading"].casefold() != breed.casefold() or record["dog"]["name"] in suppressed_names:
                    continue
                apply_name_correction(record, correction_data)
                record["source_item"] = identifier
                record["source_column"] = column_index if len(page_sets) > 1 else None
                records.append(record)
    return records
