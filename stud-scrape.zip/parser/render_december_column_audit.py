#!/usr/bin/env python3
"""Render the December 1926 printed-page-40 columns for manual boundary review."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

try:
    from .extract_monthly_1926 import apply_name_correction, extract_page, registration_range
    from .inspect_stud_book import iter_pages
    from .layout_columns import three_columns
    from .render_review import record_markdown
except ImportError:
    from extract_monthly_1926 import apply_name_correction, extract_page, registration_range
    from inspect_stud_book import iter_pages
    from layout_columns import three_columns
    from render_review import record_markdown

IDENTIFIER = "sim_american-kennel-club-stud-book-register_1926-12-31_43_12"
BREED = "Pinschers (Doberman)"
EXPECTED_COUNTS = (16, 17, 21)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--volumes-dir", type=Path, default=Path("data/volumes"))
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("data/parser-output/1926-12-printed-40-column-audit.md"),
    )
    args = parser.parse_args()

    xml_path = args.volumes_dir / IDENTIFIER / f"{IDENTIFIER}_djvu.xml"
    if not xml_path.is_file():
        parser.error(f"DjVu XML file not found: {xml_path}")
    pages = list(iter_pages(xml_path))
    page = next(page for page in pages if page.number == 42)
    volume_range = registration_range(pages)
    corrections = json.loads(Path("parser/fixtures/manual_name_corrections.json").read_text(encoding="utf-8"))
    suppressed_names = set(corrections.get("_suppress_ocr_names", []))
    report = ["# December 1926 Doberman Column Audit", "", "Printed page: **40**", ""]
    for index, column in enumerate(three_columns(page)):
        records, _ = extract_page(column, BREED, volume_range)
        records = [record for record in records if record["dog"]["name"] not in suppressed_names]
        for record in records:
            apply_name_correction(record, corrections)
            record["source_item"] = IDENTIFIER
            record["source_column"] = index + 1
        expected = EXPECTED_COUNTS[index]
        report.extend(
            [
                f"## Printed page 40 — column {index + 1}",
                "",
                f"Expected: **{expected}** dogs  ",
                f"Detected: **{len(records)}** candidates",
                "",
            ]
        )
        report.extend(record_markdown(record_index + 1, record) for record_index, record in enumerate(records))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(report), encoding="utf-8", newline="\n")
    print(f"Wrote column audit to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
