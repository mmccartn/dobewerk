#!/usr/bin/env python3
"""Render the December 1926 Doberman fixture in coordinate-aware column order."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

try:
    from .extract_monthly_1926 import apply_name_correction, extract_page, registration_range
    from .inspect_stud_book import iter_pages
    from .layout_columns import three_columns
    from .render_review import record_markdown
except ImportError:
    from extract_monthly_1926 import apply_name_correction, extract_page, registration_range
    from inspect_stud_book import iter_pages
    from layout_columns import three_columns
    from render_review import record_markdown

FIXTURE_PATH = Path("parser/fixtures/monthly_1926_v1_december_doberman_columns.json")
CORRECTIONS_PATH = Path("parser/fixtures/manual_name_corrections.json")


def reviewed(records: list[dict], corrections: dict, suppressed_names: set[str], identifier: str, column: str) -> list[dict]:
    result = []
    for record in records:
        if record["dog"]["name"] in suppressed_names:
            continue
        apply_name_correction(record, corrections)
        record["source_item"] = identifier
        record["source_column"] = column
        result.append(record)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--volumes-dir", type=Path, default=Path("data/volumes"))
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("data/parser-output/1926-12-doberman-pages-41-43-review.md"),
    )
    args = parser.parse_args()

    fixture = json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))
    corrections = json.loads(CORRECTIONS_PATH.read_text(encoding="utf-8"))
    suppressed_names = set(corrections.get("_suppress_ocr_names", []))
    identifier = fixture["identifier"]
    xml_path = args.volumes_dir / identifier / f"{identifier}_djvu.xml"
    if not xml_path.is_file():
        parser.error(f"DjVu XML file not found: {xml_path}")
    pages = list(iter_pages(xml_path))
    page_by_number = {page.number: page for page in pages}
    volume_range = registration_range(pages)
    sections: list[tuple[dict, list[dict]]] = []
    for specification in fixture["columns"]:
        page = page_by_number[specification["ocr_page"]]
        if specification["ocr_page"] == 42:
            column_index = {"left": 0, "middle": 1, "right": 2}[specification["position"]]
            records, _ = extract_page(three_columns(page)[column_index], fixture["breed_heading"], volume_range)
        else:
            records, _ = extract_page(page, "", volume_range)
            records = [record for record in records if record["breed_heading"].casefold() == fixture["breed_heading"].casefold()]
        sections.append((specification, reviewed(records, corrections, suppressed_names, identifier, specification["position"])))
    total = sum(len(records) for _, records in sections)
    report = ["# December 1926 Coordinate-Aware Doberman Review", "", f"Expected: **{fixture['expected_total']}** dogs  ", f"Detected: **{total}** dogs", ""]
    for specification, records in sections:
        report.extend(
            [
                f"## Printed page {specification['printed_page']} — {specification['position']} column",
                "",
                f"Expected: **{specification['expected_count']}** dogs  ",
                f"Detected: **{len(records)}** dogs",
                "",
            ]
        )
        report.extend(record_markdown(index + 1, record) for index, record in enumerate(records))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(report), encoding="utf-8", newline="\n")
    print(f"Wrote {total}-dog coordinate review to {args.output}")
    return 0 if total == fixture["expected_total"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
