#!/usr/bin/env python3
"""Render extracted Stud Book JSONL candidates as a Markdown review report."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any


def value(record: dict[str, Any], *path: str) -> str:
    current: Any = record
    for key in path:
        current = current.get(key, {}) if isinstance(current, dict) else {}
    return str(current or "")


def field(label: str, text: str) -> str:
    return f"- **{label}:** {text or '—'}"


def parent_reference(record: dict[str, Any], parent: str) -> str:
    registration = value(record, "parents", f"{parent}_registration_number")
    volume = value(record, "parents", f"{parent}_reference_volume")
    return f"{registration} (Vol. {volume})" if registration and volume else registration


def record_markdown(index: int, record: dict[str, Any]) -> str:
    page = value(record, "source_page")
    line_start = value(record, "source_line_start")
    line_end = value(record, "source_line_end")
    warnings = record.get("warnings", [])
    warning_text = ", ".join(warnings) if warnings else "None"
    anomaly_text = ", ".join(str(anomaly) for anomaly in record.get("source_anomalies", []))
    return "\n".join(
        [
            f"## Record {index} — page {page}, lines {line_start}–{line_end}",
            "",
            field("Breed", value(record, "breed_heading")),
            field("Name", value(record, "dog", "name")),
            field("Name OCR", value(record, "dog", "name_ocr_raw")),
            field("Registration", value(record, "dog", "registration_number")),
            field("Registration check", value(record, "dog", "registration_range_status")),
            field("Sire", value(record, "parents", "sire") or value(record, "parents", "sire_raw")),
            field("Sire registration", parent_reference(record, "sire")),
            field("Dam", value(record, "parents", "dam") or value(record, "parents", "dam_raw")),
            field("Dam registration", parent_reference(record, "dam")),
            field("Whelped", value(record, "dog", "birth_date_raw")),
            field("Sex", value(record, "dog", "sex")),
            field("Owners", value(record, "dog", "owner_raw")),
            field("Breeder / location", value(record, "dog", "breeder_location_raw")),
            field("Color", value(record, "dog", "color_raw")),
            field("Confidence", value(record, "confidence")),
            field("Source characters", str(len(value(record, "source_text")))),
            field("Source anomalies", anomaly_text),
            field("Warnings", warning_text),
            "",
            "### Source OCR",
            "",
            "```text",
            value(record, "source_text"),
            "```",
            "",
        ]
    )


def render_records(records: list[dict[str, Any]]) -> str:
    source_items = Counter(value(record, "source_item") for record in records)
    report = ["# Stud Book Candidate Review", "", f"Records: **{len(records)}**"]
    volume_range = records[0].get("volume_registration_range", {}) if records else {}
    if volume_range:
        report.append(f"Registration range: **{volume_range['minimum']}–{volume_range['maximum']}**")
    if source_items:
        report.extend(["", "Source items:", *[f"- `{item}`: {count}" for item, count in source_items.items()]])
    report.append("")
    report.extend(record_markdown(index, record) for index, record in enumerate(records, start=1))
    return "\n".join(report)


def load_records(path: Path) -> list[dict[str, Any]]:
    records = []
    with path.open(encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError as error:
                raise ValueError(f"Invalid JSON on line {line_number} of {path}") from error
    return records


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="Candidate JSONL file")
    parser.add_argument("--output", type=Path, required=True, help="Markdown report path")
    args = parser.parse_args()

    records = load_records(args.input)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(render_records(records), encoding="utf-8", newline="\n")
    print(f"Wrote {len(records)} records to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
