#!/usr/bin/env python3
"""Create a direct-Tesseract OCR audit from Stud Book JP2 scan images."""

from __future__ import annotations

import argparse
import shutil
import statistics
import subprocess
from pathlib import Path

from PIL import Image, ImageFilter, ImageOps


PRINTED_PAGE_OFFSET = -1
COLUMN_CROP_PADDING = 24


def deskew_score(image: Image.Image) -> int:
    pixels = image.load()
    score = 0
    for y in range(0, image.height, 3):
        ink = sum(pixels[x, y] < 190 for x in range(0, image.width, 3))
        score += ink * ink
    return score


def deskew(image: Image.Image) -> tuple[Image.Image, float]:
    preview_width = min(800, image.width)
    preview_height = round(image.height * preview_width / image.width)
    preview = image.resize((preview_width, preview_height), Image.Resampling.BILINEAR)
    candidates = [angle / 10 for angle in range(-20, 21, 2)]
    angle = max(
        candidates,
        key=lambda candidate: deskew_score(preview.rotate(candidate, Image.Resampling.BICUBIC, fillcolor=255)),
    )
    return image.rotate(angle, Image.Resampling.BICUBIC, fillcolor=255), angle


def preprocess(image: Image.Image) -> tuple[Image.Image, float]:
    grayscale = ImageOps.grayscale(image)
    deskewed, angle = deskew(grayscale)
    normalized = ImageOps.autocontrast(deskewed, cutoff=1).filter(ImageFilter.MedianFilter(3))
    enlarged = normalized.resize((normalized.width * 2, normalized.height * 2), Image.Resampling.LANCZOS)
    return enlarged.point(lambda pixel: 255 if pixel > 175 else 0), angle


def column_boundaries(image: Image.Image) -> tuple[int, int]:
    width, height = image.size
    body = image.crop((0, round(height * 0.08), width, round(height * 0.94)))
    pixels = body.load()
    ink = [0] * width
    for y in range(0, body.height, 4):
        for x in range(width):
            if pixels[x, y] < 190:
                ink[x] += 1
    radius = 50
    smoothed = [
        sum(ink[max(0, x - radius) : min(width, x + radius + 1)])
        for x in range(width)
    ]
    boundaries = []
    for expected in (width / 3, 2 * width / 3):
        search_radius = round(width * 0.12)
        left = max(0, round(expected) - search_radius)
        right = min(width, round(expected) + search_radius)
        boundaries.append(min(range(left, right), key=smoothed.__getitem__))
    return tuple(boundaries)


def run_tesseract(executable: str, image_path: Path, psm: int, output_format: str) -> str:
    command = [executable, str(image_path), "stdout", "--oem", "1", "--psm", str(psm)]
    if output_format != "txt":
        command.append(output_format)
    result = subprocess.run(
        command,
        check=True,
        capture_output=True,
    )
    return result.stdout.decode("utf-8", errors="replace")


def tsv_confidence(tsv: str) -> float | None:
    values = []
    for line in tsv.splitlines()[1:]:
        fields = line.split("\t")
        if len(fields) == 12 and fields[11].strip():
            try:
                confidence = float(fields[10])
            except ValueError:
                continue
            if confidence >= 0:
                values.append(confidence)
    return round(statistics.mean(values), 1) if values else None


def scan_number(path: Path) -> int:
    return int(path.stem.rsplit("_", 1)[-1])


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, nargs="+", help="JP2 scan images")
    parser.add_argument("--tesseract", default=shutil.which("tesseract"), help="Path to tesseract executable")
    parser.add_argument("--output-dir", type=Path, default=Path("data/reocr-audit"))
    args = parser.parse_args()

    if not args.tesseract:
        parser.error("Tesseract executable not found; pass --tesseract PATH")
    executable = str(Path(args.tesseract))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    report = [
        "# December 1926 Direct Tesseract Audit",
        "",
        "Preprocessing: grayscale, autocontrast, median denoise, 2x upscale, fixed threshold (175).",
        "OCR engine: Tesseract LSTM (`--oem 1`).",
        "",
    ]
    for image_path in args.input:
        if not image_path.is_file():
            parser.error(f"JP2 image not found: {image_path}")
        scan = scan_number(image_path)
        printed_page = scan + PRINTED_PAGE_OFFSET
        with Image.open(image_path) as source:
            image, deskew_angle = preprocess(source)
        width, height = image.size
        crops = [("full", image, 4, (0, width))]
        if scan == 41:
            first_boundary, second_boundary = column_boundaries(image)
            crops = [
                ("column-1", image.crop((0, 0, min(width, first_boundary + COLUMN_CROP_PADDING), height)), 6, (0, first_boundary)),
                ("column-2", image.crop((max(0, first_boundary - COLUMN_CROP_PADDING), 0, min(width, second_boundary + COLUMN_CROP_PADDING), height)), 6, (first_boundary, second_boundary)),
                ("column-3", image.crop((max(0, second_boundary - COLUMN_CROP_PADDING), 0, width, height)), 6, (second_boundary, width)),
            ]
        report.extend([f"## Scan {scan} / printed page {printed_page}", "", f"- Detected deskew angle: `{deskew_angle:+.1f}°`", ""])
        for label, crop, psm, bounds in crops:
            stem = f"{image_path.stem}_{label}"
            png_path = args.output_dir / f"{stem}.png"
            text_path = args.output_dir / f"{stem}.txt"
            tsv_path = args.output_dir / f"{stem}.tsv"
            crop.save(png_path, format="PNG", optimize=True)
            text = run_tesseract(executable, png_path, psm, "txt")
            tsv = run_tesseract(executable, png_path, psm, "tsv")
            text_path.write_text(text, encoding="utf-8", newline="\n")
            tsv_path.write_text(tsv, encoding="utf-8", newline="\n")
            confidence = tsv_confidence(tsv)
            report.extend(
                [
                    f"### {label}",
                    "",
                    f"- Crop: `{png_path}`",
                    f"- Horizontal bounds: `{bounds[0]}–{bounds[1]}`",
                    f"- OCR text: `{text_path}`",
                    f"- TSV: `{tsv_path}`",
                    f"- Page segmentation mode: `{psm}`",
                    f"- Mean word confidence: `{confidence if confidence is not None else 'unavailable'}`",
                    "",
                    "```text",
                    "\n".join(text.splitlines()[:30]),
                    "```",
                    "",
                ]
            )
    report_path = args.output_dir / "reocr-audit.md"
    report_path.write_text("\n".join(report), encoding="utf-8", newline="\n")
    print(f"Wrote OCR audit to {report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
