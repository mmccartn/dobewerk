#!/usr/bin/env python3
"""Verify a parser regression fixture against downloaded DjVu XML."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

try:
    from .extract_monthly_1926 import extract_page, registration_range
    from .inspect_stud_book import iter_pages
except ImportError:
    from extract_monthly_1926 import extract_page, registration_range
    from inspect_stud_book import iter_pages


def value(record: dict, field: str) -> object:
    if field in record.get("dog", {}):
        return record["dog"][field]
    if field in record.get("parents", {}):
        return record["parents"][field]
    return record.get(field)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--fixture",
        type=Path,
        default=Path("parser/fixtures/monthly_1926_v1_january_doberman.json"),
    )
    parser.add_argument("--volumes-dir", type=Path, default=Path("data/volumes"))
    args = parser.parse_args()

    fixture = json.loads(args.fixture.read_text(encoding="utf-8"))
    identifier = fixture["identifier"]
    xml_path = args.volumes_dir / identifier / f"{identifier}_djvu.xml"
    if not xml_path.is_file():
        parser.error(f"DjVu XML file not found: {xml_path}")
    pages = list(iter_pages(xml_path))
    volume_range = registration_range(pages)
    breed = ""
    records = []
    requested_pages = set(fixture["pages"])
    for page in pages:
        extracted, breed = extract_page(page, breed, volume_range)
        if page.number in requested_pages:
            records.extend(
                record for record in extracted if record["breed_heading"].casefold() == fixture["breed_heading"].casefold()
            )
    errors: list[str] = []
    if len(records) != fixture["expected_record_count"]:
        errors.append(f"expected {fixture['expected_record_count']} records, found {len(records)}")
    by_name = {record["dog"]["name"]: record for record in records}
    for name in fixture["required_names"]:
        if name not in by_name:
            errors.append(f"missing required record: {name}")
    for name, expected in fixture["expected_records"].items():
        record = by_name.get(name)
        if not record:
            continue
        for field, expected_value in expected.items():
            actual = value(record, field)
            if field == "warnings":
                if not all(warning in record["warnings"] for warning in expected_value):
                    errors.append(f"{name}: missing expected warnings {expected_value}")
            elif field == "max_confidence":
                if record["confidence"] > expected_value:
                    errors.append(f"{name}: confidence {record['confidence']} exceeds {expected_value}")
            elif actual != expected_value:
                errors.append(f"{name}: {field} expected {expected_value!r}, found {actual!r}")
    if errors:
        print("Fixture verification failed:")
        for error in errors:
            print(f"- {error}")
        return 1
    print(f"Fixture passed: {args.fixture} ({len(records)} records)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
