#!/usr/bin/env python3
"""Verify reviewed monthly_1926_v2 profile counts."""

from __future__ import annotations

from pathlib import Path

try:
    from .profiles.monthly_1926_v2 import extract
except ImportError:
    from profiles.monthly_1926_v2 import extract

CASES = (
    ("sim_american-kennel-club-stud-book-register_1926-01-31_43_1", {49, 50}, set(), 46),
    ("sim_american-kennel-club-stud-book-register_1926-06-30_43_6", {39, 40}, set(), 43),
    ("sim_american-kennel-club-stud-book-register_1926-12-31_43_12", {41, 42, 43}, {42}, 64),
)


def main() -> int:
    errors = []
    for identifier, pages, coordinate_pages, expected in CASES:
        records = extract(identifier, Path("data/volumes"), "Pinschers (Doberman)", pages, coordinate_pages)
        if len(records) != expected:
            errors.append(f"{identifier}: expected {expected}, found {len(records)}")
        else:
            print(f"Passed: {identifier} ({expected} records)")
    if errors:
        print("Profile verification failed:")
        for error in errors:
            print(f"- {error}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
