import json
from pathlib import Path

meta_col1 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-01-01_46_1", "date": "1929-01-01", "volume": "46", "issue": "1", "leaf": 40, "column": 2}
meta_col2 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-01-01_46_1", "date": "1929-01-01", "volume": "46", "issue": "1", "leaf": 40, "column": 3}
meta_col3 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-01-01_46_1", "date": "1929-01-01", "volume": "46", "issue": "1", "leaf": 41, "column": 1}

# Column 1 (Leaf 40, Page 35, Col 2 - 13 dogs)
col1_dogs = [
    {
        "name": "ADELLA OF RHINEGOLD", "sex": "Female", "registration_number": "666393",
        "birth_date": "May 26, 1928", "color": "Br & tn",
        "owner": "Stanley F. Lovett", "owner_location": None,
        "breeder": "Rhinegold Kennels", "breeder_location": "Detroit, Mich.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Princess Lita of Rhinegold", "dam_registration_number": "568913",
        "source": meta_col1
    },
    {
        "name": "ALMO OF MIDDLETOWN", "sex": "Female", "registration_number": "665119",
        "birth_date": "June 2, 1928", "color": "Bl & tn",
        "owner": "Roy Brown", "owner_location": None,
        "breeder": "W. N. McCoy", "breeder_location": "Middletown, O.",
        "sire": "Westphalia Dyno v Wiesengrund", "sire_registration_number": "365520",
        "dam": "Asta v Rauscheberg", "dam_registration_number": "504315",
        "source": meta_col1
    },
    {
        "name": "ARI V BOHLMAN", "sex": "Male", "registration_number": "664828",
        "birth_date": "June 12, 1928", "color": "Blk & tn",
        "owner": "Paul A. Klebba", "owner_location": None,
        "breeder": "G. C. Burr", "breeder_location": "Detroit, Mich.",
        "sire": "Benno v Glucksburg", "sire_registration_number": "605000",
        "dam": "A. Betty of Pontchartrain", "dam_registration_number": "439036",
        "source": meta_col1
    },
    {
        "name": "ARMO V KLOSTERSEE", "sex": "Male", "registration_number": "668213",
        "birth_date": "July 11, 1928", "color": "Blk & rust",
        "owner": "O. J. Phelps", "owner_location": None,
        "breeder": "Geo. H. Jones", "breeder_location": "Danville, Ill.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Princess v Rudolphsburg", "dam_registration_number": "569711",
        "source": meta_col1
    },
    {
        "name": "ASTA V HUNSTEIN", "sex": "Female", "registration_number": "665159",
        "birth_date": "Nov. 27, 1926", "color": "Blk & tn",
        "owner": "Bert Young", "owner_location": None,
        "breeder": "J. B. Whitwer", "breeder_location": "Mansfield, O.",
        "sire": "Printz Arto v d Spreehort", "sire_registration_number": "559555",
        "dam": "Zella v Geholz", "dam_registration_number": "568957",
        "source": meta_col1
    },
    {
        "name": "AUGUSTA V STROHEIM", "sex": "Female", "registration_number": "665315",
        "birth_date": "July 26, 1927", "color": "Blk & tn",
        "owner": "Harry L. Brown", "owner_location": None,
        "breeder": "H. W. Frushard", "breeder_location": "Omaha, Neb.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Frieda v Wiedensahl", "dam_registration_number": "564687",
        "source": meta_col1
    },
    {
        "name": "BARON MUNCHAUSEN", "sex": "Male", "registration_number": "666443",
        "birth_date": "Aug. 5, 1927", "color": "Rd & tn",
        "owner": "E. D. Knight", "owner_location": "Charleston, W. Va.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Siegfried v Coeln", "sire_registration_number": "382521",
        "dam": "Annetta", "dam_registration_number": "452684",
        "source": meta_col1
    },
    {
        "name": "BARON RUDOLF OF BIL KAY", "sex": "Male", "registration_number": "665924",
        "birth_date": "Feb. 15, 1928", "color": "Blk & tn",
        "owner": "Edward J. Stendts", "owner_location": None,
        "breeder": "Wm. H. Duffy", "breeder_location": "Northfield, N. J.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Huldegarde v Doernbach", "dam_registration_number": "661249",
        "source": meta_col1
    },
    {
        "name": "BLANKA V LENBURG", "sex": "Female", "registration_number": "666356",
        "birth_date": "Dec. 11, 1925", "color": "Blk & br",
        "owner": "Johanna Brauckmann", "owner_location": None,
        "breeder": "Raymond Menhard", "breeder_location": "St. Louis, Mo.",
        "sire": "Artus v d Holderburg", "sire_registration_number": None,
        "dam": "Tilly v Lenburg", "dam_registration_number": None,
        "source": meta_col1
    },
    {
        "name": "BRUNHILDE V SIGALSBURG", "sex": "Female", "registration_number": "667532",
        "birth_date": "Oct. 30, 1927", "color": "Blk & tn",
        "owner": "E. E. Carrier", "owner_location": None,
        "breeder": "Harry B. Holloway", "breeder_location": "Hamburg, N. Y.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Delice De Haven", "dam_registration_number": "525497",
        "source": meta_col1
    },
    {
        "name": "BRUNHILD V WIEDENSAHL II", "sex": "Female", "registration_number": "664968",
        "birth_date": "Sept. 16, 1927", "color": "Blk & tn",
        "owner": "E. D. Morrison", "owner_location": None,
        "breeder": "Carl A. Thiemann", "breeder_location": "Omaha, Neb.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Elly v Wiedensahl", "dam_registration_number": "489274",
        "source": meta_col1
    },
    {
        "name": "CARLO V D KONINGSTAD", "sex": "Male", "registration_number": "664902",
        "birth_date": "Feb. 1, 1928", "color": "Blk, tn mkgs",
        "owner": "Arthur J. Simon", "owner_location": None,
        "breeder": "Edward Rose", "breeder_location": "Queens Village, L. I., N. Y.",
        "sire": "Prinz Cuno of Westphalia", "sire_registration_number": "517068",
        "dam": "Mona Dora Zoic", "dam_registration_number": "412715",
        "source": meta_col1
    },
    {
        "name": "CASTOR V TIMMERSLOH", "sex": "Male", "registration_number": "667544",
        "birth_date": "Apr. 3, 1921", "color": "Blk & rd",
        "owner": "Adolf Karger", "owner_location": None,
        "breeder": "Heinr Smolenski", "breeder_location": "Germany",
        "sire": "Carlo Schilt", "sire_registration_number": None,
        "dam": "Asta Sander", "dam_registration_number": None,
        "source": meta_col1
    }
]

# Column 2 (Leaf 40, Page 35, Col 3 - 21 dogs)
col2_dogs = [
    {
        "name": "DINA V BARDINAD", "sex": "Female", "registration_number": "668351",
        "birth_date": "Sept. 1, 1922", "color": "Blk & tn",
        "owner": "Richard Volkelt", "owner_location": None,
        "breeder": "Gus Stoffels", "breeder_location": "Passaic, N. J.",
        "sire": "Prinz Kuckuck", "sire_registration_number": "257203",
        "dam": "Ardena v Elbstrom", "dam_registration_number": "380040",
        "source": meta_col2
    },
    {
        "name": "ERIN GO BRAGH", "sex": "Male", "registration_number": "665818",
        "birth_date": "May 25, 1928", "color": "Blk & rust",
        "owner": "Edmund F. Gibbons", "owner_location": None,
        "breeder": "Mrs. H. Gurtler", "breeder_location": "Coldwater, N. Y.",
        "sire": "Ludwig v Stolzenfels", "sire_registration_number": "650786",
        "dam": "Lady of the Delaware", "dam_registration_number": "642748",
        "source": meta_col2
    },
    {
        "name": "FRAULEIN V RESIDENZBURG", "sex": "Female", "registration_number": "665316",
        "birth_date": "Nov. 18, 1927", "color": "Blk, br mkgs",
        "owner": "A. M. Ferrell", "owner_location": None,
        "breeder": "M. D. Schuster", "breeder_location": "Youngstown, O.",
        "sire": "A Rappo of Pontchartrain", "sire_registration_number": "439031",
        "dam": "Perry's Glory v St. Sebald", "dam_registration_number": "425227",
        "source": meta_col2
    },
    {
        "name": "FRIEDA THE GREAT", "sex": "Female", "registration_number": "666262",
        "birth_date": "May 17, 1927", "color": "Blk & tn",
        "owner": "H. L. Foran", "owner_location": None,
        "breeder": "Carl A. Thiemann", "breeder_location": "Omaha, Neb.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Elly II v Wiedensahl", "dam_registration_number": "581816",
        "source": meta_col2
    },
    {
        "name": "FRITZIE BOY", "sex": "Male", "registration_number": "665239",
        "birth_date": "Apr. 22, 1928", "color": "Blk & tn",
        "owner": "Harold L. Neuman", "owner_location": None,
        "breeder": "E. De L. Fouque", "breeder_location": "Oxford, Pa.",
        "sire": "Trail'em Horstburg", "sire_registration_number": "545469",
        "dam": "Babette v Jagerhof", "dam_registration_number": "521089",
        "source": meta_col2
    },
    {
        "name": "FRITZ OF DHU VARREN", "sex": "Male", "registration_number": "667882",
        "birth_date": "July 10, 1928", "color": "Blk & rd",
        "owner": "Harry W. Peeples", "owner_location": None,
        "breeder": "Edward A. Hunter", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Fedor of Pontchartrain", "sire_registration_number": "509758",
        "dam": "Gaby of Pontchartrain", "dam_registration_number": "553020",
        "source": meta_col2
    },
    {
        "name": "GRAF BODO V SIGALSBURG", "sex": "Male", "registration_number": "668082",
        "birth_date": "Aug. 24, 1928", "color": "Blk & tn",
        "owner": "George E. West", "owner_location": None,
        "breeder": "Albert E. Farone", "breeder_location": "Oneonta, N. Y.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Rani v Stresow", "dam_registration_number": "561913",
        "source": meta_col2
    },
    {
        "name": "GRAF ECKENER OF RHINEGOLD", "sex": "Male", "registration_number": "664578",
        "birth_date": "June 18, 1928", "color": "Blk & br",
        "owner": "Rhinegold Kennels", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Alli v Goldgrund", "dam_registration_number": "442052",
        "source": meta_col2
    },
    {
        "name": "GRAFIN ZEPPELIN OF RHINEGOLD", "sex": "Female", "registration_number": "665906",
        "birth_date": "June 18, 1928", "color": "Br & tn",
        "owner": "Rhinegold Kennels", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favoriet Van De Koningstad", "sire_registration_number": "420325",
        "dam": "Alli v Goldgrund", "dam_registration_number": "442052",
        "source": meta_col2
    },
    {
        "name": "GRAF V SIGALSBURG", "sex": "Male", "registration_number": "668419",
        "birth_date": "Aug. 24, 1928", "color": "Blk & tn",
        "owner": "Alice F. Gilbert", "owner_location": None,
        "breeder": "Albert E. Farone", "breeder_location": "Oneonta, N. Y.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Rani v Stresow", "dam_registration_number": "561913",
        "source": meta_col2
    },
    {
        "name": "GRAF ZEPPELIN OF RHINEGOLD", "sex": "Male", "registration_number": "665905",
        "birth_date": "May 26, 1928", "color": "Blk & tn",
        "owner": "Rhinegold Kennels", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Princess Lita of Rhinegold", "dam_registration_number": "568913",
        "source": meta_col2
    },
    {
        "name": "GRETA V EVERFAITHFUL", "sex": "Female", "registration_number": "667429",
        "birth_date": "Jan. 27, 1927", "color": "Bl & tn",
        "owner": "Zoe L. Olmsted", "owner_location": None,
        "breeder": "E. H. Hillyard", "breeder_location": "Dubuque, Ia.",
        "sire": "Walden v Everfaithful", "sire_registration_number": "334992",
        "dam": "Hillyard's Greta", "dam_registration_number": "602928",
        "source": meta_col2
    },
    {
        "name": "HANS V BULOW", "sex": "Male", "registration_number": "664967",
        "birth_date": "Sept. 22, 1927", "color": "Blk & tn",
        "owner": "Blanche D. Rafter", "owner_location": None,
        "breeder": "Evarts M. Wylie", "breeder_location": "Gardiner, Me.",
        "sire": "Bisdroff", "sire_registration_number": "569707",
        "dam": "Erna v Grothaus", "dam_registration_number": "509483",
        "source": meta_col2
    },
    {
        "name": "HENNA", "sex": "Female", "registration_number": "668249",
        "birth_date": "July 11, 1928", "color": "Rd & tn",
        "owner": "D. Bosserman", "owner_location": None,
        "breeder": "Leo J. La Velle", "breeder_location": "Chicago, Ill.",
        "sire": "Toney", "sire_registration_number": "645756",
        "dam": "Dolly v d Spree", "dam_registration_number": "662837",
        "source": meta_col2
    },
    {
        "name": "JOHAN V SIEGELBERG", "sex": "Male", "registration_number": "666444",
        "birth_date": "May 12, 1924", "color": "Blk & tn",
        "owner": "Charles Hill", "owner_location": None,
        "breeder": "Chas. Baierl", "breeder_location": "Milwaukee, Wis.",
        "sire": "Amor v Siegelberg", "sire_registration_number": "407553",
        "dam": "Rosalia v Darmstadt", "dam_registration_number": "402176",
        "source": meta_col2
    },
    {
        "name": "JUDY V HORSTBURG", "sex": "Female", "registration_number": "666015",
        "birth_date": "Dec. 6, 1927", "color": "Bl & tn",
        "owner": "A. C. Flint", "owner_location": None,
        "breeder": "A. C. Steele", "breeder_location": "Ardmore, Pa.",
        "sire": "Trail'Em Horstburg", "sire_registration_number": "545469",
        "dam": "Gretchen v Eckhardstein", "dam_registration_number": "436778",
        "source": meta_col2
    },
    {
        "name": "JUNE'S LADY GRAMMONT", "sex": "Female", "registration_number": "668250",
        "birth_date": "July 17, 1928", "color": "Blk, tn & rd",
        "owner": "June Warden", "owner_location": None,
        "breeder": "P. L. Atkerton", "breeder_location": "Glenview, Ky.",
        "sire": "Prince Alexis of Ardenne", "sire_registration_number": "599344",
        "dam": "Trail'Em Sandy", "dam_registration_number": "561300",
        "source": meta_col2
    },
    {
        "name": "LADY V D TRIFFT", "sex": "Female", "registration_number": "668096",
        "birth_date": "July 5, 1928", "color": "Blk & tn",
        "owner": "Alma Reynolds", "owner_location": None,
        "breeder": "H. W. Pfalzgraf", "breeder_location": "Cincinnati, O.",
        "sire": "Apollo v Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Belle v d Spree", "dam_registration_number": "663264",
        "source": meta_col2
    },
    {
        "name": "LAMBRECHT'S FLORA", "sex": "Female", "registration_number": "668352",
        "birth_date": "Dec. 10, 1926", "color": "Blk & rust rd",
        "owner": "Gustav Lambrecht", "owner_location": None,
        "breeder": "E. Henning", "breeder_location": "Philadelphia, Pa.",
        "sire": "Trail'Em Horstburg", "sire_registration_number": "545469",
        "dam": "Trail'Em Dinah", "dam_registration_number": "569502",
        "source": meta_col2
    },
    {
        "name": "LILLIE V LICHTENSTEIN", "sex": "Female", "registration_number": "668455",
        "birth_date": "June 18, 1928", "color": "Blk & tn",
        "owner": "Alfred Rothig", "owner_location": None,
        "breeder": "Joseph Preu", "breeder_location": "Corona, L. I., N. Y.",
        "sire": "Arno v d Friedrichsau", "sire_registration_number": "537762",
        "dam": "Elka of Arkeden", "dam_registration_number": "642584",
        "source": meta_col2
    },
    {
        "name": "MAIDSHEN V GRANITE HILL", "sex": "Female", "registration_number": "668106",
        "birth_date": "Aug. 11, 1927", "color": "Blk & tn",
        "owner": "Joseph S. Treacy", "owner_location": None,
        "breeder": "Nathan Walker and Joseph S. Treacy", "breeder_location": "Manchester, N. H.",
        "sire": "Baldur v Koenigswart", "sire_registration_number": "534316",
        "dam": "Peggy v Wedon", "dam_registration_number": "556749",
        "source": meta_col2
    }
]

# Column 3 (Leaf 41, Page 36, Col 1 - 17 dogs)
col3_dogs = [
    {
        "name": "MARK TRUMANSBURG", "sex": "Male", "registration_number": "666046",
        "birth_date": "June 16, 1928", "color": "Blk & tn",
        "owner": "Max Berkowitz", "owner_location": None,
        "breeder": "Wm. H. Lawson", "breeder_location": "Detroit, Mich.",
        "sire": "Nuttall's Prinz", "sire_registration_number": "610640",
        "dam": "Lawson's Lily", "dam_registration_number": "587606",
        "source": meta_col3
    },
    {
        "name": "MAX V STRESOW", "sex": "Male", "registration_number": "668350",
        "birth_date": "Apr. 1, 1928", "color": "Br & rust",
        "owner": "S. S. Lamont", "owner_location": None,
        "breeder": "E. A. Mayberry", "breeder_location": "Enid, Okla.",
        "sire": "Diethelm v Stresow", "sire_registration_number": "480476",
        "dam": "Clovis Fra Duncan", "dam_registration_number": "591472",
        "source": meta_col3
    },
    {
        "name": "OTELLO OF PONTCHARTRAIN", "sex": "Male", "registration_number": "667919",
        "birth_date": "Sept. 10, 1928", "color": "Blk & br",
        "owner": "H. F. Heisley", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Pontchartrain Freya v Stresow", "dam_registration_number": "422451",
        "source": meta_col3
    },
    {
        "name": "PAL V D TAXILUST", "sex": "Male", "registration_number": "664533",
        "birth_date": "June 19, 1927", "color": "Rust rd & blk",
        "owner": "Sam Joffe", "owner_location": None,
        "breeder": "Norman P. Black", "breeder_location": "Cleveland, O.",
        "sire": "Benno v d Waldlust", "sire_registration_number": "503559",
        "dam": "Bertha v Taxispark", "dam_registration_number": "503560",
        "source": meta_col3
    },
    {
        "name": "PRINCESS ANGOLA OF RHINEGOLD", "sex": "Female", "registration_number": "665904",
        "birth_date": "June 15, 1928", "color": "Br & tn",
        "owner": "Rhinegold Kennels", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Alli v Goldgrund", "dam_registration_number": "442052",
        "source": meta_col3
    },
    {
        "name": "PRINCESS MINERVA OF RHINEGOLD", "sex": "Female", "registration_number": "664575",
        "birth_date": "May 26, 1928", "color": "Blk & br",
        "owner": "Rhinegold Kennels", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Princess Lita of Rhinegold", "dam_registration_number": "568913",
        "source": meta_col3
    },
    {
        "name": "PRINCE TROLL OF RHINEGOLD", "sex": "Male", "registration_number": "664577",
        "birth_date": "June 18, 1928", "color": "Blk & br",
        "owner": "Rhinegold Kennels", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Alli v Goldgrund", "dam_registration_number": "442052",
        "source": meta_col3
    },
    {
        "name": "PRINSESSIN OF BIL KAY", "sex": "Female", "registration_number": "665392",
        "birth_date": "Feb. 15, 1928", "color": "Rd & tn",
        "owner": "Walter W. Clark, Jr.", "owner_location": None,
        "breeder": "Wm. H. Duffy", "breeder_location": "Northfield, N. J.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Hildegarde v Doernbach", "dam_registration_number": "661249",
        "source": meta_col3
    },
    {
        "name": "QUEEN V D GRANITE HILLS", "sex": "Female", "registration_number": "665846",
        "birth_date": "Aug. 11, 1927", "color": "Rd & tn",
        "owner": "Joseph S. Treacy", "owner_location": None,
        "breeder": "Nathan Walker and Joseph S. Treacy", "breeder_location": "Manchester, N. H.",
        "sire": "Baldur v Koegingswart", "sire_registration_number": "534316",
        "dam": "Peggy v Wedon", "dam_registration_number": "556749",
        "source": meta_col3
    },
    {
        "name": "RENO V STROSSEN", "sex": "Female", "registration_number": "664506",
        "birth_date": "Mar. 18, 1927", "color": "Blk & rd",
        "owner": "Bart Delacourt", "owner_location": None,
        "breeder": "C. J. Groen", "breeder_location": "Monticello, Cal.",
        "sire": "Max v Strossen", "sire_registration_number": "509139",
        "dam": "Gerhilde v Roemerhof", "dam_registration_number": "582213",
        "source": meta_col3
    },
    {
        "name": "RIFF RUDOLPH V HORSTBURG", "sex": "Male", "registration_number": "665178",
        "birth_date": "June 16, 1927", "color": "Blk & rust rd",
        "owner": "Fletcher P. Wood, Jr.", "owner_location": None,
        "breeder": "John Hieber", "breeder_location": "Philadelphia, Pa.",
        "sire": "Trail'Em Horstburg", "sire_registration_number": "545469",
        "dam": "Senta Rathjen", "dam_registration_number": "518308",
        "source": meta_col3
    },
    {
        "name": "RIVAL OF BELLBERG", "sex": "Male", "registration_number": "667774",
        "birth_date": "July 3, 1928", "color": "Blk & tn",
        "owner": "A. I. Pruett", "owner_location": None,
        "breeder": "E. J. Robinson", "breeder_location": "Milwaukee, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Robinson's Leisel", "dam_registration_number": "591640",
        "source": meta_col3
    },
    {
        "name": "RUSTY", "sex": "Male", "registration_number": "666977",
        "birth_date": "May 2, 1927", "color": "Rd, br & blk",
        "owner": "W. G. Cowles", "owner_location": None,
        "breeder": "Carol L. Belger", "breeder_location": "Newtown, Mass.",
        "sire": "Carlo v Belger", "sire_registration_number": "533994",
        "dam": "Johanna v Belger", "dam_registration_number": "535725",
        "source": meta_col3
    },
    {
        "name": "SULTRA V UMSTADT", "sex": "Male", "registration_number": "665503",
        "birth_date": "Dec. 10, 1926", "color": "Lvr & tn",
        "owner": "H. C. Gilbert", "owner_location": None,
        "breeder": "E. Henning", "breeder_location": "Philadelphia, Pa.",
        "sire": "Trail'Em Horstburg", "sire_registration_number": "545469",
        "dam": "Trail'Em Dinah", "dam_registration_number": "569502",
        "source": meta_col3
    },
    {
        "name": "THE HOYDEN OF RHINEGOLD", "sex": "Female", "registration_number": "664576",
        "birth_date": "May 26, 1928", "color": "Blk & br",
        "owner": "Rhinegold Kennels", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Princess Lita of Rhinegold", "dam_registration_number": "568913",
        "source": meta_col3
    },
    {
        "name": "TINKER OF RHINEGOLD", "sex": "Male", "registration_number": "667097",
        "birth_date": "June 18, 1928", "color": "Br & rust",
        "owner": "Chas. L. Winningham", "owner_location": None,
        "breeder": "Rhinegold Kennels", "breeder_location": "Detroit, Mich.",
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Alli v Goldgrund", "dam_registration_number": "442052",
        "source": meta_col3
    },
    {
        "name": "UNSER FRITZ OF RHINEGOLD", "sex": "Male", "registration_number": "664574",
        "birth_date": "May 26, 1928", "color": "Blk & br",
        "owner": "Rhinegold Kennels", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Princess Lita of Rhinegold", "dam_registration_number": "568913",
        "source": meta_col3
    }
]

all_51 = col1_dogs + col2_dogs + col3_dogs
print(f"Total compiled dogs: {len(all_51)}")
Path("stud-scrape/data/verified_1929_01.json").write_text(json.dumps(all_51, indent=2), encoding="utf-8")
print("Saved clean 1929-01 records to stud-scrape/data/verified_1929_01.json")
