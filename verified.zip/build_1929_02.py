import json
from pathlib import Path

meta_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-02-01_46_2", "date": "1929-02-01", "volume": "46", "issue": "2", "leaf": 34, "column": 3}
meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-02-01_46_2", "date": "1929-02-01", "volume": "46", "issue": "2", "leaf": 35, "column": 1}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-02-01_46_2", "date": "1929-02-01", "volume": "46", "issue": "2", "leaf": 35, "column": 2}
meta_c4 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-02-01_46_2", "date": "1929-02-01", "volume": "46", "issue": "2", "leaf": 35, "column": 3}

# Column 1 (Leaf 34 Col 3 bottom - 2 dogs)
c1_dogs = [
    {
        "name": "ADALINE V SAUMHOF", "sex": "Female", "registration_number": "668566",
        "birth_date": "Oct. 1, 1927", "color": "Blk & tn",
        "owner": "Harold L. Walley", "owner_location": None,
        "breeder": "Jacques Blum", "breeder_location": "Pittsburgh, Pa.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Adaline v Nibelungenhort", "dam_registration_number": "438103",
        "source": meta_c1
    },
    {
        "name": "ALFRA V KLOSTERSEE", "sex": "Female", "registration_number": "669159",
        "birth_date": "July 11, 1928", "color": "Blk & rust",
        "owner": "August L. Hatzfeld", "owner_location": None,
        "breeder": "Geo. H. Jones", "breeder_location": "Danville, Ill.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Princess v Rudolphsburg", "dam_registration_number": "569711",
        "source": meta_c1
    }
]

# Column 2 (Leaf 35 Col 1 - 20 dogs)
c2_dogs = [
    {
        "name": "ALTO V BEHLMAN", "sex": "Male", "registration_number": "669651",
        "birth_date": "June 12, 1928", "color": "Rd & tn",
        "owner": "D. R. Williams", "owner_location": None,
        "breeder": "G. C. Burr", "breeder_location": "Detroit, Mich.",
        "sire": "Benno v d Glucksburg", "sire_registration_number": "605000",
        "dam": "A Betty of Pontchartrain", "dam_registration_number": "439036",
        "source": meta_c2
    },
    {
        "name": "ANNI V DOMBACHTAL", "sex": "Female", "registration_number": "669160",
        "birth_date": "Nov. 20, 1927", "color": "Blk & tn",
        "owner": "August L. Hatzfeld", "owner_location": None,
        "breeder": "Mrs. R. E. Byrd", "breeder_location": "Erie, Pa.",
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Dolly v Dombachtal of Perry", "dam_registration_number": "555513",
        "source": meta_c2
    },
    {
        "name": "ARNO V SOTHENBERG", "sex": "Male", "registration_number": "670381",
        "birth_date": "Jan. 30, 1927", "color": "Blk & rd",
        "owner": "Chas. Kasten", "owner_location": None,
        "breeder": "H. Wille", "breeder_location": "Germany",
        "sire": "Primus v Hohenesp", "sire_registration_number": None,
        "dam": "Agnes v Steinhagen", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Basto Halberstadt", "registration_number": None},
            {"role": "dam_of_dam", "name": "Alice v Lichterfelde", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Remo v d Bergstrasse", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Brunhilde v Celle", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Gerhard v Parthengrund", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Senja v d Mohrinsel", "registration_number": None},
            {"role": "sire_of_sire", "name": "Dolf v d Bergstrasse", "registration_number": None},
            {"role": "dam_of_sire", "name": "Anny v Hohenesp", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Jak v Fernrode", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Senta Heyer", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Hedda v Fernrode", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "ASTA FOSS", "sex": "Female", "registration_number": "668565",
        "birth_date": "Nov. 3, 1925", "color": "Blk & tn",
        "owner": "Mrs. L. J. Ketterman", "owner_location": "Sacramento, Cal.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Banko v Luisenberg", "sire_registration_number": "505939",
        "dam": "Minko", "dam_registration_number": "526818",
        "source": meta_c2
    },
    {
        "name": "AUGUSTO V MUNSTER", "sex": "Male", "registration_number": "669951",
        "birth_date": "Jan. 27, 1927", "color": "Blk & tn",
        "owner": "M. Peters and Helen Gurtler", "owner_location": None,
        "breeder": "Henry J. Mirbach", "breeder_location": "Syracuse, N. Y.",
        "sire": "Tango v Ostersee", "sire_registration_number": "421813",
        "dam": "Blanka v Roemerwall", "dam_registration_number": "426934",
        "source": meta_c2
    },
    {
        "name": "BEBE V KONINGSTAD", "sex": "Female", "registration_number": "668628",
        "birth_date": "Aug. 19, 1927", "color": "Blk & tn",
        "owner": "Harry V. Steiger", "owner_location": None,
        "breeder": "Mae H. P. Bigler", "breeder_location": "Ambler, Pa.",
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Reida of Red Roof", "dam_registration_number": "326634",
        "source": meta_c2
    },
    {
        "name": "BARONESS FRIEDA V D HOHEN", "sex": "Female", "registration_number": "669255",
        "birth_date": "Apr. 27, 1927", "color": "Br & tn",
        "owner": "Eileen Freed", "owner_location": None,
        "breeder": "Mrs. M. von Hoegen", "breeder_location": "Towaco, N. J.",
        "sire": "Prinz Carlo of Westphalia", "sire_registration_number": "517068",
        "dam": "Elva v Avonthal", "dam_registration_number": "506375",
        "source": meta_c2
    },
    {
        "name": "BOBO GOTTSCHALK", "sex": "Male", "registration_number": "671790",
        "birth_date": "Dec. 14, 1928", "color": "Rd & br",
        "owner": "T. Higbee Embry", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Astor Gottschalk", "sire_registration_number": "639147",
        "dam": "Ary Tremonia", "dam_registration_number": "605201",
        "source": meta_c2
    },
    {
        "name": "CESSNA V D DREHBRUCKE", "sex": "Female", "registration_number": "671789",
        "birth_date": "Oct. 1, 1928", "color": "Blk, rd mkd",
        "owner": "T. Higbee Embry", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Benno v d Drehbrucke", "sire_registration_number": "639146",
        "dam": "Anita v Grossmannstein", "dam_registration_number": "605203",
        "source": meta_c2
    },
    {
        "name": "CLAUSS OF KALAMAZOO", "sex": "Male", "registration_number": "672008",
        "birth_date": "July 27, 1928", "color": "Blk & tn",
        "owner": "Harmon S. Scott", "owner_location": None,
        "breeder": "H. J. Dwillard", "breeder_location": "Kalamazoo, Mich.",
        "sire": "Printz Negus v Nibelungenhort", "sire_registration_number": "379731",
        "dam": "Presque Isle Zareda", "dam_registration_number": "369303",
        "source": meta_c2
    },
    {
        "name": "CUNO V MUSENBACH II", "sex": "Male", "registration_number": "670925",
        "birth_date": "June 22, 1928", "color": "Blk & tn",
        "owner": "George Nagel", "owner_location": None,
        "breeder": "Margaret Lee Fahey", "breeder_location": "Lewiston, Me.",
        "sire": "Cuno v Musenbach", "sire_registration_number": "596712",
        "dam": "Rota Bella v Steuben", "dam_registration_number": "516684",
        "source": meta_c2
    },
    {
        "name": "DERBY V BURGGRAFEN", "sex": "Male", "registration_number": "671428",
        "birth_date": "Dec. 16, 1923", "color": "Blk & rd",
        "owner": "Karl O. Draeger", "owner_location": None,
        "breeder": "August Sebesse", "breeder_location": "Germany",
        "sire": "Banjo v d goldenen Hohe", "sire_registration_number": None,
        "dam": "Asta v Kreuzhoch", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Treu v d Berde", "registration_number": None},
            {"role": "dam_of_dam", "name": "Bella v d Linde", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Benno v Morgenstern", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Walli v d Freundschaft", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Teja Herzynia", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Helma II v Warteberg", "registration_number": None},
            {"role": "sire_of_sire", "name": "Arnfried v Brandis", "registration_number": None},
            {"role": "dam_of_sire", "name": "Erika v Parthengrund", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Max v d Klosterburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Lore v Parthengrund", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Stopp v Parthengrund", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Blanka v Parthengrund", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "DHU VARREN'S MARCO", "sex": "Male", "registration_number": "670528",
        "birth_date": "July 10, 1928", "color": "Blk & tn",
        "owner": "Raymond I. Hutzel", "owner_location": None,
        "breeder": "Edw. A. Hunter", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Fedor of Pontchartrain", "sire_registration_number": "509758",
        "dam": "Gaby of Pontchartrain", "dam_registration_number": "553020",
        "source": meta_c2
    },
    {
        "name": "DIANA V BRIESEN", "sex": "Female", "registration_number": "669376",
        "birth_date": "May 20, 1927", "color": "Blk & tn",
        "owner": "Helyn Ann Peck", "owner_location": None,
        "breeder": "Mickburn Kennels", "breeder_location": "Eldorado, Ill.",
        "sire": "Red Roof Rowdy", "sire_registration_number": "392482",
        "dam": "Laura of Mickburn", "dam_registration_number": "578933",
        "source": meta_c2
    },
    {
        "name": "DONOVAN'S V SKIPPY", "sex": "Female", "registration_number": "669650",
        "birth_date": "Nov. 1, 1926", "color": "Blk & tn",
        "owner": "Pete Donovan", "owner_location": "Erie, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Perry's Heinie v Saint Sebald", "sire_registration_number": "558424",
        "dam": "Donovan's Gretchen", "dam_registration_number": "538598",
        "source": meta_c2
    },
    {
        "name": "EGON OF PONTCHARTRAIN", "sex": "Male", "registration_number": "671783",
        "birth_date": "July 18, 1928", "color": "Blk & rust",
        "owner": "Mrs. R. John Heber", "owner_location": None,
        "breeder": "William O. McClane", "breeder_location": "Chicago, Ill.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Flora v d Buetersburg of Ardwin", "dam_registration_number": "499562",
        "source": meta_c2
    },
    {
        "name": "FALKO V D BLANKENSPREE", "sex": "Female", "registration_number": "669318",
        "birth_date": "July 21, 1927", "color": "Blk & rust",
        "owner": "H. B. Smith", "owner_location": None,
        "breeder": "Delbert C. Cox", "breeder_location": "Tulsa, Okla.",
        "sire": "Arno v Burgfried", "sire_registration_number": "426603",
        "dam": "Adele v d Hortspree", "dam_registration_number": "613883",
        "source": meta_c2
    },
    {
        "name": "FELAX V D STERNENSTRASSE", "sex": "Male", "registration_number": "669320",
        "birth_date": "May 1, 1928", "color": "Rd & tn",
        "owner": "Carl M. Fischer", "owner_location": None,
        "breeder": "Fred M. Berger", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Freya v Bergerhof", "dam_registration_number": "578494",
        "source": meta_c2
    },
    {
        "name": "FLOYD", "sex": "Male", "registration_number": "672006",
        "birth_date": "Apr. 1, 1927", "color": "Blk & tn",
        "owner": "Herman Koch", "owner_location": "Chicago, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Arko v Bottwartal", "sire_registration_number": "620924",
        "dam": "Betty II", "dam_registration_number": "585170",
        "source": meta_c2
    },
    {
        "name": "GERTI V HOHENSCHWANAU", "sex": "Female", "registration_number": "670137",
        "birth_date": "June 13, 1927", "color": "Blk & rust",
        "owner": "F. C. Fuqua", "owner_location": None,
        "breeder": "Mathias Schmitt", "breeder_location": "Lincoln, N. J.",
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Dora v Hohenschwanau", "dam_registration_number": "590688",
        "source": meta_c2
    }
]

# Column 3 (Leaf 35 Col 2 - 22 dogs)
c3_dogs = [
    {
        "name": "GRETEL V HORSTBURG", "sex": "Female", "registration_number": "670190",
        "birth_date": "June 21, 1927", "color": "Blk & tn",
        "owner": "Dorothy Bolce", "owner_location": None,
        "breeder": "Mrs. Elmer Schweninger", "breeder_location": "Cincinnati, O.",
        "sire": "Toby", "sire_registration_number": "491065",
        "dam": "Hamer's Peggy", "dam_registration_number": "587825",
        "source": meta_c3
    },
    {
        "name": "HILDA ROMER", "sex": "Female", "registration_number": "671944",
        "birth_date": "Aug. 17, 1926", "color": "Blk & tn",
        "owner": "H. Preston Wolfe", "owner_location": None,
        "breeder": "J. H. Vrancken", "breeder_location": "Columbus, O.",
        "sire": "Arnold v Cartenberg", "sire_registration_number": "435139",
        "dam": "Hilda Hoyler", "dam_registration_number": "495893",
        "source": meta_c3
    },
    {
        "name": "HULDA V D WINTERBURG", "sex": "Female", "registration_number": "668994",
        "birth_date": "Oct. 22, 1926", "color": "Blk & rd",
        "owner": "Herman Wohlgemuth", "owner_location": None,
        "breeder": "Karl Winter", "breeder_location": "Germany",
        "sire": "Axel v Haardtgebirg", "sire_registration_number": None,
        "dam": "Ferri v d Winterburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Benno v d Romerhof", "registration_number": "517073"},
            {"role": "dam_of_dam", "name": "Lotte v Brennetsried", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Waldo Gluck Auf Penzberg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Freya Kadletz", "registration_number": None},
            {"role": "sire_of_sire", "name": "Densos v Atlantic", "registration_number": None},
            {"role": "dam_of_sire", "name": "Asta v Pfalzer Rhein", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Friedel v Grauenstein", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Banjo v d Gold Hohe", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Mignon v Parthengrund", "registration_number": None}
        ],
        "source": meta_c3
    },
    {
        "name": "JIMMY V SIGALSBURG", "sex": "Male", "registration_number": "671041",
        "birth_date": "Sept. 7, 1928", "color": "Blk & tn",
        "owner": "Phil Frisch", "owner_location": None,
        "breeder": "Mrs. Elmer Schweninger", "breeder_location": "Cincinnati, O.",
        "sire": "Boone v Sigalsburg", "sire_registration_number": "658766",
        "dam": "Hamer's Peggy", "dam_registration_number": "587825",
        "source": meta_c3
    },
    {
        "name": "JURGEN V STEUBEN", "sex": "Male", "registration_number": "671784",
        "birth_date": "Aug. 4, 1928", "color": "Blk & rust",
        "owner": "Mary Adams Calvert", "owner_location": None,
        "breeder": "Mrs. H. S. Taylor", "breeder_location": "Lakewood, N. J.",
        "sire": "Jof v Steuben", "sire_registration_number": "654600",
        "dam": "Rota v Steuben", "dam_registration_number": "649190",
        "source": meta_c3
    },
    {
        "name": "KARZO V D POPP", "sex": "Male", "registration_number": "669278",
        "birth_date": "June 5, 1926", "color": "Blk & tn",
        "owner": "Hugh J. Beaumont", "owner_location": None,
        "breeder": "T. E. Popp", "breeder_location": "West Allis, Wis.",
        "sire": "Rolf v Koenigstuhl", "sire_registration_number": "464184",
        "dam": "Dortell v Popp", "dam_registration_number": "526001",
        "source": meta_c3
    },
    {
        "name": "KING V WALLENSTEIN", "sex": "Male", "registration_number": "671854",
        "birth_date": "Feb. 22, 1926", "color": "Blk & tn",
        "owner": "Joseph Katscha", "owner_location": None,
        "breeder": "Fred M. Berger", "breeder_location": "Chicago, Ill.",
        "sire": "Caballero v Wassertor", "sire_registration_number": "628898",
        "dam": "Freya v Bergerhof", "dam_registration_number": "578494",
        "source": meta_c3
    },
    {
        "name": "KURT V ELBERFELD", "sex": "Male", "registration_number": "669700",
        "birth_date": "July 17, 1927", "color": "Blk & tn",
        "owner": "F. M. Schwanze", "owner_location": None,
        "breeder": "Bert Young", "breeder_location": "Granville, O.",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Lady Gretchen", "dam_registration_number": "574220",
        "source": meta_c3
    },
    {
        "name": "LADY V WESTPHALENHOF", "sex": "Female", "registration_number": "671782",
        "birth_date": "Mar. 24, 1927", "color": "Blk & tn",
        "owner": "Eleanor J. Nelson", "owner_location": None,
        "breeder": "Otto Peveling", "breeder_location": "Arlington Heights, Mass.",
        "sire": "Buddy of White Gate", "sire_registration_number": "352361",
        "dam": "Dusty of Stockwell", "dam_registration_number": "527027",
        "source": meta_c3
    },
    {
        "name": "LINDY V FORSBERG", "sex": "Male", "registration_number": "670607",
        "birth_date": "May 16, 1928", "color": "Blk & tn",
        "owner": "Hjalmar G. Forsberg", "owner_location": None,
        "breeder": "A. C. Wilhelm", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Burga v Scharflueck", "dam_registration_number": "434189",
        "source": meta_c3
    },
    {
        "name": "LITA V D BURGHOLZ", "sex": "Female", "registration_number": "671060",
        "birth_date": "Mar. 15, 1926", "color": "Blk, tn mkgs",
        "owner": "Frank B. Tanner", "owner_location": None,
        "breeder": "John Schofield", "breeder_location": "Elverson, Pa.",
        "sire": "Armin v Burgfried", "sire_registration_number": "430843",
        "dam": "Countess v Burgholz", "dam_registration_number": "449862",
        "source": meta_c3
    },
    {
        "name": "LORD V STRESLAU", "sex": "Male", "registration_number": "668796",
        "birth_date": "June 22, 1928", "color": "Blk, rust rd",
        "owner": "Herman Marks", "owner_location": None,
        "breeder": "Wm. Dunn", "breeder_location": "Detroit, Mich.",
        "sire": "Carlo v d Schwanenhohe", "sire_registration_number": "567146",
        "dam": "Ali v Streslau", "dam_registration_number": "539724",
        "source": meta_c3
    },
    {
        "name": "MAUS V SEDREVLA", "sex": "Female", "registration_number": "671985",
        "birth_date": "Jan. 8, 1926", "color": "Blk & tn",
        "owner": "Karl P's Graeuwen", "owner_location": None,
        "breeder": "Richard Volkelt", "breeder_location": "Astoria, L. I., N. Y.",
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Dina v Bardinad", "dam_registration_number": "668351",
        "source": meta_c3
    },
    {
        "name": "MONA J OF GRAUTTENBAR", "sex": "Female", "registration_number": "671943",
        "birth_date": "May 30, 1928", "color": "Blk & tn",
        "owner": "Clemont G. Spoutz", "owner_location": None,
        "breeder": "Mrs. W. R. Judson", "breeder_location": "Ferndale, Mich.",
        "sire": "Prince Eitel of Rhinegold", "sire_registration_number": "614471",
        "dam": "Judy of Rhinegold", "dam_registration_number": "556001",
        "source": meta_c3
    },
    {
        "name": "NANETTE", "sex": "Female", "registration_number": "670195",
        "birth_date": "Mar. 7, 1927", "color": "Blk & rust rd",
        "owner": "E. R. Grossman", "owner_location": None,
        "breeder": "P. L. Atherton", "breeder_location": "Glenview, Ky.",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Westdorf Hermine v Dorn", "dam_registration_number": "501695",
        "source": meta_c3
    },
    {
        "name": "O'MIN OF BORNHOLM", "sex": "Female", "registration_number": "669986",
        "birth_date": "May 7, 1928", "color": "Blk & br",
        "owner": "Mrs. Wm. A. Cottingham", "owner_location": None,
        "breeder": "Carl N. Hansen", "breeder_location": "Cincinnati, O.",
        "sire": "Hamer of Bornholm", "sire_registration_number": "362662",
        "dam": "Flora v d Spree", "dam_registration_number": "606727",
        "source": meta_c3
    },
    {
        "name": "OTTO V PLEISSENBURG", "sex": "Male", "registration_number": "671525",
        "birth_date": "Oct. 26, 1926", "color": "Br & tn",
        "owner": "Lester Rankin", "owner_location": None,
        "breeder": "Sherman Armstrong", "breeder_location": "Salt Lake City, Utah",
        "sire": "Artus v Pleissenburg", "sire_registration_number": "501985",
        "dam": "Dot v Rottal", "dam_registration_number": "393411",
        "source": meta_c3
    },
    {
        "name": "PRINTZ V D INSUL", "sex": "Male", "registration_number": "671570",
        "birth_date": "July 17, 1927", "color": "Blk & tn",
        "owner": "H. H. Crowe", "owner_location": None,
        "breeder": "Bert Young", "breeder_location": "Granville, O.",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Lady Gretchen", "dam_registration_number": "574220",
        "source": meta_c3
    },
    {
        "name": "PRINZ KARL FRANZ OF BIL KAY", "sex": "Male", "registration_number": "671797",
        "birth_date": "Feb. 15, 1928", "color": "Blk & tn",
        "owner": "Harold A. Brand", "owner_location": None,
        "breeder": "William H. Duffy", "breeder_location": "Northfield, N. J.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Hildegarde v Doernbach", "dam_registration_number": "661249",
        "source": meta_c3
    },
    {
        "name": "ROBINSON'S PATRICIA", "sex": "Female", "registration_number": "669648",
        "birth_date": "July 3, 1928", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Robinson's Leisel", "dam_registration_number": "591640",
        "source": meta_c3
    },
    {
        "name": "ROBINSON'S PRINCE", "sex": "Male", "registration_number": "669647",
        "birth_date": "July 3, 1928", "color": "Blk & tn",
        "owner": "R. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Robinson's Leisel", "dam_registration_number": "591640",
        "source": meta_c3
    },
    {
        "name": "ROBINSON'S SUE CLAIRE", "sex": "Female", "registration_number": "669649",
        "birth_date": "Aug. 9, 1927", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Delsa v Blankenburg", "dam_registration_number": "532772",
        "source": meta_c3
    }
]

# Column 4 (Leaf 35 Col 3 top - 8 dogs ending before POINTERS)
c4_dogs = [
    {
        "name": "ROSA V WERTHEIMER", "sex": "Female", "registration_number": "670875",
        "birth_date": "June 22, 1928", "color": "Blk & tn",
        "owner": "Jack R. Wertheimer", "owner_location": None,
        "breeder": "Wm. Dunn", "breeder_location": "Detroit, Mich.",
        "sire": "Carlo v d Schwanenhohe", "sire_registration_number": "567146",
        "dam": "Ali v Streslau", "dam_registration_number": "539724",
        "source": meta_c4
    },
    {
        "name": "RUSTY V D SPREE", "sex": "Male", "registration_number": "672007",
        "birth_date": "Oct. 16, 1927", "color": "Rd",
        "owner": "Harmon S. Scott", "owner_location": None,
        "breeder": "Lawrence R. Curtis", "breeder_location": "Ashland, Mass.",
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Zephyr v d Leh", "dam_registration_number": "554029",
        "source": meta_c4
    },
    {
        "name": "SORTEE V D BLANKENSPREE", "sex": "Male", "registration_number": "669319",
        "birth_date": "July 21, 1927", "color": "Blk rust",
        "owner": "H. B. Smith", "owner_location": None,
        "breeder": "Delbert C. Cox", "breeder_location": "Tulsa, Okla.",
        "sire": "Arno v Burgfried", "sire_registration_number": "426603",
        "dam": "Adele v d Hortspree", "dam_registration_number": "613883",
        "source": meta_c4
    },
    {
        "name": "TODEN V KONINGSTAD", "sex": "Male", "registration_number": "669985",
        "birth_date": "July 5, 1928", "color": "Blk & tn",
        "owner": "Mrs. Wm. G. Cottingham", "owner_location": None,
        "breeder": "H. W. Pfalzgraf", "breeder_location": "Cincinnati, O.",
        "sire": "Apollo v Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Belle v d Spree", "dam_registration_number": "663264",
        "source": meta_c4
    },
    {
        "name": "TOPPO V SIGALSBURG", "sex": "Male", "registration_number": "670191",
        "birth_date": "Sept. 11, 1927", "color": "Blk & tn",
        "owner": "Dorothy Bolce", "owner_location": None,
        "breeder": "Chas. Baumgartner", "breeder_location": "Cincinnati, O.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Trudie v d Spree", "dam_registration_number": "541696",
        "source": meta_c4
    },
    {
        "name": "VERA V MUNCHEN", "sex": "Female", "registration_number": "669390",
        "birth_date": "Aug. 18, 1926", "color": "Blk & rust",
        "owner": "F. A. Duderstadt", "owner_location": None,
        "breeder": "Mrs. H. Gurtler", "breeder_location": "Rochester, N. Y.",
        "sire": "Max v Schonwald", "sire_registration_number": "319896",
        "dam": "Frau Marga v d Schonwald", "dam_registration_number": "452123",
        "source": meta_c4
    },
    {
        "name": "VICTORIA V BLUMEN", "sex": "Female", "registration_number": "669120",
        "birth_date": "Oct. 1, 1927", "color": "Blk & tn",
        "owner": "Roger Cunningham", "owner_location": None,
        "breeder": "Jacques Blum", "breeder_location": "Pittsburgh, Pa.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Adaline v Nibelungenhoff", "dam_registration_number": "438103",
        "source": meta_c4
    },
    {
        "name": "ZANA V D REHBACH", "sex": "Female", "registration_number": "671377",
        "birth_date": "Nov. 27, 1926", "color": "Blue & rust",
        "owner": "Bert Young", "owner_location": None,
        "breeder": "J. B. Whitwer", "breeder_location": "Mansfield, O.",
        "sire": "Printz Arto v d Spreehort", "sire_registration_number": "559555",
        "dam": "Zilla v Geholz", "dam_registration_number": "568957",
        "source": meta_c4
    }
]

all_52 = c1_dogs + c2_dogs + c3_dogs + c4_dogs
print(f"Total compiled 1929-02 dogs: {len(all_52)} (Expected: 52)")
print(f"Col 1: {len(c1_dogs)} (Expected: 2)")
print(f"Col 2: {len(c2_dogs)} (Expected: 20)")
print(f"Col 3: {len(c3_dogs)} (Expected: 22)")
print(f"Col 4: {len(c4_dogs)} (Expected: 8)")

Path("stud-scrape/data/verified_1929_02.json").write_text(json.dumps(all_52, indent=2), encoding="utf-8")
print("Saved clean 1929-02 records to stud-scrape/data/verified_1929_02.json")
