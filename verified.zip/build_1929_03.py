import json
from pathlib import Path

meta_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-03-01_46_3", "date": "1929-03-01", "volume": "46", "issue": "3", "leaf": 34, "column": 3}
meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-03-01_46_3", "date": "1929-03-01", "volume": "46", "issue": "3", "leaf": 35, "column": 1}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-03-01_46_3", "date": "1929-03-01", "volume": "46", "issue": "3", "leaf": 35, "column": 2}

# Column 1 (Leaf 34 Col 3 bottom - 9 dogs)
c1_dogs = [
    {
        "name": "ARISTO V ERNST", "sex": "Male", "registration_number": "674966",
        "birth_date": "Sept. 1, 1927", "color": "Blk & tn",
        "owner": "Joseph A. Ernst", "owner_location": None,
        "breeder": "R. E. Thomas", "breeder_location": "Elmhurst, Ill.",
        "sire": "Pedo", "sire_registration_number": "672391",
        "dam": "Neva v Winegate", "dam_registration_number": "516832",
        "source": meta_c1
    },
    {
        "name": "ARTUS OF BURGFRIED", "sex": "Male", "registration_number": "674987",
        "birth_date": "Aug. 19, 1928", "color": "Blk, tn mkgs",
        "owner": "John H. Vogt", "owner_location": None,
        "breeder": "John Schofield", "breeder_location": "Elverson, Pa.",
        "sire": "Armin v Burgfried", "sire_registration_number": "630843",
        "dam": "Countess v Burgholz", "dam_registration_number": "449862",
        "source": meta_c1
    },
    {
        "name": "ASTA V FINKENHERD", "sex": "Female", "registration_number": "673925",
        "birth_date": "Mar. 4, 1925", "color": "Blk & tn",
        "owner": "Jack Krumesz", "owner_location": "Cleveland, O.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Esther v d Eckardsburg", "sire_registration_number": "384897",
        "dam": "Lady Schulz", "dam_registration_number": "384896",
        "source": meta_c1
    },
    {
        "name": "ASTA V NASHVILLE", "sex": "Female", "registration_number": "675400",
        "birth_date": "Jan. 4, 1928", "color": "Blk & tn",
        "owner": "Oscar L. Simpson", "owner_location": None,
        "breeder": "C. E. Sexton, Jr.", "breeder_location": "Randolph, Ia.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Doby v Lueschenhof", "dam_registration_number": "571080",
        "source": meta_c1
    },
    {
        "name": "BERNIE V WILSONA", "sex": "Female", "registration_number": "672372",
        "birth_date": "June 25, 1928", "color": "Rd",
        "owner": "Georgene Y. Wilson", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Astor Gottschalk", "sire_registration_number": "639147",
        "dam": "Ary Tremonia", "dam_registration_number": "605201",
        "source": meta_c1
    },
    {
        "name": "BERTA V HOHENSCHWANAU", "sex": "Female", "registration_number": "673537",
        "birth_date": "Nov. 28, 1926", "color": "Blk & rusty",
        "owner": "Matthew L. Rimbach", "owner_location": None,
        "breeder": "Mathias Schmitt", "breeder_location": "Lincoln, N. J.",
        "sire": "Lux v d Foelz Bennier", "sire_registration_number": "579777",
        "dam": "Dora v Hohenschwanau", "dam_registration_number": "590688",
        "source": meta_c1
    },
    {
        "name": "BETSY HERTA V D WALDLUST", "sex": "Female", "registration_number": "673593",
        "birth_date": "Apr. 7, 1927", "color": "Blk & tn",
        "owner": "Frank K. Jelinski", "owner_location": None,
        "breeder": "Thomas Havrila", "breeder_location": "Cleveland, O.",
        "sire": "Black Bozo", "sire_registration_number": "550705",
        "dam": "Queenie Herta v d Eckardsburg", "dam_registration_number": "591334",
        "source": meta_c1
    },
    {
        "name": "BETTY V HOHENZOLLERNPARK", "sex": "Female", "registration_number": "674822",
        "birth_date": "Sept. 28, 1926", "color": "Blk & tn",
        "owner": "B. Delacourt", "owner_location": None,
        "breeder": "John A. Matson", "breeder_location": "Santa Ana, Cal.",
        "sire": "Ajax v Hohenzollernpark", "sire_registration_number": "470950",
        "dam": "Jill v Matson", "dam_registration_number": "549007",
        "source": meta_c1
    },
    {
        "name": "BOOZER", "sex": "Male", "registration_number": "674821",
        "birth_date": "June 24, 1926", "color": "Blk & tn",
        "owner": "J. T. Eiseman", "owner_location": None,
        "breeder": "R. A. Snyder", "breeder_location": "Oklahoma City, Okla.",
        "sire": "Diethelm v Stresow", "sire_registration_number": "480476",
        "dam": "Lulla v Telless II", "dam_registration_number": "363826",
        "source": meta_c1
    }
]

# Column 2 (Leaf 35 Col 1 - 22 dogs)
c2_dogs = [
    {
        "name": "BRUNO V SCHINGELHOF", "sex": "Male", "registration_number": "672873",
        "birth_date": "May 14, 1927", "color": "Blk & tn",
        "owner": "Joseph Skorepa", "owner_location": None,
        "breeder": "Jerry Schnabl", "breeder_location": "Riverside, Ill.",
        "sire": "Artus v Schlingelhof", "sire_registration_number": "422797",
        "dam": "Melinde from the Rosenau", "dam_registration_number": "367866",
        "source": meta_c2
    },
    {
        "name": "BRUTUS OF BURGFRIED", "sex": "Male", "registration_number": "674986",
        "birth_date": "Aug. 20, 1928", "color": "Blk & tn",
        "owner": "John H. Vogt", "owner_location": None,
        "breeder": "J. Henry Stump", "breeder_location": "Reading, Pa.",
        "sire": "Armin v Burgfried", "sire_registration_number": "430843",
        "dam": "Carmenia v Oma", "dam_registration_number": "590036",
        "source": meta_c2
    },
    {
        "name": "DUCK BAUERS", "sex": "Male", "registration_number": "674948",
        "birth_date": "Jan. 25, 1928", "color": "Blk & tn",
        "owner": "Henry Bauer", "owner_location": None,
        "breeder": "Bert Young", "breeder_location": "Granville, O.",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Lady Gretchen", "dam_registration_number": "574220",
        "source": meta_c2
    },
    {
        "name": "EGO V DREYERHAUSEN", "sex": "Male", "registration_number": "672764",
        "birth_date": "Dec. 21, 1927", "color": "Br & rd",
        "owner": "Billy J. Dreyer", "owner_location": None,
        "breeder": "John Ninger", "breeder_location": "Bloomfield, N. J.",
        "sire": "Ego v Allershausen", "sire_registration_number": "525324",
        "dam": "Charlotte v Burgfried", "dam_registration_number": "493051",
        "source": meta_c2
    },
    {
        "name": "EMIL OF PONTCHARTRAIN", "sex": "Male", "registration_number": "674316",
        "birth_date": "July 18, 1928", "color": "Blk, rust mkgs",
        "owner": "Francis Dodge", "owner_location": None,
        "breeder": "William O. McClane", "breeder_location": "Chicago, Ill.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Flora v Buetersburg of Ardwin", "dam_registration_number": "499562",
        "source": meta_c2
    },
    {
        "name": "EPSELON V D HOHEN", "sex": "Male", "registration_number": "672826",
        "birth_date": "July 21, 1928", "color": "Blk & tn",
        "owner": "William H. Hall", "owner_location": None,
        "breeder": "L. W. Goodyear", "breeder_location": "Sunderland, Mass.",
        "sire": "Eric Claus v d Hohen", "sire_registration_number": "654992",
        "dam": "Mitzi II", "dam_registration_number": "655331",
        "source": meta_c2
    },
    {
        "name": "FRAU V D WILDENBACH", "sex": "Female", "registration_number": "673161",
        "birth_date": "Oct. 12, 1926", "color": "Blk & tn",
        "owner": "Thomas J. Griffin", "owner_location": None,
        "breeder": "Muriel D. Gregory", "breeder_location": "Winchester, Mass.",
        "sire": "Trok v Ulmeholz", "sire_registration_number": "520690",
        "dam": "Gretel v d Wildenbach", "dam_registration_number": "457300",
        "source": meta_c2
    },
    {
        "name": "FREDDIE V LUDENDORF", "sex": "Male", "registration_number": "673682",
        "birth_date": "May 1, 1928", "color": "Blk & tn",
        "owner": "Samuel L. Pidot", "owner_location": None,
        "breeder": "Fred M. Berger", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Freya v Bergerhof", "dam_registration_number": "578494",
        "source": meta_c2
    },
    {
        "name": "FRITZ V D KLOOFT", "sex": "Male", "registration_number": "675606",
        "birth_date": "Dec. 20, 1927", "color": "Blk & tn",
        "owner": "Henry Weaver", "owner_location": None,
        "breeder": "L. L. Calkins", "breeder_location": "Hopkin, Mich.",
        "sire": "Alto v Keller", "sire_registration_number": "497117",
        "dam": "Princess Beta", "dam_registration_number": "646400",
        "source": meta_c2
    },
    {
        "name": "GLOCK V BERGENDORF", "sex": "Male", "registration_number": "673478",
        "birth_date": "Nov. 3, 1925", "color": "Blk & tn",
        "owner": "Mrs. L. J. Kitterman", "owner_location": "Sacramento, Cal.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Banjo v Luisenberg", "sire_registration_number": "505939",
        "dam": "Minko", "dam_registration_number": "526818",
        "source": meta_c2
    },
    {
        "name": "GYP V MANHATTAN", "sex": "Male", "registration_number": "674697",
        "birth_date": "May 19, 1928", "color": "Blk & rd",
        "owner": "A. A. Merson", "owner_location": None,
        "breeder": "Alexis Pilatzky", "breeder_location": "N. Y. City",
        "sire": "Derby v Burggrafen", "sire_registration_number": "671428",
        "dam": "Cora", "dam_registration_number": "532011",
        "source": meta_c2
    },
    {
        "name": "IWO V PARK", "sex": "Male", "registration_number": "674878",
        "birth_date": "Sept. 12, 1926", "color": "Br & rd",
        "owner": "Carl Feuerbacher", "owner_location": None,
        "breeder": "Otto Neubauer", "breeder_location": "Germany",
        "sire": "Salto v d Michelsburg", "sire_registration_number": None,
        "dam": "Dina v d Dreirosenstadt", "dam_registration_number": "623419",
        "extended_ancestry": [
            {"role": "sire_of_sire", "name": "Artus v Steigerwald", "registration_number": None},
            {"role": "dam_of_sire", "name": "Blanka v d Villa Adeline", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Lord v Burgberg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Amanda v Rottal", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Baldur v Rottal", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Sitta v Tonna", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "JIMMY OF SUSQUEHANNA", "sex": "Male", "registration_number": "675870",
        "birth_date": "Aug. 5, 1927", "color": "Blk & tn",
        "owner": "Charles Baitz", "owner_location": None,
        "breeder": "Joseph C. Blauner", "breeder_location": "Clifton, N. J.",
        "sire": "Benno v Roemerhof", "sire_registration_number": "517073",
        "dam": "Esther v Burgfried", "dam_registration_number": "453438",
        "source": meta_c2
    },
    {
        "name": "JIM OF ROLD", "sex": "Male", "registration_number": "675792",
        "birth_date": "Feb. 24, 1927", "color": "Blk & br",
        "owner": "E. Messersmith", "owner_location": None,
        "breeder": "Knud Jeppesen", "breeder_location": "Denmark",
        "sire": "Step II", "sire_registration_number": None,
        "dam": "Jytte of Rold", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Step", "registration_number": None},
            {"role": "dam_of_dam", "name": "Lady of Saxo Soro", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Hvidtand", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Nelly II of Saxo Soro", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Rex v Oderhof", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Freja", "registration_number": None},
            {"role": "sire_of_sire", "name": "Ajax", "registration_number": None},
            {"role": "dam_of_sire", "name": "Pola Inf", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Max Inf", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Irene II", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Rex v Oderhof", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Belle", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "KING OF THE WEST V LUESCHENHOF", "sex": "Male", "registration_number": "675028",
        "birth_date": "Aug. 28, 1928", "color": "Blk & tn",
        "owner": "R. B. Jenkins", "owner_location": None,
        "breeder": "A. G. Lueschen", "breeder_location": "Columbus, Nebr.",
        "sire": "Rudolph v Rudolphsburg", "sire_registration_number": "493363",
        "dam": "Maidy v Lueschenhof", "dam_registration_number": "557895",
        "source": meta_c2
    },
    {
        "name": "KNUT OF PONTCHARTRAIN", "sex": "Male", "registration_number": "673296",
        "birth_date": "Apr. 10, 1928", "color": "Blk & rd",
        "owner": "Gertrude B. White", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Gwanna of Pontchartrain", "dam_registration_number": "649692",
        "source": meta_c2
    },
    {
        "name": "KONNEMEHRER V TIMMENAL", "sex": "Female", "registration_number": "674117",
        "birth_date": "July 17, 1928", "color": "Blk & rust rd",
        "owner": "Timothy J. Maloney", "owner_location": None,
        "breeder": "Margaret B. Peters", "breeder_location": "Avoca, N. Y.",
        "sire": "Blitz Dorn of Pontchartrain", "sire_registration_number": "578014",
        "dam": "Asta Germania", "dam_registration_number": "438475",
        "source": meta_c2
    },
    {
        "name": "KUNGS DIETHELM V STRESOW", "sex": "Male", "registration_number": "675607",
        "birth_date": "Jan. 20, 1928", "color": "Blk & tn",
        "owner": "T. F. McKinzie", "owner_location": None,
        "breeder": "E. D. Turner", "breeder_location": "Oklahoma City, Okla.",
        "sire": "Kungs v Riga", "sire_registration_number": "492581",
        "dam": "Jaunita v Stresow", "dam_registration_number": "493836",
        "source": meta_c2
    },
    {
        "name": "MAIDA V HOLTEN", "sex": "Female", "registration_number": "675887",
        "birth_date": "Dec. 2, 1926", "color": "Rd",
        "owner": "Richard O. Dittmar", "owner_location": None,
        "breeder": "Charles Franck", "breeder_location": "West New York, N. J.",
        "sire": "Baron v Richthofen", "sire_registration_number": "526664",
        "dam": "Alma v Siegestor", "dam_registration_number": "427759",
        "source": meta_c2
    },
    {
        "name": "MITZI V LUESCHENHOF", "sex": "Female", "registration_number": "674974",
        "birth_date": "Aug. 18, 1928", "color": "Blk & tn",
        "owner": "John L. Gallagher", "owner_location": None,
        "breeder": "C. B. Strayer", "breeder_location": "Carlisle, Pa.",
        "sire": "Prinz Cuno of Westphalia", "sire_registration_number": "578324",
        "dam": "Doby v Lueschenhof", "dam_registration_number": "571080",
        "source": meta_c2
    },
    {
        "name": "PAL II", "sex": "Male", "registration_number": "672712",
        "birth_date": "Oct. 18, 1927", "color": "Br & tn",
        "owner": "Albert J. Kiszka", "owner_location": None,
        "breeder": "Clar Feuerbacher", "breeder_location": "Chicago, Ill.",
        "sire": "Siegfried v Brunstan", "sire_registration_number": "604561",
        "dam": "Dina v d Dreirosenstadt", "dam_registration_number": "623419",
        "source": meta_c2
    },
    {
        "name": "PEDO", "sex": "Male", "registration_number": "672391",
        "birth_date": "Sept. 2, 1925", "color": "Blk & tn",
        "owner": "H. Myles Cannaven", "owner_location": None,
        "breeder": "John Roberts", "breeder_location": "Framingham, Mass.",
        "sire": "Dragon v Hindendorff", "sire_registration_number": "379450",
        "dam": "Eastleigh Isolde", "dam_registration_number": "379318",
        "source": meta_c2
    }
]

# Column 3 (Leaf 35 Col 2 - 13 dogs ending before POINTERS)
c3_dogs = [
    {
        "name": "PRINCE PAL V IMMERTRUE", "sex": "Male", "registration_number": "673481",
        "birth_date": "May 19, 1928", "color": "Blk & rd",
        "owner": "Clarence S. Smith, Jr.", "owner_location": None,
        "breeder": "Alexis Pilatzky", "breeder_location": "N. Y. City",
        "sire": "Derby v Burggrafen", "sire_registration_number": "671428",
        "dam": "Cora", "dam_registration_number": "532011",
        "source": meta_c3
    },
    {
        "name": "PRINZ ARKO V KLOSTERSEE", "sex": "Male", "registration_number": "673253",
        "birth_date": "July 11, 1928", "color": "Blk & rust",
        "owner": "Charles L. Richey", "owner_location": None,
        "breeder": "Geo. H. Jones", "breeder_location": "Danville, Ill.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Princess v Rudolphsburg", "dam_registration_number": "569711",
        "source": meta_c3
    },
    {
        "name": "PRINZ V HOLENZELSAR", "sex": "Male", "registration_number": "675414",
        "birth_date": "Apr. 4, 1928", "color": "Blk & tn",
        "owner": "Agnes T. Herman", "owner_location": None,
        "breeder": "James E. Shade", "breeder_location": "Dayton, O.",
        "sire": "Ariovist v Nibelungenhort", "sire_registration_number": "524279",
        "dam": "Lady v Schaffenburg", "dam_registration_number": "650558",
        "source": meta_c3
    },
    {
        "name": "PRINZ RUDOLF V PETERSHOFF", "sex": "Male", "registration_number": "673170",
        "birth_date": "Feb. 13, 1928", "color": "Blk & rust rd",
        "owner": "R. Ernest Lopez", "owner_location": None,
        "breeder": "George A. Martindell", "breeder_location": "Painted Post, N. Y.",
        "sire": "Blitz Dorn of Pontchartrain", "sire_registration_number": "578014",
        "dam": "Liesel v d Grenzlerburg", "dam_registration_number": "586610",
        "source": meta_c3
    },
    {
        "name": "REMUS V TELLESS", "sex": "Male", "registration_number": "675231",
        "birth_date": "Jan. 25, 1926", "color": "Blk & tn",
        "owner": "Russell S. Higgins", "owner_location": None,
        "breeder": "M. S. Telless", "breeder_location": "Weymouth, Mass.",
        "sire": "Nero v Telless", "sire_registration_number": "412981",
        "dam": "Magra v d Rodolfburg", "dam_registration_number": "412980",
        "source": meta_c3
    },
    {
        "name": "ROLF OF BELBERG", "sex": "Male", "registration_number": "673464",
        "birth_date": "July 3, 1928", "color": "Blk & tn",
        "owner": "C. J. Strobel", "owner_location": None,
        "breeder": "E. J. Robinson", "breeder_location": "Milwaukee, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Robinson's Leisel", "dam_registration_number": "591640",
        "source": meta_c3
    },
    {
        "name": "SANDIE SEAL", "sex": "Male", "registration_number": "672757",
        "birth_date": "July 5, 1927", "color": "Br & tn",
        "owner": "Mr. and Mrs. Winders Duckworth", "owner_location": None,
        "breeder": "John D. Madden", "breeder_location": "E. Windsor Hill, Conn.",
        "sire": "Denno of Arkden", "sire_registration_number": "558221",
        "dam": "Cleopatra v Nordheim", "dam_registration_number": "529689",
        "source": meta_c3
    },
    {
        "name": "SCHWARZE DAME", "sex": "Female", "registration_number": "672699",
        "birth_date": "July 1, 1926", "color": "Blk & tn",
        "owner": "J. W. Gage", "owner_location": None,
        "breeder": "A. C. Wilhelm", "breeder_location": "Chicago, Ill.",
        "sire": "Benno v d Koernereiche", "sire_registration_number": "561003",
        "dam": "Burga v Scharflueck", "dam_registration_number": "434189",
        "source": meta_c3
    },
    {
        "name": "SIWEL NOTYAK HORTSBURG", "sex": "Male", "registration_number": "672835",
        "birth_date": "July 13, 1928", "color": "Blk & tn",
        "owner": "Lewis Kayton", "owner_location": None,
        "breeder": "O. C. Draheim", "breeder_location": "Fairchild, Wis.",
        "sire": "Burschel v d Spree", "sire_registration_number": "487194",
        "dam": "Tooky of Kentucky", "dam_registration_number": "625717",
        "source": meta_c3
    },
    {
        "name": "SUTTON'S BUDDY", "sex": "Male", "registration_number": "673281",
        "birth_date": "Jan. 7, 1928", "color": "Blk & tn",
        "owner": "F. T. Sutton", "owner_location": None,
        "breeder": "G. Wiese", "breeder_location": "Newton, Ia.",
        "sire": "Hans v d Sternallee", "sire_registration_number": "349691",
        "dam": "Senta v Lueschenhof", "dam_registration_number": "633072",
        "source": meta_c3
    },
    {
        "name": "TOKO V HOLSTEIN", "sex": "Female", "registration_number": "672874",
        "birth_date": "Sept. 21, 1926", "color": "Blk & tn",
        "owner": "Joseph Skorepa", "owner_location": None,
        "breeder": "Joseph Sykora", "breeder_location": "Lyons, Ill.",
        "sire": "Artus v Schlingelhof", "sire_registration_number": "422797",
        "dam": "Dina v Holstein", "dam_registration_number": "578893",
        "source": meta_c3
    },
    {
        "name": "TYRACE", "sex": "Male", "registration_number": "673460",
        "birth_date": "Dec. 21, 1927", "color": "Br & rd",
        "owner": "E. A. Heyne", "owner_location": None,
        "breeder": "John Ninger", "breeder_location": "Bloomfield, N. J.",
        "sire": "Ego v Allershausen", "sire_registration_number": "525324",
        "dam": "Charlotte v Burgfried", "dam_registration_number": "493051",
        "source": meta_c3
    },
    {
        "name": "YEDDO", "sex": "Female", "registration_number": "675922",
        "birth_date": "Jan. 29, 1927", "color": "Blk & tn",
        "owner": "Walter Venn", "owner_location": None,
        "breeder": "Mrs. R. J. McNabb", "breeder_location": "Chicago, Ill.",
        "sire": "Pedo", "sire_registration_number": "672391",
        "dam": "Asta v Meckenburg", "dam_registration_number": "406354",
        "source": meta_c3
    }
]

all_44 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1929-03 dogs: {len(all_44)} (Expected: 44)")
print(f"Col 1: {len(c1_dogs)} (Expected: 9)")
print(f"Col 2: {len(c2_dogs)} (Expected: 22)")
print(f"Col 3: {len(c3_dogs)} (Expected: 13)")

Path("stud-scrape/data/verified_1929_03.json").write_text(json.dumps(all_44, indent=2), encoding="utf-8")
print("Saved clean 1929-03 records to stud-scrape/data/verified_1929_03.json")
