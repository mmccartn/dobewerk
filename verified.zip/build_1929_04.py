import json
from pathlib import Path

meta_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-04-01_46_4", "date": "1929-04-01", "volume": "46", "issue": "4", "leaf": 33, "column": 2}
meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-04-01_46_4", "date": "1929-04-01", "volume": "46", "issue": "4", "leaf": 33, "column": 3}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-04-01_46_4", "date": "1929-04-01", "volume": "46", "issue": "4", "leaf": 34, "column": 1}

# Column 1 (Leaf 33 Col 2 bottom - 2 dogs)
c1_dogs = [
    {
        "name": "ALLIE V D FRANKENBURG", "sex": "Female", "registration_number": "676420",
        "birth_date": "Sept. 7, 1926", "color": "Blk & mhgy",
        "owner": "W. E. Taylor", "owner_location": None,
        "breeder": "David C. Dooge", "breeder_location": "Denver, Colo.",
        "sire": "Barry v Sheehagen", "sire_registration_number": "463068",
        "dam": "Tilly v Melrapp", "dam_registration_number": "462651",
        "source": meta_c1
    },
    {
        "name": "ARNO V BLUMENTHAL", "sex": "Male", "registration_number": "678672",
        "birth_date": "June 19, 1926", "color": "Blk & rd",
        "owner": "Jacob Hoeffler", "owner_location": None,
        "breeder": "Charles Franck", "breeder_location": "West New York, N. J.",
        "sire": "Tell v Hohenegg", "sire_registration_number": "504216",
        "dam": "Alma v Hohenegg", "dam_registration_number": "559125",
        "handwritten_annotation": "May issue - p. 80",
        "source": meta_c1
    }
]

# Column 2 (Leaf 33 Col 3 - 21 dogs)
c2_dogs = [
    {
        "name": "BENNO V LEIPZIG", "sex": "Male", "registration_number": "678945",
        "birth_date": "Apr. 16, 1928", "color": "Blk & br",
        "owner": "F. R. Kingsman", "owner_location": None,
        "breeder": "Max Niemand", "breeder_location": "Rosedale, L. I., N. Y.",
        "sire": "Benno v Roemerhof", "sire_registration_number": "517073",
        "dam": "Angola v Royal", "dam_registration_number": "495891",
        "source": meta_c2
    },
    {
        "name": "BENNO V WILSONA", "sex": "Male", "registration_number": "676234",
        "birth_date": "Sept. 4, 1927", "color": "Blk & tn",
        "owner": "Georgine Y. Wilson", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Detlef v Stresow", "sire_registration_number": "605202",
        "dam": "Anita v Grossmannstein", "dam_registration_number": "605203",
        "source": meta_c2
    },
    {
        "name": "BLITZ V KAHLENBERG", "sex": "Male", "registration_number": "678920",
        "birth_date": "July 24, 1928", "color": "Blk & tn",
        "owner": "Mrs. R. Shaffer", "owner_location": None,
        "breeder": "Mrs. L. J. Ketterman", "breeder_location": "Sacramento, Cal.",
        "sire": "Glock v Bergendorf", "sire_registration_number": "673478",
        "dam": "Asta Foss", "dam_registration_number": "668565",
        "source": meta_c2
    },
    {
        "name": "EDDI V WILSONA", "sex": "Female", "registration_number": "676235",
        "birth_date": "Mar. 22, 1928", "color": "Blk & tn",
        "owner": "Georgine Y. Wilson", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Benno v Drehbrucke", "sire_registration_number": "639146",
        "dam": "Anita v Grossmannstein", "dam_registration_number": "605203",
        "source": meta_c2
    },
    {
        "name": "ERDA OF OXBO", "sex": "Female", "registration_number": "679295",
        "birth_date": "June 13, 1927", "color": "Br & tn",
        "owner": "F. C. Fuqua", "owner_location": None,
        "breeder": "Mathias Schmitt", "breeder_location": "Lincoln, N. J.",
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Dora v Hohenschwanau", "dam_registration_number": "590688",
        "source": meta_c2
    },
    {
        "name": "GILDA FRA DUNCAN", "sex": "Female", "registration_number": "678513",
        "birth_date": "May 27, 1927", "color": "Chlte & tn",
        "owner": "C. A. Duncan", "owner_location": "Paris, Ky.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Leedsie v Rottal", "dam_registration_number": "393410",
        "source": meta_c2
    },
    {
        "name": "GRETA V NIBELUNGENHORT", "sex": "Female", "registration_number": "677050",
        "birth_date": "Sept. 23, 1926", "color": "Blk & tn",
        "owner": "A. W. Horner", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Beauty of Kentucky", "dam_registration_number": "517728",
        "source": meta_c2
    },
    {
        "name": "GUSTL V TANNENHAUS", "sex": "Male", "registration_number": "677473",
        "birth_date": "Jan. 28, 1927", "color": "Blk & tn",
        "owner": "Verne Buck", "owner_location": None,
        "breeder": "August Rohrer", "breeder_location": "Germany",
        "sire": "Dechant v d Eckardtsburg", "sire_registration_number": None,
        "dam": "Rita v Luisenheim", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Lux v d Blankenburg", "registration_number": "571492"},
            {"role": "dam_of_dam", "name": "Dita v d Staatlichen Zuchtanstalt Grunheide", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Artus v Langerode", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Hexe v Siegfriedsbrunnen", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_sire", "name": "Isolde v Coln", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Marko v Hornsheim Jagerhof", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Ruska v Coln", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Achim v Langerode", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Leddy v d Blankenburg", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "HANS V INGEHOVEN", "sex": "Male", "registration_number": "676645",
        "birth_date": "Feb. 7, 1928", "color": "Blk, br mks",
        "owner": "Herman Brauckmann", "owner_location": "Los Angeles, Cal.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Carlo v Belger", "sire_registration_number": "533994",
        "dam": "Blanka v Lenburg", "dam_registration_number": "666356",
        "source": meta_c2
    },
    {
        "name": "KING HAMLIN", "sex": "Male", "registration_number": "678926",
        "birth_date": "June 20, 1927", "color": "Rd & tn",
        "owner": "Mrs. A. M. Bailey", "owner_location": None,
        "breeder": "C. Schurecht", "breeder_location": "Morton Grove, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Flora v Buetersburg of Ardwin", "dam_registration_number": "499562",
        "source": meta_c2
    },
    {
        "name": "KINGSTON V NIBELUNGENHORT", "sex": "Male", "registration_number": "678925",
        "birth_date": "May 30, 1927", "color": "Blk & tn",
        "owner": "C. R. Christie", "owner_location": None,
        "breeder": "J. Finley Webb", "breeder_location": "Wenatchee, Wash.",
        "sire": "Count Monte v Nibelungenhort", "sire_registration_number": "379730",
        "dam": "Thelma of Stubenfield", "dam_registration_number": "498241",
        "source": meta_c2
    },
    {
        "name": "KUSTER V CREFELD", "sex": "Male", "registration_number": "676435",
        "birth_date": "Jan. 15, 1928", "color": "Blk & tn",
        "owner": "Willard C. Kennamer", "owner_location": None,
        "breeder": "Philip Gruber", "breeder_location": "Chicago, Ill.",
        "sire": "Iwo v Park", "sire_registration_number": "674874",
        "dam": "Thea v Hoffeld", "dam_registration_number": "633804",
        "source": meta_c2
    },
    {
        "name": "LADY V D ECKARDSBURG", "sex": "Female", "registration_number": "679268",
        "birth_date": "Apr. 7, 1927", "color": "Blk & tn",
        "owner": "James M. Osburne", "owner_location": None,
        "breeder": "Thomas Havrila", "breeder_location": "Cleveland, O.",
        "sire": "Black Bozo", "sire_registration_number": "550705",
        "dam": "Queenie Herta v d Eckardsburg", "dam_registration_number": "591334",
        "source": meta_c2
    },
    {
        "name": "MITSEYLUE OF CHARMEDLAND", "sex": "Female", "registration_number": "679467",
        "birth_date": "Nov. 8, 1926", "color": "Blk & tn",
        "owner": "Walter E. Johnson", "owner_location": "Centralia, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Hans v d Sternallee", "sire_registration_number": "349691",
        "dam": "Whilhelmina", "dam_registration_number": "441066",
        "source": meta_c2
    },
    {
        "name": "MOLLY 'O V SCHOLL", "sex": "Female", "registration_number": "678261",
        "birth_date": "June 6, 1926", "color": "Blk & tn",
        "owner": "Jno. W. Casey", "owner_location": None,
        "breeder": "Mrs. John Stringer", "breeder_location": "No. Seattle, Wash.",
        "sire": "Arnold v Minkelried", "sire_registration_number": "513005",
        "dam": "Hertha v d Ver", "dam_registration_number": "334314",
        "source": meta_c2
    },
    {
        "name": "NEVA FRA DUNCAN", "sex": "Female", "registration_number": "678512",
        "birth_date": "May 27, 1927", "color": "Blk & tn",
        "owner": "C. A. Duncan", "owner_location": "Paris, Ky.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Leedsie v Rottal", "dam_registration_number": "393410",
        "source": meta_c2
    },
    {
        "name": "OLGA V HOFFELD", "sex": "Female", "registration_number": "676436",
        "birth_date": "Jan. 15, 1928", "color": "Blk & tn",
        "owner": "Philip Gruber", "owner_location": "Chicago, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Iwo v Park", "sire_registration_number": "674874",
        "dam": "Thea v Hoffeld", "dam_registration_number": "633804",
        "source": meta_c2
    },
    {
        "name": "PERLE BER WYN", "sex": "Female", "registration_number": "678223",
        "birth_date": "Nov. 29, 1928", "color": "Blk & tn",
        "owner": "George Lindstrom", "owner_location": None,
        "breeder": "John Matthiesen", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Peggy Sallie v Jagerhof", "dam_registration_number": "558734",
        "source": meta_c2
    },
    {
        "name": "PRINCE ARNO OF SADDLE BROOK", "sex": "Male", "registration_number": "679137",
        "birth_date": "July 10, 1928", "color": "Br & tn",
        "owner": "Francis Earle", "owner_location": None,
        "breeder": "John W. Thomas", "breeder_location": "Ho-Ho-Kus, N. J.",
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Baroness Dubla v d Hoehen", "dam_registration_number": "619318",
        "source": meta_c2
    },
    {
        "name": "QUEEN BETA PRINCESS", "sex": "Female", "registration_number": "676748",
        "birth_date": "Apr. 19, 1927", "color": "Blk & tn",
        "owner": "Chas. M. Riggs", "owner_location": "Allegan, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Jasko P v Engleburg", "sire_registration_number": "577358",
        "dam": "Princess Beta", "dam_registration_number": "646400",
        "source": meta_c2
    },
    {
        "name": "RITZ II", "sex": "Male", "registration_number": "679432",
        "birth_date": "May 26, 1924", "color": "Blk & tn",
        "owner": "Walter Morosco", "owner_location": None,
        "breeder": "Melville B. Rapp", "breeder_location": "Santa Monica, Cal.",
        "sire": "Astor v Thumshoehe", "sire_registration_number": "379878",
        "dam": "Cilly v Seehagen", "dam_registration_number": "379877",
        "source": meta_c2
    }
]

# Column 3 (Leaf 34 Col 1 top - 10 dogs ending before POINTERS)
c3_dogs = [
    {
        "name": "RONNA V NIBELUNGENHORT", "sex": "Female", "registration_number": "678527",
        "birth_date": "May 10, 1928", "color": "Rd",
        "owner": "O. K. Lindquist", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "A Rappo of Pontchartrain", "sire_registration_number": "439031",
        "dam": "Kona v Nibelungenhort", "dam_registration_number": "491924",
        "source": meta_c3
    },
    {
        "name": "ROWDY OF MICKBURN", "sex": "Male", "registration_number": "677161",
        "birth_date": "Nov. 21, 1927", "color": "Blk, rd rust mkgs",
        "owner": "M. P. Springer", "owner_location": None,
        "breeder": "Mickburn Kennels", "breeder_location": "Eldorado, Ill.",
        "sire": "Red Roof Rowdy", "sire_registration_number": "392482",
        "dam": "Frances of Mickburn", "dam_registration_number": "580532",
        "source": meta_c3
    },
    {
        "name": "RUMMY", "sex": "Male", "registration_number": "676173",
        "birth_date": "Jan. 7, 1925", "color": "Blk & tn",
        "owner": "Thomas E. Ames", "owner_location": None,
        "breeder": "Marion Kreischer", "breeder_location": "Lynbrook, L. I., N. Y.",
        "sire": "Westphalia Klaus v Ostersee", "sire_registration_number": "391616",
        "dam": "Amely Beda of Westphalia", "dam_registration_number": "383731",
        "source": meta_c3
    },
    {
        "name": "SIMPSON'S MITZERAL", "sex": "Female", "registration_number": "678209",
        "birth_date": "June 16, 1928", "color": "Blk & tn",
        "owner": "Joseph A. Simpson", "owner_location": None,
        "breeder": "Wm. H. Lawson", "breeder_location": "Detroit, Mich.",
        "sire": "Nuttall's Prinz", "sire_registration_number": "610640",
        "dam": "Lawson's Lily", "dam_registration_number": "587606",
        "source": meta_c3
    },
    {
        "name": "SISTER II", "sex": "Female", "registration_number": "679455",
        "birth_date": "Dec. 15, 1927", "color": "Blk & tn",
        "owner": "Thomas J. Flynn", "owner_location": None,
        "breeder": "Mary Mueller", "breeder_location": "West Roxbury, Mass.",
        "sire": "Ritz Carlton", "sire_registration_number": "485720",
        "dam": "Hexe", "dam_registration_number": "614317",
        "source": meta_c3
    },
    {
        "name": "SYLVESTER'S CHIEF", "sex": "Male", "registration_number": "678306",
        "birth_date": "June 16, 1928", "color": "Blk & tn",
        "owner": "H. S. Sylvester", "owner_location": None,
        "breeder": "Wm. H. Lawson", "breeder_location": "Detroit, Mich.",
        "sire": "Nuttall's Prinz", "sire_registration_number": "610640",
        "dam": "Lawson's Lily", "dam_registration_number": "587606",
        "source": meta_c3
    },
    {
        "name": "TINO OF CHICAGO", "sex": "Male", "registration_number": "678420",
        "birth_date": "Oct. 20, 1928", "color": "Blk & tn",
        "owner": "Josef M. Dicktner", "owner_location": None,
        "breeder": "Carl Feuerbacher", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Dina v d Dreirosenstadt", "dam_registration_number": "623419",
        "source": meta_c3
    },
    {
        "name": "VANDEVIER FRA DUNCAN", "sex": "Female", "registration_number": "678511",
        "birth_date": "Dec. 26, 1927", "color": "Chlte & tn",
        "owner": "C. A. Duncan", "owner_location": "Paris, Ky.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Asta v Meclenburg", "dam_registration_number": "406354",
        "source": meta_c3
    },
    {
        "name": "VON DHU VARREN'S", "sex": "Male", "registration_number": "678668",
        "birth_date": "July 10, 1928", "color": "Blk & rd",
        "owner": "O. O. McLeish", "owner_location": None,
        "breeder": "Edward A. Hunter", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Fedor of Pontchartrain", "sire_registration_number": "509758",
        "dam": "Gaby of Pontchartrain", "dam_registration_number": "553020",
        "source": meta_c3
    },
    {
        "name": "WINNIE", "sex": "Female", "registration_number": "677990",
        "birth_date": "June 8, 1928", "color": "Br & tn",
        "owner": "Stanley H. Freihoft", "owner_location": None,
        "breeder": "Herman Wohlgemuth", "breeder_location": "Philadelphia, Pa.",
        "sire": "Dando de Haven", "sire_registration_number": "556187",
        "dam": "Hulda v d Winterburg", "dam_registration_number": "668994",
        "source": meta_c3
    }
]

all_33 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1929-04 dogs: {len(all_33)} (Expected: 33)")
print(f"Col 1: {len(c1_dogs)} (Expected: 2)")
print(f"Col 2: {len(c2_dogs)} (Expected: 21)")
print(f"Col 3: {len(c3_dogs)} (Expected: 10)")

Path("stud-scrape/data/verified_1929_04.json").write_text(json.dumps(all_33, indent=2), encoding="utf-8")
print("Saved clean 1929-04 records to stud-scrape/data/verified_1929_04.json")
