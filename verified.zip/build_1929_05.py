import json
from pathlib import Path

meta_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-05-01_46_5", "date": "1929-05-01", "volume": "46", "issue": "5", "leaf": 49, "column": 1}
meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-05-01_46_5", "date": "1929-05-01", "volume": "46", "issue": "5", "leaf": 49, "column": 2}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-05-01_46_5", "date": "1929-05-01", "volume": "46", "issue": "5", "leaf": 49, "column": 3}
meta_c4 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-05-01_46_5", "date": "1929-05-01", "volume": "46", "issue": "5", "leaf": 50, "column": 1}

# Column 1 (Leaf 49 Col 1 bottom - 6 dogs)
c1_dogs = [
    {
        "name": "AIDA V APOLDA", "sex": "Female", "registration_number": "681298",
        "birth_date": "July 18, 1928", "color": "Blk & rust",
        "owner": "William O. McClane", "owner_location": "Chicago, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Flora v Butersburg of Ardwin", "dam_registration_number": "499562",
        "source": meta_c1
    },
    {
        "name": "ALPHABET OF DAWN", "sex": "Female", "registration_number": "681563",
        "birth_date": "Sept. 5, 1927", "color": "Blk & rust rd",
        "owner": "H. S. Newson", "owner_location": "Wheaton, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Schatz v Ostersee", "dam_registration_number": "514975",
        "source": meta_c1
    },
    {
        "name": "ASTA V WIESENFELS", "sex": "Female", "registration_number": "683357",
        "birth_date": "May 20, 1926", "color": "Blk & rd",
        "owner": "R. C. Reko", "owner_location": None,
        "breeder": "J. H. Gray", "breeder_location": "Detroit, Mich.",
        "sire": "Westphalia Dyno v Wiesengrund", "sire_registration_number": "365520",
        "dam": "A. Metzie of Pontchartrain", "dam_registration_number": "439034",
        "source": meta_c1
    },
    {
        "name": "ATHERTON'S BETSY", "sex": "Female", "registration_number": "682038",
        "birth_date": "Mar. 7, 1927", "color": "Blk, tn & rust",
        "owner": "Charles W. Roark", "owner_location": None,
        "breeder": "P. L. Atherton", "breeder_location": "Glenview, Ky.",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Westdorf Hermine v Dorn", "dam_registration_number": "501695",
        "source": meta_c1
    },
    {
        "name": "BARON AUGUST GROSSMAN", "sex": "Male", "registration_number": "683274",
        "birth_date": "July 14, 1928", "color": "Rd & tn",
        "owner": "Edwin C. Higgins", "owner_location": None,
        "breeder": "Marshall F. Bidwell", "breeder_location": "So. Windsor, Conn.",
        "sire": "Baron v Richthofen", "sire_registration_number": "526664",
        "dam": "Cleopatra v Nordheim", "dam_registration_number": "529687",
        "source": meta_c1
    },
    {
        "name": "BEANSTEIN V MUSENBACH", "sex": "Male", "registration_number": "684313",
        "birth_date": "June 22, 1928", "color": "Blue & tn",
        "owner": "John Alexander Sloan, Jr.", "owner_location": None,
        "breeder": "Margaret Lee Fahey", "breeder_location": "Lewiston, Me.",
        "sire": "Cuno v Musenbach", "sire_registration_number": "596712",
        "dam": "Rota Bella v Steuben", "dam_registration_number": "516684",
        "source": meta_c1
    }
]

# Column 2 (Leaf 49 Col 2 - 21 dogs)
c2_dogs = [
    {
        "name": "BELLA", "sex": "Female", "registration_number": "680101",
        "birth_date": "Apr. 1, 1927", "color": "Blk & tn",
        "owner": "Joseph Sickinger", "owner_location": None,
        "breeder": "Henry Eberle", "breeder_location": "Hillside, N. J.",
        "sire": "Atos v Teufelstisch", "sire_registration_number": "462573",
        "dam": "Herta v Wetterbach", "dam_registration_number": "571748",
        "source": meta_c2
    },
    {
        "name": "BENNO V WALTERS J. D.", "sex": "Male", "registration_number": "680233",
        "birth_date": "Aug. 27, 1928", "color": "Rd & tn",
        "owner": "John D. Walters", "owner_location": None,
        "breeder": "Thomas F. Mangin", "breeder_location": "Syracuse, N. Y.",
        "sire": "Benno v Roemerhof", "sire_registration_number": "517073",
        "dam": "Lady Rickee Mangin", "dam_registration_number": "608560",
        "source": meta_c2
    },
    {
        "name": "BETTY III", "sex": "Female", "registration_number": "682280",
        "birth_date": "Nov. 9, 1924", "color": "Blk & tn",
        "owner": "W. H. Tripke", "owner_location": None,
        "breeder": "Charles Franck", "breeder_location": "West New York, N. Y.",
        "sire": "Kunibert v Rottal", "sire_registration_number": "327475",
        "dam": "Alma v Siegestor", "dam_registration_number": "427759",
        "source": meta_c2
    },
    {
        "name": "BLACKY", "sex": "Male", "registration_number": "680143",
        "birth_date": "July 27, 1928", "color": "Blk & tn",
        "owner": "Elliott O'Reilly", "owner_location": None,
        "breeder": "Roy Philip Scholz", "breeder_location": "St. Louis, Mo.",
        "sire": "Dolf v Forst", "sire_registration_number": "570944",
        "dam": "Lizett Angola v Liepzic", "dam_registration_number": "616198",
        "source": meta_c2
    },
    {
        "name": "BLITZEN V MACKENSEN", "sex": "Male", "registration_number": "683975",
        "birth_date": "Jan. 15, 1929", "color": "Blk & rust",
        "owner": "C. S. Darck", "owner_location": None,
        "breeder": "Leslie L. Romine", "breeder_location": "Livingston, N. J.",
        "sire": "Max De Haven", "sire_registration_number": "604075",
        "dam": "Hilda v Falkenturn", "dam_registration_number": "637640",
        "source": meta_c2
    },
    {
        "name": "BLIZZARD", "sex": "Male", "registration_number": "683834",
        "birth_date": "Mar. 30, 1928", "color": "Rd & tn",
        "owner": "Henry Namken", "owner_location": None,
        "breeder": "Mrs. G. A. Rentschler", "breeder_location": "Hamilton, Ohio",
        "sire": "Apollo v Schutzen-eck", "sire_registration_number": "462894",
        "dam": "Dina v Homehill", "dam_registration_number": "581382",
        "source": meta_c2
    },
    {
        "name": "BOBY V STRUSEN", "sex": "Female", "registration_number": "682034",
        "birth_date": "Aug. 20, 1927", "color": "Blk & rust",
        "owner": "Louis Hetter", "owner_location": None,
        "breeder": "G. F. Deckert", "breeder_location": "Rising City, Neb.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Dita v Lueschenhof", "dam_registration_number": "595040",
        "source": meta_c2
    },
    {
        "name": "BODO V LIEPZIC FORST", "sex": "Male", "registration_number": "680650",
        "birth_date": "July 27, 1928", "color": "Blk & tn",
        "owner": "Elizabeth W. Barnsback", "owner_location": None,
        "breeder": "Roy Philip Scholz", "breeder_location": "St. Louis, Mo.",
        "sire": "Dolf v Forst", "sire_registration_number": "570944",
        "dam": "Lizett Angola v Liepzic", "dam_registration_number": "616198",
        "source": meta_c2
    },
    {
        "name": "BO DRAGON", "sex": "Male", "registration_number": "684070",
        "birth_date": "Sept. 23, 1928", "color": "Blk & rust",
        "owner": "Mrs. Hadley F. Brown", "owner_location": None,
        "breeder": "J. D. Wickersham", "breeder_location": "Dayton, Ohio",
        "sire": "Black Guard", "sire_registration_number": "630172",
        "dam": "Diana v d Thueringen", "dam_registration_number": "663926",
        "source": meta_c2
    },
    {
        "name": "BRUNHILDE V THELSTERN", "sex": "Female", "registration_number": "680141",
        "birth_date": "Mar. 11, 1928", "color": "Blk & dk br",
        "owner": "H. Preston Wolfe", "owner_location": None,
        "breeder": "Thelma T. Stern", "breeder_location": "Clifton, Mass.",
        "sire": "Carlo v Thelstern", "sire_registration_number": "495296",
        "dam": "Elfrida v De Haven", "dam_registration_number": "467151",
        "source": meta_c2
    },
    {
        "name": "CHI V D WILDENBACK", "sex": "Male", "registration_number": "680888",
        "birth_date": "Aug. 22, 1927", "color": "Blk, rd rust",
        "owner": "Muriel D. Gregory", "owner_location": None,
        "breeder": "G. W. Meserve", "breeder_location": "Framingham, Mass.",
        "sire": "Edelblut of Westphalia", "sire_registration_number": "535468",
        "dam": "Hela's Tilly", "dam_registration_number": "435425",
        "source": meta_c2
    },
    {
        "name": "CHUMMI", "sex": "Female", "registration_number": "682108",
        "birth_date": "Apr. 10, 1926", "color": "Blk & tn",
        "owner": "Martha Griffith Babcock", "owner_location": None,
        "breeder": "Martin E. Griffith", "breeder_location": "Monessen, Pa.",
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Anni v Burgfried", "dam_registration_number": "516158",
        "source": meta_c2
    },
    {
        "name": "CORA V WEBB", "sex": "Female", "registration_number": "681721",
        "birth_date": "May 14, 1927", "color": "Blk & tn",
        "owner": "J. F. Webb", "owner_location": "Winatchee, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Count Monte v Nibelungenhort", "sire_registration_number": "379730",
        "dam": "Edna v Geholz", "dam_registration_number": "382664",
        "source": meta_c2
    },
    {
        "name": "DON V APOLDA", "sex": "Male", "registration_number": "681297",
        "birth_date": "July 18, 1928", "color": "Blk & rust",
        "owner": "William O. McClane", "owner_location": "Chicago, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Flora v Buetersburg of Ardwin", "dam_registration_number": "499562",
        "source": meta_c2
    },
    {
        "name": "DYNO V STRESLAU", "sex": "Male", "registration_number": "681064",
        "birth_date": "June 22, 1928", "color": "Rust br & tn",
        "owner": "Wm. Dunn", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Carlo v d Schwanenhohe", "sire_registration_number": "567146",
        "dam": "Ali v Streslau", "dam_registration_number": "539724",
        "source": meta_c2
    },
    {
        "name": "ELODIA V D HOHEN", "sex": "Female", "registration_number": "683705",
        "birth_date": "Apr. 3, 1927", "color": "Blk & tn",
        "owner": "Mrs. M. von Hoegen", "owner_location": "Towaco, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Westphalia Prinz Carlo v d Koningstad", "sire_registration_number": "365521",
        "dam": "Coryl v Avonthal", "dam_registration_number": "506373",
        "source": meta_c2
    },
    {
        "name": "ERDA V D HOHEN", "sex": "Female", "registration_number": "683706",
        "birth_date": "Apr. 3, 1927", "color": "Br & tn",
        "owner": "Mrs. M. von Hoegen", "owner_location": "Towaco, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Westphalia Prinz Carlo v d Koningstad", "sire_registration_number": "365521",
        "dam": "Coryl v Avonthal", "dam_registration_number": "506373",
        "source": meta_c2
    },
    {
        "name": "ERIC DUKE OF TUSCANY", "sex": "Male", "registration_number": "680741",
        "birth_date": "Nov. 27, 1928", "color": "Blk & tn",
        "owner": "Mary Page Gaines", "owner_location": None,
        "breeder": "E. R. Grossman", "breeder_location": "Louisville, Ky.",
        "sire": "Prince Alexis of Ardenne", "sire_registration_number": "599344",
        "dam": "Nanette", "dam_registration_number": "670195",
        "source": meta_c2
    },
    {
        "name": "FORTSCHRITT V ZINSGUT", "sex": "Male", "registration_number": "681436",
        "birth_date": "Apr. 18, 1925", "color": "Blk & rd",
        "owner": "Frank J. Offermann", "owner_location": None,
        "breeder": "L. Geisslinger", "breeder_location": "Germany",
        "sire": "Rival v Kranichstein", "sire_registration_number": None,
        "dam": "Brangane v Weingarten", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Cajetan v Nibelungenhort", "registration_number": None},
            {"role": "dam_of_dam", "name": "Flora III v Alt-Worms", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Hartmuth v Kranichstein", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Senta v Ried", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Betty Nanthild v Nibelungen", "registration_number": None},
            {"role": "sire_of_sire", "name": "Diethelm v Hindendorff", "registration_number": None},
            {"role": "dam_of_sire", "name": "Agathe v Romerwall", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Orest v Kranichstein", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Flora Fornoff", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Asta v Starkenburg", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "FRAULEIN OF PONTCHARTRAIN", "sex": "Female", "registration_number": "681073",
        "birth_date": "June 20, 1927", "color": "Blk rd",
        "owner": "G. A. Gorham", "owner_location": None,
        "breeder": "Glenn Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Judy of Detroit", "dam_registration_number": "371474",
        "source": meta_c2
    },
    {
        "name": "FRITZ V FUHRMANN", "sex": "Male", "registration_number": "680142",
        "birth_date": "June 22, 1928", "color": "Blk & rd",
        "owner": "R. A. Hugill", "owner_location": None,
        "breeder": "Chas. M. Riggs", "breeder_location": "Allegan, Mich.",
        "sire": "Fuhrmann v Zinsgut", "sire_registration_number": "610413",
        "dam": "Queen Beta Princess", "dam_registration_number": "676748",
        "source": meta_c2
    }
]

# Column 3 (Leaf 49 Col 3 - 22 dogs)
c3_dogs = [
    {
        "name": "FRITZ II V NIBELUNGENHORT", "sex": "Male", "registration_number": "683013",
        "birth_date": "Aug. 8, 1928", "color": "Rd & tn",
        "owner": "John A. Morrissey", "owner_location": None,
        "breeder": "E. J. Wood", "breeder_location": "Buffalo, N. Y.",
        "sire": "Niko v Nibelungenhort", "sire_registration_number": "465935",
        "dam": "Princess v Pierrot", "dam_registration_number": "645554",
        "source": meta_c3
    },
    {
        "name": "FRITZ V PALATINE", "sex": "Male", "registration_number": "681567",
        "birth_date": "June 8, 1928", "color": "Rd & tn",
        "owner": "Frank L. McGuire", "owner_location": None,
        "breeder": "Stuart McGuire", "breeder_location": "Portland, Ore.",
        "sire": "Artus v d Internationale", "sire_registration_number": "628049",
        "dam": "Dolly v Reyem", "dam_registration_number": "538466",
        "source": meta_c3
    },
    {
        "name": "GERHARDT V D HOEHEN", "sex": "Male", "registration_number": "684272",
        "birth_date": "May 16, 1928", "color": "Blk & tn",
        "owner": "Helen K. Holler", "owner_location": None,
        "breeder": "James C. Moores", "breeder_location": "Fayetteville, Tenn.",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Baroness Atora v d Hoehen", "dam_registration_number": "554720",
        "source": meta_c3
    },
    {
        "name": "GIRL OF ARKEDEN", "sex": "Female", "registration_number": "683828",
        "birth_date": "May 30, 1924", "color": "Blk & tn",
        "owner": "Paul Venth", "owner_location": None,
        "breeder": "Arkeden Kennels", "breeder_location": "Lynbrook, L. I., N. Y.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Lotte v Zoic", "dam_registration_number": "350274",
        "source": meta_c3
    },
    {
        "name": "GLEBA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "680145",
        "birth_date": "Apr. 24, 1926", "color": "Blk rd",
        "owner": "F. G. Hauessermann", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "A Rappo of Pontchartrain", "sire_registration_number": "439031",
        "dam": "Nada of Sea Cliff", "dam_registration_number": "481857",
        "source": meta_c3
    },
    {
        "name": "GRAF V DE SAND", "sex": "Male", "registration_number": "680144",
        "birth_date": "Mar. 11, 1925", "color": "Blk & tn",
        "owner": "John F. Fowler", "owner_location": None,
        "breeder": "Isaac Bowering", "breeder_location": "Melrose, Mass.",
        "sire": "Bodo v Musenbach", "sire_registration_number": "322043",
        "dam": "Princess Victoria M. P.", "dam_registration_number": "468189",
        "source": meta_c3
    },
    {
        "name": "GRETEL III", "sex": "Female", "registration_number": "683865",
        "birth_date": "Aug. 8, 1927", "color": "Blk & tn",
        "owner": "Mrs. G. H. Wilder", "owner_location": None,
        "breeder": "Raymond Desrosiers", "breeder_location": "Taunton, Mass.",
        "sire": "Remus v Telless", "sire_registration_number": "675231",
        "dam": "Berta v Phalzerland", "dam_registration_number": "604628",
        "source": meta_c3
    },
    {
        "name": "GUARD V D SELLERS", "sex": "Male", "registration_number": "684424",
        "birth_date": "Sept. 23, 1928", "color": "Blk & tn",
        "owner": "Nell Sellers", "owner_location": None,
        "breeder": "J. D. Wickersham", "breeder_location": "Dayton, Ohio",
        "sire": "Black Guard", "sire_registration_number": "630172",
        "dam": "Diana v d Thueringen", "dam_registration_number": "663926",
        "source": meta_c3
    },
    {
        "name": "GWANWYN FRUSTIN V FAVORITE", "sex": "Female", "registration_number": "681339",
        "birth_date": "Sept. 3, 1925", "color": "Rd & tn",
        "owner": "Harry B. Lathrop", "owner_location": None,
        "breeder": "Eliza M. Garrett", "breeder_location": "West Chester, Pa.",
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Marga v Jagerhof", "dam_registration_number": "394481",
        "source": meta_c3
    },
    {
        "name": "HANS OF BOSTON", "sex": "Male", "registration_number": "681093",
        "birth_date": "Oct. 28, 1927", "color": "Blk & tn",
        "owner": "Elizabeth B. Zeuch", "owner_location": None,
        "breeder": "L. H. Fairbanks", "breeder_location": "Boston, Mass.",
        "sire": "Ritz Carlton", "sire_registration_number": "485720",
        "dam": "Princess Susana Rita v Howlett", "dam_registration_number": "492756",
        "source": meta_c3
    },
    {
        "name": "HEXE NELL", "sex": "Female", "registration_number": "683031",
        "birth_date": "May 14, 1927", "color": "Blk & tn",
        "owner": "A. L. Galpin", "owner_location": None,
        "breeder": "Jerry Schnable", "breeder_location": "Riverside, Ill.",
        "sire": "Artus v Schlingelhof", "sire_registration_number": "422797",
        "dam": "Melinde from the Rosenau", "dam_registration_number": "367866",
        "source": meta_c3
    },
    {
        "name": "HILDEGARDE ISOLDE", "sex": "Female", "registration_number": "680254",
        "birth_date": "Aug. 1, 1927", "color": "Blk & tn",
        "owner": "A. E. Kohanski", "owner_location": None,
        "breeder": "Edward C. Heil", "breeder_location": "Chicago, Ill.",
        "sire": "Caesar v d Riedburg", "sire_registration_number": "534129",
        "dam": "Eastleigh Isolde", "dam_registration_number": "379318",
        "source": meta_c3
    },
    {
        "name": "ICON V D HOHEN", "sex": "Male", "registration_number": "681385",
        "birth_date": "Mar. 31, 1928", "color": "Br & tn",
        "owner": "Mrs. Zoe C. Dodd", "owner_location": None,
        "breeder": "Ruth Von Hoegen", "breeder_location": "Towaco, N. J.",
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Berta Rota v Niebelingenhort", "dam_registration_number": "370074",
        "source": meta_c3
    },
    {
        "name": "JULIE V D ROEMERHOF", "sex": "Female", "registration_number": "681376",
        "birth_date": "May 16, 1927", "color": "Blk & tn",
        "owner": "Lester W. Koehler", "owner_location": None,
        "breeder": "H. B. Hark", "breeder_location": "Glendale, Ohio",
        "sire": "Benno v d Roemerhof", "sire_registration_number": "517073",
        "dam": "Tora v d Blankenburg", "dam_registration_number": "496696",
        "source": meta_c3
    },
    {
        "name": "JUNO V ZARSTOFF", "sex": "Female", "registration_number": "682670",
        "birth_date": "Feb. 10, 1927", "color": "Blk & tn",
        "owner": "Mrs. W. V. Blakeley", "owner_location": None,
        "breeder": "Mrs. R. L. Thomas", "breeder_location": "Columbus, Ohio",
        "sire": "Shampo of Copenhagen", "sire_registration_number": "592404",
        "dam": "Cisi v Hemberg", "dam_registration_number": "542669",
        "source": meta_c3
    },
    {
        "name": "KASHA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "681856",
        "birth_date": "Apr. 10, 1928", "color": "Blk rd",
        "owner": "R. S. Morgan", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Gwanna of Pontchartrain", "dam_registration_number": "649692",
        "source": meta_c3
    },
    {
        "name": "KING LADDIE BOY", "sex": "Male", "registration_number": "683550",
        "birth_date": "May 21, 1928", "color": "Blk & tn",
        "owner": "Sabbath Centrella", "owner_location": None,
        "breeder": "Arthur C. Otto", "breeder_location": "Brooklyn, N. Y.",
        "sire": "Big Ben of Arkeden", "sire_registration_number": "500559",
        "dam": "Dotty v Hetzendorf", "dam_registration_number": "641349",
        "source": meta_c3
    },
    {
        "name": "LADY JANE V EULENDORF", "sex": "Female", "registration_number": "682618",
        "birth_date": "June 16, 1928", "color": "Rd, br & tn",
        "owner": "Helen A. Eul", "owner_location": None,
        "breeder": "Nick Beck", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Mirjam v Beckerhof", "dam_registration_number": "632253",
        "source": meta_c3
    },
    {
        "name": "LADY V SCHLINGELHOF", "sex": "Female", "registration_number": "683403",
        "birth_date": "May 14, 1927", "color": "Blk & tn",
        "owner": "Mrs. E. C. Hall", "owner_location": None,
        "breeder": "Jerry Schnabl", "breeder_location": "Riverside, Ill.",
        "sire": "Artus v Schlingelhof", "sire_registration_number": "422979",
        "dam": "Melinde from the Rosenau", "dam_registration_number": "367866",
        "source": meta_c3
    },
    {
        "name": "LANGE V ALTENDORF", "sex": "Male", "registration_number": "682035",
        "birth_date": "Aug. 20, 1927", "color": "Blk & rust",
        "owner": "Louis Hutter", "owner_location": None,
        "breeder": "G. F. Deckert", "breeder_location": "Rising City, Nebr.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Dita v Lieschenhof", "dam_registration_number": "595040",
        "source": meta_c3
    },
    {
        "name": "LEDDY OF PONTCHARTRAIN", "sex": "Female", "registration_number": "680146",
        "birth_date": "June 1, 1927", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Nada of Sea Cliff", "dam_registration_number": "481857",
        "source": meta_c3
    },
    {
        "name": "LE JEAL'S FRITZ", "sex": "Male", "registration_number": "680119",
        "birth_date": "Apr. 7, 1928", "color": "Blue & tn",
        "owner": "M. L. Le Jeal", "owner_location": None,
        "breeder": "Pete Donovan", "breeder_location": "Erie, Pa.",
        "sire": "Perry Graf of Glenraudh", "sire_registration_number": "425226",
        "dam": "Donovan's Gretchen", "dam_registration_number": "538598",
        "source": meta_c3
    }
]

# Column 4 (Leaf 50 Col 1 - 14 dogs ending before POMERANIANS)
c4_dogs = [
    {
        "name": "LINDA V FRANKEN", "sex": "Female", "registration_number": "680623",
        "birth_date": "July 11, 1928", "color": "Blk rust",
        "owner": "Mrs. Dudley C. Smith", "owner_location": None,
        "breeder": "Geo. H. Jones", "breeder_location": "Danville, Ill.",
        "sire": "Westphalia v Klostersee", "sire_registration_number": "399998",
        "dam": "Princess v Rudolphsburg", "dam_registration_number": "569711",
        "source": meta_c4
    },
    {
        "name": "LINDY", "sex": "Male", "registration_number": "684120",
        "birth_date": "Oct. 3, 1927", "color": "Blk & tn",
        "owner": "Anna Mae Hauselman", "owner_location": None,
        "breeder": "W. N. McCoy", "breeder_location": "Middletown, Ohio",
        "sire": "A Rappo of Pontchartrain", "sire_registration_number": "439031",
        "dam": "Gira v Nibelungenhort", "dam_registration_number": "491924",
        "source": meta_c4
    },
    {
        "name": "LOKI V D DREHBRUCKE", "sex": "Female", "registration_number": "684658",
        "birth_date": "Oct. 1, 1928", "color": "Blk & rd",
        "owner": "Jane L. Macfarlane", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Md.",
        "sire": "Benno v d Drehbrucke", "sire_registration_number": "639146",
        "dam": "Anita v Grossmannstein", "dam_registration_number": "605203",
        "source": meta_c4
    },
    {
        "name": "LUTZIE OF DHU VARREN", "sex": "Female", "registration_number": "682898",
        "birth_date": "Sept. 10, 1927", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": None,
        "breeder": "Edward A. Hunter", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Gaby of Pontchartrain", "dam_registration_number": "553020",
        "source": meta_c4
    },
    {
        "name": "MARCUS MORISON", "sex": "Male", "registration_number": "682368",
        "birth_date": "Aug. 27, 1928", "color": "Blk & tn",
        "owner": "Harriett Morison", "owner_location": None,
        "breeder": "Thomas L. Mangin", "breeder_location": "Syracuse, N. Y.",
        "sire": "Benno v Roemerhof", "sire_registration_number": "517073",
        "dam": "Lady Rickee Mangin", "dam_registration_number": "608560",
        "source": meta_c4
    },
    {
        "name": "MAX V GOLDGRUND", "sex": "Male", "registration_number": "680742",
        "birth_date": "May 24, 1928", "color": "Blk & tn",
        "owner": "H. S. Root", "owner_location": None,
        "breeder": "Chester A. Ellis", "breeder_location": "Pottstown, Pa.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Rowdy Allie of Pottstown", "dam_registration_number": "615095",
        "source": meta_c4
    },
    {
        "name": "NICHOLAS V BELGER", "sex": "Male", "registration_number": "684430",
        "birth_date": "Nov. 13, 1928", "color": "Rd & tn",
        "owner": "Elizabeth Reed Seavey", "owner_location": None,
        "breeder": "Edwin C. Philbrook", "breeder_location": "Rock Island, Me.",
        "sire": "Timidity Brrrp", "sire_registration_number": "614624",
        "dam": "Gretel v Belger", "dam_registration_number": "539977",
        "source": meta_c4
    },
    {
        "name": "PETER OF PONTCHARTRAIN", "sex": "Male", "registration_number": "680147",
        "birth_date": "Sept. 21, 1928", "color": "Blk rd",
        "owner": "Robert E. Hannon", "owner_location": None,
        "breeder": "Frank B. Tanner", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Lita v d Burgholz", "dam_registration_number": "671060",
        "source": meta_c4
    },
    {
        "name": "RADFORD'S ASTA", "sex": "Female", "registration_number": "679789",
        "birth_date": "Jan. 29, 1927", "color": "Blk & tn",
        "owner": "R. D. Radford", "owner_location": None,
        "breeder": "Mrs. R. J. McNabb", "breeder_location": "Chicago, Ill.",
        "sire": "Pedo", "sire_registration_number": "672391",
        "dam": "Asta v Mecklenburg", "dam_registration_number": "406354",
        "source": meta_c4
    },
    {
        "name": "RAJAH V SIMMINEAU", "sex": "Male", "registration_number": "679898",
        "birth_date": "May 10, 1928", "color": "Blk & tn",
        "owner": "Cleveland R. Davis", "owner_location": None,
        "breeder": "O. K. Lindquist", "breeder_location": "Detroit, Mich.",
        "sire": "A Rappo of Pontchartrain", "sire_registration_number": "439031",
        "dam": "Kona Nibelungenhort", "dam_registration_number": "647954",
        "source": meta_c4
    },
    {
        "name": "RUSTY V STEUBEN", "sex": "Male", "registration_number": "681723",
        "birth_date": "Aug. 4, 1928", "color": "Blk & rust",
        "owner": "M. H. McRae", "owner_location": None,
        "breeder": "Mrs. H. S. Taylor", "breeder_location": "Lakewood, N. J.",
        "sire": "Jof v Steuben", "sire_registration_number": "654600",
        "dam": "Rota v Steuben", "dam_registration_number": "649190",
        "source": meta_c4
    },
    {
        "name": "TEDDY II", "sex": "Male", "registration_number": "681722",
        "birth_date": "Mar. 31, 1928", "color": "Rd & tn",
        "owner": "W. A. Baird", "owner_location": None,
        "breeder": "Margaret Kevis", "breeder_location": "Aston Mills, Pa.",
        "sire": "Red Roof Rufus", "sire_registration_number": "491422",
        "dam": "Sophie v d Koningstad", "dam_registration_number": "540612",
        "source": meta_c4
    },
    {
        "name": "WALTER V HOH", "sex": "Male", "registration_number": "682033",
        "birth_date": "Jan. 1, 1928", "color": "Blk & tn",
        "owner": "Louis Hutter", "owner_location": "Papillion, Nebr.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Betty v Wiedensahl", "dam_registration_number": "489275",
        "source": meta_c4
    },
    {
        "name": "WANDA V SIEGESTOR", "sex": "Female", "registration_number": "684558",
        "birth_date": "Oct. 9, 1927", "color": "Blk & rust",
        "owner": "C. J. Malone", "owner_location": None,
        "breeder": "Mrs. H. Gurtler", "breeder_location": "Coldwater, N. Y.",
        "sire": "Werner v Stolzenfels", "sire_registration_number": "577357",
        "dam": "Frau Marga v d Schonwald", "dam_registration_number": "452123",
        "source": meta_c4
    }
]

all_63 = c1_dogs + c2_dogs + c3_dogs + c4_dogs
print(f"Total compiled 1929-05 dogs: {len(all_63)} (Expected: 63)")
print(f"Col 1: {len(c1_dogs)} (Expected: 6)")
print(f"Col 2: {len(c2_dogs)} (Expected: 21)")
print(f"Col 3: {len(c3_dogs)} (Expected: 22)")
print(f"Col 4: {len(c4_dogs)} (Expected: 14)")

Path("stud-scrape/data/verified_1929_05.json").write_text(json.dumps(all_63, indent=2), encoding="utf-8")
print("Saved clean 1929-05 records to stud-scrape/data/verified_1929_05.json")
