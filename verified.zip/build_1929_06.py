import json
from pathlib import Path

meta_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-06-01_46_6", "date": "1929-06-01", "volume": "46", "issue": "6", "leaf": 39, "column": 1}
meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-06-01_46_6", "date": "1929-06-01", "volume": "46", "issue": "6", "leaf": 39, "column": 2}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-06-01_46_6", "date": "1929-06-01", "volume": "46", "issue": "6", "leaf": 39, "column": 3}

# Column 1 (Leaf 39 Col 1 - 15 dogs)
c1_dogs = [
    {
        "name": "AGRI V HOHENBURG", "sex": "Female", "registration_number": "688357",
        "birth_date": "July 17, 1927", "color": "Blk & tn",
        "owner": "Carl E. Swartz", "owner_location": None,
        "breeder": "Bert Young", "breeder_location": "Granville, O.",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Lady Gretchen", "dam_registration_number": "574220",
        "source": meta_c1
    },
    {
        "name": "ALICE V D CHARLESBANK", "sex": "Female", "registration_number": "688358",
        "birth_date": "Feb. 12, 1927", "color": "Br & tn",
        "owner": "Otto Peveling", "owner_location": None,
        "breeder": "Frank McKeague", "breeder_location": "Brockton, Mass.",
        "sire": "Baldur v Koenigswart", "sire_registration_number": "534316",
        "dam": "Princess v Buren", "dam_registration_number": "412414",
        "source": meta_c1
    },
    {
        "name": "ANGOLA V D MARGARETENAU", "sex": "Female", "registration_number": "685402",
        "birth_date": "Apr. 19, 1923", "color": "Blk & tn",
        "owner": "Sofie Froelich", "owner_location": None,
        "breeder": "Peter Schmelz", "breeder_location": "Germany",
        "sire": "Infant v Hornegg", "sire_registration_number": None,
        "dam": "Wally II v Lutzellinden", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Nero v Hornsheim", "registration_number": None},
            {"role": "dam_of_dam", "name": "Nelly II v Lutzellinden", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Hellegraf v Thuringen", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Nelly v Lutzellinden", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Prinz Modern v Ilm Athen", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Nelly v Lutzellinden", "registration_number": None},
            {"role": "sire_of_sire", "name": "Lord v d Horstburg", "registration_number": "316607"},
            {"role": "dam_of_sire", "name": "Bille v Langerode", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Prinz Leuthold v Hornegg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Asta v Starkenburg", "registration_number": None}
        ],
        "source": meta_c1
    },
    {
        "name": "ARNO V HUENEFELD", "sex": "Male", "registration_number": "685527",
        "birth_date": "Dec. 21, 1927", "color": "Br & rd",
        "owner": "Wm. H. Oakley", "owner_location": None,
        "breeder": "John Ninger", "breeder_location": "Bloomfield, N. J.",
        "sire": "Ego v Allershausen", "sire_registration_number": "525324",
        "dam": "Charlotte v Burgfried", "dam_registration_number": "493051",
        "source": meta_c1
    },
    {
        "name": "BLITZ V BORNHOLM", "sex": "Male", "registration_number": "687490",
        "birth_date": "Nov. 11, 1928", "color": "Blk & tn",
        "owner": "Ralph C. Kotheimer", "owner_location": None,
        "breeder": "F. C. Bowles", "breeder_location": "Hartville, O.",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477107",
        "dam": "Tisch v Bornholm", "dam_registration_number": "401095",
        "source": meta_c1
    },
    {
        "name": "BLITZ V DOMBACHTAL", "sex": "Male", "registration_number": "685678",
        "birth_date": "Oct. 29, 1928", "color": "Blk & tn",
        "owner": "Annabell W. Cratte", "owner_location": None,
        "breeder": "Mrs. R. E. Byrd", "breeder_location": "Erie, Pa.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Donna v Dombachtal", "dam_registration_number": "653113",
        "source": meta_c1
    },
    {
        "name": "BLITZ V KANONENSTADT", "sex": "Male", "registration_number": "685608",
        "birth_date": "Aug. 23, 1928", "color": "Rd, tn mkgs",
        "owner": "E. L. White", "owner_location": None,
        "breeder": "Marshall F. Bidwell", "breeder_location": "So. Windsor, Conn.",
        "sire": "Baron v Richthofen", "sire_registration_number": "525664",
        "dam": "Adda v Kanonenstadt", "dam_registration_number": "534153",
        "source": meta_c1
    },
    {
        "name": "CITO V HOCHS", "sex": "Male", "registration_number": "687840",
        "birth_date": "Nov. 10, 1927", "color": "Blk & tn",
        "owner": "B. C. Hawkes, Jr.", "owner_location": "Kansas City, Mo.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Red Roof Rowdy", "sire_registration_number": "392482",
        "dam": "Aileen of Mickburn", "dam_registration_number": "580533",
        "source": meta_c1
    },
    {
        "name": "CITO V D MARGARETENAU", "sex": "Male", "registration_number": "685406",
        "birth_date": "Sept. 10, 1923", "color": "Blk & rd",
        "owner": "Sofie Froelich", "owner_location": None,
        "breeder": "Peter Schmelz", "breeder_location": "Germany",
        "sire": "Herold v Friedewald", "sire_registration_number": None,
        "dam": "Leska v d Margaretenau", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Montwitz v Eckardstein", "registration_number": "372484"},
            {"role": "dam_of_dam", "name": "Isolde v Friedewald", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Bruno v Friedewald", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Gunda v Friedewald", "registration_number": None},
            {"role": "sire_of_sire", "name": "Herold v Friedewald", "registration_number": None},
            {"role": "dam_of_sire", "name": "Freya Ripper", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Lord v d Horstburg", "registration_number": "316607"},
            {"role": "dam_of_paternal_granddam", "name": "Mani v Kranichstein", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Cilla v Rheintor", "registration_number": None}
        ],
        "source": meta_c1
    },
    {
        "name": "COUNT LUCKNER", "sex": "Male", "registration_number": "688743",
        "birth_date": "Oct. 11, 1927", "color": "Blk & tn",
        "owner": "Henry W. Bopp", "owner_location": "Terre Haute, Ind.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "A Hindoo of Pontchartrain", "sire_registration_number": "440792",
        "dam": "Ronne of Bornholm", "dam_registration_number": "528650",
        "source": meta_c1
    },
    {
        "name": "DIN GRANDO", "sex": "Male", "registration_number": "686555",
        "birth_date": "July 5, 1928", "color": "Blk & tn",
        "owner": "W. C. McLaughlin", "owner_location": None,
        "breeder": "H. L. Foran", "breeder_location": "Grand Island, Nebr.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Frieda the Great", "dam_registration_number": "666262",
        "source": meta_c1
    },
    {
        "name": "DOBIE II", "sex": "Female", "registration_number": "687044",
        "birth_date": "Dec. 9, 1928", "color": "Blk & tn",
        "owner": "Richard S. Smith", "owner_location": None,
        "breeder": "James M. Osborne", "breeder_location": "Cleveland, O.",
        "sire": "Rudolph Richtofen", "sire_registration_number": "612479",
        "dam": "Lady v d Eckardsburg", "dam_registration_number": "679268",
        "source": meta_c1
    },
    {
        "name": "DUKE CHARLES OF BURGANDY", "sex": "Male", "registration_number": "688436",
        "birth_date": "Mar. 13, 1929", "color": "Blk & mhgy",
        "owner": "Luther M. R. Willis", "owner_location": None,
        "breeder": "Charles King", "breeder_location": "Baltimore, Md.",
        "sire": "Beowulf v Siegestor", "sire_registration_number": "525331",
        "dam": "Reta v Siegestor", "dam_registration_number": "570743",
        "source": meta_c1
    },
    {
        "name": "DYNO V SIGALSBURG", "sex": "Male", "registration_number": "687000",
        "birth_date": "Sept. 11, 1928", "color": "Blk & tn",
        "owner": "M. C. Van Allen", "owner_location": None,
        "breeder": "E. J. Robinson", "breeder_location": "Milwaukee, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Robinson's Milly", "dam_registration_number": "516295",
        "source": meta_c1
    },
    {
        "name": "FASCINATION", "sex": "Female", "registration_number": "687043",
        "birth_date": "Dec. 9, 1928", "color": "Br & tn",
        "owner": "James M. Osborne", "owner_location": "Cleveland, O.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rudolph Richtofen", "sire_registration_number": "612479",
        "dam": "Lady v d Eckardsburg", "dam_registration_number": "679268",
        "source": meta_c1
    }
]

# Column 2 (Leaf 39 Col 2 - 22 dogs)
c2_dogs = [
    {
        "name": "FLORA V DARWICHE", "sex": "Female", "registration_number": "687799",
        "birth_date": "May 15, 1928", "color": "Blk & tn",
        "owner": "James C. Moores", "owner_location": "Fayetteville, Tenn.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Baroness Atora v d Hoehen", "dam_registration_number": "554720",
        "source": meta_c2
    },
    {
        "name": "FREYA V BURGFRIED", "sex": "Female", "registration_number": "686417",
        "birth_date": "Mar. 7, 1924", "color": "Blk & rd",
        "owner": "Fred Happe", "owner_location": None,
        "breeder": "Fr. August Happe", "breeder_location": "Germany",
        "sire": "Bosco v d Atzelburg", "sire_registration_number": "441307",
        "dam": "Anni v Burgfried", "dam_registration_number": "516158",
        "source": meta_c2
    },
    {
        "name": "FRITZI II V D HORSTBURG", "sex": "Male", "registration_number": "687883",
        "birth_date": "Jan. 8, 1928", "color": "Blk & tn",
        "owner": "Louis R. Phillips", "owner_location": None,
        "breeder": "Clarence Heather", "breeder_location": "So. Attleboro, Mass.",
        "sire": "Fritzi v d Horstburg", "sire_registration_number": "541344",
        "dam": "Flash of Mansfield", "dam_registration_number": "541342",
        "source": meta_c2
    },
    {
        "name": "FRITZ III NIBELUNGENHORT", "sex": "Male", "registration_number": "685955",
        "birth_date": "June 14, 1928", "color": "Blk",
        "owner": "Harry G. Johnson", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Asta v Mecklenburg", "dam_registration_number": "406354",
        "source": meta_c2
    },
    {
        "name": "GLORY OF WARRENCREST", "sex": "Female", "registration_number": "684802",
        "birth_date": "Aug. 18, 1926", "color": "Blk & tn",
        "owner": "Glenn R. Warren", "owner_location": None,
        "breeder": "Earl N. Meyer", "breeder_location": "Milwaukee, Wis.",
        "sire": "Carso v Siegestor", "sire_registration_number": "534314",
        "dam": "Dilya v Allgaeu", "dam_registration_number": "534156",
        "source": meta_c2
    },
    {
        "name": "GRETA V SIGALSBURG", "sex": "Female", "registration_number": "686149",
        "birth_date": "Jan. 21, 1929", "color": "Blk & tn",
        "owner": "Louis Remke", "owner_location": None,
        "breeder": "Dorothy Bolce", "breeder_location": "Cincinnati, O.",
        "sire": "Toppo v Sigalsburg", "sire_registration_number": "670191",
        "dam": "Gretel v Horstburg", "dam_registration_number": "670190",
        "source": meta_c2
    },
    {
        "name": "HANDSOME HANSEL V STEUBEN", "sex": "Male", "registration_number": "686893",
        "birth_date": "June 22, 1928", "color": "Blue & tn",
        "owner": "Thomas M. McKenney", "owner_location": None,
        "breeder": "Margaret Lee Fahey", "breeder_location": "Lewiston, Me.",
        "sire": "Cuno v Musenbach", "sire_registration_number": "596712",
        "dam": "Rota Bella v Steuben", "dam_registration_number": "516684",
        "source": meta_c2
    },
    {
        "name": "HASSO II V ALTENDORF", "sex": "Male", "registration_number": "687958",
        "birth_date": "Dec. 2, 1927", "color": "Blk, rust",
        "owner": "Ernst J. Eggerss", "owner_location": None,
        "breeder": "Harriet B. Patrick", "breeder_location": "Omaha, Nebr.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Elly II v Wiedensahl", "dam_registration_number": "581816",
        "source": meta_c2
    },
    {
        "name": "HILDEGARD V FREYBERG", "sex": "Female", "registration_number": "685019",
        "birth_date": "Sept. 23, 1928", "color": "Blk & tn",
        "owner": "W. P. Freyberg", "owner_location": None,
        "breeder": "J. D. Wickersham", "breeder_location": "Dayton, O.",
        "sire": "Black Guard", "sire_registration_number": "630172",
        "dam": "Diana v d Thueringen", "dam_registration_number": "663926",
        "source": meta_c2
    },
    {
        "name": "HOWDY BOY", "sex": "Male", "registration_number": "687042",
        "birth_date": "Dec. 9, 1928", "color": "Blk & tn",
        "owner": "Clarence H. Osborne", "owner_location": None,
        "breeder": "James M. Osborne", "breeder_location": "Cleveland, O.",
        "sire": "Rudolph Richtofen", "sire_registration_number": "612479",
        "dam": "Lady v d Eckardsburg", "dam_registration_number": "679268",
        "source": meta_c2
    },
    {
        "name": "JERRYALENE V WILDENDORF", "sex": "Female", "registration_number": "688742",
        "birth_date": "Jan. 31, 1926", "color": "Blk & tn",
        "owner": "R. A. Tibbetts", "owner_location": None,
        "breeder": "Karl A. Thiemann", "breeder_location": "Omaha, Nebr.",
        "sire": "Hasso v Altendorf", "sire_registration_number": "463070",
        "dam": "Elly v Wiedensahl", "dam_registration_number": "489274",
        "source": meta_c2
    },
    {
        "name": "JOUDA V STEIGERWALD", "sex": "Female", "registration_number": "686413",
        "birth_date": "Jan. 14, 1925", "color": "Br & rd",
        "owner": "Sofie Froelich", "owner_location": None,
        "breeder": "Herm. Herzog", "breeder_location": "Germany",
        "sire": "Baldur v d Finchohe", "sire_registration_number": None,
        "dam": "Centa v d Weiherstrasse", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Bruno v Friedewald", "registration_number": None},
            {"role": "dam_of_dam", "name": "Alma v Rednitz", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Moritz v Schweitzerhof", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Minka Rolfes", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Prinz Leuthold v Hornegg", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Bella v Dambachtal", "registration_number": None},
            {"role": "sire_of_sire", "name": "Baldur v d Finohohe", "registration_number": None},
            {"role": "dam_of_sire", "name": "Artus v Langerode", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Leddy v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Burschel v Simmenau", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Asta Voss", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Prinz Leuthold v Hornegg", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "KUNO V BERGHOF", "sex": "Male", "registration_number": "685988",
        "birth_date": "Feb. 22, 1926", "color": "Rd & tn",
        "owner": "Fred M. Berger", "owner_location": "Chicago, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Caballero v Wassertor", "sire_registration_number": "628898",
        "dam": "Freya v Bergerhof", "dam_registration_number": "578494",
        "source": meta_c2
    },
    {
        "name": "MILADY V D KEISERHEIM", "sex": "Female", "registration_number": "685983",
        "birth_date": "Sept. 23, 1928", "color": "Blk & tn",
        "owner": "Mrs. C. B. Keiser", "owner_location": None,
        "breeder": "J. D. Wickersham", "breeder_location": "Dayton, O.",
        "sire": "Black Guard", "sire_registration_number": "630172",
        "dam": "Diana v d Thueringen", "dam_registration_number": "663926",
        "source": meta_c2
    },
    {
        "name": "NETA NIBELUNGENHORT", "sex": "Female", "registration_number": "687457",
        "birth_date": "Dec. 26, 1927", "color": "Chlte & tn",
        "owner": "C. B. McCullough", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Asta v Mecklenburg", "dam_registration_number": "406354",
        "source": meta_c2
    },
    {
        "name": "OLGA V D HELME", "sex": "Female", "registration_number": "685989",
        "birth_date": "Feb. 21, 1926", "color": "Rd & tn",
        "owner": "Fred T. Holmes", "owner_location": None,
        "breeder": "Fred M. Berger", "breeder_location": "Chicago, Ill.",
        "sire": "Caballero v Wassertor", "sire_registration_number": "628898",
        "dam": "Lady v Bergerhof", "dam_registration_number": "578495",
        "source": meta_c2
    },
    {
        "name": "PANDORA V STEUBEN", "sex": "Female", "registration_number": "685793",
        "birth_date": "Dec. 1, 1927", "color": "Blk & rust",
        "owner": "F. C. Fuqua", "owner_location": None,
        "breeder": "J. R. Masters", "breeder_location": "Bowerston, O.",
        "sire": "Printz Arto v d Spreehort", "sire_registration_number": "559555",
        "dam": "Magelone v Nibelungenhort", "dam_registration_number": "483923",
        "source": meta_c2
    },
    {
        "name": "PETER RITZ RIEDOLPSBURG", "sex": "Male", "registration_number": "687456",
        "birth_date": "June 27, 1928", "color": "Blk & rust",
        "owner": "Ruth P. Goodwin", "owner_location": None,
        "breeder": "Edith L. Keirstead", "breeder_location": "Groton, Mass.",
        "sire": "Ritz Carlton", "sire_registration_number": "485720",
        "dam": "Fricka v d Nibelungenhort", "dam_registration_number": "577937",
        "source": meta_c2
    },
    {
        "name": "PHILIP V PAGEL", "sex": "Male", "registration_number": "688741",
        "birth_date": "Nov. 26, 1928", "color": "Blk & tn",
        "owner": "Haseltine Huffman", "owner_location": None,
        "breeder": "Paul B. Wallace", "breeder_location": "Buchanan, Mich.",
        "sire": "Ochsner's Best Bet", "sire_registration_number": "609713",
        "dam": "Greta v Pagel", "dam_registration_number": "618522",
        "source": meta_c2
    },
    {
        "name": "PRINCE LEO V OCCIDENTAL", "sex": "Male", "registration_number": "686204",
        "birth_date": "Sept. 11, 1926", "color": "Blk & tn",
        "owner": "Frederick Buchholz", "owner_location": "Washington, D. C.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Occidental Rolf v Eichelberg", "sire_registration_number": "387426",
        "dam": "Occidental Dolly v Desenberg", "dam_registration_number": "387425",
        "source": meta_c2
    },
    {
        "name": "PRINCESS ALMA V OCCIDENTAL", "sex": "Female", "registration_number": "686203",
        "birth_date": "Sept. 11, 1926", "color": "Blue & tn",
        "owner": "Frederick Buchholz", "owner_location": "Washington, D. C.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Occidental Rolf v Eichelberg", "sire_registration_number": "387426",
        "dam": "Occidental Dolly v Desenberg", "dam_registration_number": "387425",
        "source": meta_c2
    },
    {
        "name": "PRINTZ V D KINGHOF", "sex": "Male", "registration_number": "686983",
        "birth_date": "July 17, 1927", "color": "Blk & tn",
        "owner": "W. D. King", "owner_location": None,
        "breeder": "Bert Young", "breeder_location": "Granville, O.",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Lady Gretchen", "dam_registration_number": "574220",
        "source": meta_c2
    }
]

# Column 3 (Leaf 39 Col 3 - 18 dogs ending before POINTERS)
c3_dogs = [
    {
        "name": "QUARTON OF PONTCHARTRAIN", "sex": "Male", "registration_number": "687458",
        "birth_date": "Oct. 9, 1928", "color": "Blk & rd",
        "owner": "Alfred Fick", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Leddy of Pontchartrain", "dam_registration_number": "680146",
        "source": meta_c3
    },
    {
        "name": "REA OF NEW JERSEY", "sex": "Female", "registration_number": "685584",
        "birth_date": "Jan. 3, 1927", "color": "Br & tn",
        "owner": "Gus Stoffels", "owner_location": None,
        "breeder": "Mrs. L. Happe Malz", "breeder_location": "Jamaica, L. I., N. Y.",
        "sire": "Apollo v Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Charlotta v d Reichsburg", "dam_registration_number": "245602",
        "source": meta_c3
    },
    {
        "name": "RENO V SIMMINEAU", "sex": "Male", "registration_number": "688227",
        "birth_date": "Nov. 18, 1927", "color": "Blk & br",
        "owner": "Daniel Crumpacker", "owner_location": None,
        "breeder": "M. D. Schuster", "breeder_location": "Youngstown, O.",
        "sire": "A. Rappo of Pontchartrain", "sire_registration_number": "439031",
        "dam": "Perry's Glory v St. Sebald", "dam_registration_number": "425227",
        "source": meta_c3
    },
    {
        "name": "RETTA V FRIEDEWALD", "sex": "Female", "registration_number": "685393",
        "birth_date": "June 2, 1923", "color": "Br & rd",
        "owner": "Gustave Lockeman", "owner_location": None,
        "breeder": "Fr. Waldt", "breeder_location": "Germany",
        "sire": "Adelfried v Friedewald", "sire_registration_number": None,
        "dam": "Hella v Friedewald", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Roland v Friedewald", "registration_number": None},
            {"role": "dam_of_dam", "name": "Anni v Friedewald", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Prinz Leuthold v Hornegg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Grafin Edie v Kranichstein", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Lord v Ried", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Wilma Emschertal v Friedewald", "registration_number": None},
            {"role": "sire_of_sire", "name": "Prinz Modern v Ilm Athen", "registration_number": None},
            {"role": "dam_of_sire", "name": "Bella v Dambachtal", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Moritz v Burgwall", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Lotte v Dambachtal", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux Edelblut v Ilm Athen", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Lotte v Ilm Athen", "registration_number": None}
        ],
        "source": meta_c3
    },
    {
        "name": "ROBINSON'S BERGA", "sex": "Female", "registration_number": "685710",
        "birth_date": "Nov. 3, 1928", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dorle v Leipzig", "dam_registration_number": "462575",
        "source": meta_c3
    },
    {
        "name": "ROBINSON'S CLARE", "sex": "Female", "registration_number": "685708",
        "birth_date": "Nov. 3, 1928", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dorle v Leipzig", "dam_registration_number": "462575",
        "source": meta_c3
    },
    {
        "name": "ROBINSON'S DIANA", "sex": "Female", "registration_number": "685707",
        "birth_date": "Nov. 3, 1928", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dorle v Leipzig", "dam_registration_number": "462575",
        "source": meta_c3
    },
    {
        "name": "ROBINSON'S EITEL", "sex": "Male", "registration_number": "685709",
        "birth_date": "Nov. 3, 1928", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dorle v Leipzig", "dam_registration_number": "462575",
        "source": meta_c3
    },
    {
        "name": "ROBINSON'S KING", "sex": "Male", "registration_number": "685706",
        "birth_date": "Nov. 3, 1928", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dorle v Leipzig", "dam_registration_number": "462575",
        "source": meta_c3
    },
    {
        "name": "ROWDY GIRL", "sex": "Female", "registration_number": "685589",
        "birth_date": "Sept. 23, 1928", "color": "Blk & tn",
        "owner": "J. P. Porter", "owner_location": None,
        "breeder": "J. D. Wickersham", "breeder_location": "Dayton, O.",
        "sire": "Black Guard", "sire_registration_number": "630172",
        "dam": "Diana v d Thueringen", "dam_registration_number": "663926",
        "source": meta_c3
    },
    {
        "name": "TYNG OF KETTLE COVE", "sex": "Male", "registration_number": "684929",
        "birth_date": "June 15, 1928", "color": "Blk & tn",
        "owner": "Kettle Cove Kennels", "owner_location": "Magnolia, Mass.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Brownie v Greg", "sire_registration_number": "549527",
        "dam": "Red Roof Hexie", "dam_registration_number": "448028",
        "source": meta_c3
    },
    {
        "name": "RUDY V D KLOSTERSEE", "sex": "Male", "registration_number": "687338",
        "birth_date": "July 11, 1928", "color": "Blk & tn",
        "owner": "Mrs. W. R. Roberson", "owner_location": None,
        "breeder": "Geo. H. Jones", "breeder_location": "Danville, Ill.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Princess v Rudolphsburg", "dam_registration_number": "569711",
        "source": meta_c3
    },
    {
        "name": "WALDA V KLOSTERSEE", "sex": "Female", "registration_number": "686458",
        "birth_date": "Jan. 1, 1928", "color": "Blk & tn",
        "owner": "Flora A. Fox", "owner_location": None,
        "breeder": "Louis Hutter", "breeder_location": "Papillion, Neb.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Betty v Wiedensahl", "dam_registration_number": "489275",
        "source": meta_c3
    },
    {
        "name": "WANDA V SIGALSBURG", "sex": "Female", "registration_number": "685130",
        "birth_date": "Oct. 30, 1927", "color": "Blk & tn",
        "owner": "Fred L. Elder", "owner_location": None,
        "breeder": "Harry B. Holloway", "breeder_location": "Hamburg, N. Y.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Delice De Haven", "dam_registration_number": "525497",
        "source": meta_c3
    },
    {
        "name": "WILHELM V CORNELIUS", "sex": "Male", "registration_number": "688432",
        "birth_date": "June 19, 1928", "color": "Blk & tn",
        "owner": "Josephine Williams Heritage", "owner_location": None,
        "breeder": "Walter E. Johnson", "breeder_location": "Centralia, Wash.",
        "sire": "Kount v Schlabber", "sire_registration_number": "589401",
        "dam": "Mitseylue of Charmedland", "dam_registration_number": "679467",
        "source": meta_c3
    },
    {
        "name": "ZEB V STARKENHART", "sex": "Male", "registration_number": "685345",
        "birth_date": "Apr. 27, 1928", "color": "Blk & rd",
        "owner": "Marjorie Joesting", "owner_location": None,
        "breeder": "F. C. Bowles", "breeder_location": "Hartville, O.",
        "sire": "Westphalia Dyno v Wiesengrund", "sire_registration_number": "365520",
        "dam": "Arrah v Tilhagen", "dam_registration_number": "658426",
        "source": meta_c3
    },
    {
        "name": "ZEP", "sex": "Male", "registration_number": "684790",
        "birth_date": "Nov. 28, 1928", "color": "Blk & tn",
        "owner": "Robert Hays Smith", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "San Jose, Cal.",
        "sire": "Burschel v Falkensee", "sire_registration_number": "553217",
        "dam": "Bona v d Deckersburg", "dam_registration_number": "553222",
        "source": meta_c3
    },
    {
        "name": "ZUT", "sex": "Female", "registration_number": "687800",
        "birth_date": "May 23, 1928", "color": "Blk & tn",
        "owner": "Elizabeth Trueblood Paine", "owner_location": None,
        "breeder": "Antoinette Orth", "breeder_location": "San Francisco, Cal.",
        "sire": "Osmann", "sire_registration_number": "611285",
        "dam": "Adda v Bets", "dam_registration_number": "556862",
        "source": meta_c3
    }
]

all_55 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1929-06 dogs: {len(all_55)} (Expected: 55)")
print(f"Col 1: {len(c1_dogs)} (Expected: 15)")
print(f"Col 2: {len(c2_dogs)} (Expected: 22)")
print(f"Col 3: {len(c3_dogs)} (Expected: 18)")

Path("stud-scrape/data/verified_1929_06.json").write_text(json.dumps(all_55, indent=2), encoding="utf-8")
print("Saved clean 1929-06 records to stud-scrape/data/verified_1929_06.json")
