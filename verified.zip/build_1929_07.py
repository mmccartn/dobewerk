import json
from pathlib import Path

meta_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-07-01_46_7", "date": "1929-07-01", "volume": "46", "issue": "7", "leaf": 39, "column": 3}
meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-07-01_46_7", "date": "1929-07-01", "volume": "46", "issue": "7", "leaf": 40, "column": 1}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-07-01_46_7", "date": "1929-07-01", "volume": "46", "issue": "7", "leaf": 40, "column": 2}

# Column 1 (Leaf 39 Col 3 - 19 dogs)
c1_dogs = [
    {
        "name": "ADDY", "sex": "Female", "registration_number": "691749",
        "birth_date": "Jan. 26, 1928", "color": "Blk & tn",
        "owner": "T. Higbee Embry", "owner_location": None,
        "breeder": "Sofie Frolich", "breeder_location": "Cincinnati, O.",
        "sire": "Cito v d Margaretanau", "sire_registration_number": "685406",
        "dam": "Angola Margaretanau", "dam_registration_number": "685402",
        "source": meta_c1
    },
    {
        "name": "AMITZI V TORREZ", "sex": "Female", "registration_number": "692409",
        "birth_date": "Feb. 22, 1929", "color": "Blk & tn",
        "owner": "William A. Melody", "owner_location": None,
        "breeder": "Ernest C. Torrez", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Burga v Torrez", "dam_registration_number": "628206",
        "source": meta_c1
    },
    {
        "name": "ANDREE V TORREZ", "sex": "Female", "registration_number": "692408",
        "birth_date": "Feb. 22, 1929", "color": "Blk & tn",
        "owner": "F. E. Oswald", "owner_location": None,
        "breeder": "Ernest C. Torrez", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Burga v Torrez", "dam_registration_number": "628206",
        "source": meta_c1
    },
    {
        "name": "ARIEL V TORREZ", "sex": "Female", "registration_number": "692407",
        "birth_date": "Feb. 22, 1929", "color": "Blk & tn",
        "owner": "Mr. and Mrs. E. A. Courtney", "owner_location": None,
        "breeder": "Ernest C. Torrez", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Burga v Torrez", "dam_registration_number": "628206",
        "source": meta_c1
    },
    {
        "name": "ARI OF KETTLE COVE", "sex": "Male", "registration_number": "690590",
        "birth_date": "Mar. 25, 1928", "color": "Blk & rd",
        "owner": "Kettle Cove Kennels", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Anita v Goldgrund", "dam_registration_number": "454887",
        "source": meta_c1
    },
    {
        "name": "ARNO V EDJO", "sex": "Male", "registration_number": "689776",
        "birth_date": "Nov. 23, 1925", "color": "Blk & tn",
        "owner": "John Ninger", "owner_location": None,
        "breeder": "Joseph C. Blauner", "breeder_location": "Towaco, N. J.",
        "sire": "Apollo v Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Esther v Burgfried", "dam_registration_number": "453438",
        "source": meta_c1
    },
    {
        "name": "ASTA V TORREZ", "sex": "Female", "registration_number": "692410",
        "birth_date": "Feb. 22, 1929", "color": "Blk & tn",
        "owner": "Robert S. Ghiselin", "owner_location": None,
        "breeder": "Ernest C. Torrez", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Burga v Torrez", "dam_registration_number": "628206",
        "source": meta_c1
    },
    {
        "name": "BALDO V SPREE", "sex": "Male", "registration_number": "690953",
        "birth_date": None, "color": "Blk & tn",
        "owner": "Edw. S. Smith", "owner_location": None,
        "breeder": "Edward Rose", "breeder_location": "Queens Village, L. I., N. Y.",
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Mona Dora Zoic", "dam_registration_number": "412715",
        "source": meta_c1
    },
    {
        "name": "BEAU", "sex": "Male", "registration_number": "692517",
        "birth_date": "Aug. 23, 1928", "color": "Blk & mhgy",
        "owner": "Mary B. Hamill", "owner_location": None,
        "breeder": "Charles King", "breeder_location": "Baltimore, Md.",
        "sire": "Beowulf v Siegestor", "sire_registration_number": "525331",
        "dam": "Reta v Siegestor", "dam_registration_number": "570743",
        "source": meta_c1
    },
    {
        "name": "BLITZEN V WELDEKE", "sex": "Male", "registration_number": "690830",
        "birth_date": "Feb. 20, 1929", "color": "Blk & tn",
        "owner": "Mrs. Bert Nicolls", "owner_location": None,
        "breeder": "Helene O. Bernard", "breeder_location": "Brookline, Mass.",
        "sire": "Edelblut of Westphalia", "sire_registration_number": "535468",
        "dam": "Hexie's Marga", "dam_registration_number": "535613",
        "source": meta_c1
    },
    {
        "name": "CHICHITA", "sex": "Female", "registration_number": "691855",
        "birth_date": "Aug. 6, 1928", "color": "Blk & tn",
        "owner": "Oscar Gardner", "owner_location": None,
        "breeder": "Emil Pfieffer", "breeder_location": "Woodside, L. I., N. Y.",
        "sire": "Cy of Syosset", "sire_registration_number": "558079",
        "dam": "Jill Jonedith", "dam_registration_number": "595853",
        "source": meta_c1
    },
    {
        "name": "CHICO V SIGALSBURG", "sex": "Male", "registration_number": "691032",
        "birth_date": "Sept. 15, 1928", "color": "Blk & rd",
        "owner": "Doris Phillips", "owner_location": None,
        "breeder": "F. C. Bowles", "breeder_location": "Hartville, O.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Rena v Starkanhart", "dam_registration_number": "607477",
        "source": meta_c1
    },
    {
        "name": "DEA V SCHUETZENECK", "sex": "Female", "registration_number": "690954",
        "birth_date": "Aug. 19, 1926", "color": "Blk & dk tn",
        "owner": "Edw. S. Smith", "owner_location": None,
        "breeder": "Harry Bauman", "breeder_location": "Philadelphia, Pa.",
        "sire": "Apollo v d Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Anny v Hohenbaden", "dam_registration_number": "551333",
        "source": meta_c1
    },
    {
        "name": "DOMBACHTAL'S BIG BOY", "sex": "Male", "registration_number": "690228",
        "birth_date": "Oct. 29, 1928", "color": "Blk & tn",
        "owner": "Robert E. Lewis", "owner_location": None,
        "breeder": "Mrs. R. E. Byrd", "breeder_location": "Erie, Pa.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Donna v Dombachtal", "dam_registration_number": "653113",
        "source": meta_c1
    },
    {
        "name": "EARNEST", "sex": "Male", "registration_number": "692965",
        "birth_date": "Jan. 26, 1928", "color": "Blk & rd, tn",
        "owner": "Elmer McCab", "owner_location": None,
        "breeder": "Sofie Frolich", "breeder_location": "Cincinnati, O.",
        "sire": "Cito v d Margaretanau", "sire_registration_number": "685406",
        "dam": "Angola v d Margaretanau", "dam_registration_number": "685402",
        "source": meta_c1
    },
    {
        "name": "ELISA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "692455",
        "birth_date": "July 18, 1928", "color": "Blk, rust mkgs",
        "owner": "E. R. Silkworth", "owner_location": None,
        "breeder": "William O. McClane", "breeder_location": "Chicago, Ill.",
        "sire": "Lux v Blankenburg", "sire_registration_number": "571492",
        "dam": "Flora v d Butersburg of Ardwin", "dam_registration_number": "499562",
        "source": meta_c1
    },
    {
        "name": "ELLIE OF EDJO", "sex": "Female", "registration_number": "689594",
        "birth_date": "Nov. 20, 1925", "color": "Rd & tn",
        "owner": "Mrs. Joseph C. Blauner", "owner_location": "Towaco, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Apollo v Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Esther v Burgfried", "dam_registration_number": "453438",
        "source": meta_c1
    },
    {
        "name": "ELLISA V NUREMBERG", "sex": "Female", "registration_number": "692976",
        "birth_date": "Mar. 8, 1928", "color": "Blk & tn",
        "owner": "Donald C. Philipp", "owner_location": None,
        "breeder": "Otto Benke", "breeder_location": "Wichita, Kans.",
        "sire": "Westphalia Dyno v Wiesengrund", "sire_registration_number": "365520",
        "dam": "Nuja v Streslau", "dam_registration_number": "586735",
        "source": meta_c1
    },
    {
        "name": "FIDGETY", "sex": "Female", "registration_number": "691489",
        "birth_date": "Sept. 20, 1926", "color": "Blk & tn",
        "owner": "Robert E. Ellis", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Maina Fra Duncan", "dam_registration_number": "562196",
        "source": meta_c1
    }
]

# Column 2 (Leaf 40 Col 1 - 23 dogs)
c2_dogs = [
    {
        "name": "FLAVIA OF WESTPHALIA", "sex": "Female", "registration_number": "692324",
        "birth_date": "July 11, 1926", "color": "Br & tn",
        "owner": "Mrs. M. von Hoegen", "owner_location": None,
        "breeder": "Westphalia Kennels", "breeder_location": "N. Y. City",
        "sire": "Benno v Roemerhof", "sire_registration_number": "517073",
        "dam": "Alma v Wurmannsberg", "dam_registration_number": "368216",
        "source": meta_c2
    },
    {
        "name": "FRITZWILLIAM V WALSEHULL", "sex": "Male", "registration_number": "692705",
        "birth_date": "Oct. 4, 1927", "color": "Rd & tn",
        "owner": "W. E. Schulier", "owner_location": None,
        "breeder": "Fred M. Berger", "breeder_location": "Chicago, Ill.",
        "sire": "Akrobat v Goetterfelsen", "sire_registration_number": "522604",
        "dam": "Freya v Bergerhof", "dam_registration_number": "578494",
        "source": meta_c2
    },
    {
        "name": "GENIUS DE FONTE CAMPO", "sex": "Male", "registration_number": "689357",
        "birth_date": "Apr. 17, 1927", "color": "Blk & tn",
        "owner": "Anton M. Jaschke", "owner_location": "Springfield, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Freya v Claranton", "dam_registration_number": "476260",
        "source": meta_c2
    },
    {
        "name": "GIEF V PHALZERLAND", "sex": "Male", "registration_number": "691509",
        "birth_date": "Nov. 19, 1925", "color": "Blk & tn",
        "owner": "Andrew G. Gast", "owner_location": None,
        "breeder": "Clifford W. Lane", "breeder_location": "Foxboro, Mass.",
        "sire": "Kurt v Phalzerland", "sire_registration_number": "472066",
        "dam": "Kamerun Bongula", "dam_registration_number": "404913",
        "source": meta_c2
    },
    {
        "name": "JADE II", "sex": "Female", "registration_number": "692699",
        "birth_date": "July 8, 1928", "color": "Blk & tn",
        "owner": "Claude A. Clark", "owner_location": None,
        "breeder": "Henrietta V. Breckenridge", "breeder_location": "Rochester, N. Y.",
        "sire": "Ludwig v Stolzenfels", "sire_registration_number": "650786",
        "dam": "Mina v Stolzenfels", "dam_registration_number": "648548",
        "source": meta_c2
    },
    {
        "name": "JUNE V WILHELM", "sex": "Female", "registration_number": "692093",
        "birth_date": "June 24, 1927", "color": "Blk & tn",
        "owner": "Wm. Temple Pratt", "owner_location": None,
        "breeder": "A. C. Wilhelm", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Burga v Scharflueck", "dam_registration_number": "434189",
        "source": meta_c2
    },
    {
        "name": "KIVI V D DILLBORN", "sex": "Male", "registration_number": "688987",
        "birth_date": "Mar. 10, 1929", "color": "Blk & tn",
        "owner": "A. W. H. Lenders", "owner_location": None,
        "breeder": "K. A. McMasters", "breeder_location": "Hartford, Wis.",
        "sire": "Rowdy v d Koningstadt", "sire_registration_number": "634465",
        "dam": "Irma v d Eckardtsburg", "dam_registration_number": "438105",
        "source": meta_c2
    },
    {
        "name": "LEO V D HOHEN", "sex": "Male", "registration_number": "689279",
        "birth_date": "Sept. 21, 1928", "color": "Rd & tn",
        "owner": "Ruth von Hoegen", "owner_location": None,
        "breeder": "Mrs. M. von Hoegen", "breeder_location": "Towaco, N. J.",
        "sire": "Max De Haven", "sire_registration_number": "604075",
        "dam": "Coryl v Avonthal", "dam_registration_number": "506373",
        "source": meta_c2
    },
    {
        "name": "MAJOR OF GRAUTTENBAR", "sex": "Male", "registration_number": "691329",
        "birth_date": "May 30, 1928", "color": "Blk & tn",
        "owner": "Harry Lowenstein", "owner_location": None,
        "breeder": "Mrs. W. R. Judson", "breeder_location": "Ferndale, Mich.",
        "sire": "Prince Eitel of Rhinegold", "sire_registration_number": "614471",
        "dam": "Judy of Rhinegold", "dam_registration_number": "556001",
        "source": meta_c2
    },
    {
        "name": "MIA V HOMEHILL", "sex": "Female", "registration_number": "692097",
        "birth_date": "Nov. 11, 1927", "color": "Blk, br mkgs",
        "owner": "Mrs. A. M. Shafer", "owner_location": None,
        "breeder": "Mrs. G. A. Rentschler", "breeder_location": "Hamilton, O.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Lady v Homehill", "dam_registration_number": "565329",
        "source": meta_c2
    },
    {
        "name": "MITZIE V STROSSEN", "sex": "Female", "registration_number": "692700",
        "birth_date": "Dec. 15, 1928", "color": "Blk & tn",
        "owner": "Anna Harris Biossat", "owner_location": None,
        "breeder": "Bart Delacourt", "breeder_location": "Los Angeles, Cal.",
        "sire": "Max v Strossen", "sire_registration_number": "509139",
        "dam": "Betty vom Hohenzollernpark", "dam_registration_number": "674822",
        "source": meta_c2
    },
    {
        "name": "MITZI V WINDSTURM", "sex": "Female", "registration_number": "692838",
        "birth_date": "Aug. 28, 1928", "color": "Blk & tn",
        "owner": "Chas. F. Arnold", "owner_location": None,
        "breeder": "Karl P's Graeuwen", "breeder_location": "Brooklyn, N. Y.",
        "sire": "Fritz v Edjo", "sire_registration_number": "605709",
        "dam": "Maus v Sedrevla", "dam_registration_number": "671985",
        "source": meta_c2
    },
    {
        "name": "ORTH'S ZEPPY", "sex": "Male", "registration_number": "691695",
        "birth_date": "Sept. 7, 1928", "color": "Blk & tn",
        "owner": "Wm. F. Orth", "owner_location": None,
        "breeder": "Mrs. Elmer Schweninger", "breeder_location": "Cincinnati, O.",
        "sire": "Boone v Sigalsburg", "sire_registration_number": "658766",
        "dam": "Hamer's Peggy", "dam_registration_number": "587825",
        "source": meta_c2
    },
    {
        "name": "PAULI OF PONTCHARTRAIN", "sex": "Male", "registration_number": "690230",
        "birth_date": "Sept. 21, 1928", "color": "Blk & rd",
        "owner": "A. E. Wilson", "owner_location": None,
        "breeder": "Frank B. Tanner", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Lita v Burgholz", "dam_registration_number": "671060",
        "source": meta_c2
    },
    {
        "name": "PINKERTON PIXIE", "sex": "Female", "registration_number": "692398",
        "birth_date": "Aug. 4, 1928", "color": "Rd & tn",
        "owner": "Milton J. Waas", "owner_location": "Philadelphia, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Pinkerton Reds", "sire_registration_number": "650037",
        "dam": "Pinkerton Patsy", "dam_registration_number": "658357",
        "source": meta_c2
    },
    {
        "name": "QUEEN FREY", "sex": "Female", "registration_number": "689354",
        "birth_date": "Apr. 17, 1927", "color": "Blk & tn",
        "owner": "Frank Frey", "owner_location": None,
        "breeder": "Anton M. Jaschke", "breeder_location": "Springfield, Ill.",
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Freya v Claranton", "dam_registration_number": "476260",
        "source": meta_c2
    },
    {
        "name": "REDA BOLIN", "sex": "Female", "registration_number": "691283",
        "birth_date": "Dec. 20, 1927", "color": "Blk & tn",
        "owner": "Henry Bolin", "owner_location": "Columbus, O.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Toby", "sire_registration_number": "491065",
        "dam": "Hilda Hoyler", "dam_registration_number": "495893",
        "source": meta_c2
    },
    {
        "name": "RORY", "sex": "Male", "registration_number": "691696",
        "birth_date": "Jan. 22, 1929", "color": "Blk & tn",
        "owner": "E. J. Murphy", "owner_location": None,
        "breeder": "Geo. M. Henderson", "breeder_location": "Huntington, W. Va.",
        "sire": "Claus v d Spree Junior", "sire_registration_number": "512026",
        "dam": "Brunhilde of Bornholm", "dam_registration_number": "592815",
        "source": meta_c2
    },
    {
        "name": "SCHATZE V HORSTBURG", "sex": "Female", "registration_number": "689932",
        "birth_date": "Dec. 22, 1927", "color": "Br & rust rd mkgs",
        "owner": "Helen Krecker", "owner_location": None,
        "breeder": "John Schofield", "breeder_location": "Elverson, Pa.",
        "sire": "Trail'em Horstburg", "sire_registration_number": "545469",
        "dam": "Countess v Burgholz", "dam_registration_number": "449862",
        "source": meta_c2
    },
    {
        "name": "SEPP V MARKGRAFENBERG", "sex": "Male", "registration_number": "692222",
        "birth_date": "Jan. 4, 1925", "color": "Blk & rd",
        "owner": "F. G. Haeussermann", "owner_location": None,
        "breeder": "Wilh. Peter", "breeder_location": "Germany",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Adda v d Blankenburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Artus v Langerode", "registration_number": None},
            {"role": "dam_of_dam", "name": "Asta Voss", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Senta v Jagerheim", "registration_number": None},
            {"role": "sire_of_sire", "name": "Artus v Langerode", "registration_number": None},
            {"role": "dam_of_sire", "name": "Prinz Leuthold v Hornegg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Asta v Starkenburg", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "SHAROD OF PONTCHARTRAIN", "sex": "Male", "registration_number": "688859",
        "birth_date": "Aug. 29, 1928", "color": "Blk & rd",
        "owner": "Mrs. J. A. Winn", "owner_location": None,
        "breeder": "G. A. Gorham", "breeder_location": "Royal Oak, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Fraulein of Pontchartrain", "dam_registration_number": "681073",
        "source": meta_c2
    },
    {
        "name": "SOPHIE OF PONTCHARTRAIN", "sex": "Female", "registration_number": "688858",
        "birth_date": "Aug. 29, 1928", "color": "Bl & rd",
        "owner": "Paul Fuchnerowski", "owner_location": None,
        "breeder": "G. A. Gorham", "breeder_location": "Royal Oaks, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Fraulein of Pontchartrain", "dam_registration_number": "681073",
        "source": meta_c2
    },
    {
        "name": "TOKON V STARKANHART", "sex": "Male", "registration_number": "690690",
        "birth_date": "Nov. 11, 1928", "color": "Blk & tn",
        "owner": "Carol Atlee Keller", "owner_location": None,
        "breeder": "F. C. Bowles", "breeder_location": "Hartville, O.",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Tisch v Bornholm", "dam_registration_number": "401095",
        "source": meta_c2
    }
]

# Column 3 (Leaf 40 Col 2 - 2 dogs ending before POINTERS)
c3_dogs = [
    {
        "name": "TROLL V D STERNALLEE", "sex": "Male", "registration_number": "688872",
        "birth_date": "Aug. 4, 1928", "color": "Blk & tn",
        "owner": "Mamie C. G. Horne", "owner_location": None,
        "breeder": "W. D. King", "breeder_location": "Bridgeport, O.",
        "sire": "Hans v d Sternallee", "sire_registration_number": "349691",
        "dam": "Senta v Lueschenhof", "dam_registration_number": "633072",
        "source": meta_c3
    },
    {
        "name": "YVON OF EDJO", "sex": "Male", "registration_number": "689593",
        "birth_date": "Aug. 5, 1927", "color": "Rd & tn",
        "owner": "Joseph C. Blauner", "owner_location": "Towaco, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Benno v Romerhof", "sire_registration_number": "517073",
        "dam": "Esther v Burgfried", "dam_registration_number": "453438",
        "source": meta_c3
    }
]

all_44 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1929-07 dogs: {len(all_44)} (Expected: 44)")
print(f"Col 1: {len(c1_dogs)} (Expected: 19)")
print(f"Col 2: {len(c2_dogs)} (Expected: 23)")
print(f"Col 3: {len(c3_dogs)} (Expected: 2)")

Path("stud-scrape/data/verified_1929_07.json").write_text(json.dumps(all_44, indent=2), encoding="utf-8")
print("Saved clean 1929-07 records to stud-scrape/data/verified_1929_07.json")
