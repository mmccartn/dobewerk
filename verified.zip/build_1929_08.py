import json
from pathlib import Path

meta_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-08-01_46_8", "date": "1929-08-01", "volume": "46", "issue": "8", "leaf": 39, "column": 1}
meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-08-01_46_8", "date": "1929-08-01", "volume": "46", "issue": "8", "leaf": 39, "column": 2}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-08-01_46_8", "date": "1929-08-01", "volume": "46", "issue": "8", "leaf": 39, "column": 3}
meta_c4 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-08-01_46_8", "date": "1929-08-01", "volume": "46", "issue": "8", "leaf": 40, "column": 1}

# Column 1 (Leaf 39 Col 1 - 13 dogs)
c1_dogs = [
    {
        "name": "ADOLPH V KUCK", "sex": "Male", "registration_number": "693236",
        "birth_date": "May 19, 1925", "color": "Blk & tn",
        "owner": "F. R. Sherbourne", "owner_location": None,
        "breeder": "A. Werner", "breeder_location": "Sacramento, Cal.",
        "sire": "Alex v Seehagen", "sire_registration_number": "452589",
        "dam": "Flanda v d Spree", "dam_registration_number": "404484",
        "source": meta_c1
    },
    {
        "name": "ANGOLA OF WHITE GATE", "sex": "Female", "registration_number": "695418",
        "birth_date": "Apr. 29, 1929", "color": "Br & tn",
        "owner": "White Gate Kennels", "owner_location": "Willow Grove, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Bacchante of White Gate", "dam_registration_number": "572873",
        "source": meta_c1
    },
    {
        "name": "ARNO V TORREZ", "sex": "Male", "registration_number": "695756",
        "birth_date": "Feb. 22, 1929", "color": "Blk & tn",
        "owner": "Paul B. Wallace", "owner_location": None,
        "breeder": "Ernest C. Torrez", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Burga v Torrez", "dam_registration_number": "628206",
        "source": meta_c1
    },
    {
        "name": "BARON BUDDY", "sex": "Male", "registration_number": "696746",
        "birth_date": "Nov. 13, 1928", "color": "Blk & rust br",
        "owner": "Daniel H. Thompson", "owner_location": None,
        "breeder": "Edwin C. Philbrook", "breeder_location": "Rockland, Me.",
        "sire": "Timidity Brrrp", "sire_registration_number": "614624",
        "dam": "Gretel v Belger", "dam_registration_number": "539977",
        "source": meta_c1
    },
    {
        "name": "BELLA V SIGALSBURG", "sex": "Female", "registration_number": "694844",
        "birth_date": "Aug. 2, 1928", "color": "Blk & tn",
        "owner": "P. L. Matson", "owner_location": None,
        "breeder": "S. E. Ochsner", "breeder_location": "Milwaukee, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Delsa v Blankenburg", "dam_registration_number": "532772",
        "source": meta_c1
    },
    {
        "name": "BITTE", "sex": "Female", "registration_number": "693898",
        "birth_date": "Sept. 8, 1928", "color": "Blk & tn",
        "owner": "James A. Humphrys", "owner_location": None,
        "breeder": "Dr. and Mrs. R. D. Coneley", "breeder_location": "Lima, Pa.",
        "sire": "Riff Rudolph v Horstburg", "sire_registration_number": "665178",
        "dam": "Green Gable's Ponjola", "dam_registration_number": "577213",
        "source": meta_c1
    },
    {
        "name": "BLITZ OF TOPPO", "sex": "Male", "registration_number": "695634",
        "birth_date": "Jan. 21, 1929", "color": "Blk & tn",
        "owner": "Mrs. H. J. Sniffen", "owner_location": None,
        "breeder": "Dorothy Bolce", "breeder_location": "Cincinnati, O.",
        "sire": "Toppo v Sigalsburg", "sire_registration_number": "670191",
        "dam": "Gretel v Horstburg", "dam_registration_number": "670190",
        "source": meta_c1
    },
    {
        "name": "BORIS DU' FREYOL", "sex": "Male", "registration_number": "694845",
        "birth_date": "Nov. 6, 1928", "color": "Blk & rd",
        "owner": "Jose Guerrero", "owner_location": None,
        "breeder": "R. A. Freyol", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Nutall's Beauty", "dam_registration_number": "608304",
        "source": meta_c1
    },
    {
        "name": "CARLO OF LANDVEHR", "sex": "Male", "registration_number": "694696",
        "birth_date": "Nov. 13, 1928", "color": "Blk, tn pts",
        "owner": "Edward C. Rose", "owner_location": None,
        "breeder": "W. G. Sloan", "breeder_location": "Princeton, N. J.",
        "sire": "Sonny", "sire_registration_number": "563477",
        "dam": "Lady III", "dam_registration_number": "694693",
        "source": meta_c1
    },
    {
        "name": "CARLOTTA OF LANDVEHR", "sex": "Female", "registration_number": "694697",
        "birth_date": "Nov. 13, 1928", "color": "Blk, tn pts",
        "owner": "Edward C. Rose", "owner_location": None,
        "breeder": "W. G. Sloan", "breeder_location": "Princeton, N. J.",
        "sire": "Sonny", "sire_registration_number": "563477",
        "dam": "Lady III", "dam_registration_number": "694693",
        "source": meta_c1
    },
    {
        "name": "CLAUSINA OF ARKEDEN", "sex": "Female", "registration_number": "695924",
        "birth_date": "Oct. 20, 1925", "color": "Blk & tn",
        "owner": "Marion Kreischer", "owner_location": "Lynbrook, L. I., N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Princess Adele Of Arkeden", "dam_registration_number": "469751",
        "source": meta_c1
    },
    {
        "name": "CLEO OF ARKEDEN", "sex": "Female", "registration_number": "695930",
        "birth_date": "Oct. 20, 1925", "color": "Blk & tn",
        "owner": "Marion Kreischer", "owner_location": "Lynbrook, L. I., N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Princess Adele of Arkeden", "dam_registration_number": "469751",
        "source": meta_c1
    },
    {
        "name": "CONEY V TELLESS", "sex": "Male", "registration_number": "694435",
        "birth_date": "June 10, 1927", "color": "Blk & tn",
        "owner": "Mabel W. Murphy", "owner_location": None,
        "breeder": "Edith Patnaude", "breeder_location": "Malden, Mass.",
        "sire": "Zoic Edel v Sporthof", "sire_registration_number": "409773",
        "dam": "Agnes v Peveling", "dam_registration_number": "516991",
        "source": meta_c1
    }
]

# Column 2 (Leaf 39 Col 2 - 21 dogs)
c2_dogs = [
    {
        "name": "CUNO", "sex": "Male", "registration_number": "693200",
        "birth_date": "May 24, 1928", "color": "Blk & tn",
        "owner": "Lillian A. Chapman", "owner_location": None,
        "breeder": "Chester A. Ellis", "breeder_location": "Pottstown, Pa.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Rowdy Allie of Pottstown", "dam_registration_number": "615095",
        "source": meta_c2
    },
    {
        "name": "EDELBLUT OF WHITE GATE", "sex": "Male", "registration_number": "695415",
        "birth_date": "Apr. 29, 1929", "color": "Br & tn",
        "owner": "White Gate Kennels", "owner_location": "Willow Grove, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Bacchante of White Gate", "dam_registration_number": "572873",
        "source": meta_c2
    },
    {
        "name": "EDMUND OF ARKEDEN", "sex": "Male", "registration_number": "695929",
        "birth_date": "Aug. 19, 1926", "color": "Blk & tn",
        "owner": "Teresa Landgraf", "owner_location": None,
        "breeder": "Arkeden Kennels", "breeder_location": "Lynbrook, L. I., N. Y.",
        "sire": "Benno v Roemerhof", "sire_registration_number": "517073",
        "dam": "Gisela v Sporthof", "dam_registration_number": "521400",
        "source": meta_c2
    },
    {
        "name": "EGIA OF ARKEDEN", "sex": "Female", "registration_number": "695925",
        "birth_date": "Aug. 19, 1926", "color": "Br & tn",
        "owner": "Marion Kreischer", "owner_location": "Lynbrook, L. I., N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Benno v Roemerhof", "sire_registration_number": "517073",
        "dam": "Gisela v Sporthof", "dam_registration_number": "521400",
        "source": meta_c2
    },
    {
        "name": "EHRINE V TIMMENAL", "sex": "Female", "registration_number": "693119",
        "birth_date": "Mar. 15, 1928", "color": "Blk & rust",
        "owner": "T. J. Maloney", "owner_location": None,
        "breeder": "Herman G. Ebling", "breeder_location": "Batavia, N. Y.",
        "sire": "Cyrus v d Rehhutte", "sire_registration_number": "636115",
        "dam": "Armista", "dam_registration_number": "610884",
        "source": meta_c2
    },
    {
        "name": "ELFRIEDA OF WHITE GATE", "sex": "Female", "registration_number": "695417",
        "birth_date": "Apr. 29, 1929", "color": "Br & tn",
        "owner": "White Gate Kennels", "owner_location": "Willow Grove, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Bacchante of White Gate", "dam_registration_number": "572873",
        "source": meta_c2
    },
    {
        "name": "ERIC V TILHAGEN", "sex": "Male", "registration_number": "694285",
        "birth_date": "Nov. 2, 1925", "color": "Blk & mhgy",
        "owner": "Wm. Fraley McCafferty", "owner_location": None,
        "breeder": "David C. Dodge", "breeder_location": "Denver, Colo.",
        "sire": "Barry v Seehagen", "sire_registration_number": "463068",
        "dam": "Tilly v Melrapp", "dam_registration_number": "462651",
        "source": meta_c2
    },
    {
        "name": "FATIMA OF ARKEDEN", "sex": "Female", "registration_number": "695926",
        "birth_date": "June 10, 1928", "color": "Blk & tn",
        "owner": "Teresa Landgraf", "owner_location": "Lynbrook, L. I., N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Senena of Arkeden", "dam_registration_number": "573816",
        "source": meta_c2
    },
    {
        "name": "FAY V SEDREVLA", "sex": "Female", "registration_number": "695049",
        "birth_date": "Aug. 28, 1928", "color": "Blk & tn",
        "owner": "Karl P. S. Graeuwen", "owner_location": "Annadale, S. I., N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Fritz v Edjo", "sire_registration_number": "605709",
        "dam": "Maus v Sedrevla", "dam_registration_number": "671985",
        "source": meta_c2
    },
    {
        "name": "FEDOR OF WHITE GATE", "sex": "Male", "registration_number": "695414",
        "birth_date": "Apr. 29, 1929", "color": "Blk & tn",
        "owner": "White Gate Kennels", "owner_location": "Willow Grove, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Bacchante of White Gate", "dam_registration_number": "572873",
        "source": meta_c2
    },
    {
        "name": "FLORNELL OF ARKEDEN", "sex": "Female", "registration_number": "695928",
        "birth_date": "June 10, 1928", "color": "Blk & tn",
        "owner": "Teresa Landgraf", "owner_location": "Lynbrook, L. I., N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Senena of Arkeden", "dam_registration_number": "573816",
        "source": meta_c2
    },
    {
        "name": "FRAULEIN GRETCHEN OF BIL KAY", "sex": "Female", "registration_number": "694452",
        "birth_date": "Feb. 15, 1928", "color": "Blk & tn",
        "owner": "Mr. and Mrs. Wm. H. Duffy", "owner_location": None,
        "breeder": "Wm. H. Duffy", "breeder_location": "Northfield, N. J.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Hildegarde v Doernbach", "dam_registration_number": "661249",
        "source": meta_c2
    },
    {
        "name": "FRIEDA V NEVERSINK", "sex": "Female", "registration_number": "696872",
        "birth_date": "May 24, 1928", "color": "Blk & tn",
        "owner": "Geo. W. Carr and S. E. Wright", "owner_location": None,
        "breeder": "Chester A. Ellis", "breeder_location": "Pottstown, Pa.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Rowdy Allie of Pottstown", "dam_registration_number": "615095",
        "source": meta_c2
    },
    {
        "name": "FRIEDA V D SPREE", "sex": "Female", "registration_number": "693593",
        "birth_date": "Mar. 26, 1928", "color": "Blk & tn",
        "owner": "Eleanor Pratt", "owner_location": None,
        "breeder": "W. Goins", "breeder_location": "East Vaughn, N. M.",
        "sire": "Burschel v d Spree", "sire_registration_number": "487194",
        "dam": "Maina Fra Duncan", "dam_registration_number": "562196",
        "source": meta_c2
    },
    {
        "name": "FRITZIE", "sex": "Male", "registration_number": "697058",
        "birth_date": "Apr. 11, 1929", "color": "Blk & tn",
        "owner": "H. O'Barmen", "owner_location": None,
        "breeder": "Robert E. Ellis", "breeder_location": "San Angelo, Tex.",
        "sire": "Arno v Burgfried", "sire_registration_number": "426603",
        "dam": "Fidgety", "dam_registration_number": "691489",
        "source": meta_c2
    },
    {
        "name": "FRITZ OF WHITE GATE", "sex": "Male", "registration_number": "695413",
        "birth_date": "Apr. 29, 1929", "color": "Blk & tn",
        "owner": "White Gate Kennels", "owner_location": "Willow Grove, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Bacchante of White Gate", "dam_registration_number": "572873",
        "source": meta_c2
    },
    {
        "name": "FROLIC OF ARKEDEN", "sex": "Female", "registration_number": "695927",
        "birth_date": "June 10, 1928", "color": "Blk & tn",
        "owner": "Teresa Landgraf", "owner_location": "Lynbrook, L. I., N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Senena of Arkeden", "dam_registration_number": "573816",
        "source": meta_c2
    },
    {
        "name": "GILDA V D BLANKENBRINK", "sex": "Female", "registration_number": "696806",
        "birth_date": "Mar. 24, 1929", "color": "Blk & rd",
        "owner": "Geo. H. Jones", "owner_location": None,
        "breeder": "Edward A. Hunter", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Marko v Siegerpark", "sire_registration_number": "601008",
        "dam": "Citti v Wilbrink", "dam_registration_number": "601009",
        "source": meta_c2
    },
    {
        "name": "HANSEL V SCHWARZWALD", "sex": "Male", "registration_number": "694224",
        "birth_date": "Jan. 15, 1928", "color": "Blk & tn",
        "owner": "C. S. Moll", "owner_location": None,
        "breeder": "Philip Gruber", "breeder_location": "Chicago, Ill.",
        "sire": "Iwo v Park", "sire_registration_number": "674878",
        "dam": "Thea v Hoffeld", "dam_registration_number": "633804",
        "source": meta_c2
    },
    {
        "name": "HASSO V SIGALSBURG RHINEGOLD", "sex": "Male", "registration_number": "695158",
        "birth_date": "June 1, 1927", "color": "Blk & br",
        "owner": "J. C. Zimmerman", "owner_location": None,
        "breeder": "O. I. Sigal", "breeder_location": "Germany",
        "sire": "Alto v Sigalsburg", "sire_registration_number": None,
        "dam": "Elfe v d Volkerruhe", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Amor v Gotterfelsen", "registration_number": None},
            {"role": "dam_of_dam", "name": "Zara v Friedewald", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Max v Isenburg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Amor v Gotterfelsen", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Asta v d Volkerruhe", "registration_number": None},
            {"role": "sire_of_sire", "name": "Lux v d Blankenburg", "registration_number": "571492"},
            {"role": "dam_of_sire", "name": "Melitta v Parthengrund", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Dora v Wiesengrund", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "JEAN OF SLOAN", "sex": "Male", "registration_number": "694694",
        "birth_date": "Nov. 13, 1928", "color": "Blk, tn pts",
        "owner": "W. G. Sloan", "owner_location": "Princeton, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Sonny", "sire_registration_number": "563477",
        "dam": "Lady III", "dam_registration_number": "694693",
        "source": meta_c2
    }
]

# Column 3 (Leaf 39 Col 3 - 21 dogs)
c3_dogs = [
    {
        "name": "JENNIE OF SLOAN", "sex": "Female", "registration_number": "694695",
        "birth_date": "Nov. 13, 1928", "color": "Blk, tn pts",
        "owner": "W. G. Sloan", "owner_location": "Princeton, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Sonny", "sire_registration_number": "563477",
        "dam": "Lady III", "dam_registration_number": "694693",
        "source": meta_c3
    },
    {
        "name": "LADY III", "sex": "Female", "registration_number": "694693",
        "birth_date": "Dec. 13, 1926", "color": "Blk & tn",
        "owner": "W. G. Sloan", "owner_location": None,
        "breeder": "Emil Hofmann", "breeder_location": "Colts Neck, N. J.",
        "sire": "Carlo v Musenbach", "sire_registration_number": "561755",
        "dam": "Anni v Neudeck", "dam_registration_number": "649801",
        "source": meta_c3
    },
    {
        "name": "LADY SYBIL V D SCHWANENHOHE", "sex": "Female", "registration_number": "696168",
        "birth_date": "May 19, 1927", "color": "Br, tn mkgs",
        "owner": "John W. Young", "owner_location": None,
        "breeder": "Wm. Kummer", "breeder_location": "Detroit, Mich.",
        "sire": "Carlo v d Schwanenhohe", "sire_registration_number": "567146",
        "dam": "Fee v d Spree", "dam_registration_number": "586736",
        "source": meta_c3
    },
    {
        "name": "LOTTE V BERGHOFEN", "sex": "Female", "registration_number": "695157",
        "birth_date": "May 18, 1928", "color": "Blk & br",
        "owner": "G. G. Amory", "owner_location": None,
        "breeder": "Leopold Roth", "breeder_location": "Germany",
        "sire": "Gerd v Sporthof", "sire_registration_number": None,
        "dam": "Duna v Rheineck", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Lux v d Blankenburg", "registration_number": "571492"},
            {"role": "dam_of_dam", "name": "Asta v Reichenstein", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Prinz Bodo v Hornsheim", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Asta v Friedrichstatd", "registration_number": None},
            {"role": "sire_of_sire", "name": "Klaus v d Spree", "registration_number": None},
            {"role": "dam_of_sire", "name": "Bona v Sevira", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Artus v Langerode", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Bona v Hessen", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Burschel v Simmenau", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Adela v Oststern", "registration_number": None}
        ],
        "source": meta_c3
    },
    {
        "name": "MASTER SIEGFRIED", "sex": "Male", "registration_number": "693238",
        "birth_date": "Jan. 15, 1928", "color": "Br & tn",
        "owner": "Wm. P. Koppe", "owner_location": None,
        "breeder": "Philip Gruber", "breeder_location": "Chicago, Ill.",
        "sire": "Iwo v Park", "sire_registration_number": "674787",
        "dam": "Thea v Hoffeld", "dam_registration_number": "633804",
        "source": meta_c3
    },
    {
        "name": "MINKA V INGENHOVEN", "sex": "Female", "registration_number": "694842",
        "birth_date": "Feb. 7, 1928", "color": "Blk, br mkgs",
        "owner": "Herman Brauckmann", "owner_location": "Los Angeles, Cal.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Carlo v Belger", "sire_registration_number": "533994",
        "dam": "Blanka v Lenburg", "dam_registration_number": "666356",
        "source": meta_c3
    },
    {
        "name": "MITZI III", "sex": "Female", "registration_number": "693237",
        "birth_date": "Jan. 29, 1927", "color": "Blk & tn, wh spt",
        "owner": "Wm. J. O'Connor", "owner_location": None,
        "breeder": "Mrs. R. J. McNabb", "breeder_location": "Chicago, Ill.",
        "sire": "Pedo", "sire_registration_number": "672391",
        "dam": "Asta v Mecklenburg", "dam_registration_number": "406354",
        "source": meta_c3
    },
    {
        "name": "PEOPOCK V DOMBACHTAL", "sex": "Female", "registration_number": "693911",
        "birth_date": "Oct. 29, 1928", "color": "Blk & tn",
        "owner": "Wm. Weltman", "owner_location": None,
        "breeder": "Mrs. R. E. Byrd", "breeder_location": "Erie, Pa.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Donna v Dombachtal", "dam_registration_number": "653113",
        "source": meta_c3
    },
    {
        "name": "PERRY'S BETTY", "sex": "Female", "registration_number": "695504",
        "birth_date": "Dec. 16, 1927", "color": "Blk & tn",
        "owner": "F. C. Fugua", "owner_location": None,
        "breeder": "Perry Kennels", "breeder_location": "Erie, Pa.",
        "sire": "Delf v d Karthaeuserklause", "sire_registration_number": "583005",
        "dam": "Guda v Telless", "dam_registration_number": "319376",
        "source": meta_c3
    },
    {
        "name": "PRIDE OF DAVANNA", "sex": "Female", "registration_number": "696015",
        "birth_date": "Sept. 29, 1927", "color": "Blk & tn",
        "owner": "Anne C. Laughlin", "owner_location": None,
        "breeder": "F. C. Bowles", "breeder_location": "Hartville, O.",
        "sire": "A. Rappo of Pontchartrain", "sire_registration_number": "439031",
        "dam": "Rena v Starkanhart", "dam_registration_number": "607477",
        "source": meta_c3
    },
    {
        "name": "PRINCE FAVORITE OF WHITE GATE", "sex": "Male", "registration_number": "695416",
        "birth_date": "Apr. 29, 1929", "color": "Br & tn",
        "owner": "White Gate Kennels", "owner_location": "Willow Grove, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Bacchante of White Gate", "dam_registration_number": "572873",
        "source": meta_c3
    },
    {
        "name": "PRINCESS DAGMAR OF DENMARK", "sex": "Female", "registration_number": "694126",
        "birth_date": "Oct. 1, 1925", "color": "Blk & tn",
        "owner": "W. J. Rose", "owner_location": None,
        "breeder": "Thyra Klitgaard", "breeder_location": "San Francisco, Cal.",
        "sire": "Osmann", "sire_registration_number": "611285",
        "dam": "Ruth", "dam_registration_number": "566438",
        "source": meta_c3
    },
    {
        "name": "PRINTZ OBERMAYER", "sex": "Male", "registration_number": "694630",
        "birth_date": "Feb. 15, 1928", "color": "Blk & tn",
        "owner": "I. A. Newcomer", "owner_location": None,
        "breeder": "Bert Young", "breeder_location": "Granville, O.",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Asta v Hunstein", "dam_registration_number": "665159",
        "source": meta_c3
    },
    {
        "name": "QUEEN ANN V SCHOICH", "sex": "Female", "registration_number": "696425",
        "birth_date": "Jan. 19, 1929", "color": "Blk & tn",
        "owner": "Paul Roddy", "owner_location": None,
        "breeder": "Pearle M. Wilson", "breeder_location": "Nashville, Tenn.",
        "sire": "Ochsner's Son of Rival", "sire_registration_number": "612378",
        "dam": "Nanette of Jonedith", "dam_registration_number": "549148",
        "source": meta_c3
    },
    {
        "name": "QUITO OF PONTCHARTRAIN", "sex": "Male", "registration_number": "693244",
        "birth_date": "Oct. 9, 1928", "color": "Blk & rd",
        "owner": "Donald Clark", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Leddy of Pontchartrain", "dam_registration_number": "680146",
        "source": meta_c3
    },
    {
        "name": "RITZ V HORSTBURG", "sex": "Male", "registration_number": "695755",
        "birth_date": "Dec. 13, 1927", "color": "Rd & tn",
        "owner": "Edith L. Keirstead", "owner_location": "Groton, Mass.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Ritz-Carlton", "sire_registration_number": "485720",
        "dam": "Fricka v d Nibelungenhort", "dam_registration_number": "577937",
        "source": meta_c3
    },
    {
        "name": "ROBINSON'S ERICK", "sex": "Male", "registration_number": "695757",
        "birth_date": "Jan. 6, 1929", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Mia v Stresow", "dam_registration_number": "559952",
        "source": meta_c3
    },
    {
        "name": "ROBINSON'S MISS ADDIE", "sex": "Female", "registration_number": "695713",
        "birth_date": "Nov. 3, 1928", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dorle v Leipzig", "dam_registration_number": "462575",
        "source": meta_c3
    },
    {
        "name": "ROBINSON'S MISS LOU", "sex": "Female", "registration_number": "695758",
        "birth_date": "Jan. 6, 1929", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Mia v Stresow", "dam_registration_number": "559952",
        "source": meta_c3
    },
    {
        "name": "ROMA V POPP", "sex": "Female", "registration_number": "694843",
        "birth_date": "Mar. 30, 1928", "color": "Blk, rd mkgs",
        "owner": "T. E. Popp", "owner_location": "West Allis, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dortell v Popp", "dam_registration_number": "526001",
        "source": meta_c3
    },
    {
        "name": "SCIO OF MARVINDALE", "sex": "Male", "registration_number": "694966",
        "birth_date": "June 24, 1928", "color": "Blk & tn",
        "owner": "Albert G. Prill", "owner_location": None,
        "breeder": "E. A. Harvey", "breeder_location": "Portland, Ore.",
        "sire": "Max v Steuben", "sire_registration_number": "573145",
        "dam": "Kunigunde II v Stolzenfels", "dam_registration_number": "544196",
        "source": meta_c3
    }
]

# Column 4 (Leaf 40 Col 1 top - 3 dogs ending before POINTERS)
c4_dogs = [
    {
        "name": "TINGO V SIGALSBURG", "sex": "Male", "registration_number": "693489",
        "birth_date": "Aug. 24, 1928", "color": "Blk & tn",
        "owner": "Alexander F. Carson", "owner_location": None,
        "breeder": "Albert E. Farone", "breeder_location": "Oneonta, N. Y.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Rani v Stresow", "dam_registration_number": "561913",
        "source": meta_c4
    },
    {
        "name": "TOTO V HORTSBURG", "sex": "Male", "registration_number": "696927",
        "birth_date": "July 28, 1928", "color": "Blk & tn",
        "owner": "Otto H. Lind", "owner_location": None,
        "breeder": "Sofie Frolich", "breeder_location": "Cincinnati, O.",
        "sire": "Cito v d Margaretanau", "sire_registration_number": "685406",
        "dam": "Angola v d Margaretanau", "dam_registration_number": "685402",
        "source": meta_c4
    },
    {
        "name": "TUSA V BURGFRIED", "sex": "Female", "registration_number": "694682",
        "birth_date": "Dec. 15, 1928", "color": "Br & rd",
        "owner": "Mrs. Wm. Robert Moore, Jr.", "owner_location": None,
        "breeder": "John Ninger", "breeder_location": "Bloomfield, N. J.",
        "sire": "Ego v Allershausen", "sire_registration_number": "525324",
        "dam": "Charlotte v Burgfried", "dam_registration_number": "493051",
        "source": meta_c4
    }
]

all_58 = c1_dogs + c2_dogs + c3_dogs + c4_dogs
print(f"Total compiled 1929-08 dogs: {len(all_58)} (Expected: 58)")
print(f"Col 1: {len(c1_dogs)} (Expected: 13)")
print(f"Col 2: {len(c2_dogs)} (Expected: 21)")
print(f"Col 3: {len(c3_dogs)} (Expected: 21)")
print(f"Col 4: {len(c4_dogs)} (Expected: 3)")

Path("stud-scrape/data/verified_1929_08.json").write_text(json.dumps(all_58, indent=2), encoding="utf-8")
print("Saved clean 1929-08 records to stud-scrape/data/verified_1929_08.json")
