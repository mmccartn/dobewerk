import json
from pathlib import Path

meta_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-09-01_46_9", "date": "1929-09-01", "volume": "46", "issue": "9", "leaf": 34, "column": 1}
meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-09-01_46_9", "date": "1929-09-01", "volume": "46", "issue": "9", "leaf": 34, "column": 2}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-09-01_46_9", "date": "1929-09-01", "volume": "46", "issue": "9", "leaf": 34, "column": 3}

# Column 1 (Leaf 34 Col 1 - 17 dogs)
c1_dogs = [
    {
        "name": "ADRIA V BLANKENBURG", "sex": "Female", "registration_number": "698137",
        "birth_date": "Nov. 28, 1928", "color": "Blk & tn",
        "owner": "Frank Blattler", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "San Jose, Cal.",
        "sire": "Burschel v Falkensee", "sire_registration_number": "553217",
        "dam": "Bona v d Deckersburg", "dam_registration_number": "553222",
        "source": meta_c1
    },
    {
        "name": "ALTARA V RIGA", "sex": "Female", "registration_number": "699653",
        "birth_date": "Nov. 27, 1926", "color": "Blk & rd",
        "owner": "H. D. Anderson", "owner_location": "San Jose, Cal.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Alto v Sigalsburg", "sire_registration_number": None,
        "dam": "Valuta v Riga", "dam_registration_number": "553223",
        "source": meta_c1
    },
    {
        "name": "ARNO V D BLANKENBURG", "sex": "Male", "registration_number": "699804",
        "birth_date": "Sept. 19, 1928", "color": "Blk & tn",
        "owner": "Brown Rhodes", "owner_location": None,
        "breeder": "J. A. Finnicum", "breeder_location": "Columbus, O.",
        "sire": "Leuthold of Pontchartrain", "sire_registration_number": "629194",
        "dam": "Bell of Pontchartrain", "dam_registration_number": "578596",
        "source": meta_c1
    },
    {
        "name": "BARON'S GUSTEL", "sex": "Male", "registration_number": "698847",
        "birth_date": "Feb. 11, 1929", "color": "Rd & tn",
        "owner": "Ralph E. Case", "owner_location": None,
        "breeder": "M. F. Bidwell", "breeder_location": "So. Windsor, Conn.",
        "sire": "Baron v Richthofen", "sire_registration_number": "526664",
        "dam": "Alma v Richthofen", "dam_registration_number": "616393",
        "source": meta_c1
    },
    {
        "name": "BERTA OF DUELMAR", "sex": "Female", "registration_number": "698916",
        "birth_date": "Nov. 17, 1928", "color": "Blk & tn",
        "owner": "Duelmar Kennels", "owner_location": None,
        "breeder": "Eileen Freed", "breeder_location": "Vineland, N. J.",
        "sire": "Big Boy of White Gate", "sire_registration_number": "572868",
        "dam": "Baroness Frieda v d Hohen", "dam_registration_number": "669255",
        "source": meta_c1
    },
    {
        "name": "BETSY KLOSTERSE", "sex": "Female", "registration_number": "697787",
        "birth_date": "Jan. 4, 1928", "color": "Blk & rust",
        "owner": "A. D. Tam", "owner_location": None,
        "breeder": "C. E. Sexton, Jr.", "breeder_location": "Randolph, Ia.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Doby v Lueschenhof", "dam_registration_number": "571080",
        "source": meta_c1
    },
    {
        "name": "BREHM V NIBELUNGENHORT", "sex": "Male", "registration_number": "700106",
        "birth_date": "May 10, 1928", "color": "Blk & tn",
        "owner": "O. K. Lindquist", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "A. Rappo of Pontchartrain", "sire_registration_number": "439031",
        "dam": "Kona Nibelungenhort", "dam_registration_number": "647954",
        "source": meta_c1
    },
    {
        "name": "BYNG V BLANKENBURG", "sex": "Male", "registration_number": "699348",
        "birth_date": "Oct. 30, 1928", "color": "Blk & tn",
        "owner": "William J. Casey", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "Cupertino, Cal.",
        "sire": "Burschel v Falkensee", "sire_registration_number": "553217",
        "dam": "Asta v d Panke", "dam_registration_number": "553219",
        "source": meta_c1
    },
    {
        "name": "CHAPPIE V BERNARD", "sex": "Male", "registration_number": "698451",
        "birth_date": "Nov. 8, 1926", "color": "Blk & tn",
        "owner": "H. J. Stone", "owner_location": None,
        "breeder": "Owen Y. Eachus", "breeder_location": "Chicago, Ill.",
        "sire": "Rover v Bernard", "sire_registration_number": "551703",
        "dam": "Lottie v Gobles", "dam_registration_number": "449300",
        "source": meta_c1
    },
    {
        "name": "CHLOE V ROEMERHOF", "sex": "Female", "registration_number": "700054",
        "birth_date": "May 7, 1929", "color": "Rd",
        "owner": "Paul B. Wallace", "owner_location": None,
        "breeder": "John W. Gage", "breeder_location": "Monticello, Ill.",
        "sire": "Peter v Roemerhof", "sire_registration_number": "616494",
        "dam": "Schwarze Dame", "dam_registration_number": "672699",
        "source": meta_c1
    },
    {
        "name": "COUNT SPIKE V NIBELUNGENHORT", "sex": "Male", "registration_number": "698933",
        "birth_date": "Aug. 27, 1926", "color": "Blk & tn",
        "owner": "Stuart McGuire", "owner_location": None,
        "breeder": "J. F. Webb", "breeder_location": "Wenatchee, Wash.",
        "sire": "Count Monte v Nibelungenhort", "sire_registration_number": "379730",
        "dam": "Gretel of Steubenfield", "dam_registration_number": "327714",
        "source": meta_c1
    },
    {
        "name": "CZARINA V BLANKENBURG", "sex": "Female", "registration_number": "699626",
        "birth_date": "Sept. 9, 1927", "color": "Blk & tn",
        "owner": "Wesley J. Brokenshire", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "Cupertino, Cal.",
        "sire": "Burschel v Falkensee", "sire_registration_number": "553217",
        "dam": "Bona v d Deckersburg", "dam_registration_number": "553222",
        "source": meta_c1
    },
    {
        "name": "DEAK V GEORGETOWN", "sex": "Male", "registration_number": "700190",
        "birth_date": "Apr. 19, 1927", "color": "Blk & br",
        "owner": "Louis Little", "owner_location": None,
        "breeder": "Paul C. Washburn", "breeder_location": "Leominster, Mass.",
        "sire": "Trok v Ulmeholz", "sire_registration_number": "520690",
        "dam": "Brunhild v d Tsar", "dam_registration_number": "349692",
        "source": meta_c1
    },
    {
        "name": "DEUCE V D BECK", "sex": "Male", "registration_number": "697853",
        "birth_date": "Apr. 2, 1929", "color": "Bl & tn, wh spot",
        "owner": "Mrs. Richard E. Anthony", "owner_location": None,
        "breeder": "Beck Kennels", "breeder_location": "Middleboro, Mass.",
        "sire": "Verson v d Beck", "sire_registration_number": "539976",
        "dam": "Hanetta v d Beck", "dam_registration_number": "539973",
        "source": meta_c1
    },
    {
        "name": "ELMCROFT KING NIKO", "sex": "Male", "registration_number": "699665",
        "birth_date": "Aug. 21, 1928", "color": "Blk & tn",
        "owner": "Robert W. Jameson", "owner_location": None,
        "breeder": "R. Ray McLaughlin", "breeder_location": "Canada",
        "sire": "Alamo of Arkeden", "sire_registration_number": "465166",
        "dam": "Elmcroft Neta", "dam_registration_number": "465935",
        "source": meta_c1
    },
    {
        "name": "FLASH V NIBELUNGENHORT", "sex": "Male", "registration_number": "700105",
        "birth_date": "May 10, 1928", "color": "Blk & tn",
        "owner": "O. K. Lindquist", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "A. Rappo of Pontchartrain", "sire_registration_number": "439031",
        "dam": "Kona v Nibelungenhort", "dam_registration_number": "647954",
        "source": meta_c1
    },
    {
        "name": "FRAULEIN SCHATZIE OF BIL KAY", "sex": "Female", "registration_number": "697526",
        "birth_date": "Feb. 15, 1928", "color": "Blk & tn",
        "owner": "V. A. Oswald", "owner_location": None,
        "breeder": "Wm. H. Duffy", "breeder_location": "Northfield, N. J.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Hildegarde v Doernbach", "dam_registration_number": "661249",
        "source": meta_c1
    }
]

# Column 2 (Leaf 34 Col 2 - 22 dogs)
c2_dogs = [
    {
        "name": "FRIEDA V HARTENSTINE", "sex": "Female", "registration_number": "698915",
        "birth_date": "Dec. 2, 1927", "color": "Blk & tn",
        "owner": "James A. Burford", "owner_location": None,
        "breeder": "Harriet B. Patrick", "breeder_location": "Omaha, Neb.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Elly II v Wiedensahl", "dam_registration_number": "581816",
        "source": meta_c2
    },
    {
        "name": "FRUDIE V KOENIG", "sex": "Female", "registration_number": "699805",
        "birth_date": "Apr. 3, 1928", "color": "Blk & br",
        "owner": "C. F. Cross", "owner_location": None,
        "breeder": "Rodman M. Brown, Jr.", "breeder_location": "Omaha, Neb.",
        "sire": "Hasso v Altendorf", "sire_registration_number": "463070",
        "dam": "Trudie v Burgholz", "dam_registration_number": "549325",
        "source": meta_c2
    },
    {
        "name": "GRETA OF SIDLAW", "sex": "Female", "registration_number": "700187",
        "birth_date": "Sept. 5, 1928", "color": "Blk & tn",
        "owner": "Fanny Dickinson", "owner_location": None,
        "breeder": "Mary B. Trelease", "breeder_location": "Inglewood, Cal.",
        "sire": "Burschel v Weigand", "sire_registration_number": "652099",
        "dam": "Asta v Do Barry", "dam_registration_number": "507694",
        "source": meta_c2
    },
    {
        "name": "GUARD", "sex": "Male", "registration_number": "700191",
        "birth_date": "Aug. 18, 1928", "color": "Blk, rusty br",
        "owner": "Andrews Jansen", "owner_location": None,
        "breeder": "Thyra Klitgaard", "breeder_location": "San Francisco, Cal.",
        "sire": "Osmann", "sire_registration_number": "611285",
        "dam": "Ruth", "dam_registration_number": "566438",
        "source": meta_c2
    },
    {
        "name": "HANNA SCHMIDT", "sex": "Female", "registration_number": "700482",
        "birth_date": "Nov. 6, 1926", "color": "Blk & tn",
        "owner": "Russell D. Hays", "owner_location": None,
        "breeder": "John Schofield", "breeder_location": "Elverson, Pa.",
        "sire": "Armin v Burgfried", "sire_registration_number": "430843",
        "dam": "Countess v Burgholz", "dam_registration_number": "449862",
        "source": meta_c2
    },
    {
        "name": "HANS DER REISEGEFAHRTEN", "sex": "Male", "registration_number": "698412",
        "birth_date": "Jan. 7, 1929", "color": "Rd, rust mkgs",
        "owner": "Frederick L. Orum", "owner_location": None,
        "breeder": "Mr. and Mrs. Fred Cook", "breeder_location": "Painted Post, N. Y.",
        "sire": "Alex of Alexander", "sire_registration_number": "400178",
        "dam": "Liesel v d Grenzlerburg", "dam_registration_number": "586610",
        "source": meta_c2
    },
    {
        "name": "HANS OF TYWORTH", "sex": "Male", "registration_number": "700060",
        "birth_date": "Apr. 13, 1929", "color": "Blk, rust rd",
        "owner": "Sarah Ann Degan", "owner_location": None,
        "breeder": "Mr. and Mrs. N. E. Tyrrell", "breeder_location": "E. Ionia, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Nita v Streslau", "dam_registration_number": "539723",
        "source": meta_c2
    },
    {
        "name": "HEIMDALL V ELSTERSTRAND", "sex": "Male", "registration_number": "698806",
        "birth_date": "Mar. 14, 1928", "color": "Blk & tn",
        "owner": "H. T. Reccius", "owner_location": None,
        "breeder": "Ernst Unruh", "breeder_location": "Germany",
        "sire": "Ferry v d Triumpfpforte", "sire_registration_number": None,
        "dam": "Citty v Hoflar", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Fax v Parthengrund", "registration_number": None},
            {"role": "dam_of_dam", "name": "Biene v Muhlhausen", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Harold Ortrecht Nibelungenhort", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Alma v d Drehsa", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Banjo v d goldnen Hohe", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Carmen v Atlantic", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Asta v d Loknitz", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Lump Gansel", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Bona v d Deckersburg", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "HILDA V LEUTHOBELLE", "sex": "Female", "registration_number": "699983",
        "birth_date": "Sept. 19, 1928", "color": "Blk & br",
        "owner": "Walton G. Alcorn", "owner_location": None,
        "breeder": "J. A. Finnicum", "breeder_location": "Columbus, O.",
        "sire": "Leuthold of Pontchartrain", "sire_registration_number": "629194",
        "dam": "Bella of Pontchartrain", "dam_registration_number": "578596",
        "source": meta_c2
    },
    {
        "name": "KARL", "sex": "Male", "registration_number": "698815",
        "birth_date": "Mar. 29, 1929", "color": "Blk & tn",
        "owner": "C. A. Bowen", "owner_location": None,
        "breeder": "Oscar L. Simpson", "breeder_location": "Nashville, Tenn.",
        "sire": "Ochsner's Son of Rival", "sire_registration_number": "612378",
        "dam": "Asta v Nashville", "dam_registration_number": "675400",
        "source": meta_c2
    },
    {
        "name": "KARTZ'S FRITZ", "sex": "Male", "registration_number": "699991",
        "birth_date": "June 1, 1928", "color": "Br",
        "owner": "John F. Kartz", "owner_location": None,
        "breeder": "E. H. Liebenstein", "breeder_location": "Grafton, Wis.",
        "sire": "Peter v Reyem", "sire_registration_number": "491063",
        "dam": "Irma v d Eckardtsburg", "dam_registration_number": "438105",
        "source": meta_c2
    },
    {
        "name": "KING OF NITTA YUMA", "sex": "Male", "registration_number": "697558",
        "birth_date": "Sept. 3, 1928", "color": "Blk, rust rd",
        "owner": "W. L. Lyons, Jr.", "owner_location": None,
        "breeder": "P. L. Atherton", "breeder_location": "Glenview, Ky.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Frieda of Pontchartrain", "dam_registration_number": "511185",
        "source": meta_c2
    },
    {
        "name": "LABRADOR OF TYWORTH", "sex": "Male", "registration_number": "700067",
        "birth_date": "Apr. 13, 1929", "color": "Blk & rust",
        "owner": "E. J. Baker", "owner_location": None,
        "breeder": "Mr. and Mrs. N. E. Tyrrell", "breeder_location": "Ionia, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Nita v Streslau", "dam_registration_number": "539723",
        "source": meta_c2
    },
    {
        "name": "LADY ANNA V SEIGRIST", "sex": "Female", "registration_number": "697559",
        "birth_date": "Feb. 10, 1928", "color": "Blk & tn, rust rd mkgs",
        "owner": "W. L. Lyons, Jr.", "owner_location": None,
        "breeder": "P. L. Atherton", "breeder_location": "Glenview, Ky.",
        "sire": "Prinz Favoriet v d Koningstad", "sire_registration_number": "420325",
        "dam": "Trail 'Em Memories", "dam_registration_number": "565660",
        "source": meta_c2
    },
    {
        "name": "LADY V GROSMOUNT", "sex": "Female", "registration_number": "697832",
        "birth_date": "Aug. 14, 1926", "color": "Blk & tn",
        "owner": "G. C. Jaco", "owner_location": None,
        "breeder": "N. J. Peabody", "breeder_location": "Weston, Vt.",
        "sire": "Albert v d Rudolfsburg", "sire_registration_number": "368216",
        "dam": "Buppe v Macwahoc", "dam_registration_number": "358806",
        "source": meta_c2
    },
    {
        "name": "LADY V WILHELM", "sex": "Female", "registration_number": "699515",
        "birth_date": "May 16, 1928", "color": "Blk & tn",
        "owner": "Mrs. Moth Brausch", "owner_location": None,
        "breeder": "A. C. Wilhelm", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Burga v Scharfhueck", "dam_registration_number": "434189",
        "source": meta_c2
    },
    {
        "name": "LINDA V MANNERSTEDT", "sex": "Female", "registration_number": "697150",
        "birth_date": "Feb. 22, 1926", "color": "Blk & tn",
        "owner": "Arthur Ringbloom", "owner_location": "Chicago, Ill.",
        "breeder": "Fred M. Berger", "breeder_location": "Chicago, Ill.",
        "sire": "Caballero v Wassertor", "sire_registration_number": "628898",
        "dam": "Freya v Bergerhof", "dam_registration_number": "578494",
        "source": meta_c2
    },
    {
        "name": "MARTI V DELENBURG", "sex": "Male", "registration_number": "699328",
        "birth_date": "May 24, 1926", "color": "Blk, rd & tn",
        "owner": "Edward Martindel", "owner_location": None,
        "breeder": "J. F. Webb", "breeder_location": "Wenatchee, Wash.",
        "sire": "Count Monte v Nibelungenhort", "sire_registration_number": "379730",
        "dam": "Thelma of Stubenfield", "dam_registration_number": "498241",
        "source": meta_c2
    },
    {
        "name": "MURPHY V RULENBURG", "sex": "Male", "registration_number": "698613",
        "birth_date": "Oct. 18, 1927", "color": "Blk & tn",
        "owner": "Lawrence J. Rule", "owner_location": "Springfield, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Juno T", "dam_registration_number": "544452",
        "source": meta_c2
    },
    {
        "name": "NELLY V LINDENFELS", "sex": "Female", "registration_number": "699847",
        "birth_date": "Aug. 7, 1928", "color": "Blk & tn",
        "owner": "Charles Appel", "owner_location": None,
        "breeder": "Otto Siegmann", "breeder_location": "Brooklyn, N. Y.",
        "sire": "Fritz v Hetzendorf", "sire_registration_number": "502166",
        "dam": "Cilly v Vaterland", "dam_registration_number": "657960",
        "source": meta_c2
    },
    {
        "name": "NITTA YUMA'S FRIEDA SIGALSBURG", "sex": "Female", "registration_number": "697557",
        "birth_date": "Sept. 3, 1928", "color": "Blk, rust rd mkgs",
        "owner": "W. L. Lyons, Jr.", "owner_location": None,
        "breeder": "P. L. Atherton", "breeder_location": "Glenview, Ky.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Frieda of Pontchartrain", "dam_registration_number": "511185",
        "source": meta_c2
    },
    {
        "name": "NITTA YUMA'S FRITZ", "sex": "Male", "registration_number": "697556",
        "birth_date": "Sept. 3, 1928", "color": "Blk, rust rd mkgs",
        "owner": "W. L. Lyons, Jr.", "owner_location": None,
        "breeder": "P. L. Atherton", "breeder_location": "Glenview, Ky.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Frieda of Pontchartrain", "dam_registration_number": "511185",
        "source": meta_c2
    }
]

# Column 3 (Leaf 34 Col 3 - 15 dogs ending before POINTERS)
c3_dogs = [
    {
        "name": "NITTA YUMA'S SANDY", "sex": "Female", "registration_number": "697560",
        "birth_date": "July 17, 1928", "color": "Br, rust rd mkgs",
        "owner": "W. L. Lyons, Jr.", "owner_location": None,
        "breeder": "P. L. Atherton", "breeder_location": "Glenview, Ky.",
        "sire": "Prince Alexis of Ardenne", "sire_registration_number": "599344",
        "dam": "Trail 'Em Sandy", "dam_registration_number": "561300",
        "source": meta_c3
    },
    {
        "name": "OMAR V D HOHEN", "sex": "Male", "registration_number": "697838",
        "birth_date": "Feb. 16, 1929", "color": "Br, rd mkgs",
        "owner": "Carlota Cagliardi", "owner_location": None,
        "breeder": "Mrs. M. vom Hoegen", "breeder_location": "Towaco, N. J.",
        "sire": "Eros v d Hohen", "sire_registration_number": "663349",
        "dam": "Erda v d Hohen", "dam_registration_number": "683706",
        "source": meta_c3
    },
    {
        "name": "OSMANN II", "sex": "Male", "registration_number": "697617",
        "birth_date": "Mar. 22, 1929", "color": "Blk & tn",
        "owner": "Mrs. Frank Bishop", "owner_location": None,
        "breeder": "Gertrude H. Walsh", "breeder_location": "Mill Valley, Cal.",
        "sire": "Osmann", "sire_registration_number": "611285",
        "dam": "Adda v Bets", "dam_registration_number": "556862",
        "source": meta_c3
    },
    {
        "name": "PONTCHARTRAIN'S PRINZ TASSO", "sex": "Male", "registration_number": "697811",
        "birth_date": "Nov. 29, 1928", "color": "Blk & rd",
        "owner": "Ernest R. Kurlbaum", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Hertha of Pontchartrain", "dam_registration_number": "610096",
        "source": meta_c3
    },
    {
        "name": "PRINCE FRITZ V HEIDELBERG", "sex": "Male", "registration_number": "700198",
        "birth_date": "Feb. 27, 1929", "color": "Blk & tn",
        "owner": "M. N. Josell", "owner_location": None,
        "breeder": "Edward Rose", "breeder_location": "Queens Village, L. I., N. Y.",
        "sire": "Prinz Carlo of Westphalia", "sire_registration_number": "517068",
        "dam": "Mona Dora Zoic", "dam_registration_number": "412715",
        "source": meta_c3
    },
    {
        "name": "PRINCE NICHOLAS V D SPREE", "sex": "Male", "registration_number": "698168",
        "birth_date": "Aug. 4, 1928", "color": "Blk & rust",
        "owner": "J. H. Sower", "owner_location": None,
        "breeder": "Mrs. H. S. Taylor", "breeder_location": "Lakewood, N. J.",
        "sire": "Jof v Steuben", "sire_registration_number": "654600",
        "dam": "Rota v Steuben", "dam_registration_number": "649190",
        "source": meta_c3
    },
    {
        "name": "PRINZ CARLO'S DAUGHTER", "sex": "Female", "registration_number": "699694",
        "birth_date": "Dec. 26, 1928", "color": "Blk & tn",
        "owner": "Paul B. Wallace", "owner_location": None,
        "breeder": "John W. Thomas", "breeder_location": "Ho-Ho-Kus, N. J.",
        "sire": "Westphalia Prinz Carlo v d Koningstad", "sire_registration_number": "365521",
        "dam": "Baroness Dubla v d Hoehen", "dam_registration_number": "619318",
        "source": meta_c3
    },
    {
        "name": "PRINZ V D ECKARDTSBURG", "sex": "Male", "registration_number": "699658",
        "birth_date": "May 24, 1926", "color": "Blk & rd",
        "owner": "Walter Heidelmann", "owner_location": None,
        "breeder": "Arno Eckhardt", "breeder_location": "Germany",
        "sire": "Mento v d Eckardtsburg", "sire_registration_number": None,
        "dam": "Ruth v Maryland", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_dam", "name": "Ada v Steigerwald", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Baldur v Rottal", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Sitta Tonna", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Achim v Langerode", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Leddy v d Blankenburg", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Kitty v d Eckardtsburg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Fels v d Eckardtsburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Bona v d Eckardtsburg", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_c3
    },
    {
        "name": "RED V RULENBURG", "sex": "Male", "registration_number": "698614",
        "birth_date": "Oct. 18, 1927", "color": "Rd & tn",
        "owner": "Lawrence J. Rule", "owner_location": "Springfield, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Juno T", "dam_registration_number": "544452",
        "source": meta_c3
    },
    {
        "name": "RICH V RULENBURG", "sex": "Male", "registration_number": "698612",
        "birth_date": "Oct. 18, 1927", "color": "Blk & tn",
        "owner": "Lawrence J. Rule", "owner_location": "Springfield, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Juno T", "dam_registration_number": "544452",
        "source": meta_c3
    },
    {
        "name": "RODGER", "sex": "Male", "registration_number": "698621",
        "birth_date": "Mar. 29, 1929", "color": "Blk & tn",
        "owner": "D. Bosserman", "owner_location": None,
        "breeder": "W. O. McClane", "breeder_location": "Chicago, Ill.",
        "sire": "Gustl v Tannenhaus", "sire_registration_number": "677473",
        "dam": "Sallie v Allie", "dam_registration_number": "605877",
        "source": meta_c3
    },
    {
        "name": "SALLY OF NIBELUNGENHORT", "sex": "Female", "registration_number": "699124",
        "birth_date": "Aug. 27, 1926", "color": "Blk & tn",
        "owner": "J. F. Webb", "owner_location": "Wenatchee, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Count Monte v Nibelungenhort", "sire_registration_number": "379730",
        "dam": "Gretel of Steubenfield", "dam_registration_number": "327714",
        "source": meta_c3
    },
    {
        "name": "TOGO V ALLERSHAUSEN", "sex": "Male", "registration_number": "698571",
        "birth_date": "Feb. 3, 1927", "color": "Br & rd",
        "owner": "R. A. Hampe", "owner_location": None,
        "breeder": "John Ninger", "breeder_location": "Bloomfield, N. J.",
        "sire": "Ego v Allershausen", "sire_registration_number": "525324",
        "dam": "Geraldine v Rottal", "dam_registration_number": "439946",
        "source": meta_c3
    },
    {
        "name": "TUNO DE VALDESGUERRA", "sex": "Male", "registration_number": "698772",
        "birth_date": "Jan. 16, 1929", "color": "Blk & tn",
        "owner": "Ramon Valdes De Diego", "owner_location": None,
        "breeder": "W. L. Haley", "breeder_location": "Sioux City, Ia.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Frances of Mickburn", "dam_registration_number": "580532",
        "source": meta_c3
    },
    {
        "name": "ZOE V KLOSTERSEE", "sex": "Female", "registration_number": "700296",
        "birth_date": "July 11, 1928", "color": "Blk & rust",
        "owner": "Geo. H. Jones", "owner_location": "Danville, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Princess v Rudolphsburg", "dam_registration_number": "569711",
        "source": meta_c3
    }
]

all_54 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1929-09 dogs: {len(all_54)} (Expected: 54)")
print(f"Col 1: {len(c1_dogs)} (Expected: 17)")
print(f"Col 2: {len(c2_dogs)} (Expected: 22)")
print(f"Col 3: {len(c3_dogs)} (Expected: 15)")

Path("stud-scrape/data/verified_1929_09.json").write_text(json.dumps(all_54, indent=2), encoding="utf-8")
print("Saved clean 1929-09 records to stud-scrape/data/verified_1929_09.json")
