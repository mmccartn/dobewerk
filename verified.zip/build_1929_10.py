import json
from pathlib import Path

meta_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-10-01_46_10", "date": "1929-10-01", "volume": "46", "issue": "10", "leaf": 35, "column": 1}
meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-10-01_46_10", "date": "1929-10-01", "volume": "46", "issue": "10", "leaf": 35, "column": 2}

# Column 1 (Leaf 35 Col 1 - 21 dogs)
c1_dogs = [
    {
        "name": "ADELE OF LUXEMBOURG", "sex": "Female", "registration_number": "701723",
        "birth_date": "July 11, 1927", "color": "Rust & br",
        "owner": "Mr. and Mrs. Frederick H. Willett", "owner_location": None,
        "breeder": "Paul E. Des Champs", "breeder_location": "Corona, L. I., N. Y.",
        "sire": "Prinz Carlo of Westphalia", "sire_registration_number": "517068",
        "dam": "Daphne of Arkeden", "dam_registration_number": "553970",
        "source": meta_c1
    },
    {
        "name": "AFFRA V EARL", "sex": "Male", "registration_number": "702106",
        "birth_date": "May 7, 1929", "color": "Blk & rust rd",
        "owner": "Harry P. Earl", "owner_location": None,
        "breeder": "John W. Gage", "breeder_location": "Monticello, Ill.",
        "sire": "Peter v Roemerhof", "sire_registration_number": "616494",
        "dam": "Schwarze Dame", "dam_registration_number": "672699",
        "source": meta_c1
    },
    {
        "name": "ARNO V BECKERSHOHE", "sex": "Male", "registration_number": "701612",
        "birth_date": "Mar. 29, 1927", "color": "Blk & rd",
        "owner": "Max Fechter", "owner_location": None,
        "breeder": "Heinr. Becker", "breeder_location": "Germany",
        "sire": "Bodo v Goldgrund", "sire_registration_number": None,
        "dam": "Hilde v Reiherstieg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Astor v Goldgrund", "registration_number": None},
            {"role": "dam_of_dam", "name": "Asta v Marienbrunn", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Dolf v Wiesengrund", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Lotte v Forsthaus", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Astor v Goldgrund", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "sire_of_sire", "name": "Hela v Gotterfelsen", "registration_number": None},
            {"role": "dam_of_sire", "name": "Bodo v Goldgrund", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Norbert v Friedewald", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Hela v Goetterfelsen", "registration_number": "402278"},
            {"role": "sire_of_paternal_grandsire", "name": "Norbert v Friedewald", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Astor v d Residenz", "registration_number": None}
        ],
        "source": meta_c1
    },
    {
        "name": "BEANO V VANDERLUST", "sex": "Male", "registration_number": "702330",
        "birth_date": "Dec. 17, 1928", "color": "Blk & tn",
        "owner": "Jacob Vogt", "owner_location": None,
        "breeder": "Bart Delacourt", "breeder_location": "Los Angeles, Calif.",
        "sire": "Max v Strossen", "sire_registration_number": "509139",
        "dam": "Asta v Hohenzollernpark", "dam_registration_number": "661506",
        "source": meta_c1
    },
    {
        "name": "BETTY V POPP", "sex": "Female", "registration_number": "702787",
        "birth_date": "June 17, 1928", "color": "Blk & tn",
        "owner": "C. E. Sexton, Jr.", "owner_location": None,
        "breeder": "T. E. Popp", "breeder_location": "West Allis, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Beauty v Popp", "dam_registration_number": "655445",
        "source": meta_c1
    },
    {
        "name": "BONA V BLANKENBURG", "sex": "Female", "registration_number": "702946",
        "birth_date": "Feb. 29, 1928", "color": "Blk & tn",
        "owner": "Lawrence J. Steinhardt", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "Cupertino, Calif.",
        "sire": "Burschel v Falkensee", "sire_registration_number": "553217",
        "dam": "Altara v Riga", "dam_registration_number": "699653",
        "source": meta_c1
    },
    {
        "name": "BOY OF PINE BROOK", "sex": "Male", "registration_number": "701010",
        "birth_date": "Oct. 17, 1926", "color": "Br & tn",
        "owner": "William F. Mertz", "owner_location": None,
        "breeder": "Annetta L. Peavear", "breeder_location": "Weston, Mass.",
        "sire": "Alert v d Rudolfsburg", "sire_registration_number": "368215",
        "dam": "Zilla of Pine Brook", "dam_registration_number": "492654",
        "source": meta_c1
    },
    {
        "name": "CARLOTTA OF EDJO", "sex": "Female", "registration_number": "702796",
        "birth_date": "July 24, 1927", "color": "Blk & tn",
        "owner": "Francis P. McKenny", "owner_location": None,
        "breeder": "Joseph C. Blauner", "breeder_location": "Clifton, N. J.",
        "sire": "Prinz Carlo of Westphalia", "sire_registration_number": "517068",
        "dam": "Ellie of Edjo", "dam_registration_number": "689594",
        "source": meta_c1
    },
    {
        "name": "CARSO V REYEM", "sex": "Male", "registration_number": "703532",
        "birth_date": "Apr. 10, 1928", "color": "Blk & tn",
        "owner": "Reyem Kennels", "owner_location": "Hales Corners, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Bona v d Residenz", "dam_registration_number": "410865",
        "source": meta_c1
    },
    {
        "name": "CHUCKLES KAUTZENHOF", "sex": "Male", "registration_number": "700769",
        "birth_date": "Feb. 23, 1929", "color": "Blue & tn",
        "owner": "Richard D. Vaught", "owner_location": None,
        "breeder": "R. A. Tibbetts", "breeder_location": "Lincoln, Nebr.",
        "sire": "Duke v Weigand", "sire_registration_number": "663995",
        "dam": "Jerryalene v Wildendorf", "dam_registration_number": "688742",
        "source": meta_c1
    },
    {
        "name": "DAISY V D DOERING'S FARM", "sex": "Female", "registration_number": "703914",
        "birth_date": "July 27, 1926", "color": "Blk & tn",
        "owner": "C. L. Sutton", "owner_location": None,
        "breeder": "Ed. F. Doering", "breeder_location": "Winthrop, Minn.",
        "sire": "Armin v Allgau", "sire_registration_number": "429328",
        "dam": "Gurta v Osterburg", "dam_registration_number": "500158",
        "source": meta_c1
    },
    {
        "name": "DETRIK OF TYWORTH", "sex": "Male", "registration_number": "702313",
        "birth_date": "June 11, 1928", "color": "Blk with rust mkgs",
        "owner": "Mr. and Mrs. N. E. Tyrrell", "owner_location": "E. Ionia, Mich.",
        "breeder": "Owners", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Nita v Streslau", "dam_registration_number": "539723",
        "source": meta_c1
    },
    {
        "name": "DIGNITY V NIBELUNGENHORT", "sex": "Male", "registration_number": "702148",
        "birth_date": "June 17, 1929", "color": "Blk & tn",
        "owner": "Robert W. Jameson", "owner_location": "Antrim, N. H.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Koningstad Amerant of White Gate", "sire_registration_number": "495734",
        "dam": "Nita v Nibelungenhort", "dam_registration_number": "542235",
        "source": meta_c1
    },
    {
        "name": "DINA OF LINDFORD", "sex": "Female", "registration_number": "702702",
        "birth_date": "Aug. 28, 1928", "color": "Blk & tn",
        "owner": "John C. Lindemere", "owner_location": None,
        "breeder": "Karl P's Graeuwen", "breeder_location": "Brooklyn, N. Y.",
        "sire": "Fritz v Edjo", "sire_registration_number": "605709",
        "dam": "Maus v Sedrevla", "dam_registration_number": "671985",
        "source": meta_c1
    },
    {
        "name": "DORUSSI WALLI OF MARVINDALE", "sex": "Male", "registration_number": "694966",
        "birth_date": "June 24, 1928", "color": "Blk & tn",
        "owner": "Albert G. Prill", "owner_location": None,
        "breeder": "E. A. Harvey", "breeder_location": "Portland, Ore.",
        "sire": "Max v Steuben", "sire_registration_number": "573145",
        "dam": "Kunigunde II v Stolzenfels", "dam_registration_number": "544196",
        "source": meta_c1
    },
    {
        "name": "FRITZIE V DOMBACHTAL", "sex": "Male", "registration_number": "703639",
        "birth_date": "Oct. 29, 1928", "color": "Blk & tn",
        "owner": "Margaret Schang", "owner_location": None,
        "breeder": "Mrs. R. E. Byrd", "breeder_location": "Erie, Pa.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Donna v Dombachtal", "dam_registration_number": "653113",
        "source": meta_c1
    },
    {
        "name": "FRITZIE V D SPREE", "sex": "Female", "registration_number": "702921",
        "birth_date": "July 28, 1928", "color": "Lvr & tn",
        "owner": "Arthur D. Winslow", "owner_location": None,
        "breeder": "L. W. Schnitzer", "breeder_location": "Glenview, Ill.",
        "sire": "Dragon v Hindendorff", "sire_registration_number": "379450",
        "dam": "Josephine v d Spree", "dam_registration_number": "560427",
        "source": meta_c1
    },
    {
        "name": "GRETCHEN V NIBELUNGENHORT", "sex": "Female", "registration_number": "702150",
        "birth_date": "June 17, 1929", "color": "Lt br & tn",
        "owner": "Robert W. Jameson", "owner_location": "Antrim, N. H.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Koningstad Amerant of White Gate", "sire_registration_number": "495734",
        "dam": "Nita v Nibelungenhort", "dam_registration_number": "542235",
        "source": meta_c1
    },
    {
        "name": "GRETCHEN V STROSSEN", "sex": "Female", "registration_number": "701301",
        "birth_date": "Dec. 17, 1928", "color": "Blk & tn",
        "owner": "F. H. Bawden", "owner_location": "Los Angeles, Calif.",
        "breeder": "Bart Delacourt", "breeder_location": "Los Angeles, Calif.",
        "sire": "Max v Strossen", "sire_registration_number": "509139",
        "dam": "Asta v Hohenzollernpark", "dam_registration_number": "661506",
        "source": meta_c1
    },
    {
        "name": "ISABEL'S FRITZ V ANTRIM", "sex": "Male", "registration_number": "702149",
        "birth_date": "June 17, 1929", "color": "Blk & tn",
        "owner": "Robert W. Jameson", "owner_location": "Antrim, N. H.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Koningstad Amerant of White Gate", "sire_registration_number": "495734",
        "dam": "Nita v Nibelungenhort", "dam_registration_number": "542235",
        "source": meta_c1
    },
    {
        "name": "JIL V JAEGERSHOF", "sex": "Female", "registration_number": "703280",
        "birth_date": "Feb. 6, 1929", "color": "Blk & rd rust",
        "owner": "Robert L. Ward", "owner_location": None,
        "breeder": "Robert E. O'Connell", "breeder_location": "Ottumwa, Iowa",
        "sire": "Baro v Jaegershof", "sire_registration_number": "620043",
        "dam": "Judy of Friedrichshafen", "dam_registration_number": "663266",
        "source": meta_c1
    }
]

# Column 2 (Leaf 35 Col 2 - 15 dogs ending before POINTERS)
c2_dogs = [
    {
        "name": "LADY DELVA V D KONINGSTAD", "sex": "Female", "registration_number": "702272",
        "birth_date": "May 3, 1929", "color": "Blk & rust",
        "owner": "William Morgenstern", "owner_location": None,
        "breeder": "Matthew L. Rimbach", "breeder_location": "Baltimore, Md.",
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Berta v Hohenschwanau", "dam_registration_number": "673537",
        "source": meta_c2
    },
    {
        "name": "LUTZIE V GOTTSCHALK", "sex": "Female", "registration_number": "701415",
        "birth_date": "Dec. 14, 1928", "color": "Rd, br",
        "owner": "Mary Elizabeth Rau", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Astor Gottschalk", "sire_registration_number": "639147",
        "dam": "Ary Tremonia", "dam_registration_number": "605201",
        "source": meta_c2
    },
    {
        "name": "OWING'S BLACK SWAN", "sex": "Female", "registration_number": "703885",
        "birth_date": "June 11, 1925", "color": "Blk & tn",
        "owner": "Roy M. Swan", "owner_location": None,
        "breeder": "Athos Nilsen", "breeder_location": "Los Angeles, Calif.",
        "sire": "Astor v Thumshoehe", "sire_registration_number": "379878",
        "dam": "Tiny v Melrapp", "dam_registration_number": "479567",
        "source": meta_c2
    },
    {
        "name": "PINTO V VOLCKE", "sex": "Male", "registration_number": "702842",
        "birth_date": "Sept. 1, 1927", "color": "Blk & tn",
        "owner": "Gertrude M. Blood", "owner_location": None,
        "breeder": "Marshall F. Bidwell", "breeder_location": "So. Windsor, Conn.",
        "sire": "Baron v Richthofen", "sire_registration_number": "526664",
        "dam": "Adda v Kanonenstadt", "dam_registration_number": "534153",
        "source": meta_c2
    },
    {
        "name": "PITTS' BRAUN", "sex": "Male", "registration_number": "702299",
        "birth_date": "June 30, 1928", "color": "Blk, tn",
        "owner": "Samuel N. D. Pitts", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Nuttall's Prinz", "sire_registration_number": "610640",
        "dam": "Pitts' Queen", "dam_registration_number": "702298",
        "source": meta_c2
    },
    {
        "name": "PITTS' QUEEN", "sex": "Female", "registration_number": "702298",
        "birth_date": "Dec. 23, 1926", "color": "Rd & tn",
        "owner": "Samuel N. D. Pitts", "owner_location": None,
        "breeder": "H. M. Nuttall", "breeder_location": "Detroit, Mich.",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Robinson's Lily", "dam_registration_number": "516294",
        "source": meta_c2
    },
    {
        "name": "PRINCE NAPPY V SIEGESTOR", "sex": "Male", "registration_number": "702271",
        "birth_date": "Mar. 13, 1929", "color": "Blk, mhgy",
        "owner": "William Morgenstern", "owner_location": None,
        "breeder": "Charles King", "breeder_location": "Baltimore, Md.",
        "sire": "Beowulf v Siegestor", "sire_registration_number": "525331",
        "dam": "Reta v Siegestor", "dam_registration_number": "570743",
        "source": meta_c2
    },
    {
        "name": "REDSMOND ATTILSTRICH", "sex": "Male", "registration_number": "702903",
        "birth_date": "Jan. 12, 1929", "color": "Rd & tn",
        "owner": "Wilson W. Lyster", "owner_location": "Library, Pa.",
        "breeder": "Walter J. Lyster", "breeder_location": "Library, Pa.",
        "sire": "Sniten's Attila", "sire_registration_number": "603370",
        "dam": "Ottilie Strichrodt", "dam_registration_number": "639194",
        "source": meta_c2
    },
    {
        "name": "REX V CRAFTON", "sex": "Male", "registration_number": "702737",
        "birth_date": "June 21, 1929", "color": "Br, rd & tn",
        "owner": "Mary Gallagher", "owner_location": None,
        "breeder": "Emil Aschner", "breeder_location": "Brentwood, Pa.",
        "sire": "Bodo v Petersbach", "sire_registration_number": "605198",
        "dam": "Alma de la Ville de Bale", "dam_registration_number": "605199",
        "source": meta_c2
    },
    {
        "name": "SNITEN'S V ROTTAL", "sex": "Male", "registration_number": "702897",
        "birth_date": "Jan. 12, 1929", "color": "Blk & tn",
        "owner": "Alfred Darte", "owner_location": None,
        "breeder": "Walter J. Lyster", "breeder_location": "Library, Pa.",
        "sire": "Sniten's Attila", "sire_registration_number": "603370",
        "dam": "Ottilie Strichrodt", "dam_registration_number": "639194",
        "source": meta_c2
    },
    {
        "name": "URIANA V WALDECK", "sex": "Female", "registration_number": "702562",
        "birth_date": "April 15, 1928", "color": "Blk & tn",
        "owner": "Nicholas Lovece", "owner_location": None,
        "breeder": "Joe Palescandolo", "breeder_location": "Coney Island, N. Y.",
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Clausina of Arkeden", "dam_registration_number": "695924",
        "source": meta_c2
    },
    {
        "name": "VIGILO OF LINDFORD", "sex": "Male", "registration_number": "702703",
        "birth_date": "June 18, 1924", "color": "Br & tn",
        "owner": "John C. Lindemere", "owner_location": None,
        "breeder": "John J. Conroy", "breeder_location": "Bayside, L. I., N. Y.",
        "sire": "Westphalia Klaus v Ostersee", "sire_registration_number": "391616",
        "dam": "Mitzi v d Rudolfsburg", "dam_registration_number": "426826",
        "source": meta_c2
    },
    {
        "name": "WARNSIES FLASH V SIGALSBURG", "sex": "Male", "registration_number": "703805",
        "birth_date": "Oct. 29, 1928", "color": "Blk & tn",
        "owner": "Harland J. Warns", "owner_location": None,
        "breeder": "Mrs. R. E. Byrd", "breeder_location": "Erie, Pa.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Donna v Dombachtal", "dam_registration_number": "653113",
        "source": meta_c2
    },
    {
        "name": "ZEUS V RIGGS", "sex": "Male", "registration_number": "702455",
        "birth_date": "May 27, 1929", "color": "Blk & rust br",
        "owner": "Daniel S. Pray", "owner_location": None,
        "breeder": "Edwin C. Philbrook", "breeder_location": "Rockland, Me.",
        "sire": "Timidity Brrrp", "sire_registration_number": "614624",
        "dam": "Gretel v Belger", "dam_registration_number": "539977",
        "source": meta_c2
    },
    {
        "name": "ZUNA V SIGALSBURG", "sex": "Female", "registration_number": "700624",
        "birth_date": "Aug. 24, 1928", "color": "Blk & tn",
        "owner": "Floyd W. Conklin", "owner_location": None,
        "breeder": "Albert E. Farone", "breeder_location": "Oneonta, N. Y.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Rani v Stresow", "dam_registration_number": "561913",
        "source": meta_c2
    }
]

all_36 = c1_dogs + c2_dogs
print(f"Total compiled 1929-10 dogs: {len(all_36)} (Expected: 36)")
print(f"Col 1: {len(c1_dogs)} (Expected: 21)")
print(f"Col 2: {len(c2_dogs)} (Expected: 15)")

Path("stud-scrape/data/verified_1929_10.json").write_text(json.dumps(all_36, indent=2), encoding="utf-8")
print("Saved clean 1929-10 records to stud-scrape/data/verified_1929_10.json")
