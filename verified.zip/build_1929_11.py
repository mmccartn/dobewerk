import json
from pathlib import Path

meta_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-11-01_46_11", "date": "1929-11-01", "volume": "46", "issue": "11", "leaf": 34, "column": 3}
meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-11-01_46_11", "date": "1929-11-01", "volume": "46", "issue": "11", "leaf": 35, "column": 1}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-11-01_46_11", "date": "1929-11-01", "volume": "46", "issue": "11", "leaf": 35, "column": 2}

# Column 1 (Leaf 34 Col 3 bottom - 11 dogs)
c1_dogs = [
    {
        "name": "ALMA V LAUCHENWEIER", "sex": "Female", "registration_number": "704903",
        "birth_date": "Dec. 2, 1926", "color": "Blk, rd",
        "owner": "Jacob Hoeffler", "owner_location": None,
        "breeder": "Charles Franck", "breeder_location": "West New York, N. J.",
        "sire": "Baron v Richthofen", "sire_registration_number": "526664",
        "dam": "Alma v Siegestor", "dam_registration_number": "427759",
        "source": meta_c1
    },
    {
        "name": "ARTUS V GETHSEMANEECK", "sex": "Male", "registration_number": "706972",
        "birth_date": "April 17, 1925", "color": "Br, rd",
        "owner": "J. Gast", "owner_location": None,
        "breeder": "Paul Sombeck", "breeder_location": "Germany",
        "sire": "Moritz v Blankenfeis", "sire_registration_number": None,
        "dam": "Leddy v d Blankenburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Burschel v Simmenau", "registration_number": None},
            {"role": "dam_of_dam", "name": "Asta Voss", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Senta v Jagerheim", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Arno v d Glucksburg", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Gudrun v Hornegg", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_sire", "name": "Lore v d Eckardtsburg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Rappo v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Angola v d Eckardtsburg", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Achim v Langerode", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Leddy v d Blankenburg", "registration_number": None}
        ],
        "source": meta_c1
    },
    {
        "name": "BARON V SIMMINEAU", "sex": "Male", "registration_number": "707134",
        "birth_date": "May 10, 1928", "color": "Blk, tn",
        "owner": "J. Hoyt Wilson", "owner_location": None,
        "breeder": "O. K. Lindquist", "breeder_location": "Detroit, Mich.",
        "sire": "A. Rappo of Pontchartrain", "sire_registration_number": "439031",
        "dam": "Kona v Nibelungenhort", "dam_registration_number": "647954",
        "source": meta_c1
    },
    {
        "name": "BEAUTY V BARMEN ELBERFELD", "sex": "Female", "registration_number": "706538",
        "birth_date": "Sept. 22, 1928", "color": "Chlte, br & tn",
        "owner": "Charles F. Kluber", "owner_location": None,
        "breeder": "Fanny Cordero", "breeder_location": "Flushing, L. I., N. Y.",
        "sire": "Peter Pan of Liepzig", "sire_registration_number": "501109",
        "dam": "Ellis of Arkenden", "dam_registration_number": "601591",
        "source": meta_c1
    },
    {
        "name": "BLITZ V NORDHEIM", "sex": "Male", "registration_number": "706506",
        "birth_date": "Sept. 18, 1927", "color": "Blk & tn",
        "owner": "J. F. Webb", "owner_location": None,
        "breeder": "Ray Heerman", "breeder_location": "Sheboygan, Wis.",
        "sire": "Flux v Nordheim", "sire_registration_number": "609080",
        "dam": "Letty v Nordheim", "dam_registration_number": "663265",
        "source": meta_c1
    },
    {
        "name": "BOLO", "sex": "Male", "registration_number": "705331",
        "birth_date": "Aug. 9, 1924", "color": "Blue & tn",
        "owner": "James H. Murphy, Jr.", "owner_location": None,
        "breeder": "Beck Kennels", "breeder_location": "Middleboro, Mass.",
        "sire": "Astor v Friedrichshof", "sire_registration_number": "319177",
        "dam": "Saara Schuess", "dam_registration_number": "361407",
        "source": meta_c1
    },
    {
        "name": "CELIA V SIGALSBURG", "sex": "Female", "registration_number": "705091",
        "birth_date": "Aug. 2, 1928", "color": "Blk & tn",
        "owner": "Margaret Schang", "owner_location": None,
        "breeder": "S. E. Ochsner", "breeder_location": "Milwaukee, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Delsa v de Blankenburg", "dam_registration_number": "532772",
        "source": meta_c1
    },
    {
        "name": "CENTA OF MICKBURN", "sex": "Female", "registration_number": "706368",
        "birth_date": "Oct. 19, 1927", "color": "Rd, tn mkgs",
        "owner": "Leslie L. Romine", "owner_location": None,
        "breeder": "Mickburn Kennels", "breeder_location": "Eldorado, Ill.",
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Centa v Rinkenbuehl", "dam_registration_number": "316606",
        "source": meta_c1
    },
    {
        "name": "CLAUS V HINDENDORFF", "sex": "Male", "registration_number": "705911",
        "birth_date": "July 28, 1928", "color": "Blk & tn",
        "owner": "L. W. Schnitzer", "owner_location": "Glenview, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Dragon v Hindendorff", "sire_registration_number": "379450",
        "dam": "Josephine v d Spree", "dam_registration_number": "560427",
        "source": meta_c1
    },
    {
        "name": "CLAUS V POPP", "sex": "Male", "registration_number": "704070",
        "birth_date": "Nov. 11, 1928", "color": "Blk, tn mkgs",
        "owner": "Gerald W. Fauth", "owner_location": None,
        "breeder": "T. E. Popp", "breeder_location": "West Allis, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dortell v Popp", "dam_registration_number": "526001",
        "source": meta_c1
    },
    {
        "name": "DOBA V SCHMIDT RAPP", "sex": "Female", "registration_number": "706444",
        "birth_date": "Oct. 20, 1928", "color": "Rd & tn",
        "owner": "H. W. Rapp", "owner_location": None,
        "breeder": "A. W. Schmidt", "breeder_location": "Akron, Ohio",
        "sire": "Apollo v Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Laura of Mickburn", "dam_registration_number": "578933",
        "source": meta_c1
    }
]

# Column 2 (Leaf 35 Col 1 - 20 dogs)
c2_dogs = [
    {
        "name": "DREW V DREHBRUCKE", "sex": "Male", "registration_number": "705945",
        "birth_date": "Oct. 1, 1928", "color": "Blk & rd",
        "owner": "Leo S. Rassieur", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Benno v Drehbruecke", "sire_registration_number": "639146",
        "dam": "Anita v Grossmannstein", "dam_registration_number": "605203",
        "source": meta_c2
    },
    {
        "name": "DUKE OF LA DARE", "sex": "Male", "registration_number": "706596",
        "birth_date": "Aug. 23, 1928", "color": "Blk, tn",
        "owner": "Marie and Guy Lauren", "owner_location": "Chicago, Ill.",
        "breeder": "E. D. Morrison", "breeder_location": "Lincoln, Nebr.",
        "sire": "Duke v Weigand", "sire_registration_number": "663995",
        "dam": "Brunhilda v Wiedensahl II", "dam_registration_number": "664968",
        "source": meta_c2
    },
    {
        "name": "ETTE V D WILSONA", "sex": "Female", "registration_number": "705894",
        "birth_date": "Oct. 1, 1928", "color": "Blk, rd",
        "owner": "F. C. Fuqua", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Benno v Drehbruecke", "sire_registration_number": "639146",
        "dam": "Anita v Grossmannstein", "dam_registration_number": "605203",
        "source": meta_c2
    },
    {
        "name": "FAUST V DEUTSCHEN-ECK", "sex": "Male", "registration_number": "704006",
        "birth_date": "Nov. 25, 1921", "color": "Br, rd",
        "owner": "Sally A. Chamberlin", "owner_location": None,
        "breeder": "E. Wolfsberg", "breeder_location": "Germany",
        "sire": "Rex v Deutschen-Eck", "sire_registration_number": None,
        "dam": "Irma v Lahnfels", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Graf Edel v Ilm-Athen", "registration_number": None},
            {"role": "dam_of_dam", "name": "Nora v Lahnfels", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Lord v Ried", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Hexe v Lahnfels", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Graf Edel v Ilm-Athen", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Prinz v Ilm-Athen", "registration_number": None},
            {"role": "sire_of_sire", "name": "Betti I v Ilm-Athen", "registration_number": None},
            {"role": "dam_of_sire", "name": "Rex v Deutschen-Eck", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Argo v Wetzler", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Minka v Luapheim", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Roland v Esting", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Blanka v Haiterbach", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "FAUSTINA V D KONINGSTAD", "sex": "Female", "registration_number": "704007",
        "birth_date": "Oct. 31, 1927", "color": "Rd & tn",
        "owner": "Sally A. Chamberlin", "owner_location": "Fort Riley, Kans.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Faust v Deutschen-Eck", "sire_registration_number": "704006",
        "dam": "Lotta v Dowd", "dam_registration_number": "551479",
        "source": meta_c2
    },
    {
        "name": "FITZGERALD'S DIN", "sex": "Male", "registration_number": "705989",
        "birth_date": "Nov. 20, 1928", "color": "Blk & tn",
        "owner": "Sara Ellen Fitzgerald", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Nebraska Bob", "sire_registration_number": "654601",
        "dam": "Rosa of Ballycoreagh", "dam_registration_number": "608807",
        "source": meta_c2
    },
    {
        "name": "FRIEDA RUDOLPHSBURG", "sex": "Female", "registration_number": "705725",
        "birth_date": "June 27, 1928", "color": "Blk & rust",
        "owner": "Howard M. Longley", "owner_location": None,
        "breeder": "Edith L. Keirstead", "breeder_location": "Groton, Mass.",
        "sire": "Ritz Carlton", "sire_registration_number": "485720",
        "dam": "Fricka v d Nibelungenhort", "dam_registration_number": "577937",
        "source": meta_c2
    },
    {
        "name": "FRITZ V BLANKENBURG", "sex": "Male", "registration_number": "706785",
        "birth_date": "July 12, 1928", "color": "Blk & tn",
        "owner": "William L. Hills", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "Cupertino, Calif.",
        "sire": "Burschel v Falkensee", "sire_registration_number": "553217",
        "dam": "Asta v Stolzenberg", "dam_registration_number": "553220",
        "source": meta_c2
    },
    {
        "name": "FRITZ V DUFFIELD", "sex": "Male", "registration_number": "704573",
        "birth_date": "July 28, 1928", "color": "Blk & tn",
        "owner": "B. F. Stein", "owner_location": None,
        "breeder": "L. W. Schnitzer", "breeder_location": "Glenview, Ill.",
        "sire": "Dragon v Hindendorff", "sire_registration_number": "379450",
        "dam": "Josephine v d Spree", "dam_registration_number": "560427",
        "source": meta_c2
    },
    {
        "name": "FRITZ V OXBO", "sex": "Male", "registration_number": "706087",
        "birth_date": "Feb. 7, 1929", "color": "Rd & tn",
        "owner": "Nelson Durham", "owner_location": None,
        "breeder": "F. C. Fuqua", "breeder_location": "Seattle, Wash.",
        "sire": "Arnold v Minkelried", "sire_registration_number": "513005",
        "dam": "Gerti v Hohenschwanau", "dam_registration_number": "670137",
        "source": meta_c2
    },
    {
        "name": "GREIF V SEDREVLA", "sex": "Male", "registration_number": "704551",
        "birth_date": "Aug. 28, 1928", "color": "Blk & tn",
        "owner": "Harry M. Dickinson", "owner_location": None,
        "breeder": "Karl P's Graeuwen", "breeder_location": "Annandale, S. I., N. Y.",
        "sire": "Fritz v Edjo", "sire_registration_number": "605709",
        "dam": "Maus v Sedrevla", "dam_registration_number": "671985",
        "source": meta_c2
    },
    {
        "name": "GRETA V BURGHOLZ", "sex": "Female", "registration_number": "706597",
        "birth_date": "Dec. 29, 1927", "color": "Blk, rd",
        "owner": "M. K. Price", "owner_location": None,
        "breeder": "Mrs. M. G. Alderman", "breeder_location": "High Point, N. C.",
        "sire": "Von Burgholz's Benno", "sire_registration_number": "610000",
        "dam": "Rowdy's Manta", "dam_registration_number": "609999",
        "source": meta_c2
    },
    {
        "name": "HANSI V. MUSENBACH", "sex": "Male", "registration_number": "706998",
        "birth_date": "Jan. 25, 1929", "color": "Blk & tn",
        "owner": "Clara D. Hayes", "owner_location": None,
        "breeder": "Margaret L. Fahey", "breeder_location": "Lewiston, Me.",
        "sire": "Cuno v Musenbach", "sire_registration_number": "596712",
        "dam": "Rota-Bella v Steuben", "dam_registration_number": "516684",
        "source": meta_c2
    },
    {
        "name": "HELMA V D SPREE", "sex": "Female", "registration_number": "704385",
        "birth_date": "Sept. 19, 1928", "color": "Br & tn",
        "owner": "L. H. Rogers", "owner_location": None,
        "breeder": "J. A. Finnicum", "breeder_location": "Columbus, Ohio",
        "sire": "Leuthold of Pontchartrain", "sire_registration_number": "629194",
        "dam": "Bella of Pontchartrain", "dam_registration_number": "578596",
        "source": meta_c2
    },
    {
        "name": "HILDA V NIBELUNGENHORT", "sex": "Female", "registration_number": "706870",
        "birth_date": "June 15, 1929", "color": "Blk & tn",
        "owner": "L. P. Haldeman", "owner_location": None,
        "breeder": "C. B. McCullough", "breeder_location": "Morehead, Ky.",
        "sire": "Storm v Nibelungenhort", "sire_registration_number": "640456",
        "dam": "Neta Nibelungenhort", "dam_registration_number": "687457",
        "source": meta_c2
    },
    {
        "name": "HUGO V NIBLUNGENHORT", "sex": "Male", "registration_number": "706776",
        "birth_date": "Mar. 31, 1929", "color": "Blk & tn",
        "owner": "Francis H. Phipps", "owner_location": None,
        "breeder": "J. F. Webb", "breeder_location": "Wenatchee, Wash.",
        "sire": "Count Monte v Nibelungenhort", "sire_registration_number": "379730",
        "dam": "Sally of Nibelungenhort", "dam_registration_number": "699124",
        "source": meta_c2
    },
    {
        "name": "IDA V NIETZE", "sex": "Female", "registration_number": "706537",
        "birth_date": "Apr. 6, 1927", "color": "Blk & rd",
        "owner": "Henry A. Lauhoff", "owner_location": None,
        "breeder": "Otto Klaus", "breeder_location": "Detroit, Mich.",
        "sire": "A. Fidelis of Pontchartrain", "sire_registration_number": "440793",
        "dam": "Grafin Klaus v Belling", "dam_registration_number": "505583",
        "source": meta_c2
    },
    {
        "name": "ILLA V POPP", "sex": "Female", "registration_number": "707425",
        "birth_date": "Nov. 11, 1928", "color": "Blk, tn",
        "owner": "T. E. Popp", "owner_location": "West Allis, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dortell v Popp", "dam_registration_number": "526001",
        "source": meta_c2
    },
    {
        "name": "JOCKEL V LOBENSTEIN", "sex": "Male", "registration_number": "706937",
        "birth_date": "June 4, 1926", "color": "Blk, rd",
        "owner": "Edward A. Hunter", "owner_location": None,
        "breeder": "Otto Humann", "breeder_location": "Germany",
        "sire": "Alto v Sigalsburg", "sire_registration_number": None,
        "dam": "Hedda v Margarethenhof", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Burschel v Coln", "registration_number": None},
            {"role": "dam_of_dam", "name": "Dora v d Eckardtsburg", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Isolde v Coln", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Burschel v Coln", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Zeus v Parthengrund", "registration_number": None},
            {"role": "sire_of_sire", "name": "Lux v d Blankenburg", "registration_number": "571492"},
            {"role": "dam_of_sire", "name": "Lotte v Roneckenstein", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Dora v Wiesengrund", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "KITTY V RODELTAL", "sex": "Female", "registration_number": "706938",
        "birth_date": "June 2, 1925", "color": "Blk, rd",
        "owner": "Edward A. Hunter", "owner_location": None,
        "breeder": "Max Schott", "breeder_location": "Germany",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Fee v Rodeltal", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Faust v d Pleissenburg", "registration_number": None},
            {"role": "dam_of_dam", "name": "Carla v Rodeltal", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Ledy v Rodeltal", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Zeus v Parthengrund", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Juno v Parthengrund", "registration_number": None}
        ],
        "source": meta_c2
    }
]

# Column 3 (Leaf 35 Col 2 - 15 dogs ending before POINTERS)
c3_dogs = [
    {
        "name": "KOENIG DER GREIFEN", "sex": "Male", "registration_number": "705990",
        "birth_date": "Aug. 28, 1928", "color": "Blk & tn",
        "owner": "Carl Brockenauer", "owner_location": None,
        "breeder": "Karl P.'s Graeuwen", "breeder_location": "Brooklyn, N. Y.",
        "sire": "Fritz v Edjo", "sire_registration_number": "605709",
        "dam": "Maus v Sedrevla", "dam_registration_number": "671985",
        "source": meta_c3
    },
    {
        "name": "KUNDRY V ZAUBERSCHLOSS", "sex": "Female", "registration_number": "706864",
        "birth_date": "Oct. 24, 1928", "color": "Blk & rust",
        "owner": "Geoffrey Landesman", "owner_location": "Cleveland, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Lisel v Katzenellenbogan", "dam_registration_number": "620914",
        "source": meta_c3
    },
    {
        "name": "LADY OF MIDDLETOWN", "sex": "Female", "registration_number": "704063",
        "birth_date": "June 28, 1925", "color": "Blk, rd, br mkgs",
        "owner": "W. N. McCoy", "owner_location": None,
        "breeder": "W. B. Masters", "breeder_location": "Bowerston, Ohio",
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Berta Rota v Nibelungenhort", "dam_registration_number": "370074",
        "source": meta_c3
    },
    {
        "name": "LOST AGNES", "sex": "Female", "registration_number": "704162",
        "birth_date": "June 16, 1927", "color": "Rust, rd & blk",
        "owner": "Anton Studeny", "owner_location": None,
        "breeder": "Norman P. Black", "breeder_location": "Cleveland, Ohio",
        "sire": "Benno v d Waldlust", "sire_registration_number": "503559",
        "dam": "Bertha v Taxispark", "dam_registration_number": "503560",
        "source": meta_c3
    },
    {
        "name": "MITZIE V BUDAPEST", "sex": "Female", "registration_number": "704904",
        "birth_date": "Oct. 15, 1927", "color": "Blk, rd",
        "owner": "Jacob Hoeffler", "owner_location": None,
        "breeder": "Owner", "breeder_location": "West Englewood, N. J.",
        "sire": "Arno v Blumenthal", "sire_registration_number": "678672",
        "dam": "Alma v Lauchenweier", "dam_registration_number": "704903",
        "source": meta_c3
    },
    {
        "name": "NIPPUR V FALKENTURM", "sex": "Male", "registration_number": "704777",
        "birth_date": "Jan. 15, 1929", "color": "Blk & rust",
        "owner": "Leslie L. Romine", "owner_location": "Livingston, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Max De Haven", "sire_registration_number": "604075",
        "dam": "Hilda v Falkenturm", "dam_registration_number": "637640",
        "source": meta_c3
    },
    {
        "name": "OH BOY", "sex": "Male", "registration_number": "704374",
        "birth_date": "Feb. 28, 1929", "color": "Blk & tn",
        "owner": "Charles B. Hays", "owner_location": None,
        "breeder": "Henry J. Dwillard", "breeder_location": "Kalamazoo, Mich.",
        "sire": "Printz Negus v Nibelungenhort", "sire_registration_number": "379731",
        "dam": "Presque Isle Zareda", "dam_registration_number": "369303",
        "source": meta_c3
    },
    {
        "name": "PAT V BURGFRIED", "sex": "Male", "registration_number": "706970",
        "birth_date": "Feb. 12, 1929", "color": "Blk & rust",
        "owner": "C. A. Powhatan", "owner_location": None,
        "breeder": "L. E. Reamer", "breeder_location": "Okmulgee, Okla.",
        "sire": "Arno v Burgfried", "sire_registration_number": "426603",
        "dam": "Countess v Telless", "dam_registration_number": "435136",
        "source": meta_c3
    },
    {
        "name": "RANDIE", "sex": "Male", "registration_number": "705856",
        "birth_date": "Aug. 22, 1928", "color": "Blk & tn",
        "owner": "Leo P. Debes", "owner_location": None,
        "breeder": "Otto C. Benke", "breeder_location": "Wichita, Kans.",
        "sire": "Dietrich v d Barbarossahoehle", "sire_registration_number": "561617",
        "dam": "Nuja v Streslau", "dam_registration_number": "586735",
        "source": meta_c3
    },
    {
        "name": "RED V BURGHOLZ", "sex": "Male", "registration_number": "705143",
        "birth_date": "Aug. 19, 1928", "color": "Br & tn",
        "owner": "Harold M. Bates", "owner_location": None,
        "breeder": "John Schofield", "breeder_location": "Elverson, Pa.",
        "sire": "Armin v Burgfried", "sire_registration_number": "430843",
        "dam": "Countess v Burgholz", "dam_registration_number": "449862",
        "source": meta_c3
    },
    {
        "name": "REVA FROM AKRON", "sex": "Female", "registration_number": "706961",
        "birth_date": "Oct. 21, 1928", "color": "Blk & rd rust",
        "owner": "Mrs. J. Thompson White", "owner_location": None,
        "breeder": "A. C. Wales", "breeder_location": "Akron, Ohio",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Reva of Pontchartrain", "dam_registration_number": "624345",
        "source": meta_c3
    },
    {
        "name": "REX OF OXBO", "sex": "Male", "registration_number": "706997",
        "birth_date": "Apr. 11, 1929", "color": "Blk & tn",
        "owner": "James W. Bigelow", "owner_location": None,
        "breeder": "F. C. Fuqua", "breeder_location": "Seattle, Wash.",
        "sire": "Arnold II", "sire_registration_number": "634930",
        "dam": "Erda of Oxbo", "dam_registration_number": "679295",
        "source": meta_c3
    },
    {
        "name": "RITA V POPP", "sex": "Female", "registration_number": "707424",
        "birth_date": "Nov. 11, 1928", "color": "Blk & tn",
        "owner": "T. E. Popp", "owner_location": "West Allis, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dortell v Popp", "dam_registration_number": "526001",
        "source": meta_c3
    },
    {
        "name": "ROBINSON'S SULLY", "sex": "Male", "registration_number": "706298",
        "birth_date": "Oct. 3, 1927", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Dorle v Leipzig", "dam_registration_number": "462575",
        "source": meta_c3
    },
    {
        "name": "ZITA V BRAMBERG", "sex": "Female", "registration_number": "705275",
        "birth_date": "Apr. 17, 1927", "color": "Rd & tn",
        "owner": "John J. Twohill", "owner_location": None,
        "breeder": "William A. Barron", "breeder_location": "So. Manchester, Conn.",
        "sire": "Baron v Richthofen", "sire_registration_number": "526664",
        "dam": "Dina v Hetzendorf", "dam_registration_number": "504499",
        "source": meta_c3
    }
]

all_46 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1929-11 dogs: {len(all_46)} (Expected: 46)")
print(f"Col 1: {len(c1_dogs)} (Expected: 11)")
print(f"Col 2: {len(c2_dogs)} (Expected: 20)")
print(f"Col 3: {len(c3_dogs)} (Expected: 15)")

Path("stud-scrape/data/verified_1929_11.json").write_text(json.dumps(all_46, indent=2), encoding="utf-8")
print("Saved clean 1929-11 records to stud-scrape/data/verified_1929_11.json")
