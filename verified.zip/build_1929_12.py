import json
from pathlib import Path

meta_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-12-01_46_12", "date": "1929-12-01", "volume": "46", "issue": "12", "leaf": 45, "column": 1}
meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-12-01_46_12", "date": "1929-12-01", "volume": "46", "issue": "12", "leaf": 45, "column": 2}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1929-12-01_46_12", "date": "1929-12-01", "volume": "46", "issue": "12", "leaf": 45, "column": 3}

# Column 1 (Leaf 45 Col 1 bottom - 8 dogs)
c1_dogs = [
    {
        "name": "ADONIS OF PONTCHARTRAIN", "sex": "Male", "registration_number": "710287",
        "birth_date": "Dec. 1, 1928", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Hella of Pontchartrain", "dam_registration_number": "497377",
        "source": meta_c1
    },
    {
        "name": "AIDA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "710289",
        "birth_date": "May 1, 1928", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Werra v Ostersee", "dam_registration_number": "476468",
        "source": meta_c1
    },
    {
        "name": "ALARIC OF DAWN", "sex": "Male", "registration_number": "707789",
        "birth_date": "Mar. 3, 1929", "color": "Blk & rust rd",
        "owner": "Mrs. Isidore Schuman", "owner_location": None,
        "breeder": "H. S. Newson", "breeder_location": "Wheaton, Ill.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Alphabet of Dawn", "dam_registration_number": "681563",
        "source": meta_c1
    },
    {
        "name": "ALTAS OF MIDDLETOWN", "sex": "Female", "registration_number": "711211",
        "birth_date": "June 2, 1928", "color": "Blk & tn",
        "owner": "W. N. McCoy", "owner_location": "Middletown, O.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Westphalia Dyno v Wiesengrund", "sire_registration_number": "365520",
        "dam": "Asta v Rauscheberg", "dam_registration_number": "504315",
        "source": meta_c1
    },
    {
        "name": "ALTROLL V D STROSSEN", "sex": "Male", "registration_number": "709947",
        "birth_date": "Mar. 6, 1929", "color": "Blk & tn",
        "owner": "Cleona Woodbridge", "owner_location": None,
        "breeder": "Mrs. B. Delacourt", "breeder_location": "Los Angeles, Cal.",
        "sire": "Troll-Son v d Blankenburg", "sire_registration_number": "618743",
        "dam": "Rena v Strossen", "dam_registration_number": "664506",
        "source": meta_c1
    },
    {
        "name": "ANNIE", "sex": "Female", "registration_number": "711526",
        "birth_date": "Sept. 1, 1928", "color": "Blk & tn",
        "owner": "Earl E. Straley", "owner_location": None,
        "breeder": "Geo. A. Danforth", "breeder_location": "Omaha, Neb.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Ochsner's Gretchen v Rottal", "dam_registration_number": "584695",
        "source": meta_c1
    },
    {
        "name": "ARKO V D SCHEFFELSBURG", "sex": "Male", "registration_number": "710298",
        "birth_date": "Apr. 2, 1926", "color": "Blk & rd",
        "owner": "F. C. Fuqua", "owner_location": None,
        "breeder": "Karl Huber", "breeder_location": "Germany",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Dolli v Wetterbach", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Achim v Langerode", "registration_number": None},
            {"role": "dam_of_dam", "name": "Hella v Wetterbach", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Schuft Kaiser", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Eleonora v Heimbachtal", "registration_number": None},
            {"role": "sire_of_sire", "name": "Achim v Langerode", "registration_number": None},
            {"role": "dam_of_sire", "name": "Prinz Leuthold v Hornegg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Asta v Starkenburg", "registration_number": None}
        ],
        "source": meta_c1
    },
    {
        "name": "ARTUS V D OLGAHOHE", "sex": "Male", "registration_number": "710297",
        "birth_date": "Sept. 8, 1926", "color": "Blk & rd",
        "owner": "F. C. Fuqua", "owner_location": None,
        "breeder": "Adolf Merkle", "breeder_location": "Germany",
        "sire": "Benno v d Hegenau", "sire_registration_number": None,
        "dam": "Drudl v Prassberg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Tiro v Ostersee", "registration_number": None},
            {"role": "dam_of_dam", "name": "Blanka v Atlantic", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Arnfried v Brandis", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Mignon v Parthengrund", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Tiro v Ostersee", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "sire_of_sire", "name": "Freya v Ostersee", "registration_number": None},
            {"role": "dam_of_sire", "name": "Stolz v Roeneckenstein", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Helma v Reussenstein", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Artus v Siegestor", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Fee v Reussenstein", "registration_number": None}
        ],
        "source": meta_c1
    }
]

# Column 2 (Leaf 45 Col 2 - 21 dogs)
c2_dogs = [
    {
        "name": "ASTA V D FRANKENFORT II", "sex": "Female", "registration_number": "709696",
        "birth_date": "Nov. 11, 1927", "color": "Blk, rust rd mkgs",
        "owner": "Joseph Bley", "owner_location": None,
        "breeder": "Ralph T. Miller", "breeder_location": "West Philadelphia, Pa.",
        "sire": "Trail'em Horstburg", "sire_registration_number": "545469",
        "dam": "Asta v d Frankenfort", "dam_registration_number": "627856",
        "source": meta_c2
    },
    {
        "name": "BEAU GESTE II", "sex": "Male", "registration_number": "711296",
        "birth_date": "July 19, 1929", "color": "Blk & tn",
        "owner": "Dorothea Rebmann", "owner_location": None,
        "breeder": "August L. Hatzfeld", "breeder_location": "Wilkinsburg, Pa.",
        "sire": "Arno v d Kanonenstadt", "sire_registration_number": "540314",
        "dam": "Anni v Dombachtal", "dam_registration_number": "669160",
        "source": meta_c2
    },
    {
        "name": "BLUE BOY", "sex": "Male", "registration_number": "709795",
        "birth_date": "Oct. 13, 1927", "color": "Bl, rust rd",
        "owner": "Mr. and Mrs. Frank L. Beck", "owner_location": None,
        "breeder": "Pete Donovan", "breeder_location": "Erie, Pa.",
        "sire": "Major v d Burgwall", "sire_registration_number": "436901",
        "dam": "Donovan's Gretchen", "dam_registration_number": "538598",
        "source": meta_c2
    },
    {
        "name": "BOZO V ROEMERHOF", "sex": "Male", "registration_number": "710475",
        "birth_date": "May 7, 1929", "color": "Rd & rust",
        "owner": "Paul B. Wallace", "owner_location": None,
        "breeder": "John W. Gage", "breeder_location": "Monticello, Ill.",
        "sire": "Peter v Roemerhof", "sire_registration_number": "616494",
        "dam": "Schwarze Dame", "dam_registration_number": "672699",
        "source": meta_c2
    },
    {
        "name": "BUD", "sex": "Male", "registration_number": "710643",
        "birth_date": "May 20, 1929", "color": "Blk & tn",
        "owner": "John W. Roxborough", "owner_location": None,
        "breeder": "Wm. H. Lawson", "breeder_location": "Detroit, Mich.",
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Lawson's Lily", "dam_registration_number": "587606",
        "source": meta_c2
    },
    {
        "name": "CITTI OF DHU VARREN", "sex": "Female", "registration_number": "711924",
        "birth_date": "Mar. 24, 1929", "color": "Blk & rd",
        "owner": "Edward A. Hunter", "owner_location": "Ann Arbor, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Marko v Siegerpark", "sire_registration_number": "601008",
        "dam": "Citti v Wilbrink", "dam_registration_number": "601009",
        "source": meta_c2
    },
    {
        "name": "DAWN OF DAYTON", "sex": "Female", "registration_number": "711031",
        "birth_date": "Sept. 23, 1928", "color": "Blk & tn",
        "owner": "J. D. Wickersham", "owner_location": "Dayton, O.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Black Guard", "sire_registration_number": "630172",
        "dam": "Diana v d Thueringen", "dam_registration_number": "663926",
        "source": meta_c2
    },
    {
        "name": "ELLA V ROEMERHOF", "sex": "Female", "registration_number": "711032",
        "birth_date": "June 2, 1927", "color": "Blk & tn",
        "owner": "Mrs. Bernhard Wiesel", "owner_location": "West New York, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Benno v Roemerhof", "sire_registration_number": "517073",
        "dam": "Caprice v Kioma", "dam_registration_number": "570512",
        "source": meta_c2
    },
    {
        "name": "ELLA V TELLESS", "sex": "Female", "registration_number": "708997",
        "birth_date": "Sept. 24, 1925", "color": "Blk & tn",
        "owner": "Arthur W. Macdonald", "owner_location": None,
        "breeder": "Mrs. M. S. Telless", "breeder_location": "Raynham, Mass.",
        "sire": "Bodo v Musenbach", "sire_registration_number": "332043",
        "dam": "Lucia v Telless", "dam_registration_number": "319375",
        "source": meta_c2
    },
    {
        "name": "ESTHER", "sex": "Female", "registration_number": "708696",
        "birth_date": "Oct. 15, 1925", "color": "Blk & tn",
        "owner": "B. F. Stein", "owner_location": None,
        "breeder": "Herbert E. Stange", "breeder_location": "Chicago, Ill.",
        "sire": "Asko v Bolanden", "sire_registration_number": "432279",
        "dam": "Princess Bea v Silverberg", "dam_registration_number": "403875",
        "source": meta_c2
    },
    {
        "name": "FLASH V AKRONA", "sex": "Female", "registration_number": "710338",
        "birth_date": "Oct. 20, 1928", "color": "Rd & tn",
        "owner": "A. W. Schmidt", "owner_location": "Akron, O.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Apollo v Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Laura of Mickburn", "dam_registration_number": "578933",
        "source": meta_c2
    },
    {
        "name": "FRITZ II", "sex": "Male", "registration_number": "711977",
        "birth_date": "Jan. 22, 1929", "color": "Rd & tn",
        "owner": "Clyde B. McLane", "owner_location": None,
        "breeder": "Geo. M. Henderson", "breeder_location": "Huntington, W. Va.",
        "sire": "Claus v d Spree, Jr.", "sire_registration_number": "512026",
        "dam": "Brunhilde of Bornholm", "dam_registration_number": "592815",
        "source": meta_c2
    },
    {
        "name": "GRAF FELIX V LUCKNER", "sex": "Male", "registration_number": "711445",
        "birth_date": "July 29, 1929", "color": "Blk, tn mkgs",
        "owner": "George H. Grant, 2nd", "owner_location": None,
        "breeder": "Marshall F. Bidwell", "breeder_location": "So. Windsor, Conn.",
        "sire": "Baron v Richthofen", "sire_registration_number": "526664",
        "dam": "Adda v Kanonenstadt", "dam_registration_number": "534153",
        "source": meta_c2
    },
    {
        "name": "GRETCHEN V BUETERSBURG", "sex": "Female", "registration_number": "707959",
        "birth_date": "July 18, 1929", "color": "Br & rust rd",
        "owner": "Wm. D. Schneider", "owner_location": None,
        "breeder": "Helen Krecker", "breeder_location": "Stonehurst, Pa.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Schatze v Horstburg", "dam_registration_number": "689932",
        "source": meta_c2
    },
    {
        "name": "HASSO V LEUTHBEL", "sex": "Male", "registration_number": "708180",
        "birth_date": "Sept. 19, 1928", "color": "Br & tn",
        "owner": "P. G. Felix", "owner_location": None,
        "breeder": "J. A. Finnicum", "breeder_location": "Columbus, O.",
        "sire": "Leuthold of Pontchartrain", "sire_registration_number": "629194",
        "dam": "Bella of Pontchartrain", "dam_registration_number": "578596",
        "source": meta_c2
    },
    {
        "name": "HENSHAW'S POLO", "sex": "Male", "registration_number": "707788",
        "birth_date": "Apr. 11, 1929", "color": "Blk & tn",
        "owner": "G. A. Henshaw, Jr.", "owner_location": None,
        "breeder": "Robert E. Ellis", "breeder_location": "San Angelo, Tex.",
        "sire": "Arno v Burgfried", "sire_registration_number": "426603",
        "dam": "Fidgety", "dam_registration_number": "691489",
        "source": meta_c2
    },
    {
        "name": "ISMENE V D HOHEN", "sex": "Female", "registration_number": "711109",
        "birth_date": "Mar. 31, 1928", "color": "Blk, tn mkgs",
        "owner": "Sidney P. Seeler", "owner_location": None,
        "breeder": "Ruth von Hoegen", "breeder_location": "Towaco, N. J.",
        "sire": "Prinz Favoriet v d Koningstad", "sire_registration_number": "420325",
        "dam": "Berta Rota v Nibelungenhort", "dam_registration_number": "370074",
        "source": meta_c2
    },
    {
        "name": "JACK V MEISEHEIM", "sex": "Male", "registration_number": "710238",
        "birth_date": "Mar. 26, 1928", "color": "Blk & tn",
        "owner": "Chas. Herrmann", "owner_location": None,
        "breeder": "W. S. Goins", "breeder_location": "E. Vaughn, N. Mex.",
        "sire": "Burschel v d Spree", "sire_registration_number": "487194",
        "dam": "Maina Fra Duncan", "dam_registration_number": "562196",
        "source": meta_c2
    },
    {
        "name": "JUNYA", "sex": "Male", "registration_number": "710233",
        "birth_date": "May 10, 1928", "color": "Blk & tn",
        "owner": "Otto Beuke", "owner_location": "Wichita, Kans.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Dietrich v d Barbarossahoehle", "sire_registration_number": "561617",
        "dam": "Hilda of Pontchartrain", "dam_registration_number": "497378",
        "source": meta_c2
    },
    {
        "name": "LADY KWIK", "sex": "Female", "registration_number": "707649",
        "birth_date": "Aug. 4, 1928", "color": "Blk & rust rd",
        "owner": "Frank X. Simon", "owner_location": None,
        "breeder": "Ralph Miller", "breeder_location": "Philadelphia, Pa.",
        "sire": "Trail'em Horstburg", "sire_registration_number": "545469",
        "dam": "Trail'em Dinah", "dam_registration_number": "569502",
        "source": meta_c2
    },
    {
        "name": "LADY VEDA V EDELBLUT", "sex": "Female", "registration_number": "708435",
        "birth_date": "June 15, 1929", "color": "Blk & rust rd",
        "owner": "Julius R. Offenhauer", "owner_location": None,
        "breeder": "H. S. Newsom", "breeder_location": "Chicago, Ill.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Schatz v Ostersee", "dam_registration_number": "514975",
        "source": meta_c2
    }
]

# Column 3 (Leaf 45 Col 3 - 19 dogs ending before POINTERS)
c3_dogs = [
    {
        "name": "LASKA V NIBELUNGENHORT", "sex": "Female", "registration_number": "708971",
        "birth_date": "Apr. 28, 1927", "color": "Blk & tn",
        "owner": "H. F. Steffan", "owner_location": None,
        "breeder": "W. Propst, Jr.", "breeder_location": "Concord, N. C.",
        "sire": "Duke v Nibelungenhort", "sire_registration_number": "584997",
        "dam": "Peggy of Steubenfield", "dam_registration_number": "402123",
        "source": meta_c3
    },
    {
        "name": "LINDY V BENNO", "sex": "Female", "registration_number": "710927",
        "birth_date": "May 16, 1927", "color": "Blk & tn",
        "owner": "Mrs. Elmer Schweninger", "owner_location": None,
        "breeder": "H. B. Hark", "breeder_location": "Glendale, O.",
        "sire": "Benno v Roemerhof", "sire_registration_number": "517073",
        "dam": "Tora v d Blankenburg", "dam_registration_number": "496696",
        "source": meta_c3
    },
    {
        "name": "LUCKY BOY BEUKE", "sex": "Male", "registration_number": "710232",
        "birth_date": "Mar. 8, 1928", "color": "Blk & tn",
        "owner": "Otto Beuke", "owner_location": "Wichita, Kans.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Westphalia Dyno v Wiesengrund", "sire_registration_number": "365520",
        "dam": "Nuja v Streslau", "dam_registration_number": "586735",
        "source": meta_c3
    },
    {
        "name": "MARQUISIA", "sex": "Female", "registration_number": "709446",
        "birth_date": "May 29, 1929", "color": "Blk & tn",
        "owner": "Joseph Norkovics", "owner_location": None,
        "breeder": "Joseph Preu", "breeder_location": "Corona, L. I., N. Y.",
        "sire": "Cy of Syosset", "sire_registration_number": "558079",
        "dam": "Elka of Arkeden", "dam_registration_number": "642584",
        "source": meta_c3
    },
    {
        "name": "NORDICA V D HOHEN", "sex": "Female", "registration_number": "709069",
        "birth_date": "Nov. 2, 1928", "color": "Blk & tn",
        "owner": "Mrs. M. von Hoegen", "owner_location": None,
        "breeder": "Mrs. L. H. Malz", "breeder_location": "Jamaica, L. I., N. Y.",
        "sire": "Westphalia Prinz Carlo v d Koningstadt", "sire_registration_number": "365521",
        "dam": "Dina v Burgfried", "dam_registration_number": "586788",
        "source": meta_c3
    },
    {
        "name": "PONTCHARTRAIN'S PRINZ FIGARO", "sex": "Male", "registration_number": "707624",
        "birth_date": "Mar. 10, 1929", "color": "Blk & rd",
        "owner": "F. L. Young", "owner_location": None,
        "breeder": "Glenn Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Tilly v Melrapp", "dam_registration_number": "462651",
        "source": meta_c3
    },
    {
        "name": "PRINCE CLAUS OF PONTCHARTRAIN", "sex": "Male", "registration_number": "710286",
        "birth_date": "Feb. 1, 1929", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Ilisa of Pontchartrain", "dam_registration_number": "571491",
        "source": meta_c3
    },
    {
        "name": "PRINCE JOCKEL OF RHINEGOLD", "sex": "Male", "registration_number": "710171",
        "birth_date": "Apr. 26, 1929", "color": "Br & tn",
        "owner": "Donald Garpow", "owner_location": None,
        "breeder": "J. C. Zimmerman", "breeder_location": "Detroit, Mich.",
        "sire": "Jockel v Loebenstein", "sire_registration_number": "706937",
        "dam": "Alli of Rhinegold", "dam_registration_number": "560310",
        "source": meta_c3
    },
    {
        "name": "PRINCE OF NEWPORT", "sex": "Male", "registration_number": "711737",
        "birth_date": "July 27, 1929", "color": "Blk & tn",
        "owner": "August Bertmann", "owner_location": None,
        "breeder": "Sofie Frolich", "breeder_location": "Cincinnati, O.",
        "sire": "Cito v d Margaretenau", "sire_registration_number": "685406",
        "dam": "Angola v d Margaretenau", "dam_registration_number": "685402",
        "source": meta_c3
    },
    {
        "name": "PRINCESS BETTY OF PONTCHARTRAIN", "sex": "Female", "registration_number": "710288",
        "birth_date": "Mar. 28, 1929", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Freia v d Butersburg of Ardwin", "dam_registration_number": "499561",
        "source": meta_c3
    },
    {
        "name": "PRINCESS B OF PONTCHARTRAIN", "sex": "Female", "registration_number": "710339",
        "birth_date": "Mar. 28, 1929", "color": "Blk & rd",
        "owner": "Richard S. Quigley", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Freia v d Buetersburg", "dam_registration_number": "499561",
        "source": meta_c3
    },
    {
        "name": "PRINCESS FLORA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "710290",
        "birth_date": "Mar. 10, 1929", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Tilly v Melrapp", "dam_registration_number": "462651",
        "source": meta_c3
    },
    {
        "name": "PUPRO", "sex": "Female", "registration_number": "710340",
        "birth_date": "Nov. 1, 1926", "color": "Blk & tn",
        "owner": "James H. Murphy, Jr.", "owner_location": None,
        "breeder": "Charles Boyden", "breeder_location": "Boston, Mass.",
        "sire": "Haig", "sire_registration_number": "557312",
        "dam": "Dinah", "dam_registration_number": "569147",
        "source": meta_c3
    },
    {
        "name": "QUEEN OF DAVANNA", "sex": "Female", "registration_number": "708772",
        "birth_date": "Feb. 12, 1929", "color": "Blk & rust",
        "owner": "A. O. Laughlin", "owner_location": "Akron, O.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Pride of Davanna", "dam_registration_number": "696015",
        "source": meta_c3
    },
    {
        "name": "QUEEN ISOLDE", "sex": "Female", "registration_number": "709288",
        "birth_date": "Aug. 1, 1927", "color": "Blk & tn",
        "owner": "Edward C. Heil", "owner_location": "Chicago, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Caesar v d Riedburg", "sire_registration_number": "534129",
        "dam": "Eastleigh Isolde", "dam_registration_number": "379318",
        "source": meta_c3
    },
    {
        "name": "REDDY V PETERSHOFF", "sex": "Female", "registration_number": "708854",
        "birth_date": "July 8, 1929", "color": "Rd & tn",
        "owner": "Jay Noble Emley", "owner_location": None,
        "breeder": "Mr. and Mrs. Fred Cook", "breeder_location": "Painted Post, N. Y.",
        "sire": "Blitz Dorn of Pontchartrain", "sire_registration_number": "578014",
        "dam": "Liesel v d Grenzlerburg", "dam_registration_number": "586610",
        "source": meta_c3
    },
    {
        "name": "ROPOLLO V TWIN LAKES", "sex": "Male", "registration_number": "707691",
        "birth_date": "Oct. 20, 1928", "color": "Blk & tn",
        "owner": "T. H. Schmidt", "owner_location": None,
        "breeder": "A. W. Schmidt", "breeder_location": "Akron, O.",
        "sire": "Apollo v Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Laura of Mickburn", "dam_registration_number": "578933",
        "source": meta_c3
    },
    {
        "name": "TRAIL'EM ADONIS", "sex": "Male", "registration_number": "709104",
        "birth_date": "Nov. 27, 1927", "color": "Br, rust rd",
        "owner": "Ralph T. Miller", "owner_location": None,
        "breeder": "V. R. Shattuck", "breeder_location": "Pittsburgh, Pa.",
        "sire": "Prinz Favorite v d Koningstad", "sire_registration_number": "420325",
        "dam": "Cordula v d Hunnenheide", "dam_registration_number": "558647",
        "source": meta_c3
    },
    {
        "name": "ZEPPELIN V SCHWARZSCHILD", "sex": "Male", "registration_number": "711191",
        "birth_date": "Apr. 11, 1929", "color": "Blk & tn",
        "owner": "C. P. Burnett", "owner_location": None,
        "breeder": "F. C. Fuqua", "breeder_location": "Seattle, Wash.",
        "sire": "Arnold II", "sire_registration_number": "634930",
        "dam": "Erda of Oxbo", "dam_registration_number": "679295",
        "source": meta_c3
    }
]

all_48 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1929-12 dogs: {len(all_48)} (Expected: 48)")
print(f"Col 1: {len(c1_dogs)} (Expected: 8)")
print(f"Col 2: {len(c2_dogs)} (Expected: 21)")
print(f"Col 3: {len(c3_dogs)} (Expected: 19)")

Path("stud-scrape/data/verified_1929_12.json").write_text(json.dumps(all_48, indent=2), encoding="utf-8")
print("Saved clean 1929-12 records to stud-scrape/data/verified_1929_12.json")
