import json
from pathlib import Path

meta_l45_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-01-01_47_1", "date": "1930-01-01", "volume": "47", "issue": "1", "leaf": 45, "column": 2}
meta_l45_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-01-01_47_1", "date": "1930-01-01", "volume": "47", "issue": "1", "leaf": 45, "column": 3}
meta_l46_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-01-01_47_1", "date": "1930-01-01", "volume": "47", "issue": "1", "leaf": 46, "column": 1}
meta_l46_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-01-01_47_1", "date": "1930-01-01", "volume": "47", "issue": "1", "leaf": 46, "column": 2}

# Leaf 45, Column 2 (Starts under PINSCHERS (Doberman) - 18 dogs)
dogs_l45_c2 = [
    {
        "name": "AJAX V TORREZ", "sex": "Male", "registration_number": "713682",
        "birth_date": "Feb. 22, 1929", "color": "Blk & tn",
        "owner": "Mr. and Mrs. E. C. Torrez", "owner_location": None,
        "breeder": "Ernest C. Torrez", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Burga v Torrez", "dam_registration_number": "628206",
        "source": meta_l45_c2
    },
    {
        "name": "ALTO V TORREZ", "sex": "Male", "registration_number": "713439",
        "birth_date": "Feb. 22, 1929", "color": "Blk & tn",
        "owner": "Mr. and Mrs. E. C. Torrez", "owner_location": None,
        "breeder": "Ernest C. Torrez", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Burga v Torrez", "dam_registration_number": "628206",
        "source": meta_l45_c2
    },
    {
        "name": "ALYSE V SIGALSBURG", "sex": "Female", "registration_number": "712472",
        "birth_date": "Feb. 22, 1929", "color": "Blk & tn",
        "owner": "M. S. Harrison", "owner_location": None,
        "breeder": "Ernest C. Torrez", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Burga v Torrez", "dam_registration_number": "628206",
        "source": meta_l45_c2
    },
    {
        "name": "ASTA V DANKWARDERODE", "sex": "Female", "registration_number": "714983",
        "birth_date": "Apr. 27, 1923", "color": "Blk & rd",
        "owner": "J. W. Oltmanns", "owner_location": None,
        "breeder": "Bruno Fechner", "breeder_location": "Germany",
        "sire": "Ador v Mydlinghofen", "sire_registration_number": None,
        "dam": "Afra v d Hofburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Jack v Stubbenhaus", "registration_number": None},
            {"role": "dam_of_dam", "name": "Ledy Weirauch", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Marko v Warteberg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Lotte II Gersbach", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Graf Waldo v d Strengbach", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Gretel v Dusselthal", "registration_number": None},
            {"role": "sire_of_sire", "name": "Bob v Rhein Erft", "registration_number": None},
            {"role": "dam_of_sire", "name": "Lotte v Bergischen Hof", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Jack v Stubbenhaus", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Lotte II Gersbach", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Roland Gersbach", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Dinorah v Hornegg", "registration_number": None}
        ],
        "source": meta_l45_c2
    },
    {
        "name": "ASTA V EDJO", "sex": "Female", "registration_number": "713233",
        "birth_date": "Nov. 20, 1925", "color": "Blk & tn",
        "owner": "William Searle", "owner_location": None,
        "breeder": "Joseph C. Blauner", "breeder_location": "Clifton, N. J.",
        "sire": "Apollo v Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Esther v Burgfried", "dam_registration_number": "453438",
        "source": meta_l45_c2
    },
    {
        "name": "BAUER'S JOY", "sex": "Female", "registration_number": "716313",
        "birth_date": "Feb. 27, 1929", "color": "Blk, tn mkgs",
        "owner": "Henry Bauer", "owner_location": None,
        "breeder": "Edward Rose", "breeder_location": "Queens Village, L. I., N. Y.",
        "sire": "Prinz Carlo of Westphalia", "sire_registration_number": "517068",
        "dam": "Mona Dora Zoic", "dam_registration_number": "412715",
        "source": meta_l45_c2
    },
    {
        "name": "BEAUTY V HOMEHILL", "sex": "Female", "registration_number": "716212",
        "birth_date": "Nov. 11, 1927", "color": "Blk with br mkgs",
        "owner": "Mrs. G. A. Rentschler", "owner_location": "Hamilton, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Lady v Homehill", "dam_registration_number": "565329",
        "source": meta_l45_c2
    },
    {
        "name": "BEAUTY V SEDREVLA", "sex": "Female", "registration_number": "713492",
        "birth_date": "Aug. 28, 1928", "color": "Blk & tn",
        "owner": "Karl P.'s Graeuwen", "owner_location": "Annadale, S. I., N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Fritz v Edjo", "sire_registration_number": "605709",
        "dam": "Maus v Sedrevla", "dam_registration_number": "671985",
        "source": meta_l45_c2
    },
    {
        "name": "BEDA V BOHLMAN", "sex": "Female", "registration_number": "715346",
        "birth_date": "Dec. 16, 1928", "color": "Blk, rd mkgs",
        "owner": "Glenn S. Staines", "owner_location": None,
        "breeder": "R. C. Reko", "breeder_location": "Mason City, Ia.",
        "sire": "Erlo v d Romerhof", "sire_registration_number": "468297",
        "dam": "Asta v Wiesenfels", "dam_registration_number": "683357",
        "source": meta_l45_c2
    },
    {
        "name": "BETTY OF WILMETTE", "sex": "Female", "registration_number": "713304",
        "birth_date": "Nov. 5, 1926", "color": "Rd & tn",
        "owner": "William C. Black", "owner_location": None,
        "breeder": "Spencer Otis, Jr.", "breeder_location": "Barrington, Ill.",
        "sire": "Dragon v Hindendorff", "sire_registration_number": "379450",
        "dam": "Gisela v Bayern", "dam_registration_number": "502580",
        "source": meta_l45_c2
    },
    {
        "name": "BIENE V MEISENHEIN", "sex": "Female", "registration_number": "713943",
        "birth_date": "Sept. 7, 1928", "color": "Blk & tn",
        "owner": "Chas. Herrmann", "owner_location": None,
        "breeder": "Mrs. Elmer Schweninger", "breeder_location": "Cincinnati, Ohio",
        "sire": "Boone v Sigalsburg", "sire_registration_number": "658766",
        "dam": "Hamer's Peggy", "dam_registration_number": "587825",
        "source": meta_l45_c2
    },
    {
        "name": "BINKS", "sex": "Male", "registration_number": "712217",
        "birth_date": "Oct. 16, 1928", "color": "Rd & tn",
        "owner": "Massena Clark", "owner_location": None,
        "breeder": "Harold A. Peck", "breeder_location": "Albany, N. Y.",
        "sire": "Benno v Roemerhof", "sire_registration_number": "517073",
        "dam": "Chummy", "dam_registration_number": "648332",
        "source": meta_l45_c2
    },
    {
        "name": "BLITZ V SIGALSBURG", "sex": "Male", "registration_number": "715138",
        "birth_date": "July 1, 1929", "color": "Blk & tn",
        "owner": "S. E. Ochsner", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Bella v Stolzenberg", "dam_registration_number": "337253",
        "source": meta_l45_c2
    },
    {
        "name": "BUBINE V GRAMMONT", "sex": "Female", "registration_number": "714185",
        "birth_date": "May 27, 1929", "color": "Blk & tn",
        "owner": "Emilio Marino", "owner_location": None,
        "breeder": "Nicholas Lovece", "breeder_location": "Brooklyn, N. Y.",
        "sire": "Edelblut of Arkeden", "sire_registration_number": "619599",
        "dam": "Uriana v Waldeck", "dam_registration_number": "702562",
        "source": meta_l45_c2
    },
    {
        "name": "BURSCHEL V BOHLMAN", "sex": "Male", "registration_number": "714496",
        "birth_date": "Dec. 16, 1928", "color": "Blk & rd mkgs",
        "owner": "Edwin J. Randall", "owner_location": None,
        "breeder": "R. C. Reko", "breeder_location": "Mason City, Ia.",
        "sire": "Erlo v d Roemerhof", "sire_registration_number": "468297",
        "dam": "Asta v Wiesenfels", "dam_registration_number": "683357",
        "source": meta_l45_c2
    },
    {
        "name": "CLAUS V HOMEHILL", "sex": "Male", "registration_number": "716213",
        "birth_date": "Nov. 11, 1927", "color": "Blk with br mkgs",
        "owner": "Mrs. G. A. Rentschler", "owner_location": "Hamilton, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Lady v Homehill", "dam_registration_number": "565329",
        "source": meta_l45_c2
    },
    {
        "name": "CLAUS V STROH", "sex": "Male", "registration_number": "712122",
        "birth_date": "July 2, 1926", "color": "Blk & tn",
        "owner": "Arthur Haberstroh", "owner_location": None,
        "breeder": "Abraham Van De Griek", "breeder_location": "L. I., N. Y.",
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Betty v d Hermesburg", "dam_registration_number": "496682",
        "source": meta_l45_c2
    },
    {
        "name": "CONDE DANILO DE FREYOL", "sex": "Male", "registration_number": "712426",
        "birth_date": "Nov. 6, 1928", "color": "Blk & rd",
        "owner": "R. A. Freyol", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Nuttall's Beauty", "dam_registration_number": "608304",
        "source": meta_l45_c2
    }
]

# Leaf 45, Column 3 (20 dogs)
dogs_l45_c3 = [
    {
        "name": "CONSEDINE'S BALTO", "sex": "Male", "registration_number": "714091",
        "birth_date": "Feb. 28, 1929", "color": "Rd",
        "owner": "C. H. Consedine", "owner_location": None,
        "breeder": "Merton Reed", "breeder_location": "McKean, Pa.",
        "sire": "Perry's Hooso v St. Sebald", "sire_registration_number": "546165",
        "dam": "Hermine of Mickburn", "dam_registration_number": "550425",
        "source": meta_l45_c3
    },
    {
        "name": "DIETHELM V CHANTRE", "sex": "Male", "registration_number": "712210",
        "birth_date": "July 22, 1928", "color": "Br & rd",
        "owner": "Thomas J. McCaffrey", "owner_location": None,
        "breeder": "R. A. Snyder", "breeder_location": "Oklahoma City, Okla.",
        "sire": "Diethelm v Stresow", "sire_registration_number": "480476",
        "dam": "Asta v Kalkental", "dam_registration_number": "556019",
        "source": meta_l45_c3
    },
    {
        "name": "DORIS OF ARIZONA", "sex": "Female", "registration_number": "713765",
        "birth_date": "Jan. 26, 1929", "color": "Blk, rust rd",
        "owner": "L. D. Hemman", "owner_location": "Phoenix, Ariz.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Judge of Pontchartrain", "sire_registration_number": "636369",
        "dam": "Diane of Arizona", "dam_registration_number": "639136",
        "source": meta_l45_c3
    },
    {
        "name": "ELSBETH OF GRASSINGTON", "sex": "Female", "registration_number": "712291",
        "birth_date": "Apr. 29, 1927", "color": "Blk & rd",
        "owner": "Frederick Wheeler", "owner_location": None,
        "breeder": "J. Austin Bucknall", "breeder_location": "Ypsilanti, Mich.",
        "sire": "Westphalia Dyno v Wiesengrund", "sire_registration_number": "365520",
        "dam": "Gisela of Pontchartrain", "dam_registration_number": "649685",
        "source": meta_l45_c3
    },
    {
        "name": "EMIR LENTULUS", "sex": "Male", "registration_number": "714460",
        "birth_date": "May 5, 1925", "color": "Blk & rd",
        "owner": "Frank Blattler", "owner_location": None,
        "breeder": "Gottfried Liechti", "breeder_location": "Switzerland",
        "sire": "Axel Kirchbuhl", "sire_registration_number": None,
        "dam": "Dely v d Barenburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "dam_of_dam", "name": "Miss Berneck", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Max Heidenstein", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Helda Lentulus", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Prinz Modern v Ilm Athen", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Tatjana v Jagerhof", "registration_number": None},
            {"role": "sire_of_sire", "name": "Axel v Hindendorff", "registration_number": None},
            {"role": "dam_of_sire", "name": "Buddy Hambuhl", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Max Hambuhl", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Helda Lentulus", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Zeus Parthengrund", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Asta Starkenburg", "registration_number": None}
        ],
        "source": meta_l45_c3
    },
    {
        "name": "FEDOR V BOHLMAN", "sex": "Male", "registration_number": "715344",
        "birth_date": "June 12, 1928", "color": "Blk & tn",
        "owner": "William E. Johnson", "owner_location": None,
        "breeder": "G. C. Burr", "breeder_location": "Detroit, Mich.",
        "sire": "Benno v d Glucksburg", "sire_registration_number": "605000",
        "dam": "A Betty of Pontchartrain", "dam_registration_number": "439036",
        "source": meta_l45_c3
    },
    {
        "name": "FRITZ V BARON", "sex": "Male", "registration_number": "716435",
        "birth_date": "Aug. 5, 1929", "color": "Rd, tn mkgs",
        "owner": "Waldo E. Gehring", "owner_location": None,
        "breeder": "Marshall F. Bidwell", "breeder_location": "South Windsor, Conn.",
        "sire": "Gretchen Flash", "sire_registration_number": "638956",
        "dam": "Rozeta v Baron", "dam_registration_number": "714011",
        "source": meta_l45_c3
    },
    {
        "name": "FRITZIE V SCHEFF", "sex": "Female", "registration_number": "713105",
        "birth_date": "Jan. 27, 1927", "color": "Blk & tn",
        "owner": "H. E. A. Doxsee, Jr.", "owner_location": None,
        "breeder": "Henry J. Mirbach", "breeder_location": "Syracuse, N. Y.",
        "sire": "Tango v Ostersee", "sire_registration_number": "421813",
        "dam": "Blanka v Roemerwall", "dam_registration_number": "426934",
        "source": meta_l45_c3
    },
    {
        "name": "FRITZ V SIGALSBURG", "sex": "Male", "registration_number": "715137",
        "birth_date": "July 1, 1929", "color": "Blk & tn",
        "owner": "S. E. Ochsner", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Bella v Stolzenberg", "dam_registration_number": "337253",
        "source": meta_l45_c3
    },
    {
        "name": "GAVAN V STARKANHART", "sex": "Male", "registration_number": "714861",
        "birth_date": "Sept. 15, 1928", "color": "Blk & rd",
        "owner": "F. C. Bowles", "owner_location": "Hartville, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Rena v Starkanhart", "dam_registration_number": "607477",
        "source": meta_l45_c3
    },
    {
        "name": "GODELINDE V WITTMUND", "sex": "Female", "registration_number": "714982",
        "birth_date": "Dec. 1, 1924", "color": "Blk & rd",
        "owner": "J. W. Oltmanns", "owner_location": None,
        "breeder": "Albert Schmitte", "breeder_location": "Germany",
        "sire": "Fredi v Jungborn", "sire_registration_number": None,
        "dam": "Hertha v Ostersee", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Salto v Rottal", "registration_number": None},
            {"role": "dam_of_dam", "name": "Freya v Ostersee", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Waldo v d Strengbach", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Wanda Knoll", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Roland v d Haide", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Brunhild v Silberberg", "registration_number": None},
            {"role": "sire_of_sire", "name": "Astor v Schwalbennest", "registration_number": None},
            {"role": "dam_of_sire", "name": "Hertha v Ostersee", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Salto v Rottal", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Freya v Ostersee", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Desi v Atlantic", "registration_number": None}
        ],
        "source": meta_l45_c3
    },
    {
        "name": "GRETCHEN V EARL", "sex": "Female", "registration_number": "712123",
        "birth_date": "May 7, 1929", "color": "Br, rust rd mkgs",
        "owner": "Harry P. Earl", "owner_location": None,
        "breeder": "John W. Gage", "breeder_location": "Monticello, Ill.",
        "sire": "Peter v Roemerhof", "sire_registration_number": "616494",
        "dam": "Schwarze Dame", "dam_registration_number": "672699",
        "source": meta_l45_c3
    },
    {
        "name": "HILDA V SKYEL FISK OER", "sex": "Female", "registration_number": "713104",
        "birth_date": "Mar. 8, 1928", "color": "Blk & tn",
        "owner": "Wilhelmina Silberbauer", "owner_location": None,
        "breeder": "W. J. Ross", "breeder_location": "Los Angeles, Calif.",
        "sire": "Eric v Barry", "sire_registration_number": "542592",
        "dam": "Princess Dagmar of Denmark", "dam_registration_number": "694126",
        "source": meta_l45_c3
    },
    {
        "name": "HUERTA V D HORSTBURG", "sex": "Female", "registration_number": "712028",
        "birth_date": "Nov. 11, 1927", "color": "Blk, rust rd mkgs",
        "owner": "Mary C. Wilson", "owner_location": None,
        "breeder": "Ralph T. Miller", "breeder_location": "W. Philadelphia, Pa.",
        "sire": "Trail 'Em Horstburg", "sire_registration_number": "545469",
        "dam": "Asta v d Frankenfurt", "dam_registration_number": "627856",
        "source": meta_l45_c3
    },
    {
        "name": "HUGO V D BACH", "sex": "Male", "registration_number": "714800",
        "birth_date": "Feb. 16, 1928", "color": "Blk & tn",
        "owner": "Naomi Hewitt", "owner_location": None,
        "breeder": "Arthur W. Macdonald", "breeder_location": "Buzzards Bay, Mass.",
        "sire": "Frederick v d Beck Bach", "sire_registration_number": "539975",
        "dam": "Ella v Telless", "dam_registration_number": "708997",
        "source": meta_l45_c3
    },
    {
        "name": "JACQUELINE OF SPRING VIEW", "sex": "Female", "registration_number": "715109",
        "birth_date": "July 29, 1926", "color": "Blk & rd brn",
        "owner": "H. E. Stickel", "owner_location": None,
        "breeder": "D. A. Raney", "breeder_location": "Eaton, Ohio",
        "sire": "Ariovist v Nibelungenhort", "sire_registration_number": "524279",
        "dam": "Mickey of Preble", "dam_registration_number": "501187",
        "source": meta_l45_c3
    },
    {
        "name": "JERRY OF ARIZONA", "sex": "Male", "registration_number": "713766",
        "birth_date": "Jan. 26, 1929", "color": "Blk & rust rd",
        "owner": "L. D. Hemman", "owner_location": "Phoenix, Ariz.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Judge of Pontchartrain", "sire_registration_number": "636369",
        "dam": "Diane of Arizona", "dam_registration_number": "639136",
        "source": meta_l45_c3
    },
    {
        "name": "JIGGS", "sex": "Male", "registration_number": "715649",
        "birth_date": "Aug. 4, 1929", "color": "Rd",
        "owner": "J. W. Bodley", "owner_location": None,
        "breeder": "Bert Young", "breeder_location": "Granville, Ohio",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Alice Blue Gown", "dam_registration_number": "492047",
        "source": meta_l45_c3
    },
    {
        "name": "KENTUCKY COLONEL", "sex": "Male", "registration_number": "715396",
        "birth_date": "Aug. 22, 1929", "color": "Blk & tn",
        "owner": "R. A. Goodner", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Leedsie v Rottal", "dam_registration_number": "393410",
        "source": meta_l45_c3
    },
    {
        "name": "KONIG ERICH V D SCHUTZENECK", "sex": "Male", "registration_number": "714567",
        "birth_date": "Nov. 24, 1928", "color": "Blk & tn",
        "owner": "Earle H. Smith", "owner_location": None,
        "breeder": "Walter E. Riggs", "breeder_location": "Greenville, Ohio",
        "sire": "Apollo v d Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Ruth v Oldensburg", "dam_registration_number": "478789",
        "source": meta_l45_c3
    }
]

# Leaf 46, Column 1 (22 dogs)
dogs_l46_c1 = [
    {
        "name": "LADDIE V CORSAIR", "sex": "Male", "registration_number": "715970",
        "birth_date": "June 29, 1929", "color": "Blk & tn",
        "owner": "B. Clarke", "owner_location": None,
        "breeder": "Mrs. Bernhard Wiesel", "breeder_location": "West New York, N. J.",
        "sire": "Arno v Edjo", "sire_registration_number": "689776",
        "dam": "Ella v Roemerhof", "dam_registration_number": "711032",
        "source": meta_l46_c1
    },
    {
        "name": "LADY BELLA V BLANDENBURG", "sex": "Female", "registration_number": "714799",
        "birth_date": "Sept. 19, 1928", "color": "Blk, tn mkgs",
        "owner": "Raymond Brown", "owner_location": None,
        "breeder": "J. A. Finnicum", "breeder_location": "Columbus, Ohio",
        "sire": "Leuthold of Pontchartrain", "sire_registration_number": "629194",
        "dam": "Bella of Pontchartrain", "dam_registration_number": "578596",
        "source": meta_l46_c1
    },
    {
        "name": "LADY V BURGFRIED", "sex": "Female", "registration_number": "712488",
        "birth_date": "Aug. 19, 1928", "color": "Blk & tn",
        "owner": "S. E. Hershey", "owner_location": None,
        "breeder": "John Schofield", "breeder_location": "Elverson, Pa.",
        "sire": "Armin v Burgfried", "sire_registration_number": "430843",
        "dam": "Countess v Burgholz", "dam_registration_number": "449862",
        "source": meta_l46_c1
    },
    {
        "name": "MAUDIE", "sex": "Female", "registration_number": "716441",
        "birth_date": "Oct. 20, 1928", "color": "Rd & tn",
        "owner": "R. H. Cummings", "owner_location": None,
        "breeder": "Carl Feuerbacher", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Dina v d Dreirosenstadt", "dam_registration_number": "623419",
        "source": meta_l46_c1
    },
    {
        "name": "MITZI V SEDREVLA", "sex": "Female", "registration_number": "713491",
        "birth_date": "Dec. 26, 1928", "color": "Rd & tn",
        "owner": "Mrs. Ile's Graeuwen", "owner_location": None,
        "breeder": "Gus Stoffels", "breeder_location": "Nutley, N. J.",
        "sire": "Yvon of Edjo", "sire_registration_number": "689593",
        "dam": "Rea of New Jersey", "dam_registration_number": "685584",
        "source": meta_l46_c1
    },
    {
        "name": "NYMPO FRA DUNCAN", "sex": "Male", "registration_number": "714010",
        "birth_date": "Nov. 24, 1928", "color": "Blk & tn",
        "owner": "G. Sherman", "owner_location": None,
        "breeder": "Walter E. Riggs", "breeder_location": "Greenville, Ohio",
        "sire": "Apollo v d Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Ruth v Oldensburg", "dam_registration_number": "478789",
        "source": meta_l46_c1
    },
    {
        "name": "OXBO BERTA", "sex": "Female", "registration_number": "712639",
        "birth_date": "Feb. 7, 1929", "color": "Blk & tn",
        "owner": "F. C. Fuqua", "owner_location": "Seattle, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Arnold v Minkelried", "sire_registration_number": "513005",
        "dam": "Gerti v Hohenschwanau", "dam_registration_number": "670137",
        "source": meta_l46_c1
    },
    {
        "name": "PAULA GRETEL", "sex": "Female", "registration_number": "713077",
        "birth_date": "Nov. 25, 1926", "color": "Blk, tn mkgs",
        "owner": "Arthur L. Edwards", "owner_location": None,
        "breeder": "Benj. F. Earl", "breeder_location": "Quincy, Mass.",
        "sire": "Knight of Tidewater", "sire_registration_number": "293613",
        "dam": "Elwin Princess Patsy", "dam_registration_number": "545312",
        "source": meta_l46_c1
    },
    {
        "name": "PAULI OF PONTCHARTRAIN II", "sex": "Female", "registration_number": "715345",
        "birth_date": "Sept. 21, 1928", "color": "Blk, rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Frank B. Tanner", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Lita v Burgholz", "dam_registration_number": "671060",
        "source": meta_l46_c1
    },
    {
        "name": "PRINCE BARON OF PONTCHARTRAIN", "sex": "Male", "registration_number": "712155",
        "birth_date": "Mar. 28, 1929", "color": "Blk, rd",
        "owner": "G. S. Mawhinney", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Freia v d Butersburg of Ardwin", "dam_registration_number": "499561",
        "source": meta_l46_c1
    },
    {
        "name": "PRINCESS MITZI", "sex": "Female", "registration_number": "715395",
        "birth_date": "June 13, 1929", "color": "Blk, bronze mkgs",
        "owner": "Mrs. J. Eckle Starnes", "owner_location": None,
        "breeder": "Mignon Preston", "breeder_location": "Fresno, Calif.",
        "sire": "Guard", "sire_registration_number": "700191",
        "dam": "Aimee Semple McPherson", "dam_registration_number": "547816",
        "source": meta_l46_c1
    },
    {
        "name": "PRINZ LUDWIG OF MIAMI", "sex": "Male", "registration_number": "712744",
        "birth_date": "Apr. 18, 1929", "color": "Blk & tn",
        "owner": "L. S. Crane", "owner_location": None,
        "breeder": "Wm. H. Duffy", "breeder_location": "Northfield, N. J.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Hildegarde v Doernbach", "dam_registration_number": "661249",
        "source": meta_l46_c1
    },
    {
        "name": "RIVAL", "sex": "Male", "registration_number": "714513",
        "birth_date": "Mar. 29, 1929", "color": "Blk & tn",
        "owner": "Andrew Nelson", "owner_location": None,
        "breeder": "Oscar L. Simpson", "breeder_location": "Nashville, Tenn.",
        "sire": "Ochsner's Son of Rival", "sire_registration_number": "612378",
        "dam": "Asta v Nashville", "dam_registration_number": "675400",
        "source": meta_l46_c1
    },
    {
        "name": "ROZETA V BARON", "sex": "Female", "registration_number": "714011",
        "birth_date": "Mar. 20, 1928", "color": "Blk, tn mkgs",
        "owner": "Marshall F. Bidwell", "owner_location": "So. Windsor, Conn.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Baron v Richtofen", "sire_registration_number": "526664",
        "dam": "Adda v Kanonenstadt", "dam_registration_number": "534153",
        "source": meta_l46_c1
    },
    {
        "name": "SALLY", "sex": "Female", "registration_number": "713971",
        "birth_date": "Dec. 31, 1927", "color": "Blk & rd",
        "owner": "Emily F. Lidster", "owner_location": None,
        "breeder": "Mickburn Kennels", "breeder_location": "Eldorado, Ill.",
        "sire": "Red Roof Rowdy", "sire_registration_number": "392482",
        "dam": "Arabella of Mickburn", "dam_registration_number": "550427",
        "source": meta_l46_c1
    },
    {
        "name": "SENTA V TECKLENBURG", "sex": "Female", "registration_number": "713600",
        "birth_date": "Apr. 22, 1927", "color": "Blk & tn",
        "owner": "Hugo Brenninkmeyer", "owner_location": None,
        "breeder": "Anton M. Jaschke", "breeder_location": "Springfield, Ill.",
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Gretta of Mickburn", "dam_registration_number": "486005",
        "source": meta_l46_c1
    },
    {
        "name": "SOPHIA V JAGERHOF", "sex": "Female", "registration_number": "715741",
        "birth_date": "May 13, 1929", "color": "Blk & tn",
        "owner": "John Caldwell Smith", "owner_location": None,
        "breeder": "E. DeL. Fouque", "breeder_location": "Media, Pa.",
        "sire": "Red Roof Rufus", "sire_registration_number": "491422",
        "dam": "Babette v Jagerhof", "dam_registration_number": "521089",
        "source": meta_l46_c1
    },
    {
        "name": "STURKO'S BEAUTY", "sex": "Female", "registration_number": "713764",
        "birth_date": "July 15, 1928", "color": "Blk & tn",
        "owner": "Martin E. Sturko", "owner_location": None,
        "breeder": "Phil Hagerman", "breeder_location": "Chicago, Ill.",
        "sire": "Asko v Bolanden", "sire_registration_number": "432279",
        "dam": "Princess Bea v Silverberg", "dam_registration_number": "403875",
        "source": meta_l46_c1
    },
    {
        "name": "TAMAR V TILHAGEN", "sex": "Female", "registration_number": "714860",
        "birth_date": "Apr. 27, 1928", "color": "Blk, rd",
        "owner": "F. C. Bowles", "owner_location": "Hartville, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Westphalia Dyno v Wiesengrund", "sire_registration_number": "365520",
        "dam": "Arrah v Tilhagen", "dam_registration_number": "658426",
        "source": meta_l46_c1
    },
    {
        "name": "TENA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "715343",
        "birth_date": "Feb. 6, 1929", "color": "Blk, rd",
        "owner": "William L. Pease", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Neba v Streslau", "dam_registration_number": "539722",
        "source": meta_l46_c1
    },
    {
        "name": "TOLLA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "715342",
        "birth_date": "Feb. 6, 1929", "color": "Blk, rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Neba v Streslau", "dam_registration_number": "539722",
        "source": meta_l46_c1
    },
    {
        "name": "TRAIL 'EM RIFF OF ADONIS", "sex": "Male", "registration_number": "713763",
        "birth_date": "Aug. 1, 1929", "color": "Br, rust rd",
        "owner": "Lillian M. Rahner", "owner_location": None,
        "breeder": "Frank X. Simon", "breeder_location": "Philadelphia, Pa.",
        "sire": "Trail 'Em Adonis", "sire_registration_number": "709104",
        "dam": "Lady Kwik", "dam_registration_number": "707649",
        "source": meta_l46_c1
    }
]

# Leaf 46, Column 2 top (2 dogs ending before PINSCHER (Miniature))
dogs_l46_c2 = [
    {
        "name": "VON WEDON'S MAX SCHUESS", "sex": "Male", "registration_number": "716479",
        "birth_date": "Feb. 20, 1929", "color": "Blk & tn",
        "owner": "Walter E. Donovan", "owner_location": None,
        "breeder": "Helene O. Bernard", "breeder_location": "Brookline, Mass.",
        "sire": "Edelblut of Westphalia", "sire_registration_number": "535468",
        "dam": "Hexie's Marga", "dam_registration_number": "535613",
        "source": meta_l46_c2
    },
    {
        "name": "VON WEDON'S MOTTE SCHUESS", "sex": "Female", "registration_number": "716478",
        "birth_date": "Feb. 20, 1929", "color": "Rd & tn",
        "owner": "Mrs. Walter E. Donovan", "owner_location": None,
        "breeder": "Helene Bernard", "breeder_location": "Brookline, Mass.",
        "sire": "Edelblut of Westphalia", "sire_registration_number": "535468",
        "dam": "Hexie's Marga", "dam_registration_number": "535613",
        "source": meta_l46_c2
    }
]

all_dogs_1930_01 = dogs_l45_c2 + dogs_l45_c3 + dogs_l46_c1 + dogs_l46_c2
print(f"Total compiled 1930-01 dogs: {len(all_dogs_1930_01)}")
print(f"  Leaf 45 Col 2: {len(dogs_l45_c2)}")
print(f"  Leaf 45 Col 3: {len(dogs_l45_c3)}")
print(f"  Leaf 46 Col 1: {len(dogs_l46_c1)}")
print(f"  Leaf 46 Col 2: {len(dogs_l46_c2)}")

out_path = Path("stud-scrape/data/verified_1930_01.json")
out_path.write_text(json.dumps(all_dogs_1930_01, indent=2), encoding="utf-8")
print(f"Saved verified 1930-01 records to {out_path}")
