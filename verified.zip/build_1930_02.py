import json
from pathlib import Path

meta_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-02-01_47_2", "date": "1930-02-01", "volume": "47", "issue": "2", "leaf": 40, "column": 1}
meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-02-01_47_2", "date": "1930-02-01", "volume": "47", "issue": "2", "leaf": 40, "column": 2}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-02-01_47_2", "date": "1930-02-01", "volume": "47", "issue": "2", "leaf": 40, "column": 3}

# Leaf 40, Column 1 (bottom under PINSCHERS (Doberman) - 4 dogs)
c1_dogs = [
    {
        "name": "ARABELLA VIRGINIA", "sex": "Female", "registration_number": "716736",
        "birth_date": "Jan. 16, 1929", "color": "Blk, tn mkgs",
        "owner": "Gerald Hayter", "owner_location": None,
        "breeder": "W. L. Haley", "breeder_location": "Sioux City, Iowa",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Frances of Mickburn", "dam_registration_number": "580532",
        "source": meta_c1
    },
    {
        "name": "BLONDE", "sex": "Male", "registration_number": "719154",
        "birth_date": "Mar. 2, 1929", "color": "Blk & tn",
        "owner": "Raymond Backes", "owner_location": None,
        "breeder": "Max Scheuer", "breeder_location": "Thiensville, Wis.",
        "sire": "Robinson's Sully", "sire_registration_number": "706298",
        "dam": "Robinson's Sue Claire", "dam_registration_number": "669649",
        "source": meta_c1
    },
    {
        "name": "BOZO OF KETTLE COVE", "sex": "Male", "registration_number": "717412",
        "birth_date": "Oct. 5, 1929", "color": "Blk & tn",
        "owner": "Kettle Cove Kennels", "owner_location": None,
        "breeder": "G. G. Amory", "breeder_location": "Magnolia, Mass.",
        "sire": "Edelblut of Westphalia", "sire_registration_number": "535468",
        "dam": "Moyra of Kettle Cove", "dam_registration_number": "641528",
        "source": meta_c1
    },
    {
        "name": "CARL", "sex": "Male", "registration_number": "719147",
        "birth_date": "April 28, 1929", "color": "Blk & tn",
        "owner": "J. J. Cohen", "owner_location": None,
        "breeder": "John F. Carey", "breeder_location": "Joliet, Ill.",
        "sire": "Dolf v Taunusblick", "sire_registration_number": "438104",
        "dam": "Mina Faithful", "dam_registration_number": "611899",
        "source": meta_c1
    }
]

# Leaf 40, Column 2 (20 dogs)
c2_dogs = [
    {
        "name": "DOLLY V JAEGERSHOF", "sex": "Female", "registration_number": "719690",
        "birth_date": "Feb. 24, 1928", "color": "Blk & rd rust",
        "owner": "Mrs. C. A. Bergman", "owner_location": None,
        "breeder": "R. E. O'Connell", "breeder_location": "Ottumwa, Iowa",
        "sire": "Baro v Jaegershof", "sire_registration_number": "620043",
        "dam": "Dolly Dechert v Lueschenhof", "dam_registration_number": "571083",
        "source": meta_c2
    },
    {
        "name": "DONA V BRONIA", "sex": "Female", "registration_number": "717798",
        "birth_date": "June 20, 1927", "color": "Blk & tn",
        "owner": "Ross M. Taylor", "owner_location": None,
        "breeder": "Chas. M. Riggs", "breeder_location": "Allegan, Mich.",
        "sire": "Jasko P. v Engleburg", "sire_registration_number": "577358",
        "dam": "Princess Beta", "dam_registration_number": "646400",
        "source": meta_c2
    },
    {
        "name": "DONNA V FRIEDRICHSHOF", "sex": "Female", "registration_number": "719497",
        "birth_date": "May 2, 1929", "color": "Br & tn",
        "owner": "L. Foster Powers", "owner_location": None,
        "breeder": "Chas. W. Downs", "breeder_location": "So. Hanson, Mass.",
        "sire": "Blitzen v Schuess", "sire_registration_number": "451172",
        "dam": "Fraulein v Friedrichshof", "dam_registration_number": "615476",
        "source": meta_c2
    },
    {
        "name": "DUKESHIRE V GUENTER", "sex": "Male", "registration_number": "716556",
        "birth_date": "Nov. 26, 1928", "color": "Blk & tn",
        "owner": "Milo K. Miller", "owner_location": None,
        "breeder": "Paul B. Wallace", "breeder_location": "Buchanan, Mich.",
        "sire": "Ochsner's Best Bet", "sire_registration_number": "609713",
        "dam": "Greta v Pagel", "dam_registration_number": "618522",
        "source": meta_c2
    },
    {
        "name": "FIGARO V D BARBAROSSAHOHLE", "sex": "Male", "registration_number": "718040",
        "birth_date": "Sept. 3, 1928", "color": "Blk & rd",
        "owner": "E. D. Schneider", "owner_location": None,
        "breeder": "Gustav Bodewig", "breeder_location": "Germany",
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Dilly v Stolzenberg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Troll v d Blankenburg", "registration_number": "553218"},
            {"role": "dam_of_dam", "name": "Lotte v Simmenau", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Alex v Simmenau", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Gudrun v Hornegg", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "FRITZ V D METZ", "sex": "Male", "registration_number": "716532",
        "birth_date": "Dec. 23, 1926", "color": "Blk & tn",
        "owner": "Stuart D. Wilson", "owner_location": None,
        "breeder": "H. F. Aldrich", "breeder_location": "Spokane, Wash.",
        "sire": "Arno v Burgfried", "sire_registration_number": "426603",
        "dam": "Princess Mitzi v Rheinhart", "dam_registration_number": "468190",
        "source": meta_c2
    },
    {
        "name": "GERTIE", "sex": "Female", "registration_number": "717632",
        "birth_date": "Aug. 22, 1928", "color": "Blk & tn",
        "owner": "Otto Beuke", "owner_location": "Wichita, Kans.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Dietrich v d Barbarossahoehle", "sire_registration_number": "561617",
        "dam": "Nuja v Streslau", "dam_registration_number": "586735",
        "source": meta_c2
    },
    {
        "name": "HASSO OF TYWORTH", "sex": "Male", "registration_number": "719074",
        "birth_date": "April 13, 1929", "color": "Blk & rd",
        "owner": "Mr. and Mrs. John Bernard Keena, Jr.", "owner_location": None,
        "breeder": "Mr. and Mrs. N. E. Tyrrell", "breeder_location": "Ionia, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Nita v Streslau", "dam_registration_number": "539723",
        "source": meta_c2
    },
    {
        "name": "JANE V STRAHLAU", "sex": "Female", "registration_number": "718141",
        "birth_date": "May 5, 1929", "color": "Blk, rd, rust mkgs",
        "owner": "Leonore Freitag", "owner_location": None,
        "breeder": "Mrs. Harry Trevor Whayne", "breeder_location": "Louisville, Ky.",
        "sire": "Prince Alexis of Ardenne", "sire_registration_number": "599344",
        "dam": "Sophie v d Nibelunghort", "dam_registration_number": "554721",
        "source": meta_c2
    },
    {
        "name": "KENTUCKY SPREE", "sex": "Male", "registration_number": "719703",
        "birth_date": "July 13, 1928", "color": "Blk & tn",
        "owner": "Marine P. Darby", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Burschel v d Spree", "sire_registration_number": "487194",
        "dam": "Tookey of Kentucky", "dam_registration_number": "625717",
        "source": meta_c2
    },
    {
        "name": "KINNOC V NOSHIM", "sex": "Male", "registration_number": "717830",
        "birth_date": "Mar. 29, 1929", "color": "Blk & tn",
        "owner": "Lee J. Watkins, Jr.", "owner_location": None,
        "breeder": "Oscar L. Simpson", "breeder_location": "Nashville, Tenn.",
        "sire": "Ochsner's Son of Rival", "sire_registration_number": "612378",
        "dam": "Asta v Nashville", "dam_registration_number": "675400",
        "source": meta_c2
    },
    {
        "name": "KONA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "719496",
        "birth_date": "April 10, 1928", "color": "Blk & rd",
        "owner": "S. W. Rogers", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Gwanna of Pontchartrain", "dam_registration_number": "649692",
        "source": meta_c2
    },
    {
        "name": "LADY GILDA V TARR", "sex": "Female", "registration_number": "719581",
        "birth_date": "Aug. 10, 1929", "color": "Blk & tn",
        "owner": "C. C. Tarr", "owner_location": None,
        "breeder": "Geo. H. Jones", "breeder_location": "Danville, Ill.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Princess v Rudolphsburg", "dam_registration_number": "569711",
        "source": meta_c2
    },
    {
        "name": "LENA-DU", "sex": "Female", "registration_number": "718758",
        "birth_date": "Aug. 4, 1929", "color": "Blk & tn",
        "owner": "Clarence T. Dyer", "owner_location": None,
        "breeder": "Bert Young", "breeder_location": "Granville, Ohio",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Alice Blue Gown", "dam_registration_number": "492047",
        "source": meta_c2
    },
    {
        "name": "MAX PRINGEL", "sex": "Male", "registration_number": "716596",
        "birth_date": "Feb. 18, 1929", "color": "Blk & tn",
        "owner": "Allan S. McNeil", "owner_location": None,
        "breeder": "Fredalea Kennels", "breeder_location": "Detroit, Mich.",
        "sire": "The Imperator of Rhinegold", "sire_registration_number": "653798",
        "dam": "Lady Gwena of Rhinegold", "dam_registration_number": "584359",
        "source": meta_c2
    },
    {
        "name": "NIELS V D SCHOLLE OF ASHLAND", "sex": "Male", "registration_number": "718154",
        "birth_date": "June 19, 1925", "color": "Br & rd",
        "owner": "Louis E. Moschel", "owner_location": None,
        "breeder": "L. Bordingbrann", "breeder_location": "Austria",
        "sire": "Argo v Altmannsdorf", "sire_registration_number": None,
        "dam": "Ridhill v d Scholle", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Sven Hedin", "registration_number": None},
            {"role": "dam_of_dam", "name": "Sahaf Gedolah", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Pazzo Naxos", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Ruth v d Traun", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Tasso v d Weissen Elster", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Lady v d Linde", "registration_number": None},
            {"role": "sire_of_sire", "name": "Rex Salzer", "registration_number": None},
            {"role": "dam_of_sire", "name": "Dina v Rutersburg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Prinz Modern v Ilm Athen", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Hertha v Quellennpark", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v Saxonia", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Sie Zeun Sentra", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "PERRY'S DOBSCHEN V ST. SEBALD", "sex": "Female", "registration_number": "718311",
        "birth_date": "Apr. 5, 1928", "color": "Blk & tn",
        "owner": "Ernest R. Behrend", "owner_location": None,
        "breeder": "Perry Kennels", "breeder_location": "Erie, Pa.",
        "sire": "Delf v Karthaeuserklause", "sire_registration_number": "583005",
        "dam": "Alma v Schillingsburg", "dam_registration_number": "583004",
        "source": meta_c2
    },
    {
        "name": "PRINCE HEINRICH V SIGALSBURG", "sex": "Male", "registration_number": "718932",
        "birth_date": "Sept. 7, 1928", "color": "Blk & tn",
        "owner": "Walter H. Meier", "owner_location": None,
        "breeder": "Mrs. Elmer Schweninger", "breeder_location": "Cincinnati, Ohio",
        "sire": "Boone v Sigalsburg", "sire_registration_number": "658766",
        "dam": "Hamer's Peggy", "dam_registration_number": "587825",
        "source": meta_c2
    },
    {
        "name": "PRINCE O' THE WEST V LUSCHENHOF", "sex": "Male", "registration_number": "718106",
        "birth_date": "June 6, 1929", "color": "Blk & tn",
        "owner": "R. B. Jenkins", "owner_location": None,
        "breeder": "A. G. Lueschen", "breeder_location": "Columbus, Nebr.",
        "sire": "Rudolph v d Rudolphsburg", "sire_registration_number": "493363",
        "dam": "Asta v Striesen", "dam_registration_number": "487147",
        "source": meta_c2
    },
    {
        "name": "QUEEN V APOLDA", "sex": "Female", "registration_number": "716657",
        "birth_date": "Aug. 9, 1929", "color": "Br, tn mkgs",
        "owner": "Paul G. Heinze", "owner_location": None,
        "breeder": "James M. Osborne", "breeder_location": "Cleveland, Ohio",
        "sire": "Rudolph Richtofen", "sire_registration_number": "612479",
        "dam": "Lady v d Eckardsburg", "dam_registration_number": "679268",
        "source": meta_c2
    }
]

# Leaf 40, Column 3 (top half down to POINTERS - 6 dogs)
c3_dogs = [
    {
        "name": "ROWDY OF WATSEKA", "sex": "Female", "registration_number": "718482",
        "birth_date": "Nov. 28, 1926", "color": "Br",
        "owner": "J. W. Oltmanns", "owner_location": "Watseka, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Arko v Bottwartal", "sire_registration_number": "620924",
        "dam": "Asta v Dankwarderode", "dam_registration_number": "714983",
        "source": meta_c3
    },
    {
        "name": "SALLY DORN OF PETERSHOFF", "sex": "Female", "registration_number": "719921",
        "birth_date": "Feb. 13, 1928", "color": "Blk & rust rd",
        "owner": "George Pugh", "owner_location": None,
        "breeder": "Geo. A. Martindell", "breeder_location": "Painted Post, N. Y.",
        "sire": "Blitz Dorn of Pontchartrain", "sire_registration_number": "578014",
        "dam": "Liesel v d Grenzlerburg", "dam_registration_number": "586610",
        "source": meta_c3
    },
    {
        "name": "SUSAN", "sex": "Female", "registration_number": "719252",
        "birth_date": "Dec. 9, 1928", "color": "Blk & tn",
        "owner": "H. G. Kraus", "owner_location": None,
        "breeder": "James M. Osborne", "breeder_location": "Cleveland, Ohio",
        "sire": "Rudolph Richtofen", "sire_registration_number": "612479",
        "dam": "Lady v d Eckardsburg", "dam_registration_number": "679268",
        "source": meta_c3
    },
    {
        "name": "TEUSCHEL V DOORN", "sex": "Male", "registration_number": "719106",
        "birth_date": "Dec. 20, 1927", "color": "Blk & tn",
        "owner": "R. A. Martin", "owner_location": None,
        "breeder": "L. L. Calkins", "breeder_location": "Hopkins, Mich.",
        "sire": "Alto v Keller", "sire_registration_number": "497117",
        "dam": "Princess Beta", "dam_registration_number": "646400",
        "source": meta_c3
    },
    {
        "name": "ZARISTO V ZINGSHEIM", "sex": "Male", "registration_number": "720051",
        "birth_date": "Sept. 3, 1929", "color": "Blk & tn",
        "owner": "Mr. and Mrs. A. Gordon", "owner_location": None,
        "breeder": "M. L. Zingsheim", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Betsy v Wilhelm", "dam_registration_number": "623310",
        "source": meta_c3
    },
    {
        "name": "ZEPPY", "sex": "Female", "registration_number": "719434",
        "birth_date": "June 13, 1929", "color": "Blk, rd rust",
        "owner": "John T. Keating", "owner_location": None,
        "breeder": "Martin Gaus", "breeder_location": "Philadelphia, Pa.",
        "sire": "Duke v Stroheim", "sire_registration_number": "563574",
        "dam": "Bella v Horstburg", "dam_registration_number": "620406",
        "source": meta_c3
    }
]

leaf40_dogs = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1930-02 dogs: {len(leaf40_dogs)}")
print(f"  Col 1: {len(c1_dogs)}")
print(f"  Col 2: {len(c2_dogs)}")
print(f"  Col 3: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1930_02.json").write_text(json.dumps(leaf40_dogs, indent=2), encoding="utf-8")
print("Saved verified 1930-02 records.")
