import json
from pathlib import Path

meta_l39_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-03-01_47_3", "date": "1930-03-01", "volume": "47", "issue": "3", "leaf": 39, "column": 3}
meta_l40_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-03-01_47_3", "date": "1930-03-01", "volume": "47", "issue": "3", "leaf": 40, "column": 1}
meta_l40_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-03-01_47_3", "date": "1930-03-01", "volume": "47", "issue": "3", "leaf": 40, "column": 2}

# Leaf 39, Column 3 (Starts under PINSCHERS (Doberman) - 9 dogs)
dogs_l39_c3 = [
    {
        "name": "ALEX OF PONTCHARTRAIN II", "sex": "Male", "registration_number": "722350",
        "birth_date": "April 28, 1929", "color": "Blk & rd",
        "owner": "J. A. Schwarzmann", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Anita v Goldgrund", "dam_registration_number": "454887",
        "source": meta_l39_c3
    },
    {
        "name": "ANITA OF KENCARO", "sex": "Female", "registration_number": "724236",
        "birth_date": "April 18, 1928", "color": "Blk & tn",
        "owner": "J. Howard Moore", "owner_location": None,
        "breeder": "J. F. Planz", "breeder_location": "Akron, Ohio",
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Rowdy Rilda", "dam_registration_number": "653353",
        "source": meta_l39_c3
    },
    {
        "name": "BARON ABEL V EDSTROM", "sex": "Male", "registration_number": "720997",
        "birth_date": "Dec. 17, 1928", "color": "Blk, tn mkgs",
        "owner": "H. Prescott Gatley, Jr.", "owner_location": None,
        "breeder": "Alice G. Cutts", "breeder_location": "Quantico, Va.",
        "sire": "Prince Leo v Occidental", "sire_registration_number": "686204",
        "dam": "Baroness Arva v d Hoehen", "dam_registration_number": "536284",
        "source": meta_l39_c3
    },
    {
        "name": "BLITZ V ROEMERHOF II", "sex": "Male", "registration_number": "722493",
        "birth_date": "May 23, 1929", "color": "Blue & tn",
        "owner": "C. B. Hannig", "owner_location": None,
        "breeder": "J. M. Kaiser", "breeder_location": "Chicago, Ill.",
        "sire": "Peter v Roemerhof", "sire_registration_number": "616494",
        "dam": "Eda v Hugelstadt", "dam_registration_number": "627598",
        "source": meta_l39_c3
    },
    {
        "name": "BODO V STARKANHART", "sex": "Male", "registration_number": "724365",
        "birth_date": "Sept. 15, 1928", "color": "Blk & rd",
        "owner": "F. C. Marshall", "owner_location": None,
        "breeder": "F. C. Bowles", "breeder_location": "Hartville, Ohio",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Rena v Starkenhart", "dam_registration_number": "607477",
        "source": meta_l39_c3
    },
    {
        "name": "DIETHELM FRA DUNCAN", "sex": "Male", "registration_number": "722682",
        "birth_date": "Feb. 11, 1928", "color": "Br & rust",
        "owner": "C. A. Duncan", "owner_location": None,
        "breeder": "R. A. Snyder", "breeder_location": "Oklahoma City, Okla.",
        "sire": "Diethelm v Stresow", "sire_registration_number": "480476",
        "dam": "Berna v d Quellenstadt", "dam_registration_number": "556020",
        "source": meta_l39_c3
    },
    {
        "name": "DOBER V MANX", "sex": "Male", "registration_number": "723221",
        "birth_date": "May 13, 1929", "color": "Blk & tn",
        "owner": "Gene Olson", "owner_location": None,
        "breeder": "Paul W. Westfall", "breeder_location": "Eureka, Calif.",
        "sire": "Sig v Sigalsburg", "sire_registration_number": "659175",
        "dam": "Misery's Redway Sweetheart", "dam_registration_number": "623880",
        "source": meta_l39_c3
    },
    {
        "name": "DUKE V D JEANNETTESBURG", "sex": "Male", "registration_number": "722282",
        "birth_date": "April 26, 1926", "color": "Blk & tn",
        "owner": "H. W. Callison", "owner_location": None,
        "breeder": "H. B. Hark", "breeder_location": "Glendale, Ohio",
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Tora v d Blankenburg", "dam_registration_number": "496696",
        "source": meta_l39_c3
    },
    {
        "name": "ELLA THE GREAT", "sex": "Female", "registration_number": "721313",
        "birth_date": "July 5, 1928", "color": "Blk & tn",
        "owner": "Earl Gillmore", "owner_location": None,
        "breeder": "H. L. Foran", "breeder_location": "Grand Island, Nebr.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Frieda the Great", "dam_registration_number": "666262",
        "source": meta_l39_c3
    }
]

# Leaf 40, Column 1 (20 dogs)
dogs_l40_c1 = [
    {
        "name": "FIFI V STEHLIN", "sex": "Female", "registration_number": "723751",
        "birth_date": "July 2, 1929", "color": "Blk & tn",
        "owner": "Howard W. Stehlin", "owner_location": None,
        "breeder": "Arthur T. Jones", "breeder_location": "Lynbrook, L. I., N. Y.",
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Delma de Haven", "dam_registration_number": "660602",
        "source": meta_l40_c1
    },
    {
        "name": "FREYA V D BLANKENBURG", "sex": "Female", "registration_number": "723166",
        "birth_date": "May 13, 1929", "color": "Br & tn",
        "owner": "Mrs. G. H. Browne", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "Cupertino, Calif.",
        "sire": "Burschel v Falkensee", "sire_registration_number": "553217",
        "dam": "Asta v d Panke", "dam_registration_number": "553219",
        "source": meta_l40_c1
    },
    {
        "name": "FRITZ V DOMBACHTAL", "sex": "Male", "registration_number": "722890",
        "birth_date": "June 30, 1929", "color": "Blk & tn",
        "owner": "Joseph L. McAndrews", "owner_location": None,
        "breeder": "Ida White", "breeder_location": "Pittsburgh, Pa.",
        "sire": "Hans v Dombachtal", "sire_registration_number": "606668",
        "dam": "Bebe v Sigalsburg", "dam_registration_number": "655996",
        "source": meta_l40_c1
    },
    {
        "name": "FRITZ V GILBERT", "sex": "Male", "registration_number": "723651",
        "birth_date": "July 20, 1929", "color": "Blk & tn",
        "owner": "John T. Raker", "owner_location": None,
        "breeder": "Albert L. Hamilton, Sr.", "breeder_location": "Upland, Pa.",
        "sire": "Rover v Bernard", "sire_registration_number": "551703",
        "dam": "Lottie v Gobles", "dam_registration_number": "449300",
        "source": meta_l40_c1
    },
    {
        "name": "GAY BRUNO V RESIDENZ", "sex": "Male", "registration_number": "723007",
        "birth_date": "June 26, 1925", "color": "Rd",
        "owner": "Frederick K. Marsh", "owner_location": None,
        "breeder": "Louis E. Moschel", "breeder_location": "Buffalo, N. Y.",
        "sire": "Bruno v d Residenz", "sire_registration_number": "434861",
        "dam": "Gaea v Nibelungenhort", "dam_registration_number": "556027",
        "source": meta_l40_c1
    },
    {
        "name": "GRAF V BARTSCHENDORF", "sex": "Male", "registration_number": "722607",
        "birth_date": "July 20, 1928", "color": "Br, tn mkgs",
        "owner": "Chester C. Kapfelsberger", "owner_location": None,
        "breeder": "F. Vincent Bartscher", "breeder_location": "Rosedale, L. I., N. Y.",
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Belle v Leipzig", "dam_registration_number": "603290",
        "source": meta_l40_c1
    },
    {
        "name": "GYPSY STOVER", "sex": "Female", "registration_number": "720562",
        "birth_date": "April 26, 1928", "color": "Blk & tn",
        "owner": "Ruth Stover", "owner_location": None,
        "breeder": "Fred Seigel", "breeder_location": "No. Plymouth, Mass.",
        "sire": "Ritz Carlton", "sire_registration_number": "485720",
        "dam": "Brenda v Heidelberg", "dam_registration_number": "636088",
        "source": meta_l40_c1
    },
    {
        "name": "ISOLDA V NIBELUNGENHORT", "sex": "Female", "registration_number": "721835",
        "birth_date": "Jan. 12, 1929", "color": "Blk & tn, br tpd",
        "owner": "J. F. Hattman", "owner_location": None,
        "breeder": "Walter J. Lyster", "breeder_location": "Lansdowne, Pa.",
        "sire": "Sniten's Attila", "sire_registration_number": "603370",
        "dam": "Ottilie Strichrodt", "dam_registration_number": "639194",
        "source": meta_l40_c1
    },
    {
        "name": "JOCKEL", "sex": "Male", "registration_number": "723334",
        "birth_date": "Aug. 15, 1929", "color": "Blk & br",
        "owner": "Stanley W. McFarland", "owner_location": None,
        "breeder": "Joseph F. Elias", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Dhu Varren's Judy", "dam_registration_number": "649764",
        "source": meta_l40_c1
    },
    {
        "name": "JOUDA OF MIDDLETOWN", "sex": "Female", "registration_number": "722204",
        "birth_date": "June 20, 1929", "color": "Rd & tn",
        "owner": "Glenn S. Staines", "owner_location": None,
        "breeder": "W. N. McCoy", "breeder_location": "Middletown, Ohio",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Jouda v Steigerwald", "dam_registration_number": "686413",
        "source": meta_l40_c1
    },
    {
        "name": "JUNE BENNO V BURGHOLZ", "sex": "Female", "registration_number": "724071",
        "birth_date": "April 3, 1928", "color": "Blk & rust rd",
        "owner": "Norman Ziemann", "owner_location": None,
        "breeder": "Rodman M. Brown, Jr.", "breeder_location": "Omaha, Nebr.",
        "sire": "Hasso v Altendorf", "sire_registration_number": "463070",
        "dam": "Trudie v Burgholz", "dam_registration_number": "549325",
        "source": meta_l40_c1
    },
    {
        "name": "KARL V BLANKENBURG", "sex": "Male", "registration_number": "722359",
        "birth_date": "April 23, 1929", "color": "Blk & tn",
        "owner": "Geo. Schroth", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "Cupertino, Calif.",
        "sire": "Graf v Blankenburg", "sire_registration_number": "629406",
        "dam": "Altara v Riga", "dam_registration_number": "699653",
        "source": meta_l40_c1
    },
    {
        "name": "KICKEY RINKENBUEHL BURGHOLZ", "sex": "Female", "registration_number": "722281",
        "birth_date": "June 12, 1928", "color": "Blk, rust rd mkgs",
        "owner": "W. H. Dillinger and J. T. Clements", "owner_location": None,
        "breeder": "Mickburn Kennels", "breeder_location": "Eldorado, Ill.",
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Rotha of Red Roof", "dam_registration_number": "327092",
        "source": meta_l40_c1
    },
    {
        "name": "KIT OF PONTCHARTRAIN", "sex": "Female", "registration_number": "722203",
        "birth_date": "April 10, 1928", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Gwanna of Pontchartrain", "dam_registration_number": "649692",
        "handwritten_annotation": "See Correction - Nov. 1930 - p. 68",
        "source": meta_l40_c1
    },
    {
        "name": "LOLA V AUGARTEN", "sex": "Female", "registration_number": "724400",
        "birth_date": "April 8, 1927", "color": "Blk & rd",
        "owner": "W. N. McCoy", "owner_location": None,
        "breeder": "Otto Herm", "breeder_location": "Germany",
        "sire": "Axel v Haardtgebirg", "sire_registration_number": None,
        "dam": "Hella v Wetterbach", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Ari v Sigalsburg", "registration_number": "517070"},
            {"role": "dam_of_dam", "name": "Dolli v Wetterbach", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Achim v Langerode", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Hella v Wetterbach", "registration_number": None},
            {"role": "sire_of_sire", "name": "Densos v Atlantic", "registration_number": None},
            {"role": "dam_of_sire", "name": "Asta v Pfalzer Rhein", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Friedel v Grauenstein", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Banjo v d Goldnen Hohe", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Mignon v Parthengrund", "registration_number": None}
        ],
        "source": meta_l40_c1
    },
    {
        "name": "MANFRED V SABINA", "sex": "Male", "registration_number": "723082",
        "birth_date": "Dec. 25, 1927", "color": "Blk & rd",
        "owner": "Emil Hofmann", "owner_location": None,
        "breeder": "Jakob Effler", "breeder_location": "Germany",
        "sire": "Belfried v Johanniter", "sire_registration_number": None,
        "dam": "Carmen v Monchworthof", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Lux v d Blankenburg", "registration_number": "571492"},
            {"role": "dam_of_dam", "name": "Alice of Hohen-Horst", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Adda v Masarino", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Mia v Stresow", "registration_number": "559952"},
            {"role": "sire_of_paternal_granddam", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_l40_c1
    },
    {
        "name": "MIKOSCH OF PONTCHARTRAIN", "sex": "Male", "registration_number": "721118",
        "birth_date": "Mar. 25, 1928", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Anita v Goldgrund", "dam_registration_number": "454887",
        "source": meta_l40_c1
    },
    {
        "name": "NORA V ALLERSCHAUSEN", "sex": "Female", "registration_number": "721666",
        "birth_date": "Dec. 11, 1926", "color": "Br & rd",
        "owner": "Daniel Brodow", "owner_location": None,
        "breeder": "John Ninger", "breeder_location": "Bloomfield, N. J.",
        "sire": "Ego v Allershausen", "sire_registration_number": "525324",
        "dam": "Charlotte v Burgfried", "dam_registration_number": "493051",
        "source": meta_l40_c1
    },
    {
        "name": "OMEGA OF KETTLE COVE", "sex": "Male", "registration_number": "722680",
        "birth_date": "Jan. 2, 1930", "color": "Blk & tn",
        "owner": "Kettle Cove Kennels", "owner_location": "Magnolia, Mass.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Red Roof Hexie", "dam_registration_number": "448028",
        "source": meta_l40_c1
    },
    {
        "name": "PATSY V NIBELUNGENHORT", "sex": "Female", "registration_number": "721247",
        "birth_date": "Sept. 6, 1926", "color": "Chlte & tn",
        "owner": "Georgia Christman", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Dot v Christman", "dam_registration_number": "460743",
        "source": meta_l40_c1
    }
]

# Leaf 40, Column 2 (Starts with PONTCHARTRAIN PRINCESS TILY - 17 dogs down to PINSCHERS (Miniature))
dogs_l40_c2 = [
    {
        "name": "PONTCHARTRAIN PRINCESS TILY", "sex": "Female", "registration_number": "721782",
        "birth_date": "Nov. 29, 1928", "color": "Blk & rd",
        "owner": "Horner W. Ward", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Hertha of Pontchartrain", "dam_registration_number": "610096",
        "source": meta_l40_c2
    },
    {
        "name": "PRINCESS BEL O'PONTCHARTRAIN", "sex": "Female", "registration_number": "724430",
        "birth_date": "Mar. 28, 1929", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Freia v Buetersburg of Ardwin", "dam_registration_number": "499561",
        "source": meta_l40_c2
    },
    {
        "name": "PRINCESS FAVORIETA", "sex": "Female", "registration_number": "721388",
        "birth_date": "April 24, 1929", "color": "Blk & tn",
        "owner": "Gertrude Baker", "owner_location": None,
        "breeder": "Margaret Kussner", "breeder_location": "Philadelphia, Pa.",
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Queen Marie", "dam_registration_number": "574669",
        "source": meta_l40_c2
    },
    {
        "name": "PRINCESS ILISA OF BIRWOOD", "sex": "Female", "registration_number": "724431",
        "birth_date": "Sept. 24, 1927", "color": "Blk, rd",
        "owner": "Glenn S. Staines", "owner_location": None,
        "breeder": "Geo. C. Stokes", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Beda of Nordet Farms", "dam_registration_number": "553344",
        "source": meta_l40_c2
    },
    {
        "name": "PRINCESS TIL O'PONTCHARTRAIN", "sex": "Female", "registration_number": "722202",
        "birth_date": "Nov. 29, 1928", "color": "Blk, rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Hertha of Pontchartrain", "dam_registration_number": "610096",
        "source": meta_l40_c2
    },
    {
        "name": "PRINZ V EDJO", "sex": "Male", "registration_number": "721081",
        "birth_date": "April 2, 1929", "color": "Br",
        "owner": "William Searle", "owner_location": "Nutley, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Baldo v d Spree", "sire_registration_number": "690953",
        "dam": "Asta v Edjo", "dam_registration_number": "713233",
        "source": meta_l40_c2
    },
    {
        "name": "REX KONINGSTAD V D MER", "sex": "Male", "registration_number": "723094",
        "birth_date": "Mar. 31, 1926", "color": "Blk & tn",
        "owner": "Caroline Maier", "owner_location": None,
        "breeder": "Chas. H. Patterson", "breeder_location": "Atlantic City, N. J.",
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Antina v d Holderburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Artus v d Siegestor", "registration_number": None},
            {"role": "dam_of_dam", "name": "Minka v Birkeneck", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Prinz Luitpold", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Flora Lockle", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Bluto v Isarstrand", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Thessa v Ostersee", "registration_number": None}
        ],
        "source": meta_l40_c2
    },
    {
        "name": "TESS O' V SCHOLL", "sex": "Female", "registration_number": "721170",
        "birth_date": "May 13, 1928", "color": "Blk & tn",
        "owner": "A. C. Costello", "owner_location": None,
        "breeder": "S. W. Costello", "breeder_location": "Tacoma, Wash.",
        "sire": "Kount v Schlabber", "sire_registration_number": "589401",
        "dam": "Molly O v Scholl", "dam_registration_number": "678261",
        "source": meta_l40_c2
    },
    {
        "name": "TOD V MALONE", "sex": "Male", "registration_number": "722189",
        "birth_date": "June 2, 1929", "color": "Blk & rust",
        "owner": "C. J. Malone", "owner_location": "Hagerstown, Md.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Ben of Hesse", "sire_registration_number": "578779",
        "dam": "Wanda v Siegester", "dam_registration_number": "684558",
        "source": meta_l40_c2
    },
    {
        "name": "TOGA V ZINGSHEIM", "sex": "Female", "registration_number": "722681",
        "birth_date": "Sept. 3, 1929", "color": "Blk & tn",
        "owner": "Norman Scheibe", "owner_location": None,
        "breeder": "M. L. Zingsheim", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Betsy v Wilhelm", "dam_registration_number": "623310",
        "source": meta_l40_c2
    },
    {
        "name": "TOGO V D SPREE", "sex": "Male", "registration_number": "721955",
        "birth_date": "July 13, 1928", "color": "Blk & tn",
        "owner": "John P. Wetz", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Burschel v d Spree", "sire_registration_number": "487194",
        "dam": "Tooky of Kentucky", "dam_registration_number": "625717",
        "source": meta_l40_c2
    },
    {
        "name": "TOTSIE V STARKENHART", "sex": "Male", "registration_number": "724429",
        "birth_date": "April 27, 1928", "color": "Blk, rd",
        "owner": "Harold J. Riley", "owner_location": None,
        "breeder": "F. C. Bowles", "breeder_location": "Hartville, Ohio",
        "sire": "Westphalia Dyno v Wiesengrund", "sire_registration_number": "365520",
        "dam": "Arrah v Tilhagen", "dam_registration_number": "658426",
        "source": meta_l40_c2
    },
    {
        "name": "TULSA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "721117",
        "birth_date": "Feb. 6, 1929", "color": "Blk, rd",
        "owner": "Edna S. Rathburn", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Neba v Streslau", "dam_registration_number": "539722",
        "source": meta_l40_c2
    },
    {
        "name": "ZAZU V ZINGSHEIM", "sex": "Female", "registration_number": "721625",
        "birth_date": "Sept. 3, 1929", "color": "Blk & tn",
        "owner": "Mr. and Mrs. F. S. Johnson", "owner_location": None,
        "breeder": "M. L. Zingsheim", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Betsy v Wilhelm", "dam_registration_number": "623310",
        "source": meta_l40_c2
    }
]

all_30_03 = dogs_l39_c3 + dogs_l40_c1 + dogs_l40_c2
print(f"Total compiled 1930-03 dogs: {len(all_30_03)}")
print(f"  Leaf 39 Col 3: {len(dogs_l39_c3)}")
print(f"  Leaf 40 Col 1: {len(dogs_l40_c1)}")
print(f"  Leaf 40 Col 2: {len(dogs_l40_c2)}")

Path("stud-scrape/data/verified_1930_03.json").write_text(json.dumps(all_30_03, indent=2), encoding="utf-8")
print("Saved verified 1930-03 records.")
