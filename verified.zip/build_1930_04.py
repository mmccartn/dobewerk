import json
from pathlib import Path

meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-04-01_47_4", "date": "1930-04-01", "volume": "47", "issue": "4", "leaf": 35, "column": 2}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-04-01_47_4", "date": "1930-04-01", "volume": "47", "issue": "4", "leaf": 35, "column": 3}

# Leaf 35, Column 2 (Starts under PINSCHERS (Doberman) - 13 dogs)
c2_dogs = [
    {
        "name": "ASTRID OF DAWN", "sex": "Female", "registration_number": "727910",
        "birth_date": "Mar. 3, 1929", "color": "Blk & rust rd",
        "owner": "E. J. W. Fink", "owner_location": None,
        "breeder": "H. S. Newsom", "breeder_location": "Wheaton, Ill.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Alphabet of Dawn", "dam_registration_number": "681563",
        "source": meta_c2
    },
    {
        "name": "BARON ERICH", "sex": "Male", "registration_number": "725095",
        "birth_date": "June 7, 1928", "color": "Blk & tn",
        "owner": "Robert M. Laird", "owner_location": None,
        "breeder": "R. Blair Stewart", "breeder_location": "Huntingdon, Pa.",
        "sire": "Duke v Dessau", "sire_registration_number": "633803",
        "dam": "Bella v d Wartburg", "dam_registration_number": "614524",
        "source": meta_c2
    },
    {
        "name": "BRUNO", "sex": "Male", "registration_number": "725153",
        "birth_date": "May 9, 1929", "color": "Blk & tn",
        "owner": "Clarence F. Simonson", "owner_location": None,
        "breeder": "Daniel Brodow", "breeder_location": "Nutley, N. J.",
        "sire": "Arno v Edjo", "sire_registration_number": "689776",
        "dam": "Nora v Allershausen", "dam_registration_number": "721666",
        "source": meta_c2
    },
    {
        "name": "DUCHESS", "sex": "Female", "registration_number": "726216",
        "birth_date": "Nov. 22, 1927", "color": "Blk & tn",
        "owner": "Roy E. Brown", "owner_location": None,
        "breeder": "Emil Zipf", "breeder_location": "North Bergen, N. J.",
        "sire": "Tell v Falkenstein", "sire_registration_number": "529765",
        "dam": "Lora v d Burg Heidelberg", "dam_registration_number": "567709",
        "source": meta_c2
    },
    {
        "name": "DUCHESS V OPASIK", "sex": "Female", "registration_number": "725271",
        "birth_date": "May 14, 1928", "color": "Blk, tn mkgs",
        "owner": "C. W. Haight", "owner_location": None,
        "breeder": "Pete Donovan", "breeder_location": "Erie, Pa.",
        "sire": "Major v Burgwall II", "sire_registration_number": "658840",
        "dam": "Donovan's v Skippy", "dam_registration_number": "669650",
        "source": meta_c2
    },
    {
        "name": "EGON V DOMBACHTAL", "sex": "Male", "registration_number": "726317",
        "birth_date": "April 25, 1926", "color": "Rd & br pts",
        "owner": "John M. Watson, Jr.", "owner_location": None,
        "breeder": "Hans Hohn", "breeder_location": "Germany",
        "sire": "Kainz v Langerode", "sire_registration_number": None,
        "dam": "Carmen v Dombachtal", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Helmut v Grammont", "registration_number": None},
            {"role": "dam_of_dam", "name": "Alma v Waidachgrund", "registration_number": "463069"},
            {"role": "sire_of_maternal_grandsire", "name": "Rivals Adonis", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Undine v Grammont", "registration_number": None},
            {"role": "sire_of_sire", "name": "Banjo v d Goldenen Hohe", "registration_number": None},
            {"role": "dam_of_sire", "name": "Anni v Langerode", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Prinz Leuthold v Hornegg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Asta v Starkenburg", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Arnfried v Brandis", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Erika v Parthengrund", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "FRITZ BEELBIHEIM", "sex": "Male", "registration_number": "725971",
        "birth_date": "May 20, 1929", "color": "Rd & tn",
        "owner": "Ann H. Beelby", "owner_location": None,
        "breeder": "Wm. H. Lawson", "breeder_location": "Detroit, Mich.",
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Lawson's Lily", "dam_registration_number": "587606",
        "source": meta_c2
    },
    {
        "name": "FRITZ CARLO RESIDENZ", "sex": "Male", "registration_number": "727485",
        "birth_date": "June 26, 1928", "color": "Blk & tn",
        "owner": "Winford Marsh", "owner_location": None,
        "breeder": "Bernard Buchmann", "breeder_location": "Detroit, Mich.",
        "sire": "Gay Bruno v Residenz", "sire_registration_number": "723007",
        "dam": "Bussy v d Courbiere", "dam_registration_number": "541289",
        "source": meta_c2
    },
    {
        "name": "FRITZ V KRANICHSTEIN", "sex": "Male", "registration_number": "725803",
        "birth_date": "May 24, 1929", "color": "Blk & tn",
        "owner": "Otto Cook", "owner_location": None,
        "breeder": "W. N. McCoy", "breeder_location": "Middletown, Ohio",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Lady of Middletown", "dam_registration_number": "704063",
        "source": meta_c2
    },
    {
        "name": "FRITZE V UNDERSTROUTH", "sex": "Male", "registration_number": "727908",
        "birth_date": "Sept. 21, 1929", "color": "Blk, br mkgs",
        "owner": "Mr. & Mrs. A. M. Schafer", "owner_location": "Cincinnati, Ohio",
        "breeder": "Owners", "breeder_location": None,
        "sire": "Hansel v Crabbside", "sire_registration_number": "611218",
        "dam": "Mia v Homehill", "dam_registration_number": "692097",
        "source": meta_c2
    },
    {
        "name": "GERMANIA V EICHENWALD", "sex": "Female", "registration_number": "724772",
        "birth_date": "July 22, 1928", "color": "Br, rd, mkgs",
        "owner": "Adolph Ille", "owner_location": None,
        "breeder": "R. A. Snyder", "breeder_location": "Oklahoma City, Okla.",
        "sire": "Diethelm v Stresow", "sire_registration_number": "480476",
        "dam": "Asta v Kalkental", "dam_registration_number": "556019",
        "source": meta_c2
    },
    {
        "name": "GILDA GRAY", "sex": "Female", "registration_number": "725480",
        "birth_date": "July 5, 1928", "color": "Blk & tn mkgs",
        "owner": "Gertrude Fausz", "owner_location": None,
        "breeder": "H. W. Pfalzgraf", "breeder_location": "Cincinnati, Ohio",
        "sire": "Apollo v Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Belle v d Spree", "dam_registration_number": "663264",
        "source": meta_c2
    },
    {
        "name": "GILDA V SIGALSBURG", "sex": "Female", "registration_number": "725011",
        "birth_date": "July 18, 1929", "color": "Blk & tn mkgs",
        "owner": "Howard E. Robinson", "owner_location": None,
        "breeder": "John W. Young", "breeder_location": "Rushton, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Lady Sybil v d Schwanenhohe", "dam_registration_number": "696168",
        "source": meta_c2
    }
]

# Leaf 35, Column 3 (Starts with GRAF PHILEMON OF MIDDLETOWN - 18 dogs down to POINTERS)
c3_dogs = [
    {
        "name": "GRAF PHILEMON OF MIDDLETOWN", "sex": "Male", "registration_number": "724550",
        "birth_date": "June 20, 1929", "color": "Rd & tn",
        "owner": "Thelma Baker", "owner_location": None,
        "breeder": "W. N. McCoy", "breeder_location": "Middletown, Ohio",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Jouda v Steigerwald", "dam_registration_number": "686413",
        "source": meta_c3
    },
    {
        "name": "GRETTA V FALKENTURM", "sex": "Female", "registration_number": "725314",
        "birth_date": "April 30, 1928", "color": "Rd & rust",
        "owner": "Leslie L. Romine", "owner_location": "Livingston, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Arno v Arcald", "sire_registration_number": "657709",
        "dam": "Sonia v Falkenturm", "dam_registration_number": "637639",
        "source": meta_c3
    },
    {
        "name": "HANSEL V CRABBSIDE JUNIOR", "sex": "Male", "registration_number": "726553",
        "birth_date": "Sept. 21, 1929", "color": "Chlte & tn",
        "owner": "H. W. Keegler", "owner_location": None,
        "breeder": "Mrs. A. M. Shafer", "breeder_location": "Cincinnati, Ohio",
        "sire": "Hansel v Crabbside", "sire_registration_number": "611218",
        "dam": "Mia v Homehill", "dam_registration_number": "692097",
        "source": meta_c3
    },
    {
        "name": "HANS V SIGALSBURG", "sex": "Male", "registration_number": "724575",
        "birth_date": "July 18, 1929", "color": "Blk, tn mkgs",
        "owner": "Charles H. Marden", "owner_location": None,
        "breeder": "John W. Young", "breeder_location": "Rushton, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Lady Sybil v d Schwanenhohe", "dam_registration_number": "696168",
        "source": meta_c3
    },
    {
        "name": "HAUNS V SIEGESTOR OF WINDMAR", "sex": "Male", "registration_number": "725970",
        "birth_date": "Mar. 13, 1929", "color": "Blk & mhgy",
        "owner": "Katherine F. Burch", "owner_location": None,
        "breeder": "Charles King", "breeder_location": "Baltimore, Md.",
        "sire": "Beowulf v Siegestor", "sire_registration_number": "525331",
        "dam": "Reta v Siegestor", "dam_registration_number": "570743",
        "source": meta_c3
    },
    {
        "name": "HECTOR V BINN", "sex": "Male", "registration_number": "725216",
        "birth_date": "July 2, 1929", "color": "Blk & tn",
        "owner": "Martin Binn", "owner_location": None,
        "breeder": "T. D. Rhoda", "breeder_location": "Milwaukee, Wis.",
        "sire": "MacArthur's Duke", "sire_registration_number": "578254",
        "dam": "Sister", "dam_registration_number": "342063",
        "source": meta_c3
    },
    {
        "name": "JUDITH HYDE", "sex": "Female", "registration_number": "725590",
        "birth_date": "Nov. 17, 1929", "color": "Blk, tn mkgs",
        "owner": "Walter Kirby", "owner_location": None,
        "breeder": "Wayne D. King", "breeder_location": "Bridgeport, Ohio",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Asta v Nashville", "dam_registration_number": "675400",
        "source": meta_c3
    },
    {
        "name": "KITTY OF FREDALEA", "sex": "Female", "registration_number": "725973",
        "birth_date": "July 25, 1929", "color": "Blk & rd",
        "owner": "Floyd W. Warner", "owner_location": None,
        "breeder": "Edward A. Hunter", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Kitty v Rodelthal", "dam_registration_number": "706938",
        "source": meta_c3
    },
    {
        "name": "KONINGSTAD NICHOLAS", "sex": "Male", "registration_number": "727756",
        "birth_date": "April 29, 1925", "color": "Blk with rust mkgs",
        "owner": "K. B. Boker", "owner_location": None,
        "breeder": "White Gate Kennels", "breeder_location": "Willow Grove, Pa.",
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Prinsessin Elfreida v d Koningstad", "dam_registration_number": "417156",
        "source": meta_c3
    },
    {
        "name": "LADY DIANA", "sex": "Female", "registration_number": "727041",
        "birth_date": "Sept. 14, 1928", "color": "Blk, rust mkgs",
        "owner": "F. G. Morton", "owner_location": None,
        "breeder": "Herbert Simeral", "breeder_location": "Granville, Ohio",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Lady Gretchen", "dam_registration_number": "574220",
        "source": meta_c3
    },
    {
        "name": "LA GUARDA BEELBIHEIM", "sex": "Female", "registration_number": "725972",
        "birth_date": "May 20, 1929", "color": "Blk & tn",
        "owner": "Ann H. Beelby", "owner_location": None,
        "breeder": "Wm. H. Lawson", "breeder_location": "Detroit, Mich.",
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Lawson's Lily", "dam_registration_number": "587606",
        "source": meta_c3
    },
    {
        "name": "MARK", "sex": "Male", "registration_number": "724967",
        "birth_date": "June 3, 1929", "color": "Blk & tn",
        "owner": "Walter Jauncey", "owner_location": None,
        "breeder": "Mrs. R. E. Byrd", "breeder_location": "Erie, Pa.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Dolly v Dombachtal of Perry", "dam_registration_number": "555513",
        "source": meta_c3
    },
    {
        "name": "OXBO MAXIE", "sex": "Female", "registration_number": "724563",
        "birth_date": "April 12, 1929", "color": "Rd & rust",
        "owner": "F. C. Fuqua", "owner_location": "Seattle, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Arnold II", "sire_registration_number": "634930",
        "dam": "Erda of Oxbo", "dam_registration_number": "679295",
        "source": meta_c3
    },
    {
        "name": "OXBO QUEEN", "sex": "Female", "registration_number": "724700",
        "birth_date": "April 12, 1929", "color": "Blk & rust",
        "owner": "F. C. Fuqua", "owner_location": "Seattle, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Arnold II", "sire_registration_number": "634930",
        "dam": "Erda of Oxbo", "dam_registration_number": "679295",
        "source": meta_c3
    },
    {
        "name": "PAL OF FRIEDRICHSHAFEN", "sex": "Male", "registration_number": "727604",
        "birth_date": "Oct. 27, 1929", "color": "Blk & rd rust",
        "owner": "Walter N. Manns", "owner_location": None,
        "breeder": "Robert E. O'Connell", "breeder_location": "Ottumwa, Ia.",
        "sire": "Red Roof Rowdy", "sire_registration_number": "392482",
        "dam": "July of Friedrichshafen", "dam_registration_number": "663266",
        "source": meta_c3
    },
    {
        "name": "SCHOENE V HOMEHILL", "sex": "Female", "registration_number": "725969",
        "birth_date": "Feb. 25, 1927", "color": "Rd, tn mkgs",
        "owner": "Mrs. G. A. Rentschler", "owner_location": "Hamilton, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Apollo v Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Dina v Homehill", "dam_registration_number": "581382",
        "source": meta_c3
    },
    {
        "name": "SERANO OF TOPPO", "sex": "Male", "registration_number": "725421",
        "birth_date": "Oct. 2, 1929", "color": "Blk & tn",
        "owner": "W. C. Connely", "owner_location": None,
        "breeder": "Mrs. Elmer Schweninger", "breeder_location": "Cincinnati, Ohio",
        "sire": "Toppo v Sigalsburg", "sire_registration_number": "670191",
        "dam": "Lindy v Benno", "dam_registration_number": "710927",
        "source": meta_c3
    },
    {
        "name": "TRAIL'EM NU KING", "sex": "Male", "registration_number": "724914",
        "birth_date": "Oct. 18, 1929", "color": "Blk, rust rd mkgs",
        "owner": "Mr. and Mrs. Albert T. Rahner", "owner_location": None,
        "breeder": "Ralph T. Miller", "breeder_location": "Philadelphia, Pa.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Asta v d Frankenfurt", "dam_registration_number": "627856",
        "source": meta_c3
    },
    {
        "name": "ZARDIS V ZINGSHEIM", "sex": "Male", "registration_number": "725294",
        "birth_date": "Sept. 3, 1929", "color": "Blk & tn",
        "owner": "J. Warner", "owner_location": None,
        "breeder": "M. L. Zingsheim", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Betsy v Wilhelm", "dam_registration_number": "623310",
        "source": meta_c3
    }
]

leaf35_dogs = c2_dogs + c3_dogs
print(f"Total compiled 1930-04 dogs: {len(leaf35_dogs)}")
print(f"  Col 2: {len(c2_dogs)}")
print(f"  Col 3: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1930_04.json").write_text(json.dumps(leaf35_dogs, indent=2), encoding="utf-8")
print("Saved verified 1930-04 records.")
