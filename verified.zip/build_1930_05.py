import json
from pathlib import Path

meta_l35_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-05-01_47_5", "date": "1930-05-01", "volume": "47", "issue": "5", "leaf": 35, "column": 2}
meta_l35_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-05-01_47_5", "date": "1930-05-01", "volume": "47", "issue": "5", "leaf": 35, "column": 3}
meta_l36_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-05-01_47_5", "date": "1930-05-01", "volume": "47", "issue": "5", "leaf": 36, "column": 1}

# Leaf 35, Column 2 (Starts under PINSCHERS (Doberman) - 19 dogs)
c2_dogs = [
    {
        "name": "ALFRA SCHOEN HUSSAR", "sex": "Female", "registration_number": "731273",
        "birth_date": "Aug. 24, 1929", "color": "Blk & tn",
        "owner": "Robert J. Beiswenger", "owner_location": None,
        "breeder": "Herbert Simeral", "breeder_location": "Granville, Ohio",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Lady Gretchen", "dam_registration_number": "574220",
        "source": meta_l35_c2
    },
    {
        "name": "APPALACHES OF PONTCHARTRAIN", "sex": "Male", "registration_number": "730830",
        "birth_date": "Oct. 1, 1929", "color": "Blk & rd",
        "owner": "David G. White", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Westphalia Dyno v Wiesengrund", "sire_registration_number": "365520",
        "dam": "Princess Ilisa v Birwood", "dam_registration_number": "724431",
        "source": meta_l35_c2
    },
    {
        "name": "ARI V D BLANKENBURG", "sex": "Female", "registration_number": "730206",
        "birth_date": "Nov. 27, 1926", "color": "Blk & tn",
        "owner": "F. C. Fuqua", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "San Jose, Cal.",
        "sire": "Alto v Sigalsburg", "sire_registration_number": None,
        "dam": "Valuta v Riga", "dam_registration_number": "553223",
        "extended_ancestry": [
            {"role": "sire_of_sire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Lotte v Roneckenstein", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Dora v Wiesengrund", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Burschel v Simmenau", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Asta Voss", "registration_number": None}
        ],
        "source": meta_l35_c2
    },
    {
        "name": "BARON V STRESOW", "sex": "Male", "registration_number": "730474",
        "birth_date": "Dec. 21, 1929", "color": "Blk & tn",
        "owner": "Robert A. Jackson", "owner_location": None,
        "breeder": "R. A. Frayol", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Nuttall's Beauty", "dam_registration_number": "608304",
        "source": meta_l35_c2
    },
    {
        "name": "BENNO V HORSTBURG", "sex": "Male", "registration_number": "729270",
        "birth_date": "Sept. 8, 1928", "color": "Blk & tn",
        "owner": "W. H. Lindsey", "owner_location": None,
        "breeder": "Mr. and Mrs. R. D. Coneley", "breeder_location": "Lima, Pa.",
        "sire": "Riff Rudolph v Horstburg", "sire_registration_number": "665178",
        "dam": "Green Gable's Ponjola", "dam_registration_number": "577213",
        "source": meta_l35_c2
    },
    {
        "name": "BENNO V D TANNENBERG", "sex": "Male", "registration_number": "731274",
        "birth_date": "Sept. 16, 1929", "color": "Blk & tn",
        "owner": "G. Parker Geistwhite", "owner_location": None,
        "breeder": "H. L. Foran", "breeder_location": "Grand Island, Nebr.",
        "sire": "Favorit-v-d-Wietze", "sire_registration_number": "549017",
        "dam": "Frieda the Great", "dam_registration_number": "666262",
        "source": meta_l35_c2
    },
    {
        "name": "BERTHA V STARKANHART", "sex": "Female", "registration_number": "729660",
        "birth_date": "Aug. 24, 1929", "color": "Blk, rust rd mkgs",
        "owner": "Mrs. George Everett Kirsch", "owner_location": None,
        "breeder": "F. C. Bowles", "breeder_location": "Hartville, Ohio",
        "sire": "Gavan v Starkanhart", "sire_registration_number": "714861",
        "dam": "Tamar v Tilhagen", "dam_registration_number": "714860",
        "source": meta_l35_c2
    },
    {
        "name": "BROWNIE OF BROADLEAF", "sex": "Female", "registration_number": "728815",
        "birth_date": "Sept. 5, 1926", "color": "Rd, tn mkgs",
        "owner": "Harry E. Allen", "owner_location": "Elmwood, Conn.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Apollo v d Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Frieda's Gretchen", "dam_registration_number": "479756",
        "source": meta_l35_c2
    },
    {
        "name": "CLAUS", "sex": "Male", "registration_number": "729659",
        "birth_date": "Aug. 8, 1929", "color": "Blk & tn",
        "owner": "Edward J. Van den Berg", "owner_location": None,
        "breeder": "E. J. Robinson", "breeder_location": "Milwaukee, Wis.",
        "sire": "Gustl v Tannenhaus", "sire_registration_number": "677473",
        "dam": "Robinson's Greta", "dam_registration_number": "610212",
        "source": meta_l35_c2
    },
    {
        "name": "CLAUS V STOLZENFELS", "sex": "Male", "registration_number": "729273",
        "birth_date": "July 21, 1928", "color": "Blk & tn",
        "owner": "Mrs. H. Gurtler", "owner_location": None,
        "breeder": "Fanny E. Peters", "breeder_location": "Savona, N. Y.",
        "sire": "Alex of Alexander", "sire_registration_number": "400178",
        "dam": "Asta v Petershoff", "dam_registration_number": "663516",
        "source": meta_l35_c2
    },
    {
        "name": "COLONEL RENTSCHLER KORN", "sex": "Male", "registration_number": "731300",
        "birth_date": "June 6, 1929", "color": "Blk, rust mkgs",
        "owner": "Frances H. Korn", "owner_location": None,
        "breeder": "Mrs. G. A. Rentschler", "breeder_location": "Hamilton, Ohio",
        "sire": "Claus v Homehill", "sire_registration_number": "716213",
        "dam": "Lady v Homehill", "dam_registration_number": "565329",
        "source": meta_l35_c2
    },
    {
        "name": "DINA DEMPSEY", "sex": "Female", "registration_number": "728138",
        "birth_date": "Jan. 15, 1928", "color": "Blk & tn",
        "owner": "James M. Dempsey", "owner_location": None,
        "breeder": "Philip Gruber", "breeder_location": "Chicago, Ill.",
        "sire": "Iwo v Park", "sire_registration_number": "674878",
        "dam": "Thea v Hoffeld", "dam_registration_number": "633804",
        "source": meta_l35_c2
    },
    {
        "name": "DUCHESS V NORDHEIM", "sex": "Female", "registration_number": "731377",
        "birth_date": "Nov. 8, 1927", "color": "Blk & tn",
        "owner": "F. R. Winther", "owner_location": None,
        "breeder": "Ray Heernan", "breeder_location": "Sheboygan, Wis.",
        "sire": "Flux v Nordheim", "sire_registration_number": "609080",
        "dam": "Dolly v Reyem", "dam_registration_number": "538466",
        "source": meta_l35_c2
    },
    {
        "name": "ERIC V BLANKENBURG", "sex": "Male", "registration_number": "730310",
        "birth_date": "May 13, 1929", "color": "Br, tn mkgs",
        "owner": "Joanna FitzPatrick", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "Cupertino, Cal.",
        "sire": "Burschel v Falkensee", "sire_registration_number": "553217",
        "dam": "Asta v d Panke", "dam_registration_number": "553219",
        "source": meta_l35_c2
    },
    {
        "name": "ERIC THE RED", "sex": "Male", "registration_number": "728139",
        "birth_date": "Aug. 4, 1929", "color": "Red",
        "owner": "W. H. Barton", "owner_location": None,
        "breeder": "Bert Young", "breeder_location": "Granville, Ohio",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Alice Blue Gown", "dam_registration_number": "492047",
        "source": meta_l35_c2
    },
    {
        "name": "ESTEP'S CHUM", "sex": "Male", "registration_number": "729661",
        "birth_date": "July 5, 1928", "color": "Blk & tn",
        "owner": "H. R. Estep", "owner_location": None,
        "breeder": "H. L. Foran", "breeder_location": "Grand Island, Nebr.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Frieda the Great", "dam_registration_number": "666262",
        "source": meta_l35_c2
    },
    {
        "name": "GINGER BREAD GIRL", "sex": "Female", "registration_number": "729272",
        "birth_date": "May 29, 1929", "color": "Rd & tn",
        "owner": "William H. Lawson", "owner_location": None,
        "breeder": "H. M. Nuttall", "breeder_location": "Detroit, Mich.",
        "sire": "Hektor Plato", "sire_registration_number": "517072",
        "dam": "Nuttall's Tobie", "dam_registration_number": "608303",
        "source": meta_l35_c2
    },
    {
        "name": "GIRL OF THE RIDGE", "sex": "Female", "registration_number": "730070",
        "birth_date": "Sept. 13, 1929", "color": "Blk & tn",
        "owner": "William Stringham", "owner_location": None,
        "breeder": "Chas. Baumgartner", "breeder_location": "Cincinnati, Ohio",
        "sire": "Toppo v Sigalsburg", "sire_registration_number": "670191",
        "dam": "Trudie v d Spree", "dam_registration_number": "541696",
        "source": meta_l35_c2
    },
    {
        "name": "GRAF NICHOLAS GRAMMONT", "sex": "Male", "registration_number": "730069",
        "birth_date": "May 7, 1929", "color": "Rd, rust mkgs",
        "owner": "John W. Gage", "owner_location": "Monticello, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Peter v Roemerhof", "sire_registration_number": "616494",
        "dam": "Schwarze Dame", "dam_registration_number": "672699",
        "source": meta_l35_c2
    }
]

# Leaf 35, Column 3 (Starts with GRETCHEN VI - 24 dogs)
c3_dogs = [
    {
        "name": "GRETCHEN VI", "sex": "Female", "registration_number": "728321",
        "birth_date": "Apr. 11, 1929", "color": "Br & tn",
        "owner": "Mrs. Geo. H. McIntyre", "owner_location": None,
        "breeder": "Robert E. Ellis", "breeder_location": "San Angelo, Texas",
        "sire": "Arno v Burgfried", "sire_registration_number": "426603",
        "dam": "Fidgety", "dam_registration_number": "691489",
        "source": meta_l35_c3
    },
    {
        "name": "HELDA ROMER", "sex": "Female", "registration_number": "729271",
        "birth_date": "Sept. 19, 1928", "color": "Blk, tn mkgs",
        "owner": "Mrs. Louis H. Mussman", "owner_location": None,
        "breeder": "J. A. Finnicum", "breeder_location": "Columbus, O.",
        "sire": "Leuthold of Pontchartrain", "sire_registration_number": "629194",
        "dam": "Bella of Pontchartrain", "dam_registration_number": "578596",
        "source": meta_l35_c3
    },
    {
        "name": "HERR KAPTAIN V RUGEN", "sex": "Male", "registration_number": "730999",
        "birth_date": "Oct. 5, 1929", "color": "Bl & tn",
        "owner": "Arthur F. Siebel", "owner_location": None,
        "breeder": "G. G. Amory", "breeder_location": "Magnolia, Mass.",
        "sire": "Edelblut of Westphalia", "sire_registration_number": "535468",
        "dam": "Moyra of Kettle Cove", "dam_registration_number": "641528",
        "source": meta_l35_c3
    },
    {
        "name": "LEX V GROSSMOUNT", "sex": "Male", "registration_number": "730466",
        "birth_date": "Mar. 24, 1929", "color": "Blk & rd",
        "owner": "G. C. Jaco", "owner_location": "Uniontown, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Marko v Siegerpark", "sire_registration_number": "601008",
        "dam": "Citti v Wilbrink", "dam_registration_number": "601009",
        "source": meta_l35_c3
    },
    {
        "name": "MAJOR V BURGWALL III", "sex": "Male", "registration_number": "728161",
        "birth_date": "May 14, 1928", "color": "Blk & tn",
        "owner": "Mrs. Warren Morton", "owner_location": None,
        "breeder": "Peter Donovan", "breeder_location": "Erie, Pa.",
        "sire": "Major v Burgwall II", "sire_registration_number": "658840",
        "dam": "Donovan's v Skippy", "dam_registration_number": "669650",
        "source": meta_l35_c3
    },
    {
        "name": "MARGARET BALHEXE", "sex": "Female", "registration_number": "730626",
        "birth_date": "Aug. 9, 1929", "color": "Blk & tn",
        "owner": "Harold Barclay", "owner_location": None,
        "breeder": "A. L. Galpin", "breeder_location": "Aurora, Ill.",
        "sire": "Balto Boy", "sire_registration_number": "562371",
        "dam": "Hexe Nell", "dam_registration_number": "683031",
        "source": meta_l35_c3
    },
    {
        "name": "MAX WUNDERSCHON", "sex": "Male", "registration_number": "728141",
        "birth_date": "Sept. 16, 1929", "color": "Blk & tn",
        "owner": "John J. Merkelbach", "owner_location": None,
        "breeder": "H. L. Foran", "breeder_location": "Grand Island, Nebr.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Frieda the Great", "dam_registration_number": "666262",
        "source": meta_l35_c3
    },
    {
        "name": "NELETA NIBELUNGENHARDT", "sex": "Female", "registration_number": "730476",
        "birth_date": "Feb. 12, 1929", "color": "Blk, rust mkgs",
        "owner": "Elinor Stevens", "owner_location": None,
        "breeder": "A. O. Laughlin", "breeder_location": "Akron, Ohio",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Pride of Davanna", "dam_registration_number": "696015",
        "source": meta_l35_c3
    },
    {
        "name": "OSCAR OF KENT COUNTY", "sex": "Male", "registration_number": "730067",
        "birth_date": "July 30, 1929", "color": "Blk & tn",
        "owner": "Leo. A. Jiranek", "owner_location": None,
        "breeder": "O. C. Draheim", "breeder_location": "Fairchild, Miss.",
        "sire": "Gunther v d Residenz", "sire_registration_number": "605528",
        "dam": "Tooky of Kentucky", "dam_registration_number": "625717",
        "source": meta_l35_c3
    },
    {
        "name": "PRINCE V.", "sex": "Male", "registration_number": "730413",
        "birth_date": "July 30, 1929", "color": "Br & rd",
        "owner": "J. Harold Cassin", "owner_location": None,
        "breeder": "John Ninger", "breeder_location": "Bloomfield, N. J.",
        "sire": "Arno v Edjo", "sire_registration_number": "689776",
        "dam": "Bessie", "dam_registration_number": "632045",
        "source": meta_l35_c3
    },
    {
        "name": "PRINCE DUKE OF PONTCHARTRAIN", "sex": "Male", "registration_number": "730068",
        "birth_date": "July 5, 1929", "color": "Blk & rd",
        "owner": "F. G. Haeussermann", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Anita of Pontchartrain", "dam_registration_number": "658425",
        "source": meta_l35_c3
    },
    {
        "name": "PRINCE ROBERT V SARGENT", "sex": "Male", "registration_number": "730066",
        "birth_date": "Dec. 17, 1928", "color": "Blk, tn mkgs",
        "owner": "Wm. Townsend Pheiffer", "owner_location": None,
        "breeder": "Alice G. Cutts", "breeder_location": "Quantico, Va.",
        "sire": "Prince Leo v Occidental", "sire_registration_number": "686204",
        "dam": "Baroness Arva v d Hoehen", "dam_registration_number": "536284",
        "source": meta_l35_c3
    },
    {
        "name": "REX III", "sex": "Male", "registration_number": "728140",
        "birth_date": "Nov. 13, 1927", "color": "Blk & tn",
        "owner": "J. D. Kenney", "owner_location": None,
        "breeder": "James A. Howlett", "breeder_location": "Dorchester, Mass.",
        "sire": "Ari v Friedrichshof", "sire_registration_number": "619254",
        "dam": "Trude v Koenigswart", "dam_registration_number": "544267",
        "source": meta_l35_c3
    },
    {
        "name": "ROBERSON'S CAROLINA", "sex": "Female", "registration_number": "728083",
        "birth_date": "June 29, 1929", "color": "Blk & tn",
        "owner": "Foy Roberson", "owner_location": None,
        "breeder": "Mrs. Bernhard Wiesel", "breeder_location": "West New York, N. J.",
        "sire": "Arno v Edjo", "sire_registration_number": "689776",
        "dam": "Ella v Roemerhof", "dam_registration_number": "711032",
        "source": meta_l35_c3
    },
    {
        "name": "ROBINSON'S AMOS", "sex": "Male", "registration_number": "730467",
        "birth_date": "July 24, 1929", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Mia v Stresow", "dam_registration_number": "559952",
        "source": meta_l35_c3
    },
    {
        "name": "ROBINSON'S ANDY", "sex": "Male", "registration_number": "730468",
        "birth_date": "July 24, 1929", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Mia v Stresow", "dam_registration_number": "559952",
        "source": meta_l35_c3
    },
    {
        "name": "ROBINSON'S MADAME QUEEN", "sex": "Female", "registration_number": "730469",
        "birth_date": "July 24, 1929", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Mia v Stresow", "dam_registration_number": "559952",
        "source": meta_l35_c3
    },
    {
        "name": "ROBINSON'S SONNY BOY", "sex": "Male", "registration_number": "730412",
        "birth_date": "Aug. 8, 1929", "color": "Blk & tn",
        "owner": "R. H. Hommel", "owner_location": None,
        "breeder": "E. J. Robinson", "breeder_location": "Milwaukee, Wis.",
        "sire": "Gustl v Tannenhaus", "sire_registration_number": "677473",
        "dam": "Robinson's Greta", "dam_registration_number": "610212",
        "source": meta_l35_c3
    },
    {
        "name": "SON OF HANSEL", "sex": "Male", "registration_number": "729043",
        "birth_date": "Sept. 21, 1929", "color": "Chlte & tn",
        "owner": "Dan W. Striley", "owner_location": None,
        "breeder": "Mrs. A. M. Shafer", "breeder_location": "Cincinnati, Ohio",
        "sire": "Hansel v Crabbside", "sire_registration_number": "611218",
        "dam": "Mia v Homehill", "dam_registration_number": "692097",
        "source": meta_l35_c3
    },
    {
        "name": "SPARNY PEVELING", "sex": "Male", "registration_number": "729269",
        "birth_date": "Apr. 23, 1929", "color": "Blk & tn",
        "owner": "Charles W. Sharpe", "owner_location": None,
        "breeder": "Frank D. Troth, Jr.", "breeder_location": "Riverside, Calif.",
        "sire": "Carlo v Peveling", "sire_registration_number": "455591",
        "dam": "Linda", "dam_registration_number": "581164",
        "source": meta_l35_c3
    },
    {
        "name": "TELL OF PONTCHARTRAIN", "sex": "Male", "registration_number": "728486",
        "birth_date": "Feb. 6, 1929", "color": "Blk & rd",
        "owner": "Lee L. Taylor", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Neba v Streslau", "dam_registration_number": "539722",
        "source": meta_l35_c3
    },
    {
        "name": "TRAF OF BORNHOLM", "sex": "Male", "registration_number": "730589",
        "birth_date": "June 2, 1929", "color": "Blk & br",
        "owner": "John H. Niles", "owner_location": None,
        "breeder": "Carl N. Hansen", "breeder_location": "Cincinnati, Ohio",
        "sire": "Hamer of Bornholm", "sire_registration_number": "362662",
        "dam": "Flora v d Spree", "dam_registration_number": "606727",
        "source": meta_l35_c3
    },
    {
        "name": "VALUTA V D BLANKENBURG", "sex": "Female", "registration_number": "730071",
        "birth_date": "Apr. 17, 1928", "color": "Blk & tn",
        "owner": "Frank Blattler", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "Cupertino, Calif.",
        "sire": "Burschel v Falkensee", "sire_registration_number": "553217",
        "dam": "Asta v d Panke", "dam_registration_number": "553219",
        "source": meta_l35_c3
    },
    {
        "name": "VEDA V TIMMENAL", "sex": "Female", "registration_number": "730262",
        "birth_date": "Oct. 30, 1929", "color": "Blk, rust mkgs",
        "owner": "Elizabeth D. Andrew", "owner_location": None,
        "breeder": "T. J. Maloney", "breeder_location": "Onondaga Hill, N. Y.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Ehrine v Timmenal", "dam_registration_number": "693119",
        "source": meta_l35_c3
    },
    {
        "name": "YOUNG CLAUS V SIGALSBURG", "sex": "Male", "registration_number": "730003",
        "birth_date": "Sept. 3, 1929", "color": "Blk & tn",
        "owner": "E. K. Childers", "owner_location": None,
        "breeder": "M. L. Zingsheim", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Betsy v Wilhelm", "dam_registration_number": "623310",
        "source": meta_l35_c3
    },
    {
        "name": "ZIGURD V ZINGSHEIM", "sex": "Male", "registration_number": "728283",
        "birth_date": "Sept. 3, 1929", "color": "Blk & tn",
        "owner": "Max Thorek", "owner_location": None,
        "breeder": "M. L. Zingsheim", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Betsy v Wilhelm", "dam_registration_number": "623310",
        "source": meta_l35_c3
    }
]

# Leaf 36, Column 1 top (1 dog down to POINTERS)
c1_dogs = [
    {
        "name": "ZIMMT V ZIMMERMAN", "sex": "Male", "registration_number": "730481",
        "birth_date": "Aug. 3, 1929", "color": "Blk & tn",
        "owner": "Catherine B. Mash", "owner_location": None,
        "breeder": "Daniel L. Hoffman", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Bell v Huffman", "dam_registration_number": "647069",
        "source": meta_l36_c1
    }
]

all_30_05 = c2_dogs + c3_dogs + c1_dogs
print(f"Total compiled 1930-05 dogs: {len(all_30_05)}")
print(f"  Leaf 35 Col 2: {len(c2_dogs)}")
print(f"  Leaf 35 Col 3: {len(c3_dogs)}")
print(f"  Leaf 36 Col 1: {len(c1_dogs)}")

Path("stud-scrape/data/verified_1930_05.json").write_text(json.dumps(all_30_05, indent=2), encoding="utf-8")
print("Saved verified 1930-05 records.")
