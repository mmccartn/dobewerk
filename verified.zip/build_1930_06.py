import json
from pathlib import Path

meta_l31_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-06-01_47_6", "date": "1930-06-01", "volume": "47", "issue": "6", "leaf": 31, "column": 3}
meta_l32_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-06-01_47_6", "date": "1930-06-01", "volume": "47", "issue": "6", "leaf": 32, "column": 1}

# Leaf 31, Column 3 (Starts under PINSCHERS (Doberman) - 18 dogs)
dogs_l31_c3 = [
    {
        "name": "BLACK GOLD V SIGALSBURG", "sex": "Female", "registration_number": "734148",
        "birth_date": "Oct. 23, 1929", "color": "Blk & tn",
        "owner": "Emily L. Bowers", "owner_location": None,
        "breeder": "Dorothy Bolce", "breeder_location": "Cincinnati, Ohio",
        "sire": "Toppo v Sigalsburg", "sire_registration_number": "670191",
        "dam": "Gretel v Horstburg", "dam_registration_number": "670190",
        "source": meta_l31_c3
    },
    {
        "name": "BURGCHOLZ SANDY", "sex": "Male", "registration_number": "732673",
        "birth_date": "July 11, 1929", "color": "Br, rd mkgs",
        "owner": "J. M. Owen", "owner_location": None,
        "breeder": "W. L. Lyons, Jr.", "breeder_location": "Harrods Creek, Ky.",
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Nitta Yuma's Sandy", "dam_registration_number": "697670",
        "source": meta_l31_c3
    },
    {
        "name": "CINDER V GOTTSCHALK", "sex": "Female", "registration_number": "732509",
        "birth_date": "Nov. 11, 1929", "color": "Blk, rd mkgs",
        "owner": "Irene Reeves Moore", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Astor Gottschalk", "sire_registration_number": "639147",
        "dam": "Anita v Grossmannstein", "dam_registration_number": "605203",
        "source": meta_l31_c3
    },
    {
        "name": "CUMBERLAND DOBYHANNA", "sex": "Female", "registration_number": "731856",
        "birth_date": "Mar. 29, 1929", "color": "Blk & tn",
        "owner": "Noble Van Ness", "owner_location": None,
        "breeder": "Oscar L. Simpson", "breeder_location": "Nashville, Tenn.",
        "sire": "Ochsner's Son of Rival", "sire_registration_number": "612378",
        "dam": "Asta v Nashville", "dam_registration_number": "675400",
        "source": meta_l31_c3
    },
    {
        "name": "DOBIE DAVIS", "sex": "Male", "registration_number": "733666",
        "birth_date": "May 29, 1929", "color": "Blk & rd",
        "owner": "Gilmore S. Davis", "owner_location": None,
        "breeder": "Harry Morris", "breeder_location": "Denver, Colo.",
        "sire": "Barry v Seehagen", "sire_registration_number": "463068",
        "dam": "Gerda v Wiedensahl", "dam_registration_number": "640908",
        "source": meta_l31_c3
    },
    {
        "name": "ENDLICH'S PINSCH", "sex": "Female", "registration_number": "732508",
        "birth_date": "June 11, 1927", "color": "Blk & tn",
        "owner": "Anna G. Endlich", "owner_location": None,
        "breeder": "W. B. Washabaugh", "breeder_location": "Erie, Pa.",
        "sire": "Erie Pa", "sire_registration_number": "533542",
        "dam": "Pinsch III", "dam_registration_number": "565072",
        "source": meta_l31_c3
    },
    {
        "name": "ETTA V WILSONA HOF", "sex": "Female", "registration_number": "733027",
        "birth_date": "Oct. 1, 1928", "color": "Blk, rd mkgs",
        "owner": "Ben H. Wilson", "owner_location": "Rushville, Ind.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Astor Gottschalk", "sire_registration_number": "639147",
        "dam": "Anita v Grossmannstein", "dam_registration_number": "605203",
        "source": meta_l31_c3
    },
    {
        "name": "FELTHAM'S PRIDE", "sex": "Female", "registration_number": "733452",
        "birth_date": "Oct. 1, 1929", "color": "Blk, tn mkgs",
        "owner": "Charles R. Goater", "owner_location": None,
        "breeder": "W. S. Bader", "breeder_location": "Arlington, N. J.",
        "sire": "Alex v Polzei", "sire_registration_number": "494371",
        "dam": "Kinka v Schmidt", "dam_registration_number": "645634",
        "source": meta_l31_c3
    },
    {
        "name": "FRIE V D KALKENTAL", "sex": "Male", "registration_number": "734018",
        "birth_date": "Feb. 23, 1930", "color": "Br",
        "owner": "H. T. Rucks", "owner_location": None,
        "breeder": "Harry Mead", "breeder_location": "Oklahoma City, Okla.",
        "sire": "Bingo Son of Edmund", "sire_registration_number": "655754",
        "dam": "Asta v Kalkental", "dam_registration_number": "556019",
        "source": meta_l31_c3
    },
    {
        "name": "FRITZ V FALKENTURM", "sex": "Male", "registration_number": "734049",
        "birth_date": "June 7, 1929", "color": "Blk & tn",
        "owner": "Edna S. Plump", "owner_location": None,
        "breeder": "Leslie L. Romine", "breeder_location": "Livingston, N. J.",
        "sire": "Mac De Haven", "sire_registration_number": "604075",
        "dam": "Sonia v Falkenturm", "dam_registration_number": "637639",
        "source": meta_l31_c3
    },
    {
        "name": "FRITZ V D KONIGSTADT", "sex": "Male", "registration_number": "733318",
        "birth_date": "Oct. 1, 1929", "color": "Blk, tn mkgs",
        "owner": "Malcolm La Prade", "owner_location": None,
        "breeder": "W. S. Bader", "breeder_location": "Arlington, N. J.",
        "sire": "Alex v Polzei", "sire_registration_number": "494371",
        "dam": "Kinka v Schmidt", "dam_registration_number": "645634",
        "source": meta_l31_c3
    },
    {
        "name": "GAMAR OF STARKANHART", "sex": "Male", "registration_number": "731897",
        "birth_date": "Aug. 24, 1929", "color": "Blk & rust rd",
        "owner": "C. E. Fisher", "owner_location": None,
        "breeder": "F. C. Bowles", "breeder_location": "Hartville, Ohio",
        "sire": "Gaven v Starkanhart", "sire_registration_number": "714861",
        "dam": "Tamar v Tilhagen", "dam_registration_number": "714860",
        "source": meta_l31_c3
    },
    {
        "name": "GRAF V SEPP", "sex": "Male", "registration_number": "733058",
        "birth_date": "Nov. 26, 1928", "color": "Blk & tn",
        "owner": "Carl J. Althaus", "owner_location": None,
        "breeder": "F. G. Haeussermann", "breeder_location": "St. Louis, Mo.",
        "sire": "Sepp v Markgrafenberg", "sire_registration_number": "692222",
        "dam": "Gleba of Pontchartrain", "dam_registration_number": "680145",
        "source": meta_l31_c3
    },
    {
        "name": "HARRY V RENNBERG", "sex": "Male", "registration_number": "731621",
        "birth_date": "Mar. 21, 1923", "color": "Dk br",
        "owner": "Jos. Freyberg", "owner_location": None,
        "breeder": "Friedrech Schierer", "breeder_location": "Austria",
        "sire": "Rigo v freien Grund", "sire_registration_number": None,
        "dam": "Hera v Wielandstal", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Tasso v Landgut", "registration_number": None},
            {"role": "dam_of_dam", "name": "Tesca Naxos", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Slenz v Thuringen", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Sonja v Saaletal", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Prinz v Lutzellinden", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Wanda v Bernhardsthal", "registration_number": None},
            {"role": "sire_of_sire", "name": "Rex Salzer", "registration_number": None},
            {"role": "dam_of_sire", "name": "Lady Taussig", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Manfred v Panthengrund", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Nora v Parthengrund", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v Saxonia", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Senta", "registration_number": None}
        ],
        "source": meta_l31_c3
    },
    {
        "name": "HELLA V D WINTERBURG", "sex": "Female", "registration_number": "733229",
        "birth_date": "Jan. 22, 1926", "color": "Blk & rd",
        "owner": "Francis Earle", "owner_location": None,
        "breeder": "Karl Winter", "breeder_location": "Germany",
        "sire": "Axel v Haardtgebirg", "sire_registration_number": None,
        "dam": "Ferri v d Winterburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Benno v d Romerhof", "registration_number": "517673"},
            {"role": "dam_of_dam", "name": "Lotte v Brennetsried", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Waldo Gluck Auf Penzberg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Freya Kadletz", "registration_number": None},
            {"role": "sire_of_sire", "name": "Densos v Atlantic", "registration_number": None},
            {"role": "dam_of_sire", "name": "Asta v Pfalzer Rhein", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Friedel v Grauenstein", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Banjo v d goldnen Hohe", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Mignon v Parthengrund", "registration_number": None}
        ],
        "source": meta_l31_c3
    },
    {
        "name": "JOCKETTE OF RHINEGOLD", "sex": "Female", "registration_number": "734041",
        "birth_date": "Apr. 25, 1929", "color": "Blk & br mkgs",
        "owner": "Edward V. Raslings", "owner_location": None,
        "breeder": "J. C. Zimmerman", "breeder_location": "Detroit, Mich.",
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Alli of Rhinegold", "dam_registration_number": "560310",
        "source": meta_l31_c3
    },
    {
        "name": "KING NIKO OF ANTRIM", "sex": "Male", "registration_number": "733980",
        "birth_date": "Dec. 25, 1929", "color": "Blk & tn",
        "owner": "Robert W. Jameson", "owner_location": "Antrim, N. H.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Elmcroft King Niko", "sire_registration_number": "699665",
        "dam": "Nita v Nibelungenhort", "dam_registration_number": "542235",
        "source": meta_l31_c3
    },
    {
        "name": "KUNO V D WINTERBURG", "sex": "Male", "registration_number": "731635",
        "birth_date": "June 30, 1928", "color": "Blk & rd",
        "owner": "F. C. Fuqua", "owner_location": None,
        "breeder": "Karl Winter", "breeder_location": "Germany",
        "sire": "Edel v d Barbarossahohle", "sire_registration_number": None,
        "dam": "Ferri v d Winterburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Benno v d Romerhof", "registration_number": "517073"},
            {"role": "dam_of_dam", "name": "Lotte v Brennetsried", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Waldo Gluck auf Penzberg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Freya Kadletz", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Dilly v Stolzenberg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Lotte v Simmenau", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_l31_c3
    },
    {
        "name": "LEX V CHARMEL", "sex": "Male", "registration_number": "733967",
        "birth_date": "Oct. 1, 1929", "color": "Blk, tn mkgs",
        "owner": "Charles A. Gramling", "owner_location": None,
        "breeder": "W. S. Bader", "breeder_location": "Arlington, N. J.",
        "sire": "Alex v Polzei", "sire_registration_number": "494371",
        "dam": "Kinka v Schmidt", "dam_registration_number": "645634",
        "source": meta_l31_c3
    }
]

# Leaf 32, Column 1 (Starts with MARKO V D ROMERHOFF - 17 dogs down to POINTERS)
dogs_l32_c1 = [
    {
        "name": "MARKO V D ROMERHOFF", "sex": "Male", "registration_number": "731734",
        "birth_date": "Mar. 24, 1929", "color": "Blk & rd",
        "owner": "Frederick O. Betz", "owner_location": None,
        "breeder": "Edward A. Hunter", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Marko v Siegerpark", "sire_registration_number": "601008",
        "dam": "Citti v Wilbrink", "dam_registration_number": "601009",
        "source": meta_l32_c1
    },
    {
        "name": "MINCHA V. RIETH", "sex": "Female", "registration_number": "732402",
        "birth_date": "Mar. 8, 1928", "color": "Blk & tn",
        "owner": "Henry Meyer", "owner_location": None,
        "breeder": "W. J. Ross", "breeder_location": "Huntington Park, Calif.",
        "sire": "Eric v Barry", "sire_registration_number": "542592",
        "dam": "Princess Dagmar of Denmark", "dam_registration_number": "694126",
        "source": meta_l32_c1
    },
    {
        "name": "MITZI V HELMHOLST", "sex": "Female", "registration_number": "733696",
        "birth_date": "Jan. 12, 1929", "color": "Blk & tn",
        "owner": "Anna Robey", "owner_location": None,
        "breeder": "W. J. Lyster", "breeder_location": "Library, Pa.",
        "sire": "Snitzen's Attila", "sire_registration_number": "603370",
        "dam": "Ottilie Strichrodt", "dam_registration_number": "639194",
        "source": meta_l32_c1
    },
    {
        "name": "NINA OF ANTRIM", "sex": "Female", "registration_number": "733978",
        "birth_date": "Dec. 25, 1929", "color": "Gr & tn",
        "owner": "Robert W. Jameson", "owner_location": "Antrim, N. H.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Elmcroft King Niko", "sire_registration_number": "699665",
        "dam": "Nita v Nibelungenhort", "dam_registration_number": "542235",
        "source": meta_l32_c1
    },
    {
        "name": "OLGA V STROSSEN", "sex": "Female", "registration_number": "731846",
        "birth_date": "Mar. 6, 1929", "color": "Blk & tn",
        "owner": "Bart Delacourt", "owner_location": "Los Angeles, Calif.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Troll Son v d Blankenburg", "sire_registration_number": "618743",
        "dam": "Reno v Strossen", "dam_registration_number": "664506",
        "source": meta_l32_c1
    },
    {
        "name": "ONKEL SAM OF PONTCHARTRAIN", "sex": "Male", "registration_number": "733283",
        "birth_date": "Oct. 26, 1929", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Freia v Buetersburg of Ardwin", "dam_registration_number": "499561",
        "source": meta_l32_c1
    },
    {
        "name": "PEGGY V WEST", "sex": "Female", "registration_number": "733077",
        "birth_date": "May 9, 1928", "color": "Blk, tn mkgs",
        "owner": "John Werner", "owner_location": None,
        "breeder": "Ernest Mansch", "breeder_location": "Chicago, Ill.",
        "sire": "Siegfried v Brunstan", "sire_registration_number": "604561",
        "dam": "Gold Jewel v d Mansch", "dam_registration_number": "585010",
        "source": meta_l32_c1
    },
    {
        "name": "PETER V ELSENBACH", "sex": "Male", "registration_number": "732510",
        "birth_date": "Oct. 30, 1929", "color": "Blk, rust mkgs",
        "owner": "Harriet T. Jack", "owner_location": None,
        "breeder": "T. J. Maloney", "breeder_location": "Onondaga Hill, N. Y.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Ehrine v Timmenal", "dam_registration_number": "693119",
        "source": meta_l32_c1
    },
    {
        "name": "Q E D", "sex": "Male", "registration_number": "732493",
        "birth_date": "Aug. 14, 1929", "color": "Blk & tn",
        "owner": "Mrs. John Decoven Berry", "owner_location": None,
        "breeder": "E. M. Wylie", "breeder_location": "Gardiner, Me.",
        "sire": "Bisdroff", "sire_registration_number": "569707",
        "dam": "Erna v Grothaus", "dam_registration_number": "509483",
        "source": meta_l32_c1
    },
    {
        "name": "REX V TIMMENAL", "sex": "Male", "registration_number": "732292",
        "birth_date": "Oct. 30, 1929", "color": "Blk, rust mkgs",
        "owner": "Harry T. Allen", "owner_location": None,
        "breeder": "T. J. Maloney", "breeder_location": "Onondaga Hill, N. Y.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Ehrine v Timmenal", "dam_registration_number": "693119",
        "source": meta_l32_c1
    },
    {
        "name": "ROLF V SIGALSBURG", "sex": "Male", "registration_number": "733198",
        "birth_date": "Nov. 21, 1929", "color": "Blk & rd",
        "owner": "B. A. Brutscher", "owner_location": None,
        "breeder": "Georgia Christman", "breeder_location": "Harrodsburg, Ky.",
        "sire": "Rolf v Schendsenthal", "sire_registration_number": "624504",
        "dam": "Patsy v Nibelungenhort", "dam_registration_number": "721247",
        "source": meta_l32_c1
    },
    {
        "name": "SALTO OF PONTCHARTRAIN", "sex": "Male", "registration_number": "733963",
        "birth_date": "May 1, 1928", "color": "Blk & rd",
        "owner": "Mrs. David C. Dodge", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Werra v Ostersee", "dam_registration_number": "476468",
        "source": meta_l32_c1
    },
    {
        "name": "SAMSON V STROSSEN", "sex": "Male", "registration_number": "731845",
        "birth_date": "Mar. 6, 1929", "color": "Blk & tn",
        "owner": "Bart Delacourt", "owner_location": "Los Angeles, Calif.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Troll Son v d Blankenburg", "sire_registration_number": "618743",
        "dam": "Reno v Strossen", "dam_registration_number": "664506",
        "source": meta_l32_c1
    },
    {
        "name": "SIS", "sex": "Female", "registration_number": "733319",
        "birth_date": "Oct. 21, 1926", "color": "Blk & tn",
        "owner": "Walter Probert", "owner_location": None,
        "breeder": "F. W. Wearstler", "breeder_location": "Limaville, Ohio",
        "sire": "Benno v d Waldlust", "sire_registration_number": "503559",
        "dam": "Asta of Bornholm", "dam_registration_number": "490366",
        "source": meta_l32_c1
    },
    {
        "name": "SUE'S NITA", "sex": "Female", "registration_number": "733979",
        "birth_date": "Dec. 25, 1929", "color": "Gr & tn",
        "owner": "Robert W. Jameson", "owner_location": "Antrim, N. H.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Elmcroft King Niko", "sire_registration_number": "699665",
        "dam": "Nita v Nibelungenhort", "dam_registration_number": "542235",
        "source": meta_l32_c1
    },
    {
        "name": "TRIXIE MASSON", "sex": "Female", "registration_number": "734149",
        "birth_date": "Feb. 17, 1929", "color": "Rd, tn mkgs",
        "owner": "Harry Isaacs", "owner_location": None,
        "breeder": "Evelyn Masson", "breeder_location": "Eureka, Calif.",
        "sire": "Robinson's Bruno", "sire_registration_number": "494368",
        "dam": "Mugsy v d Robinson", "dam_registration_number": "425459",
        "source": meta_l32_c1
    }
]

all_30_06 = dogs_l31_c3 + dogs_l32_c1
print(f"Total compiled 1930-06 dogs: {len(all_30_06)}")
print(f"  Leaf 31 Col 3: {len(dogs_l31_c3)}")
print(f"  Leaf 32 Col 1: {len(dogs_l32_c1)}")

Path("stud-scrape/data/verified_1930_06.json").write_text(json.dumps(all_30_06, indent=2), encoding="utf-8")
print("Saved verified 1930-06 records.")
