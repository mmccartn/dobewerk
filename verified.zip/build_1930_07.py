import json
from pathlib import Path

meta_l37_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-07-01_47_7", "date": "1930-07-01", "volume": "47", "issue": "7", "leaf": 37, "column": 3}
meta_l38_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-07-01_47_7", "date": "1930-07-01", "volume": "47", "issue": "7", "leaf": 38, "column": 1}
meta_l38_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-07-01_47_7", "date": "1930-07-01", "volume": "47", "issue": "7", "leaf": 38, "column": 2}

# Leaf 37, Column 3 (Starts under PINSCHERS (Doberman) - 13 dogs)
c1_dogs = [
    {
        "name": "AIDA KOESSLER", "sex": "Female", "registration_number": "737977",
        "birth_date": "Mar. 12, 1928", "color": "Blk, rd",
        "owner": "J. L. Meier", "owner_location": None,
        "breeder": "Louis Koessler", "breeder_location": "Germany",
        "sire": "Mikosch v d Eckardtsburg", "sire_registration_number": None,
        "dam": "Adda v Gaitenfeld", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Lord v d Engelsburg", "registration_number": None},
            {"role": "dam_of_dam", "name": "Adda v Viehtor", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Edelblut v d Engelsburg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Asta v d Elbburg", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Ehlers Bella", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Kitty v d Eckardtsburg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Fels v d Eckardtsburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Bona v d Eckardtsburg", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_l37_c3
    },
    {
        "name": "ALICIA OF DAWN", "sex": "Female", "registration_number": "737244",
        "birth_date": "Mar. 3, 1929", "color": "Blk, rust rd mkgs",
        "owner": "Mr. and Mrs. H. S. Newsom", "owner_location": "Wheaton, Ill.",
        "breeder": "Owners", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Alphabet of Dawn", "dam_registration_number": "681563",
        "source": meta_l37_c3
    },
    {
        "name": "AMOR KOESSLER", "sex": "Male", "registration_number": "737978",
        "birth_date": "Mar. 12, 1928", "color": "Blk, rd",
        "owner": "J. L. Meier", "owner_location": None,
        "breeder": "Louis Koessler", "breeder_location": "Germany",
        "sire": "Mikosch v d Eckardtsburg", "sire_registration_number": None,
        "dam": "Adda v Gaitenfeld", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Lord v d Engelsburg", "registration_number": None},
            {"role": "dam_of_dam", "name": "Adda v Viehtor", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Edelblut v d Engelsburg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Asta v d Elbburg", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Ehlers Bella", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Kitty v d Eckardtsburg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Fels v d Eckardtsburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Bona v d Eckardtsburg", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_l37_c3
    },
    {
        "name": "ARLO V D ROEMERHOF", "sex": "Male", "registration_number": "737453",
        "birth_date": "Dec. 16, 1928", "color": "Rd, rust mkgs",
        "owner": "R. C. Reko", "owner_location": "Mason City, Iowa",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Erlo v d Roemerhof", "sire_registration_number": "468297",
        "dam": "Asta v Wiesenfels", "dam_registration_number": "683357",
        "source": meta_l37_c3
    },
    {
        "name": "ASTOR V LAUTERSEE", "sex": "Male", "registration_number": "737995",
        "birth_date": "Apr. 10, 1925", "color": "Blk, rd",
        "owner": "Ross Cunningham", "owner_location": None,
        "breeder": "Hermann Dill", "breeder_location": "Germany",
        "sire": "Ari v Sigalsburg", "sire_registration_number": "517070",
        "dam": "Festa v d Sieg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Prinz Bodo v Hornsheim", "registration_number": None},
            {"role": "dam_of_dam", "name": "Bubine of Elfenfeld", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Moritz v Burgwall", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Eddie v Elfenfeld", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Lord v Ried", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Zilla v Hornsheim", "registration_number": None}
        ],
        "source": meta_l37_c3
    },
    {
        "name": "BARON FRITZ", "sex": "Male", "registration_number": "734787",
        "birth_date": "Jan. 6, 1930", "color": "Blk & tn",
        "owner": "Herbert P. Weierman", "owner_location": None,
        "breeder": "H. Conrad Hare", "breeder_location": "West New York, N. J.",
        "sire": "Big Boy of White Gate", "sire_registration_number": "572868",
        "dam": "Doctor's Bertchen", "dam_registration_number": "627181",
        "source": meta_l37_c3
    },
    {
        "name": "BESSIE MAY V SCHOLL", "sex": "Female", "registration_number": "735568",
        "birth_date": "May 10, 1929", "color": "Blk & tn",
        "owner": "L. S. Mellinger", "owner_location": None,
        "breeder": "Jno. W. Casey", "breeder_location": "Tacoma, Wash.",
        "sire": "Harri v Luckner", "sire_registration_number": "651391",
        "dam": "Molly O v Scholl", "dam_registration_number": "678261",
        "source": meta_l37_c3
    },
    {
        "name": "BOB BECKER", "sex": "Male", "registration_number": "737975",
        "birth_date": "June 15, 1927", "color": "Blk, rd",
        "owner": "J. L. Meier", "owner_location": None,
        "breeder": "Jos. Becker", "breeder_location": "Germany",
        "sire": "Mikosch v Eckardtsburg", "sire_registration_number": None,
        "dam": "Alma Maykuchel", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Achim v Langerode", "registration_number": None},
            {"role": "dam_of_dam", "name": "Hertha v Reussenstein", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Artus v Siegestor", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Fee v Reussenstein", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Prinz Leuthold v Hornegg", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Asta v Starkenburg", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Kitty v d Eckardtsburg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Fels v d Eckardtsburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Bona v d Eckardtsburg", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_l37_c3
    },
    {
        "name": "BODO V ASKANIERLAND", "sex": "Male", "registration_number": "736236",
        "birth_date": "Mar. 25, 1928", "color": "Blk & rd",
        "owner": "Ben H. Wilson", "owner_location": None,
        "breeder": "Franz Stoye", "breeder_location": "Germany",
        "sire": "Alto v Sigalsburg", "sire_registration_number": None,
        "dam": "Lori v Oldenburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Fedor v Butersburg", "registration_number": None},
            {"role": "dam_of_dam", "name": "Afra v d Herrlichkeit", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Eitel v Timmersloh", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Barbara v Fernsicht", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Astor v Goldgrund", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Blanka Halberstadt", "registration_number": None},
            {"role": "sire_of_sire", "name": "Lux v d Blankenburg", "registration_number": "571492"},
            {"role": "dam_of_sire", "name": "Lotte v Roneckenstein", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Dora v Weisengrund", "registration_number": None}
        ],
        "source": meta_l37_c3
    },
    {
        "name": "BUCHNAM'S BRENDA V SIGALSBURG", "sex": "Female", "registration_number": "736112",
        "birth_date": "May 15, 1929", "color": "Blk, rust rd mkgs",
        "owner": "Jessie I. Buchnam", "owner_location": None,
        "breeder": "Paul W. Westfall", "breeder_location": "Eureka, Calif.",
        "sire": "Sig. v Sigalsburg", "sire_registration_number": "659175",
        "dam": "Misery's Redway Sweetheart", "dam_registration_number": "623880",
        "source": meta_l37_c3
    },
    {
        "name": "CAPTAIN LINDY", "sex": "Male", "registration_number": "735681",
        "birth_date": "Feb. 3, 1927", "color": "Br & rd",
        "owner": "William Kuhn", "owner_location": None,
        "breeder": "John Ninger", "breeder_location": "Bloomfield, N. J.",
        "sire": "Ego v Allershausen", "sire_registration_number": "525324",
        "dam": "Geraldine v Rottal", "dam_registration_number": "439946",
        "source": meta_l37_c3
    },
    {
        "name": "CONTESSA V LUXENBURG", "sex": "Female", "registration_number": "736994",
        "birth_date": "Dec. 21, 1929", "color": "Blk & tn",
        "owner": "Miss Patricia Kennedy", "owner_location": None,
        "breeder": "R. A. Frayol", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Nuttall's Beauty", "dam_registration_number": "608304",
        "source": meta_l37_c3
    },
    {
        "name": "DAN OF BORNHOLM", "sex": "Male", "registration_number": "734661",
        "birth_date": "June 2, 1929", "color": "Blk, br mkgs",
        "owner": "John E. Maurer", "owner_location": None,
        "breeder": "Carl N. Hansen", "breeder_location": "Cincinnati, Ohio",
        "sire": "Hamer of Bornholm", "sire_registration_number": "362662",
        "dam": "Flora v d Spree", "dam_registration_number": "606727",
        "source": meta_l37_c3
    },
    {
        "name": "DOCTOR'S BERTCHEN II", "sex": "Female", "registration_number": "737211",
        "birth_date": "April 26, 1928", "color": "Blk & tn",
        "owner": "Otto Wild", "owner_location": None,
        "breeder": "Harry E. Kroin", "breeder_location": "Bklyn., N. Y.",
        "sire": "Prinz Carlo of Westphalia", "sire_registration_number": "517068",
        "dam": "Doctor's Bertchen", "dam_registration_number": "627181",
        "source": meta_l37_c3
    }
]

# Leaf 38, Column 1 (20 dogs)
c2_dogs = [
    {
        "name": "DON OF CONCHO LAND", "sex": "Male", "registration_number": "736932",
        "birth_date": "July 21, 1929", "color": "Blk & tn",
        "owner": "H. O. Bannon", "owner_location": None,
        "breeder": "Laura B. Gibson", "breeder_location": "Hales Corners, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Adie v Reyem", "dam_registration_number": "517408",
        "source": meta_l38_c1
    },
    {
        "name": "DRELL FIAND", "sex": "Male", "registration_number": "737979",
        "birth_date": "Apr. 1, 1928", "color": "Blk, rd",
        "owner": "J. L. Meier", "owner_location": None,
        "breeder": "Charles Fiand", "breeder_location": "Germany",
        "sire": "Mikosch v d Eckardtsburg", "sire_registration_number": None,
        "dam": "Miss de la Marne", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Artur v Hindendorff", "registration_number": None},
            {"role": "dam_of_dam", "name": "Diane de la Cotes Lorance", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Max de Redina", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Liane", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Zeus v Parthengrund", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Asta v Starkenburg", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Kitty v d Eckardtsburg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Fels v d Eckardtsburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Bona v d Eckardtsburg", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_l38_c1
    },
    {
        "name": "DUTCHE V RHODENBACK", "sex": "Male", "registration_number": "735672",
        "birth_date": "Jan. 26, 1930", "color": "Blk & tn",
        "owner": "A. W. Topkis", "owner_location": None,
        "breeder": "Mr. and Mrs. Wm. E. Abbott", "breeder_location": "Camden, N. J.",
        "sire": "Trail Em Adonis", "sire_registration_number": "709104",
        "dam": "Schunppe v Rhodenback", "dam_registration_number": "649814",
        "source": meta_l38_c1
    },
    {
        "name": "DYLIA V HUENN", "sex": "Female", "registration_number": "737120",
        "birth_date": "Aug. 17, 1927", "color": "Blk & tn",
        "owner": "Mrs. Arthur J. Kaminski", "owner_location": None,
        "breeder": "Reyem Kennels", "breeder_location": "Milwaukee, Wis.",
        "sire": "Carso v Siegestor", "sire_registration_number": "534314",
        "dam": "Dilya v Allgeau", "dam_registration_number": "534156",
        "source": meta_l38_c1
    },
    {
        "name": "FRAULIN OF PONTCHARTRAIN", "sex": "Female", "registration_number": "737064",
        "birth_date": "June 20, 1927", "color": "Blk & rd",
        "owner": "G. A. Gorham", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Judy of Detroit", "dam_registration_number": "371474",
        "source": meta_l38_c1
    },
    {
        "name": "FRITZ DHU VARREN II", "sex": "Male", "registration_number": "736334",
        "birth_date": "July 25, 1929", "color": "Blk & rd",
        "owner": "W. C. Acklin", "owner_location": None,
        "breeder": "Edward A. Hunter", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Kitty v Rodeltal", "dam_registration_number": "706938",
        "source": meta_l38_c1
    },
    {
        "name": "FRITZ V RENNBERG", "sex": "Male", "registration_number": "736470",
        "birth_date": "Dec. 19, 1928", "color": "Rd & tn",
        "owner": "Rudolph Freyberg", "owner_location": None,
        "breeder": "Harry H. Brandt", "breeder_location": "Cincinnati, Ohio",
        "sire": "Harry v Rennberg", "sire_registration_number": "731621",
        "dam": "Asta Waldschloss II", "dam_registration_number": "646360",
        "source": meta_l38_c1
    },
    {
        "name": "GOLDINA V D BARBAROSSAHOHLE", "sex": "Female", "registration_number": "737976",
        "birth_date": "July 11, 1928", "color": "Blk, rd",
        "owner": "J. L. Meier", "owner_location": None,
        "breeder": "Gustav Bodewig", "breeder_location": "Germany",
        "sire": "Eitel v d Barbarossahohle", "sire_registration_number": None,
        "dam": "Helga v Sigalsburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_dam", "name": "Elfe v d Volkerruh", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Amor v Gotterfelsen", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Asta v d Volkerruh", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Dilly v Stolzenberg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Lotte v Simmenau", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_l38_c1
    },
    {
        "name": "HADJI BEN RIFF", "sex": "Male", "registration_number": "736408",
        "birth_date": "Dec. 29, 1929", "color": "Blk, rust rd mkgs",
        "owner": "Fritz Pflug", "owner_location": None,
        "breeder": "Joseph Bley", "breeder_location": "Philadelphia, Pa.",
        "sire": "Trail Em Adonis", "sire_registration_number": "709104",
        "dam": "Asta v d Frankanfort II", "dam_registration_number": "709696",
        "source": meta_l38_c1
    },
    {
        "name": "HANSE V RENNBERG", "sex": "Male", "registration_number": "735275",
        "birth_date": "Dec. 19, 1928", "color": "Rd & tn",
        "owner": "Clarence C. Wolf", "owner_location": None,
        "breeder": "Harry H. Brandt", "breeder_location": "Cincinnati, Ohio",
        "sire": "Harry v Rennberg", "sire_registration_number": "731621",
        "dam": "Asta Waldschloss II", "dam_registration_number": "646360",
        "source": meta_l38_c1
    },
    {
        "name": "HERR MAXIE", "sex": "Male", "registration_number": "737452",
        "birth_date": "June 6, 1929", "color": "Blk & rust rd",
        "owner": "Alfred H. Foisie", "owner_location": None,
        "breeder": "Maximilian F. Laessig", "breeder_location": "Philadelphia, Pa.",
        "sire": "Duke of Stolzenberg", "sire_registration_number": "639153",
        "dam": "Daisy v Meerane", "dam_registration_number": "625787",
        "source": meta_l38_c1
    },
    {
        "name": "ILISA V D HOHEN", "sex": "Female", "registration_number": "735502",
        "birth_date": "Mar. 31, 1928", "color": "Blk, tn mkgs",
        "owner": "George Owen Bonawit", "owner_location": None,
        "breeder": "Mrs. M. von Hoegen", "breeder_location": "Towaco, N. J.",
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Berta Rota v Nibelungenhort", "dam_registration_number": "370074",
        "source": meta_l38_c1
    },
    {
        "name": "IRA V D WINTERBURG", "sex": "Female", "registration_number": "736237",
        "birth_date": "June 6, 1927", "color": "Blk, rd mkgs",
        "owner": "Ben H. Wilson", "owner_location": None,
        "breeder": "Karl Winter", "breeder_location": "Germany",
        "sire": "Jolly v d Minneburg", "sire_registration_number": None,
        "dam": "Ferri v d Winterburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Benno v d Romerhof", "registration_number": "517073"},
            {"role": "dam_of_dam", "name": "Lotte v Brennetsried", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Waldo Gluck Auf Penzberg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Freya Kadletz", "registration_number": None},
            {"role": "sire_of_sire", "name": "Ari v Sigalsburg", "registration_number": "517070"},
            {"role": "dam_of_sire", "name": "Birke v Vortrupp", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Deithelm v Hindendorff", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Blute Hock-Wart", "registration_number": None}
        ],
        "source": meta_l38_c1
    },
    {
        "name": "JUDY V TELLESS", "sex": "Female", "registration_number": "736380",
        "birth_date": "June 1, 1925", "color": "Blk, tn mkgs",
        "owner": "Ray W. Preston", "owner_location": None,
        "breeder": "Victor S. Nelson", "breeder_location": "Winthrop, Minn.",
        "sire": "Red Roof Rowdy", "sire_registration_number": "392482",
        "dam": "Bess Felicia", "dam_registration_number": "478062",
        "source": meta_l38_c1
    },
    {
        "name": "KUNO V SCHOENAU", "sex": "Male", "registration_number": "735928",
        "birth_date": "Dec. 28, 1928", "color": "Blk & tn",
        "owner": "Charles A. Kugler", "owner_location": None,
        "breeder": "August L. Hatzfeld", "breeder_location": "Wilkinsburg, Pa.",
        "sire": "Arno v d Kanonenstadt", "sire_registration_number": "540314",
        "dam": "Anni v Dombachtal", "dam_registration_number": "669160",
        "source": meta_l38_c1
    },
    {
        "name": "LADY FREIA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "737148",
        "birth_date": "Mar. 10, 1929", "color": "Blk & rd",
        "owner": "Mrs. David C. Dodge", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Tilly v Melrapp", "dam_registration_number": "462651",
        "source": meta_l38_c1
    },
    {
        "name": "LENZ V SIMMENAU", "sex": "Male", "registration_number": "737795",
        "birth_date": "Nov. 17, 1926", "color": "Blk, rd",
        "owner": "Frank M. Gould", "owner_location": None,
        "breeder": "Carl Winkler", "breeder_location": "Germany",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Lotte v Roneckenstein", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_dam", "name": "Dora v Wiesengrund", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Lea v Weissenfels", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Achim v Langerode", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Leddy v d Blankenburg", "registration_number": None}
        ],
        "source": meta_l38_c1
    },
    {
        "name": "LINDA LOU", "sex": "Female", "registration_number": "736088",
        "birth_date": "May 22, 1927", "color": "Blk & tn",
        "owner": "Royce A. Kidder", "owner_location": None,
        "breeder": "R. S. Reding", "breeder_location": "Nashville, Tenn.",
        "sire": "Rolf v Schendsenthal", "sire_registration_number": "624504",
        "dam": "Dolly Fra Duncan", "dam_registration_number": "580783",
        "source": meta_l38_c1
    }
]

# Leaf 38, Column 2 (Starts with MI-BO V BOYLAN - 18 dogs down to POINTERS)
c3_dogs = [
    {
        "name": "MI-BO V BOYLAN", "sex": "Male", "registration_number": "734506",
        "birth_date": "Aug. 25, 1925", "color": "Rd & tn",
        "owner": "Leroy Boylan", "owner_location": None,
        "breeder": "Karl Thiemann", "breeder_location": "Omaha, Nebr.",
        "sire": "Hasso v Altendorf", "sire_registration_number": "463070",
        "dam": "Alma v Waidachgrund", "dam_registration_number": "463069",
        "source": meta_l38_c2
    },
    {
        "name": "MITZIE II V BLANKENBURG", "sex": "Female", "registration_number": "735682",
        "birth_date": "July 12, 1928", "color": "Blk & tn",
        "owner": "James C. Daily", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "Cupertino, Calif.",
        "sire": "Burschel v Falkensee", "sire_registration_number": "553217",
        "dam": "Asta v Stolzenberg", "dam_registration_number": "553220",
        "source": meta_l38_c2
    },
    {
        "name": "NADA V GROSSMOUNT", "sex": "Female", "registration_number": "737077",
        "birth_date": "Mar. 24, 1929", "color": "Blk & rd",
        "owner": "G. C. Jaco", "owner_location": "Uniontown, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Marko v Siegerpark", "sire_registration_number": "601008",
        "dam": "Citti v Wilbrink", "dam_registration_number": "601009",
        "source": meta_l38_c2
    },
    {
        "name": "NORDSTROM", "sex": "Male", "registration_number": "734556",
        "birth_date": "Sept. 4, 1929", "color": "Blk & rd",
        "owner": "Harry Williams", "owner_location": None,
        "breeder": "S. W. Rogers", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Kona of Pontchartrain", "dam_registration_number": "719496",
        "source": meta_l38_c2
    },
    {
        "name": "OXBO BEN", "sex": "Male", "registration_number": "737333",
        "birth_date": "April 12, 1929", "color": "Rd & tn",
        "owner": "F. C. Fuqua", "owner_location": "Seattle, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Arnold II", "sire_registration_number": "634930",
        "dam": "Erda of Oxbo", "dam_registration_number": "679295",
        "source": meta_l38_c2
    },
    {
        "name": "OXBO BOZO", "sex": "Male", "registration_number": "737334",
        "birth_date": "Jan. 30, 1930", "color": "Blk & tn",
        "owner": "F. C. Fuqua", "owner_location": None,
        "breeder": "Oxbo Kennels", "breeder_location": "Seattle, Wash.",
        "sire": "Carlo v Belger", "sire_registration_number": "533994",
        "dam": "Gerti v Hohenschwanau", "dam_registration_number": "670137",
        "source": meta_l38_c2
    },
    {
        "name": "PAT OF STARKANHART", "sex": "Male", "registration_number": "734706",
        "birth_date": "Sept. 29, 1927", "color": "Blk & tn",
        "owner": "J. R. Gilmore", "owner_location": None,
        "breeder": "F. C. Bowles", "breeder_location": "Hartville, Ohio",
        "sire": "A Rappo of Pontchartrain", "sire_registration_number": "439031",
        "dam": "Rena v Starkanhart", "dam_registration_number": "607477",
        "source": meta_l38_c2
    },
    {
        "name": "PETER V KONIGSTADT", "sex": "Male", "registration_number": "734997",
        "birth_date": "Oct. 1, 1929", "color": "Blk, tn mkgs",
        "owner": "Mrs. Philip Barrison", "owner_location": None,
        "breeder": "W. S. Bader", "breeder_location": "Arlington, N. J.",
        "sire": "Alex v Polzei", "sire_registration_number": "494371",
        "dam": "Kinka v Schmidt", "dam_registration_number": "645634",
        "source": meta_l38_c2
    },
    {
        "name": "PINSCHO RITA REDCLIFFE", "sex": "Female", "registration_number": "737076",
        "birth_date": "Oct. 1, 1929", "color": "Blk & tn",
        "owner": "Anna G. B. Ward", "owner_location": None,
        "breeder": "Edith M. Schenck", "breeder_location": "New Brunswick, N. J.",
        "sire": "Arno v Edjo", "sire_registration_number": "689776",
        "dam": "Alala v d Hohen", "dam_registration_number": "526476",
        "source": meta_l38_c2
    },
    {
        "name": "PONTCHARTRAIN'S PRINCE FALLO", "sex": "Male", "registration_number": "737147",
        "birth_date": "Mar. 10, 1929", "color": "Blk & rd",
        "owner": "Elyse M. Higg", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Tilly v Melrapp", "dam_registration_number": "462651",
        "source": meta_l38_c2
    },
    {
        "name": "PRINCE DYNO OF PONTCHARTRAIN", "sex": "Male", "registration_number": "735692",
        "birth_date": "July 5, 1929", "color": "Blk, rd",
        "owner": "Alfred Fick", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Anita of Pontchartrain", "dam_registration_number": "658425",
        "source": meta_l38_c2
    },
    {
        "name": "PRINCE MARK OF PONTCHARTRAIN", "sex": "Male", "registration_number": "737476",
        "birth_date": "July 1, 1929", "color": "Blk, rd",
        "owner": "Gerald S. Howland", "owner_location": None,
        "breeder": "G. C. Stokes", "breeder_location": "Detroit, Mich.",
        "sire": "Sept of Pontchartrain", "sire_registration_number": "659620",
        "dam": "Beda of Nordet Farms", "dam_registration_number": "553344",
        "source": meta_l38_c2
    },
    {
        "name": "PRINZESS FIDELIA V BURGHOLZ", "sex": "Female", "registration_number": "735298",
        "birth_date": "Nov. 10, 1926", "color": "Rd, tn mkgs",
        "owner": "G. W. Hatfield, Jr.", "owner_location": None,
        "breeder": "Mickburn Kennels", "breeder_location": "Eldorado, Ill.",
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Centa v Rinkenbuehl", "dam_registration_number": "316606",
        "source": meta_l38_c2
    },
    {
        "name": "PRINZ ROLFE V D KONINGSTAD", "sex": "Male", "registration_number": "735673",
        "birth_date": "Jan. 26, 1930", "color": "Blk & tn",
        "owner": "John F. Cook", "owner_location": None,
        "breeder": "Mr. and Mrs. Wm. E. Abbott", "breeder_location": "Camden, N. J.",
        "sire": "Trail Em Adonis", "sire_registration_number": "709104",
        "dam": "Schunppe v Rhodenback", "dam_registration_number": "649814",
        "source": meta_l38_c2
    },
    {
        "name": "SHEIK CARLO V SIGALSBURG", "sex": "Male", "registration_number": "734788",
        "birth_date": "July 18, 1929", "color": "Blk, tn mkgs",
        "owner": "John W. Young", "owner_location": "Rushton, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Lady Sybil v d Schwanenhohe", "dam_registration_number": "696168",
        "source": meta_l38_c2
    },
    {
        "name": "SPHINX", "sex": "Male", "registration_number": "737065",
        "birth_date": "May 8, 1927", "color": "Blk, rd tn mkgs",
        "owner": "R. E. Blankenbuehler", "owner_location": None,
        "breeder": "J. R. Masters", "breeder_location": "Bowerston, Ohio",
        "sire": "Printz Arto v d Spreehort", "sire_registration_number": "559555",
        "dam": "Magelone v Nibelungenhort", "dam_registration_number": "483923",
        "source": meta_l38_c2
    },
    {
        "name": "TAN BOOTS", "sex": "Female", "registration_number": "735817",
        "birth_date": "Sept. 4, 1928", "color": "Blk & tn",
        "owner": "Anton Cihlar, Jr.", "owner_location": None,
        "breeder": "Thos. J. Zamiska", "breeder_location": "Cleveland, Ohio",
        "sire": "Black Bozo", "sire_registration_number": "550705",
        "dam": "Cordula From Lake Erie", "dam_registration_number": "391940",
        "source": meta_l38_c2
    },
    {
        "name": "TAN UEA V FELSENRUHE", "sex": "Female", "registration_number": "735671",
        "birth_date": "July 2, 1924", "color": "Blk & tn",
        "owner": "Gens Christensen", "owner_location": None,
        "breeder": "Margaret Bohland", "breeder_location": "Savona, N. Y.",
        "sire": "Alex of Alexander", "sire_registration_number": "400178",
        "dam": "Trixen v Felsenruhe", "dam_registration_number": "437337",
        "source": meta_l38_c2
    },
    {
        "name": "TEKA", "sex": "Female", "registration_number": "737604",
        "birth_date": "Dec. 2, 1927", "color": "Blk, rust mkgs",
        "owner": "Frank F. Messer", "owner_location": None,
        "breeder": "Harriet B. Patrick", "breeder_location": "Omaha, Nebr.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Elly II v Wiedensahl", "dam_registration_number": "581816",
        "source": meta_l38_c2
    },
    {
        "name": "VEEDOE", "sex": "Male", "registration_number": "736298",
        "birth_date": "July 28, 1928", "color": "Blk & tn mkgs",
        "owner": "C. A. Fausz", "owner_location": None,
        "breeder": "Sofie Frolich", "breeder_location": "Cincinnati, Ohio",
        "sire": "Cito v d Margaretanau", "sire_registration_number": "685406",
        "dam": "Angola v d Margaretanau", "dam_registration_number": "685402",
        "source": meta_l38_c2
    }
]

all_30_07 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1930-07 dogs: {len(all_30_07)}")
print(f"  Leaf 37 Col 3: {len(c1_dogs)}")
print(f"  Leaf 38 Col 1: {len(c2_dogs)}")
print(f"  Leaf 38 Col 2: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1930_07.json").write_text(json.dumps(all_30_07, indent=2), encoding="utf-8")
print("Saved verified 1930-07 records.")
