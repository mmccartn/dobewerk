import json
from pathlib import Path

meta_l57_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-08-01_47_8", "date": "1930-08-01", "volume": "47", "issue": "8", "leaf": 57, "column": 3}
meta_l58_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-08-01_47_8", "date": "1930-08-01", "volume": "47", "issue": "8", "leaf": 58, "column": 1}
meta_l58_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-08-01_47_8", "date": "1930-08-01", "volume": "47", "issue": "8", "leaf": 58, "column": 2}

# Leaf 57, Column 3 (Starts under PINSCHERS (Doberman) - 15 dogs)
c1_dogs = [
    {
        "name": "ADA BLACK JACK", "sex": "Female", "registration_number": "740713",
        "birth_date": "Dec. 2, 1928", "color": "Blk & rd tn",
        "owner": "Sofie Frolich", "owner_location": "Cincinnati, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Cito v d Margaretenau", "sire_registration_number": "685406",
        "dam": "Jouda v Steigerwald", "dam_registration_number": "686413",
        "source": meta_l57_c3
    },
    {
        "name": "AFRA OF MICKBURN", "sex": "Female", "registration_number": "742709",
        "birth_date": "Oct. 19, 1927", "color": "Rd & tn",
        "owner": "George Wood", "owner_location": None,
        "breeder": "Mickburn Kennels", "breeder_location": "Eldorado, Ill.",
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Centa v Rinkenbuehl", "dam_registration_number": "316606",
        "source": meta_l57_c3
    },
    {
        "name": "AL FRIEDA V D JULIUSBURG", "sex": "Female", "registration_number": "741074",
        "birth_date": "Apr. 14, 1928", "color": "Blk & tn",
        "owner": "J. O. Strutz", "owner_location": None,
        "breeder": "Mrs. D. D. Critchlow", "breeder_location": "Oklahoma City, Okla.",
        "sire": "Kungs v Riga", "sire_registration_number": "492581",
        "dam": "Gretta v d Gracht", "dam_registration_number": "560749",
        "source": meta_l57_c3
    },
    {
        "name": "BARON V BOHLMAN", "sex": "Male", "registration_number": "741281",
        "birth_date": "Dec. 16, 1928", "color": "Blk, rd mkgs",
        "owner": "Pat O'Day", "owner_location": None,
        "breeder": "R. C. Reko", "breeder_location": "Mason City, Iowa",
        "sire": "Erlo v d Roemerhof", "sire_registration_number": "468297",
        "dam": "Asta v Wiesenfels", "dam_registration_number": "683357",
        "source": meta_l57_c3
    },
    {
        "name": "BARON V TIMMENAL", "sex": "Male", "registration_number": "738553",
        "birth_date": "Oct. 30, 1929", "color": "Blk, rust mkgs",
        "owner": "Kenneth Andrew", "owner_location": None,
        "breeder": "T. J. Maloney", "breeder_location": "Onondaga Hills, N. Y.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Ehrine v Timmenal", "dam_registration_number": "693119",
        "source": meta_l57_c3
    },
    {
        "name": "BEAUTY V BONER", "sex": "Female", "registration_number": "741836",
        "birth_date": "Jan. 6, 1930", "color": "Blk & tn",
        "owner": "S. M. Boner", "owner_location": None,
        "breeder": "Hugo Brenninkmeyer", "breeder_location": "Granite City, Ill.",
        "sire": "Rich v Rulenburg", "sire_registration_number": "698612",
        "dam": "Senta v Tecklenburg", "dam_registration_number": "713600",
        "source": meta_l57_c3
    },
    {
        "name": "BETTY V AUGARTEN", "sex": "Female", "registration_number": "739710",
        "birth_date": "Sept. 4, 1929", "color": "Blk & rust",
        "owner": "H. F. Brown", "owner_location": None,
        "breeder": "W. N. McCoy", "breeder_location": "Middletown, Ohio",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Lola v Augarten", "dam_registration_number": "724400",
        "source": meta_l57_c3
    },
    {
        "name": "BIM BO SIGALSBURG", "sex": "Male", "registration_number": "740475",
        "birth_date": "Feb. 16, 1930", "color": "Blk & tn",
        "owner": "Bernard Edw. Hinrichs", "owner_location": None,
        "breeder": "E. E. Carrier", "breeder_location": "Summerville, Pa.",
        "sire": "Hans v Dombachtal", "sire_registration_number": "606668",
        "dam": "Brunhilde v Sigalsburg", "dam_registration_number": "667532",
        "source": meta_l57_c3
    },
    {
        "name": "BLACK JACK OF PONTCHARTRAIN", "sex": "Male", "registration_number": "742823",
        "birth_date": "Sept. 4, 1929", "color": "Blk rd",
        "owner": "Jack Dempsey", "owner_location": None,
        "breeder": "S. W. Rogers", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Kona of Pontchartrain", "dam_registration_number": "719496",
        "source": meta_l57_c3
    },
    {
        "name": "BONITA V STARKANHART", "sex": "Female", "registration_number": "738995",
        "birth_date": "Aug. 24, 1929", "color": "Blk & rust rd",
        "owner": "Paul B. Wallace", "owner_location": None,
        "breeder": "F. C. Bowles", "breeder_location": "Hartville, Ohio",
        "sire": "Gavan v Starkanhart", "sire_registration_number": "714861",
        "dam": "Tamar v Tilhagen", "dam_registration_number": "714860",
        "source": meta_l57_c3
    },
    {
        "name": "BROWNIE V D STERNALLEE", "sex": "Female", "registration_number": "742710",
        "birth_date": "July 17, 1927", "color": "Br & tn",
        "owner": "George Wood", "owner_location": None,
        "breeder": "H. A. Zobel", "breeder_location": "Dysart, Iowa",
        "sire": "Hans v d Sternallee", "sire_registration_number": "349691",
        "dam": "Hilda v Bismark", "dam_registration_number": "612307",
        "source": meta_l57_c3
    },
    {
        "name": "CARLO V SCHOENAU", "sex": "Male", "registration_number": "742490",
        "birth_date": "Dec. 28, 1928", "color": "Rd & tn",
        "owner": "R. J. Albrecht", "owner_location": None,
        "breeder": "August L. Hatzfeld", "breeder_location": "Wilkinsburg, Pa.",
        "sire": "Arno v d Kanonenstadt", "sire_registration_number": "540314",
        "dam": "Anni v Dombachtal", "dam_registration_number": "669160",
        "source": meta_l57_c3
    },
    {
        "name": "COUNT V DUFFIELD", "sex": "Male", "registration_number": "740275",
        "birth_date": "Dec. 5, 1929", "color": "Blk & tn",
        "owner": "Josephine H. Loewenstein", "owner_location": None,
        "breeder": "Jerry Schnabl", "breeder_location": "Riverside, Ill.",
        "sire": "Fritz v Duffield", "sire_registration_number": "704573",
        "dam": "Freda from Duffield", "dam_registration_number": "608113",
        "source": meta_l57_c3
    },
    {
        "name": "DEEKA V SMITZ", "sex": "Male", "registration_number": "742861",
        "birth_date": "Mar. 13, 1929", "color": "Blk, tn pts",
        "owner": "Robt. Upshaw", "owner_location": None,
        "breeder": "W. J. Hendley", "breeder_location": "Columbia, Tenn.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Phronsie Pepper", "dam_registration_number": "506372",
        "source": meta_l57_c3
    },
    {
        "name": "DELMA V ECKENER", "sex": "Female", "registration_number": "739766",
        "birth_date": "July 2, 1929", "color": "Rd & tn",
        "owner": "Arthur T. Jones", "owner_location": "Lynbrook, L. I., N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Delma De Haven", "dam_registration_number": "660602",
        "source": meta_l57_c3
    }
]

# Leaf 58, Column 1 (20 dogs)
c2_dogs = [
    {
        "name": "DOBB", "sex": "Male", "registration_number": "741601",
        "birth_date": "Oct. 20, 1929", "color": "Blk & tn",
        "owner": "W. F. Gates", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Beauty of Kentucky", "dam_registration_number": "517728",
        "source": meta_l58_c1
    },
    {
        "name": "DODDY OF RHINEGOLD", "sex": "Female", "registration_number": "739666",
        "birth_date": "June 26, 1929", "color": "Blk, tn mkgs",
        "owner": "Rhinegold Kennels", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Hasso v Sigalsburg Rhinegold", "sire_registration_number": "695158",
        "dam": "Princess Lita of Rhinegold", "dam_registration_number": "568913",
        "source": meta_l58_c1
    },
    {
        "name": "DUKE LU", "sex": "Male", "registration_number": "740024",
        "birth_date": "Jan. 1, 1930", "color": "Br & tn",
        "owner": "Lugi Di Scala", "owner_location": None,
        "breeder": "Gus Stoffels", "breeder_location": "Nutley, N. J.",
        "sire": "Yvon of Edjo", "sire_registration_number": "689593",
        "dam": "Rea of New Jersey", "dam_registration_number": "685584",
        "source": meta_l58_c1
    },
    {
        "name": "DUNK", "sex": "Male", "registration_number": "741602",
        "birth_date": "Oct. 20, 1929", "color": "Blk & tn",
        "owner": "W. F. Gates", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Beauty of Kentucky", "dam_registration_number": "517728",
        "source": meta_l58_c1
    },
    {
        "name": "ELLICA OF EDJO", "sex": "Female", "registration_number": "739496",
        "birth_date": "July 24, 1927", "color": "Rd & tn",
        "owner": "Jarvis C. Buxton", "owner_location": None,
        "breeder": "Mrs. Joseph C. Blauner", "breeder_location": "Clifton, N. J.",
        "sire": "Prinz Carlo of Westphalia", "sire_registration_number": "517068",
        "dam": "Ellie of Edjo", "dam_registration_number": "689594",
        "source": meta_l58_c1
    },
    {
        "name": "ETTA V WILSONA HOF", "sex": "Female", "registration_number": "733027",
        "birth_date": "Oct. 1, 1928", "color": "Blk, rd mkgs",
        "owner": "Ben H. Wilson", "owner_location": "Rushville, Ind.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Benno v d Drehbrucke", "sire_registration_number": "639147",
        "dam": "Anita v Grossmannstein", "dam_registration_number": "605203",
        "handwritten_annotation": "Incorrectly published in June, 1930, Stud Book",
        "source": meta_l58_c1
    },
    {
        "name": "FALKO V D MARGARETENAU", "sex": "Male", "registration_number": "740710",
        "birth_date": "Sept. 28, 1923", "color": "Blk, rd",
        "owner": "Max R. Vollmer", "owner_location": None,
        "breeder": "Peter Schmelz", "breeder_location": "Germany",
        "sire": "Diethelm v Hindendorff", "sire_registration_number": None,
        "dam": "Waly II v Lutzellinden", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Nero v Hornsheim", "registration_number": None},
            {"role": "dam_of_dam", "name": "Nelly II v Lutzellinden", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Hellegaf v Thiringen", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Nelly III v Lutzellinden", "registration_number": None},
            {"role": "sire_of_sire", "name": "Troll v d Blankenburg", "registration_number": "553218"},
            {"role": "dam_of_sire", "name": "Asta v Starkenburg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Betty v Jagerhof", "registration_number": None}
        ],
        "source": meta_l58_c1
    },
    {
        "name": "FRITZ V SCHOENBRUNN", "sex": "Male", "registration_number": "742411",
        "birth_date": "June 10, 1929", "color": "Blk & rd",
        "owner": "Wm. Moore", "owner_location": None,
        "breeder": "Edward A. Hunter", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Marko v Siegerpark", "sire_registration_number": "601008",
        "dam": "Norma v Streslau", "dam_registration_number": "586734",
        "source": meta_l58_c1
    },
    {
        "name": "FRITZ V D SPREE", "sex": "Male", "registration_number": "742716",
        "birth_date": "July 14, 1928", "color": "Blk & tn",
        "owner": "Andrew M. E. Dunlap", "owner_location": None,
        "breeder": "Edw. K. Shelmerdine, III", "breeder_location": "Wallingford, Pa.",
        "sire": "Krumm v d Spree", "sire_registration_number": "500610",
        "dam": "Gretchen v Heusen", "dam_registration_number": "636348",
        "source": meta_l58_c1
    },
    {
        "name": "HASSAM V D BASSEWITZ", "sex": "Male", "registration_number": "738326",
        "birth_date": "June 3, 1927", "color": "Blk, rust rd mkgs",
        "owner": "Helen Louise Eaton", "owner_location": None,
        "breeder": "E. J. Child", "breeder_location": "Brookfield, Mass.",
        "sire": "Hasso v Bassewitz", "sire_registration_number": "517338",
        "dam": "Asta v d Berne", "dam_registration_number": "502591",
        "source": meta_l58_c1
    },
    {
        "name": "HEJSA", "sex": "Male", "registration_number": "739670",
        "birth_date": "Nov. 7, 1928", "color": "Blk & tn",
        "owner": "Esther Rudbeck", "owner_location": None,
        "breeder": "R. A. Hampe", "breeder_location": "Bloomfield, N. J.",
        "sire": "Arno v Edjo", "sire_registration_number": "689776",
        "dam": "Togo v Allershausen", "dam_registration_number": "698571",
        "source": meta_l58_c1
    },
    {
        "name": "HENRY OF RHINEGOLD", "sex": "Male", "registration_number": "739668",
        "birth_date": "Apr. 25, 1929", "color": "Blk, br mkgs",
        "owner": "Rhinegold Kennels", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Alli of Rhinegold", "dam_registration_number": "560310",
        "source": meta_l58_c1
    },
    {
        "name": "ISKO V BRUNIA", "sex": "Male", "registration_number": "742243",
        "birth_date": "Apr. 7, 1928", "color": "Blk & rd",
        "owner": "Burke Healey", "owner_location": None,
        "breeder": "Heinz Brunen", "breeder_location": "Germany",
        "sire": "Claus v Wilbrink", "sire_registration_number": None,
        "dam": "Adda v Nettebach", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Claus v d Spree", "registration_number": "412661"},
            {"role": "dam_of_dam", "name": "Dora v Barental", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Prinz Bodo v Hornsheim", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Blanka v Hohenstein", "registration_number": None},
            {"role": "sire_of_sire", "name": "Benno v d Romerhof", "registration_number": "517073"},
            {"role": "dam_of_sire", "name": "Asta v Wilbrink", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Cuno v Sporthof", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Else v Sporthof", "registration_number": None}
        ],
        "source": meta_l58_c1
    },
    {
        "name": "JOHN SNITENS", "sex": "Male", "registration_number": "738300",
        "birth_date": "Jan. 12, 1929", "color": "Blk & tn",
        "owner": "Harry Moore Felton", "owner_location": None,
        "breeder": "W. J. Lyster", "breeder_location": "Library, Pa.",
        "sire": "Sniten's Attila", "sire_registration_number": "603370",
        "dam": "Ottilie Strichrodt", "dam_registration_number": "639194",
        "source": meta_l58_c1
    },
    {
        "name": "JUDY'S SON OF PONTCHARTRAIN", "sex": "Male", "registration_number": "742824",
        "birth_date": "June 20, 1927", "color": "Blk, rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Judy of Detroit", "dam_registration_number": "371474",
        "source": meta_l58_c1
    },
    {
        "name": "JUNKER", "sex": "Male", "registration_number": "740030",
        "birth_date": "June 3, 1929", "color": "Blk & tn",
        "owner": "Edward P. Walker", "owner_location": None,
        "breeder": "Mrs. R. E. Byrd", "breeder_location": "Erie, Pa.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Dolly v Dombachtal of Perry", "dam_registration_number": "555513",
        "source": meta_l58_c1
    },
    {
        "name": "LADY OLGA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "738959",
        "birth_date": "Oct. 26, 1929", "color": "Blk & rd",
        "owner": "Mr. and Mrs. N. E. Tyrell", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Freia v Buetersburg of Ardwin", "dam_registration_number": "499561",
        "source": meta_l58_c1
    },
    {
        "name": "LORD FROM CINCINNATI", "sex": "Male", "registration_number": "740712",
        "birth_date": "Dec. 2, 1928", "color": "Blk, rd mkgs",
        "owner": "Sofie Frolich", "owner_location": "Cincinnati, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Cito v d Margaretenau", "sire_registration_number": "685406",
        "dam": "Jouda v Steigerwald", "dam_registration_number": "686413",
        "source": meta_l58_c1
    },
    {
        "name": "LYNDORA FRA DUNCAN", "sex": "Female", "registration_number": "739761",
        "birth_date": "Sept. 9, 1926", "color": "Chlte & tn",
        "owner": "C. A. Duncan", "owner_location": "Paris, Ky.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Dot v Christman", "dam_registration_number": "460743",
        "source": meta_l58_c1
    },
    {
        "name": "MISS FLASH OF RHINEGOLD", "sex": "Female", "registration_number": "739667",
        "birth_date": "Apr. 25, 1929", "color": "Br, tn mkgs",
        "owner": "Rhinegold Kennels", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Alli of Rhinegold", "dam_registration_number": "560310",
        "source": meta_l58_c1
    },
    {
        "name": "MITZI OF CANOE BROOK", "sex": "Female", "registration_number": "739497",
        "birth_date": "Sept. 19, 1929", "color": "Blk & tn",
        "owner": "J. C. Buxton", "owner_location": "Livingston, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Ellica of Edjo", "dam_registration_number": "739496",
        "handwritten_annotation": "See Correction Oct., 1930 issue - p. 88",
        "source": meta_l58_c1
    }
]

# Leaf 58, Column 2 (Starts with NEG V GROSSMOUNT - 13 dogs down to PINSCHERS (Miniature))
c3_dogs = [
    {
        "name": "NEG V GROSSMOUNT", "sex": "Female", "registration_number": "742033",
        "birth_date": "Aug. 10, 1929", "color": "Blk & tn",
        "owner": "G. C. Jaco", "owner_location": None,
        "breeder": "Geo. H. Jones", "breeder_location": "Danville, Ill.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Princess v Rudolphsburg", "dam_registration_number": "569711",
        "source": meta_l58_c2
    },
    {
        "name": "PANDY", "sex": "Female", "registration_number": "740711",
        "birth_date": "July 28, 1929", "color": "Blk & rd, tn mkgs",
        "owner": "Sofie Frolich", "owner_location": "Cincinnati, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Cito v d Margaretenau", "sire_registration_number": "685406",
        "dam": "Angola v d Margaretenau", "dam_registration_number": "685402",
        "source": meta_l58_c2
    },
    {
        "name": "PERRY'S GRETCHEN V SAINT SEBALD", "sex": "Female", "registration_number": "741371",
        "birth_date": "Aug. 20, 1928", "color": "Blk & tn",
        "owner": "Collier A. Dean", "owner_location": None,
        "breeder": "Perry Kennels", "breeder_location": "Erie, Pa.",
        "sire": "Perry's Hasso v Saint Sebald", "sire_registration_number": "546165",
        "dam": "Guda v Telless", "dam_registration_number": "319376",
        "source": meta_l58_c2
    },
    {
        "name": "PRIM OF RHINEGOLD", "sex": "Female", "registration_number": "739665",
        "birth_date": "June 26, 1929", "color": "Blk & tn mkgs",
        "owner": "Rhinegold Kennels", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Hasso v Sigalsburg Rhinegold", "sire_registration_number": "695158",
        "dam": "Princess Lita of Rhinegold", "dam_registration_number": "568913",
        "source": meta_l58_c2
    },
    {
        "name": "PRINCE V WILSONA HOF", "sex": "Male", "registration_number": "742672",
        "birth_date": "Sept. 6, 1929", "color": "Rd & tn",
        "owner": "Raehel Fitler", "owner_location": None,
        "breeder": "W. N. McCoy", "breeder_location": "Middletown, Ohio",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Lola v Augarten", "dam_registration_number": "724400",
        "source": meta_l58_c2
    },
    {
        "name": "PRINZ OLRAC", "sex": "Male", "registration_number": "739722",
        "birth_date": "May 10, 1929", "color": "Rd & tn",
        "owner": "Harry Rankin", "owner_location": None,
        "breeder": "R. A. Hampe", "breeder_location": "Bloomfield, N. J.",
        "sire": "Arno v Edjo", "sire_registration_number": "689776",
        "dam": "Togo v Allershausen", "dam_registration_number": "698571",
        "source": meta_l58_c2
    },
    {
        "name": "PRINZ OMAR OF PONTCHARTRAIN", "sex": "Male", "registration_number": "738125",
        "birth_date": "Oct. 26, 1929", "color": "Blk & rd",
        "owner": "Francis Cruger", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Freia v Buetersburg of Ardwin", "dam_registration_number": "499561",
        "source": meta_l58_c2
    },
    {
        "name": "QUEEN V GRIMM", "sex": "Female", "registration_number": "741280",
        "birth_date": "Aug. 24, 1929", "color": "Blk & tn",
        "owner": "J. E. Grimm", "owner_location": None,
        "breeder": "Herbert C. Simeral", "breeder_location": "Granville, Ohio",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Lady Gretchen", "dam_registration_number": "574220",
        "source": meta_l58_c2
    },
    {
        "name": "RAPPO OF GLENACRES", "sex": "Male", "registration_number": "742116",
        "birth_date": "Jan. 21, 1929", "color": "Blk & tn",
        "owner": "Glenn Adams", "owner_location": None,
        "breeder": "Dorothy Bolce", "breeder_location": "Cincinnati, Ohio",
        "sire": "Toppo v Sigalsburg", "sire_registration_number": "670191",
        "dam": "Gretel v Horstburg", "dam_registration_number": "670190",
        "source": meta_l58_c2
    },
    {
        "name": "REX IV", "sex": "Male", "registration_number": "739727",
        "birth_date": "Apr. 23, 1929", "color": "Blk & tn",
        "owner": "Oscar Ruelicke", "owner_location": None,
        "breeder": "Jos. Sickinger", "breeder_location": "Union, N. J.",
        "sire": "Captain Lindy", "sire_registration_number": "735681",
        "dam": "Bella", "dam_registration_number": "680101",
        "source": meta_l58_c2
    },
    {
        "name": "ROSE OF SHARON", "sex": "Female", "registration_number": "740714",
        "birth_date": "July 28, 1928", "color": "Rd & rd tn",
        "owner": "Sofie Frolich", "owner_location": "Cincinnati, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Cito v d Margaretenau", "sire_registration_number": "685406",
        "dam": "Angola v d Margaretenau", "dam_registration_number": "685402",
        "source": meta_l58_c2
    },
    {
        "name": "SALLY OF PONTCHARTRAIN", "sex": "Female", "registration_number": "739905",
        "birth_date": "Aug. 29, 1929", "color": "Blk & rd",
        "owner": "Gertrude B. White", "owner_location": None,
        "breeder": "G. O. Gorham", "breeder_location": "Royal Oak, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Fraulin of Pontchartrain", "dam_registration_number": "737064",
        "source": meta_l58_c2
    },
    {
        "name": "ZARGOT OF TYWORTH", "sex": "Male", "registration_number": "738958",
        "birth_date": "Apr. 13, 1929", "color": "Blk & rust",
        "owner": "Mr. and Mrs. A. B. Cook, Jr.", "owner_location": None,
        "breeder": "Mr. and Mrs. N. E. Tyrrell", "breeder_location": "Ionia, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Nita v Streslau", "dam_registration_number": "539723",
        "source": meta_l58_c2
    },
    {
        "name": "ZECKSEL V ZINGSHEIM", "sex": "Male", "registration_number": "739033",
        "birth_date": "Sept. 3, 1929", "color": "Blk & tn",
        "owner": "Mr. and Mrs. M. L. Zingsheim", "owner_location": None,
        "breeder": "M. L. Zingsheim", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Betsy v Wilhelm", "dam_registration_number": "623310",
        "source": meta_l58_c2
    }
]

all_30_08 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1930-08 dogs: {len(all_30_08)}")
print(f"  Leaf 57 Col 3: {len(c1_dogs)}")
print(f"  Leaf 58 Col 1: {len(c2_dogs)}")
print(f"  Leaf 58 Col 2: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1930_08.json").write_text(json.dumps(all_30_08, indent=2), encoding="utf-8")
print("Saved verified 1930-08 records.")
