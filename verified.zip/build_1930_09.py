import json
from pathlib import Path

meta_l54_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-09-01_47_9", "date": "1930-09-01", "volume": "47", "issue": "9", "leaf": 54, "column": 1}
meta_l54_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-09-01_47_9", "date": "1930-09-01", "volume": "47", "issue": "9", "leaf": 54, "column": 2}
meta_l54_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-09-01_47_9", "date": "1930-09-01", "volume": "47", "issue": "9", "leaf": 54, "column": 3}

# Leaf 54, Column 1 (Starts under PINSCHERS (Doberman) - 6 dogs)
c1_dogs = [
    {
        "name": "BENNO V GRAMMONT", "sex": "Male", "registration_number": "746638",
        "birth_date": "June 4, 1929", "color": "Blk & tn",
        "owner": "Mr. and Mrs. Richard Carvel", "owner_location": None,
        "breeder": "Eunice Gregg", "breeder_location": "Oneida, N. Y.",
        "sire": "Benno v Roemerhof", "sire_registration_number": "517073",
        "dam": "Blanka v Zoic", "dam_registration_number": "460683",
        "source": meta_l54_c1
    },
    {
        "name": "BISMARK V ROEMERHOF", "sex": "Male", "registration_number": "744494",
        "birth_date": "May 23, 1929", "color": "Blk & tn",
        "owner": "Ross C. Poultney", "owner_location": None,
        "breeder": "J. M. Kaiser", "breeder_location": "Chicago, Ill.",
        "sire": "Peter v Roemerhof", "sire_registration_number": "616494",
        "dam": "Eda v Hugelstadt", "dam_registration_number": "627598",
        "source": meta_l54_c1
    },
    {
        "name": "CAESAR V RUDOLPHSBURG", "sex": "Male", "registration_number": "744134",
        "birth_date": "Aug. 1, 1929", "color": "Blk, rust rd",
        "owner": "John G. Llewellyn", "owner_location": None,
        "breeder": "Mrs. C. A. Bergman", "breeder_location": "Ottumwa, Iowa",
        "sire": "Rudolph v d Rudolphsburg", "sire_registration_number": "493363",
        "dam": "Dolly v Jaegershof", "dam_registration_number": "719690",
        "source": meta_l54_c1
    },
    {
        "name": "CARLO OF MIDDLETOWN", "sex": "Male", "registration_number": "743836",
        "birth_date": "June 20, 1929", "color": "Rd & tn",
        "owner": "C. E. Murphy", "owner_location": None,
        "breeder": "W. N. McCoy", "breeder_location": "Middletown, Ohio",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Jouda v Steigerwald", "dam_registration_number": "686413",
        "source": meta_l54_c1
    },
    {
        "name": "COUNT FRITZ V NIBELUNGENHORT", "sex": "Male", "registration_number": "744359",
        "birth_date": "May 14, 1927", "color": "Blk & tn",
        "owner": "Mrs. Rose M. Thompson", "owner_location": None,
        "breeder": "J. Finley Webb", "breeder_location": "Wenatchee, Wash.",
        "sire": "Count Monte v Nibelungenhort", "sire_registration_number": "379730",
        "dam": "Edna v Geholz", "dam_registration_number": "382664",
        "source": meta_l54_c1
    },
    {
        "name": "DECKER V LUDWIGSBURG", "sex": "Male", "registration_number": "743928",
        "birth_date": "Dec. 2, 1928", "color": "Blk & tn",
        "owner": "G. G. Amory", "owner_location": None,
        "breeder": "Georg Lochner", "breeder_location": "Germany",
        "sire": "Stolz v Roneckenstein", "sire_registration_number": None,
        "dam": "Cilly v Rheinadler", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_dam", "name": "Betty v St. Odile", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Fels v d Eckardtsburg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Bela v d Meinau", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_sire", "name": "Dora v Wiesengrund", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Lea v Wissenfels", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Achim v Langerode", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Leddy v d Blankenburg", "registration_number": None}
        ],
        "source": meta_l54_c1
    }
]

# Leaf 54, Column 2 (20 dogs)
c2_dogs = [
    {
        "name": "DOBER V JACOBS", "sex": "Male", "registration_number": "743118",
        "birth_date": "Dec. 5, 1929", "color": "Blk & tn",
        "owner": "W. L. Jacobs", "owner_location": None,
        "breeder": "Jerry Schnabl", "breeder_location": "Riverside, Ill.",
        "sire": "Fritz v Duffield", "sire_registration_number": "704573",
        "dam": "Freida v Duffield", "dam_registration_number": "608113",
        "source": meta_l54_c2
    },
    {
        "name": "DOLLY", "sex": "Female", "registration_number": "745811",
        "birth_date": "Mar. 4, 1928", "color": "Blk & tn",
        "owner": "Joseph Piszcz", "owner_location": None,
        "breeder": "Eunice Gregg", "breeder_location": "Oneida, N. Y.",
        "sire": "Max v d Spree", "sire_registration_number": "513007",
        "dam": "Dolly v d Eckardtsburg", "dam_registration_number": "438107",
        "source": meta_l54_c2
    },
    {
        "name": "DORN V PETERSTOFF", "sex": "Male", "registration_number": "745929",
        "birth_date": "July 16, 1929", "color": "Blk & rust",
        "owner": "George Pugh", "owner_location": "Lawton, Okla.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Diethelm v Stresow", "sire_registration_number": "480476",
        "dam": "Sally Dorn of Petershoff", "dam_registration_number": "719921",
        "source": meta_l54_c2
    },
    {
        "name": "ERA V D SCHOLLE", "sex": "Female", "registration_number": "747143",
        "birth_date": "Apr. 28, 1929", "color": "Blk, rd",
        "owner": "Henrich Heindl", "owner_location": None,
        "breeder": "Josef Bodingbauer", "breeder_location": "Austria",
        "sire": "Hugin v d Scholle", "sire_registration_number": None,
        "dam": "Hispa v d Scholle", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Bilo v Burghausen", "registration_number": None},
            {"role": "dam_of_dam", "name": "Kundrie v d Scholle", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Assis v d Scholle", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Ridhill v d Scholle", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Argo v Altmannsdorf", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Brenda v d Marburg", "registration_number": None},
            {"role": "sire_of_sire", "name": "Pazzo v d Blumau", "registration_number": None},
            {"role": "dam_of_sire", "name": "Rakscha v St. Rochus", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Prinz v Kastel", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Lady v St. Rochus", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Pazzo Naxos", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Hexe Winkler", "registration_number": None}
        ],
        "source": meta_l54_c2
    },
    {
        "name": "GRETA V D SCHWANENHOHE", "sex": "Female", "registration_number": "744683",
        "birth_date": "July 18, 1929", "color": "Blk, tn mkgs",
        "owner": "John W. Young", "owner_location": "Rushton, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Lady Sybil v d Schwanenhohe", "dam_registration_number": "696168",
        "source": meta_l54_c2
    },
    {
        "name": "GRETEL V HOMEHILL", "sex": "Female", "registration_number": "744721",
        "birth_date": "Sept. 21, 1929", "color": "Chlte & tn",
        "owner": "J. R. Johnson", "owner_location": None,
        "breeder": "Mrs. A. M. Shafer", "breeder_location": "Cincinnati, Ohio",
        "sire": "Hansel v Crabbside", "sire_registration_number": "611218",
        "dam": "Mia v Homehill", "dam_registration_number": "692097",
        "source": meta_l54_c2
    },
    {
        "name": "HATHOR FRA DUNCAN", "sex": "Female", "registration_number": "743870",
        "birth_date": "July 13, 1928", "color": "Blk & tn",
        "owner": "C. A. Duncan", "owner_location": None,
        "breeder": "O. C. Draheim", "breeder_location": "Fairchild, Wis.",
        "sire": "Burschel v d Spree", "sire_registration_number": "487194",
        "dam": "Tooky of Kentucky", "dam_registration_number": "625717",
        "source": meta_l54_c2
    },
    {
        "name": "HEINRICH V DOMBACHTAL", "sex": "Male", "registration_number": "740475",
        "birth_date": "Feb. 16, 1930", "color": "Blk & tn",
        "owner": "Bernard Edw. Hinrichs", "owner_location": None,
        "breeder": "E. E. Carrier", "breeder_location": "Summerville, Pa.",
        "sire": "Hans v Dombachtal", "sire_registration_number": "606668",
        "dam": "Brunhilde v Sigalsburg", "dam_registration_number": "667532",
        "source": meta_l54_c2
    },
    {
        "name": "JEANNE OF RHINEGOLD", "sex": "Female", "registration_number": "746768",
        "birth_date": "Apr. 25, 1929", "color": "Blk, br mkgs",
        "owner": "Mr. and Mrs. A. S. McNeil", "owner_location": None,
        "breeder": "John C. Zimmerman", "breeder_location": "Detroit, Mich.",
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Alli of Rhinegold", "dam_registration_number": "560310",
        "source": meta_l54_c2
    },
    {
        "name": "LADY A", "sex": "Female", "registration_number": "745786",
        "birth_date": "Nov. 6, 1928", "color": "Blk, tn mkgs",
        "owner": "Wm. F. Quinn", "owner_location": None,
        "breeder": "Edw. S. Smith", "breeder_location": "Keyport, N. J.",
        "sire": "Carlo v Musenbach", "sire_registration_number": "561755",
        "dam": "Dea v Schuetzeneck", "dam_registration_number": "690954",
        "source": meta_l54_c2
    },
    {
        "name": "LADY ROEMERHOF", "sex": "Female", "registration_number": "745764",
        "birth_date": "Oct. 16, 1928", "color": "Blk, tn mkgs",
        "owner": "Nelson M. Packard", "owner_location": None,
        "breeder": "Harold A. Peck", "breeder_location": "Albany, N. Y.",
        "sire": "Benno v Roemerhof", "sire_registration_number": "517073",
        "dam": "Chummy", "dam_registration_number": "648332",
        "source": meta_l54_c2
    },
    {
        "name": "LUE V WIEDENSAHL", "sex": "Female", "registration_number": "743218",
        "birth_date": "Mar. 30, 1928", "color": "Blk & tn",
        "owner": "M. A. Boylan", "owner_location": None,
        "breeder": "Mrs. Carl Thiemann", "breeder_location": "Omaha, Neb.",
        "sire": "Favorite v d Wietze", "sire_registration_number": "549017",
        "dam": "Elly v Wiedensahl", "dam_registration_number": "489274",
        "source": meta_l54_c2
    },
    {
        "name": "MIKSELLA V SIGALSBURG", "sex": "Male", "registration_number": "744767",
        "birth_date": "July 13, 1929", "color": "Blk & rust",
        "owner": "Charles R. Meusel", "owner_location": None,
        "breeder": "R. C. Reko", "breeder_location": "Mason City, Iowa",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Asta v Wiesenfels", "dam_registration_number": "683357",
        "source": meta_l54_c2
    },
    {
        "name": "PAT V STOLZENFELS", "sex": "Male", "registration_number": "746034",
        "birth_date": "Oct. 9, 1924", "color": "Blk, tn rust",
        "owner": "George Hammond", "owner_location": None,
        "breeder": "Helen Gurtler", "breeder_location": "Rochester, N. Y.",
        "sire": "Danny v Schonwald", "sire_registration_number": "388194",
        "dam": "Witch Hexe v Stolzenfels", "dam_registration_number": "309321",
        "source": meta_l54_c2
    },
    {
        "name": "PAUL REVERE", "sex": "Male", "registration_number": "744872",
        "birth_date": "Apr. 18, 1930", "color": "Blk & mhgy",
        "owner": "Charles F. Harley", "owner_location": "Baltimore, Md.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Hauns v Telless", "sire_registration_number": "435133",
        "dam": "Berta v Hohenschwanau", "dam_registration_number": "673537",
        "source": meta_l54_c2
    },
    {
        "name": "PETER V ROEMERHOF II", "sex": "Male", "registration_number": "746871",
        "birth_date": "Nov. 3, 1928", "color": "Bl & tn",
        "owner": "Florence L. Austin", "owner_location": None,
        "breeder": "Eunice Gregg", "breeder_location": "Oneida, N. Y.",
        "sire": "Benno v Roemerhof", "sire_registration_number": "517073",
        "dam": "Blanka Zoic", "dam_registration_number": "460683",
        "source": meta_l54_c2
    },
    {
        "name": "PRINCE MAX OF PONTCHARTRAIN", "sex": "Male", "registration_number": "745274",
        "birth_date": "July 1, 1929", "color": "Blk & rd",
        "owner": "W. H. Dillinger", "owner_location": None,
        "breeder": "G. C. Stokes", "breeder_location": "Detroit, Mich.",
        "sire": "Sept of Pontchartrain", "sire_registration_number": "659620",
        "dam": "Beda of Nordet Farms", "dam_registration_number": "553344",
        "source": meta_l54_c2
    },
    {
        "name": "PRINCE REX V NIBELUNGENHORT", "sex": "Male", "registration_number": "744754",
        "birth_date": "May 14, 1927", "color": "Blk & tn",
        "owner": "J. M. Carmody", "owner_location": None,
        "breeder": "J. F. Webb", "breeder_location": "Wenatchee, Wash.",
        "sire": "Count Monte v Nibelungenhort", "sire_registration_number": "379730",
        "dam": "Edna v Geholz", "dam_registration_number": "382664",
        "source": meta_l54_c2
    },
    {
        "name": "PRINTZ CARLO OF CARLISLE", "sex": "Male", "registration_number": "745147",
        "birth_date": "Aug. 18, 1928", "color": "Blk & tn",
        "owner": "C. B. Strayer", "owner_location": "Carlisle, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Cuno of Westphalia", "sire_registration_number": "578324",
        "dam": "Doby v Lueschenhof", "dam_registration_number": "571080",
        "source": meta_l54_c2
    },
    {
        "name": "PRINZ CUNO OF PONTCHARTRAIN", "sex": "Male", "registration_number": "747297",
        "birth_date": "Dec. 24, 1929", "color": "Blk & rd",
        "owner": "Geo. A. Taylor", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Ilisa of Pontchartrain", "dam_registration_number": "571491",
        "source": meta_l54_c2
    }
]

# Leaf 54, Column 3 (12 dogs down to PINSCHERS (Miniature))
c3_dogs = [
    {
        "name": "QUEEN OF ARKEDEN", "sex": "Female", "registration_number": "746385",
        "birth_date": "Apr. 12, 1929", "color": "Blk & tn",
        "owner": "Mrs. Janet Meader", "owner_location": None,
        "breeder": "Paul Venth", "breeder_location": "Lakeview, L. I., N. Y.",
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Girl of Arkeden", "dam_registration_number": "683828",
        "source": meta_l54_c3
    },
    {
        "name": "REX LINDENBURG", "sex": "Male", "registration_number": "743068",
        "birth_date": "Dec. 20, 1929", "color": "Blk, br mkgs",
        "owner": "H. B. Huston", "owner_location": None,
        "breeder": "Walton G. Alcorn", "breeder_location": "Columbus, Ohio",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Hilda v Leuthobelle", "dam_registration_number": "699983",
        "source": meta_l54_c3
    },
    {
        "name": "RINE V D SPREE", "sex": "Male", "registration_number": "744129",
        "birth_date": "Jan. 4, 1930", "color": "Blk & wh",
        "owner": "Charles S. Krumrine", "owner_location": None,
        "breeder": "Edw. K. Shelmerdine, III", "breeder_location": "Wallingford, Pa.",
        "sire": "Krumm v d Spree", "sire_registration_number": "500610",
        "dam": "Gretchen v Heusen", "dam_registration_number": "636348",
        "source": meta_l54_c3
    },
    {
        "name": "ROLLO V POPP", "sex": "Male", "registration_number": "747259",
        "birth_date": "July 17, 1929", "color": "Blk, tn mkgs",
        "owner": "Anthony Yeray", "owner_location": None,
        "breeder": "T. E. Popp", "breeder_location": "West Allis, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Ida v Hornegg", "dam_registration_number": "534315",
        "source": meta_l54_c3
    },
    {
        "name": "SENTA V INGENHOVEN", "sex": "Female", "registration_number": "744128",
        "birth_date": "July 2, 1929", "color": "Blk, br mks",
        "owner": "O. L. Cox", "owner_location": None,
        "breeder": "Herman Brauckmann", "breeder_location": "Los Angeles, Calif.",
        "sire": "Marti v Delenburg", "sire_registration_number": "699328",
        "dam": "Minka v Ingenhoven", "dam_registration_number": "694842",
        "source": meta_l54_c3
    },
    {
        "name": "TAGO V D DONAUSTADT", "sex": "Male", "registration_number": "747144",
        "birth_date": "Apr. 28, 1929", "color": "Blk, rd",
        "owner": "Heinrich Heindl", "owner_location": None,
        "breeder": "Rudolf Hoch", "breeder_location": "Austria",
        "sire": "Hagen v Kettenhof", "sire_registration_number": None,
        "dam": "Holle v d Donaustadt", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Bruno v Achau", "registration_number": None},
            {"role": "dam_of_dam", "name": "Bessie v d Donaustadt", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Slenz v Thuringen", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Lori Kretzer", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Rigo v freien Grund", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Bella II v Altmannsdorf", "registration_number": None},
            {"role": "sire_of_sire", "name": "Frech v Doberdo", "registration_number": None},
            {"role": "dam_of_sire", "name": "Holle v d Donaustadt", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Bruno v Achau", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Bessie v d Donaustadt", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Bombe Hoch-Wart", "registration_number": None}
        ],
        "source": meta_l54_c3
    },
    {
        "name": "TILLY'S HILDA", "sex": "Female", "registration_number": "743850",
        "birth_date": "Aug. 22, 1927", "color": "Blk, rust rd mkgs",
        "owner": "G. W. Meserve", "owner_location": "Framingham, Mass.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Edelblut of Westphalia", "sire_registration_number": "535468",
        "dam": "Hela's Tilly", "dam_registration_number": "435425",
        "source": meta_l54_c3
    },
    {
        "name": "TONY V. D. RHEINPERLE", "sex": "Male", "registration_number": "745462",
        "birth_date": "Aug. 3, 1929", "color": "Blk & tn",
        "owner": "Margaret L. Goodwin", "owner_location": None,
        "breeder": "Daniel L. Hoffman", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Bell v Huffmann", "dam_registration_number": "647069",
        "source": meta_l54_c3
    },
    {
        "name": "TOPSY V DOMBACHTAL", "sex": "Female", "registration_number": "745980",
        "birth_date": "Dec. 15, 1929", "color": "Blk & tn",
        "owner": "Geo. W. Cross", "owner_location": None,
        "breeder": "Mrs. R. E. Byrd", "breeder_location": "Erie, Pa.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Hetty v Dombachtal", "dam_registration_number": "653112",
        "source": meta_l54_c3
    },
    {
        "name": "TRAIL 'EM ADONIS II", "sex": "Male", "registration_number": "743097",
        "birth_date": "Dec. 29, 1929", "color": "Blk, rust rd",
        "owner": "Ralph T. Miller", "owner_location": None,
        "breeder": "Joseph Bley", "breeder_location": "Philadelphia, Pa.",
        "sire": "Trail 'Em Adonis", "sire_registration_number": "709104",
        "dam": "Asta v d Frankenfurt II", "dam_registration_number": "709696",
        "source": meta_l54_c3
    },
    {
        "name": "VADA", "sex": "Female", "registration_number": "746147",
        "birth_date": "Sept. 21, 1929", "color": "Blk, br mkgs",
        "owner": "Mrs. John E. Maurer", "owner_location": None,
        "breeder": "Mrs. A. M. Shafer", "breeder_location": "Cincinnati, Ohio",
        "sire": "Hansel v Crabbside", "sire_registration_number": "611218",
        "dam": "Mia v Homehill", "dam_registration_number": "692097",
        "source": meta_l54_c3
    },
    {
        "name": "WIZARD OF DAWN", "sex": "Male", "registration_number": "744787",
        "birth_date": "Feb. 27, 1930", "color": "Blk & rd",
        "owner": "Paul B. Wallace", "owner_location": None,
        "breeder": "H. S. Newsom", "breeder_location": "Wheaton, Ill.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Schatz v Ostersee", "dam_registration_number": "514975",
        "source": meta_l54_c3
    }
]

all_30_09 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1930-09 dogs: {len(all_30_09)}")
print(f"  Leaf 54 Col 1: {len(c1_dogs)}")
print(f"  Leaf 54 Col 2: {len(c2_dogs)}")
print(f"  Leaf 54 Col 3: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1930_09.json").write_text(json.dumps(all_30_09, indent=2), encoding="utf-8")
print("Saved verified 1930-09 records.")
