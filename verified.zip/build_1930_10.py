import json
from pathlib import Path

meta_l60_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-10-01_47_10", "date": "1930-10-01", "volume": "47", "issue": "10", "leaf": 60, "column": 1}
meta_l60_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-10-01_47_10", "date": "1930-10-01", "volume": "47", "issue": "10", "leaf": 60, "column": 2}
meta_l60_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-10-01_47_10", "date": "1930-10-01", "volume": "47", "issue": "10", "leaf": 60, "column": 3}
meta_l61_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-10-01_47_10", "date": "1930-10-01", "volume": "47", "issue": "10", "leaf": 61, "column": 1}

# Leaf 60, Column 1 bottom (Starts under PINSCHERS (Doberman) - 14 dogs)
c1_dogs = [
    {
        "name": "ASA V REMERK", "sex": "Male", "registration_number": "751472",
        "birth_date": "Jan. 22, 1929", "color": "Blk & tn",
        "owner": "E. G. Kremer", "owner_location": None,
        "breeder": "E. J. Robinson", "breeder_location": "Milwaukee, Wis.",
        "sire": "Westphalia Dyno v Wiesengrund", "sire_registration_number": "365520",
        "dam": "Robinson's Greta", "dam_registration_number": "610212",
        "source": meta_l60_c1
    },
    {
        "name": "ASTA V ALLIE", "sex": "Female", "registration_number": "749528",
        "birth_date": "Aug. 17, 1921", "color": "Blk & tn",
        "owner": "Joseph Weissenhofer", "owner_location": None,
        "breeder": "Norah E. Knowlson", "breeder_location": "Hinsdale, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Sallie v Allie", "dam_registration_number": "605877",
        "source": meta_l60_c1
    },
    {
        "name": "ASTA V D COR", "sex": "Female", "registration_number": "751900",
        "birth_date": "Apr. 13, 1926", "color": "Rd, tn mkgs",
        "owner": "J. H. Mullarkey", "owner_location": None,
        "breeder": "Florence J. Connor", "breeder_location": "Brookfield, Mass.",
        "sire": "Hasso v Bassowitz", "sire_registration_number": "517338",
        "dam": "Asta v d Berne", "dam_registration_number": "502591",
        "source": meta_l60_c1
    },
    {
        "name": "ASTA V MENDELSOHN", "sex": "Female", "registration_number": "750696",
        "birth_date": "Oct. 22, 1927", "color": "Blk & rd",
        "owner": "F. C. Fuqua", "owner_location": None,
        "breeder": "Albert Geigle", "breeder_location": "Germany",
        "sire": "Baron v Hohenlohe", "sire_registration_number": None,
        "dam": "Cilla v Rebstock", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Bruno v Schonbuch", "registration_number": None},
            {"role": "dam_of_dam", "name": "Breta Colonia", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Hektor Klett", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Schelde II v Colonia", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Asko v Grodno", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Liesel v Klesbernwald", "registration_number": None},
            {"role": "sire_of_sire", "name": "Pik v Ostersee", "registration_number": None},
            {"role": "dam_of_sire", "name": "Rica v d Fruhlingshohe", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Prinz Leutholf v Hornegg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Julia v Haiterbach", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lord v d Horstburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Freya v Ostersee", "registration_number": None}
        ],
        "source": meta_l60_c1
    },
    {
        "name": "ATTILO OF OXBO", "sex": "Male", "registration_number": "751353",
        "birth_date": "Feb. 16, 1930", "color": "Br & tn",
        "owner": "F. C. Fuqua", "owner_location": None,
        "breeder": "Frank Blattler", "breeder_location": "Berkeley, Calif.",
        "sire": "Emir Lentulus", "sire_registration_number": "714460",
        "dam": "Valuta v d Blankenburg", "dam_registration_number": "730071",
        "source": meta_l60_c1
    },
    {
        "name": "BAD BOY OF KETTLE COVE", "sex": "Male", "registration_number": "747946",
        "birth_date": "Mar. 31, 1930", "color": "Blk & tn",
        "owner": "Kettle Cove Kennels", "owner_location": "Magnolia, Mass.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Lotte v Berghofen", "dam_registration_number": "695157",
        "source": meta_l60_c1
    },
    {
        "name": "BETTY V SIGALSBURG", "sex": "Female", "registration_number": "750268",
        "birth_date": "July 17, 1929", "color": "Blk, tn mkgs",
        "owner": "Arthur F. Tuttle", "owner_location": None,
        "breeder": "T. E. Popp", "breeder_location": "West Allis, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Ida v Hornegg", "dam_registration_number": "534315",
        "source": meta_l60_c1
    },
    {
        "name": "BLACK PRINCESS", "sex": "Female", "registration_number": "749687",
        "birth_date": "Apr. 10, 1929", "color": "Blk & rust",
        "owner": "Clarence O. Lenning", "owner_location": None,
        "breeder": "Henry Ulrich", "breeder_location": "N. Y. City",
        "sire": "Duck Bauers", "sire_registration_number": "674948",
        "dam": "Asta v Hohenschwanau", "dam_registration_number": "609112",
        "source": meta_l60_c1
    },
    {
        "name": "BLITZ V D VOSS", "sex": "Male", "registration_number": "748272",
        "birth_date": "Mar. 31, 1930", "color": "Blk & tn",
        "owner": "J. Frank Thain", "owner_location": None,
        "breeder": "Kettle Cove Kennels", "breeder_location": "Magnolia, Mass.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Lotte v Berghofen", "dam_registration_number": "695157",
        "source": meta_l60_c1
    },
    {
        "name": "CAMILLA WUHLER", "sex": "Female", "registration_number": "750695",
        "birth_date": "Apr. 5, 1927", "color": "Blk & rd",
        "owner": "F. C. Fuqua", "owner_location": None,
        "breeder": "Wilh. Wuhler", "breeder_location": "Germany",
        "sire": "Lux v Saumhof", "sire_registration_number": None,
        "dam": "Cara v Zollstock", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Ari v Sigalsburg", "registration_number": "517070"},
            {"role": "dam_of_dam", "name": "Beda v d Bernhardtsburg", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Arcus v Sudostring", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Alli v d Haardt", "registration_number": None},
            {"role": "sire_of_sire", "name": "Ari v Sigalsburg", "registration_number": "517070"},
            {"role": "dam_of_sire", "name": "Edeltrud v Saumhof", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Senta v Indura", "registration_number": None}
        ],
        "source": meta_l60_c1
    },
    {
        "name": "CLAUS V LINDENBERG", "sex": "Male", "registration_number": "752229",
        "birth_date": "July 6, 1929", "color": "Blk & rust",
        "owner": "H. F. Aldrich", "owner_location": "Spokane, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Mia v Lindenberg", "dam_registration_number": "598397",
        "source": meta_l60_c1
    },
    {
        "name": "COO-COO OF KETTLE COVE", "sex": "Male", "registration_number": "751352",
        "birth_date": "Mar. 31, 1930", "color": "Blk & tn",
        "owner": "Kettle Cove Kennels", "owner_location": "Magnolia, Mass.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Lotte v Berghofen", "dam_registration_number": "695157",
        "source": meta_l60_c1
    },
    {
        "name": "COUNT V D BLANKENBACH", "sex": "Male", "registration_number": "748798",
        "birth_date": "Feb. 12, 1929", "color": "Blk rust",
        "owner": "F. M. Gouse", "owner_location": None,
        "breeder": "L. E. Reamer", "breeder_location": "Okmulgee, Okla.",
        "sire": "Arno v Burgfried", "sire_registration_number": "426603",
        "dam": "Countess v Telless", "dam_registration_number": "435136",
        "source": meta_l60_c1
    },
    {
        "name": "COUNT V STEUBEN", "sex": "Male", "registration_number": "748375",
        "birth_date": "Dec. 17, 1929", "color": "Blk & tn",
        "owner": "D. R. Stratton", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Hathor Fra Duncan", "dam_registration_number": "743870",
        "source": meta_l60_c1
    },
    {
        "name": "DON V BARON", "sex": "Male", "registration_number": "751876",
        "birth_date": "Aug. 5, 1929", "color": "Blk & tn",
        "owner": "J. R. Walton, Jr.", "owner_location": None,
        "breeder": "Marshall F. Bidwell", "breeder_location": "South Windsor, Conn.",
        "sire": "Gretchen Flash", "sire_registration_number": "638956",
        "dam": "Rozeta v Baron", "dam_registration_number": "714011",
        "source": meta_l60_c1
    }
]

# Leaf 60, Column 2 (20 dogs)
c2_dogs = [
    {
        "name": "GISELA V D KARLSAUE", "sex": "Female", "registration_number": "750699",
        "birth_date": "Nov. 9, 1927", "color": "Bl rd",
        "owner": "Joseph Schmidt", "owner_location": None,
        "breeder": "Hermann Herbst", "breeder_location": "Germany",
        "sire": "Claus v Wilbrink", "sire_registration_number": None,
        "dam": "Freya v Westend", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Hans v Jagerhof", "registration_number": None},
            {"role": "dam_of_dam", "name": "Hexe Lungen", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Fedor v Giessen", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Hexe", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Prinz Modern v Ilm Athen", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Cosima v Jagerhof", "registration_number": None},
            {"role": "sire_of_sire", "name": "Benno v d Romerhof", "registration_number": "517073"},
            {"role": "dam_of_sire", "name": "Asta v Wilbrink", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Cuno v Sporthof", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Else v Sporthof", "registration_number": None}
        ],
        "source": meta_l60_c2
    },
    {
        "name": "GRAF EDMUND V NIBELUNGENHORT", "sex": "Male", "registration_number": "750490",
        "birth_date": "June 15, 1929", "color": "Blk & tn",
        "owner": "John H. Witherow", "owner_location": None,
        "breeder": "C. B. McCullough", "breeder_location": "Morehead, Ky.",
        "sire": "Storm v Nibelungenhort", "sire_registration_number": "640456",
        "dam": "Neta Nibelungenhort", "dam_registration_number": "687457",
        "source": meta_l60_c2
    },
    {
        "name": "GRANITE HILL GOOSESTEP", "sex": "Female", "registration_number": "750210",
        "birth_date": "Sept. 21, 1928", "color": "Blk & tn",
        "owner": "Joseph S. Treacy", "owner_location": "Manchester, N. H.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Zoic Edel v Sporthof", "sire_registration_number": "409773",
        "dam": "Maidshen Granite Hill", "dam_registration_number": "668106",
        "source": meta_l60_c2
    },
    {
        "name": "GRETA V ROBINSKY", "sex": "Female", "registration_number": "749532",
        "birth_date": "Aug. 17, 1927", "color": "Blk & rd",
        "owner": "F. K. Robeson, Jr.", "owner_location": None,
        "breeder": "A. G. Schroeder", "breeder_location": "Chicago, Ill.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Sybilla v Seehausen", "dam_registration_number": "542655",
        "source": meta_l60_c2
    },
    {
        "name": "GYPSY QUEEN OF WAKERIDGE", "sex": "Female", "registration_number": "752308",
        "birth_date": "July 12, 1930", "color": "Blk & rd",
        "owner": "Clyde H. Eagon", "owner_location": None,
        "breeder": "William L. Pease", "breeder_location": "Wakeman, Ohio",
        "sire": "Gustl v Tannenhaus", "sire_registration_number": "677473",
        "dam": "Tena of Pontchartrain", "dam_registration_number": "715343",
        "source": meta_l60_c2
    },
    {
        "name": "HANS REDHEART", "sex": "Male", "registration_number": "749098",
        "birth_date": "Aug. 1, 1929", "color": "Br, rust mkgs",
        "owner": "George K. Erb and Grace H. Erb", "owner_location": None,
        "breeder": "Mary Cobb Wilson", "breeder_location": "Springfield, Pa.",
        "sire": "Trail Em Adonis", "sire_registration_number": "709104",
        "dam": "Huerta v d Horstburg", "dam_registration_number": "712028",
        "source": meta_l60_c2
    },
    {
        "name": "HARRIET OF KETTLE COVE", "sex": "Female", "registration_number": "747938",
        "birth_date": "Mar. 31, 1930", "color": "Blk & tn",
        "owner": "Kettle Cove Kennels", "owner_location": "Magnolia, Mass.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Lotte v Berghofen", "dam_registration_number": "695157",
        "source": meta_l60_c2
    },
    {
        "name": "HECTOR J", "sex": "Male", "registration_number": "749955",
        "birth_date": "Mar. 29, 1927", "color": "Blk & tn",
        "owner": "Mrs. Jennie Vanderwood", "owner_location": None,
        "breeder": "George Hammond", "breeder_location": "Clark Mills, N. Y.",
        "sire": "Pat v Stolzenfels", "sire_registration_number": "746034",
        "dam": "Smarty Brunhilda v Stolzenfels", "dam_registration_number": "309322",
        "source": meta_l60_c2
    },
    {
        "name": "HERMOSA LEIBSHEN", "sex": "Female", "registration_number": "748246",
        "birth_date": "Nov. 15, 1926", "color": "Blk & tn",
        "owner": "Hermosa Kennels", "owner_location": "Denver, Colo.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Barry v Seehagen", "sire_registration_number": "463068",
        "dam": "Ingeborg v d Treuburg", "dam_registration_number": "457509",
        "source": meta_l60_c2
    },
    {
        "name": "HOPE OF KETTLE COVE", "sex": "Female", "registration_number": "748834",
        "birth_date": "Mar. 31, 1930", "color": "Blk & tn",
        "owner": "Kettle Cove Kennels", "owner_location": "Magnolia, Mass.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Lotte v Berghofen", "dam_registration_number": "695157",
        "source": meta_l60_c2
    },
    {
        "name": "HUNSICK V KIRCHBURG", "sex": "Male", "registration_number": "750571",
        "birth_date": "Apr. 23, 1930", "color": "Blk & tn",
        "owner": "Guy R. Campbell, Jr.", "owner_location": None,
        "breeder": "D. C. Philipp", "breeder_location": "Wichita, Kan.",
        "sire": "Dietrich v d Barbarossahoehle", "sire_registration_number": "561617",
        "dam": "Ellisa v Nuremberg", "dam_registration_number": "692976",
        "source": meta_l60_c2
    },
    {
        "name": "IOLA V ROMER", "sex": "Female", "registration_number": "750604",
        "birth_date": "May 25, 1929", "color": "Blk & tn",
        "owner": "J. H. Vrancken", "owner_location": "Columbus, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rowdy Strobel", "sire_registration_number": "627427",
        "dam": "Queen Rotterdam", "dam_registration_number": "541792",
        "source": meta_l60_c2
    },
    {
        "name": "JACK V HAGUE", "sex": "Male", "registration_number": "747585",
        "birth_date": "May 5, 1930", "color": "Blk & tn",
        "owner": "W. S. Mills, Jr.", "owner_location": None,
        "breeder": "R. H. Cummings", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Maudie", "dam_registration_number": "716441",
        "source": meta_l60_c2
    },
    {
        "name": "JEANETTE V JAGERHOF", "sex": "Female", "registration_number": "752040",
        "birth_date": "May 13, 1929", "color": "Blk & tn",
        "owner": "Alexander Gallan", "owner_location": None,
        "breeder": "E. De L. Fouque", "breeder_location": "Media, Pa.",
        "sire": "Red Roof Rufus", "sire_registration_number": "491422",
        "dam": "Babette v Jagerhof", "dam_registration_number": "521089",
        "source": meta_l60_c2
    },
    {
        "name": "JESSAL V POPP SIGALSBURG", "sex": "Female", "registration_number": "749420",
        "birth_date": "Feb. 19, 1930", "color": "Blk & tn",
        "owner": "Edward D. Leete", "owner_location": None,
        "breeder": "T. E. Popp", "breeder_location": "West Allis, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dortell v Popp", "dam_registration_number": "526001",
        "source": meta_l60_c2
    },
    {
        "name": "JOAL OF DHU VARREN", "sex": "Female", "registration_number": "749951",
        "birth_date": "Apr. 25, 1929", "color": "Blk, rust mkgs",
        "owner": "Edward A. Hunter", "owner_location": None,
        "breeder": "J. C. Zimmerman", "breeder_location": "Detroit, Mich.",
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Alli of Rhinegold", "dam_registration_number": "560310",
        "source": meta_l60_c2
    },
    {
        "name": "KIM OF MASONCREST", "sex": "Male", "registration_number": "749443",
        "birth_date": "Mar. 31, 1930", "color": "Blk & tn",
        "owner": "Henrie A. Mason", "owner_location": None,
        "breeder": "Kettle Cove Kennels", "breeder_location": "Magnolia, Mass.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Lotte v Berghofen", "dam_registration_number": "695157",
        "source": meta_l60_c2
    },
    {
        "name": "KITTY OF DHU VARREN", "sex": "Female", "registration_number": "749950",
        "birth_date": "July 25, 1929", "color": "Blk & rd",
        "owner": "Edward A. Hunter", "owner_location": "Ann Arbor, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Kitty v Rodeltal", "dam_registration_number": "706938",
        "source": meta_l60_c2
    },
    {
        "name": "KITTY OF KETTLE COVE", "sex": "Female", "registration_number": "749603",
        "birth_date": "Apr. 14, 1930", "color": "Blk & tn",
        "owner": "Kettle Cove Kennels", "owner_location": "Magnolia, Mass.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Alphabet of Dawn", "dam_registration_number": "681563",
        "source": meta_l60_c2
    }
]

# Leaf 60, Column 3 (22 dogs)
c3_dogs = [
    {
        "name": "KITTY V D RESIDENZ", "sex": "Female", "registration_number": "751717",
        "birth_date": "May 30, 1927", "color": "Blk rd",
        "owner": "Mrs. B. F. Lewis", "owner_location": None,
        "breeder": "H. Flach", "breeder_location": "Germany",
        "sire": "Alto v Sigalsburg", "sire_registration_number": None,
        "dam": "Frohgunde v d Residenz", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Rival v Kranichstein", "registration_number": "515099"},
            {"role": "dam_of_dam", "name": "Clare v d Residenz", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Brummer Hoch-Wart", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Eia v Langerode", "registration_number": None},
            {"role": "sire_of_sire", "name": "Lux v d Blankenburg", "registration_number": "571492"},
            {"role": "dam_of_sire", "name": "Lotte v Roneckenstein", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Dora v Wiesengrund", "registration_number": None}
        ],
        "source": meta_l60_c3
    },
    {
        "name": "LADY V HOMEHILL II", "sex": "Female", "registration_number": "750119",
        "birth_date": "Sept. 7, 1927", "color": "Blk, br mkgs",
        "owner": "R. C. Bauman", "owner_location": None,
        "breeder": "Mrs. G. A. Rentschler", "breeder_location": "Hamilton, Ohio",
        "sire": "Apollo v Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Dina v Homehill", "dam_registration_number": "581382",
        "source": meta_l60_c3
    },
    {
        "name": "LADY V D KONINGSTAD", "sex": "Female", "registration_number": "748062",
        "birth_date": "Jan. 26, 1930", "color": "Blk & tn",
        "owner": "A. W. Topkis", "owner_location": None,
        "breeder": "Mr. and Mrs. Wm. E. Abbott", "breeder_location": "Camden, N. J.",
        "sire": "Trail Em Adonis", "sire_registration_number": "709104",
        "dam": "Schunppe v Rhodenback", "dam_registration_number": "649814",
        "source": meta_l60_c3
    },
    {
        "name": "LENA V D KONINGSTADT", "sex": "Female", "registration_number": "748963",
        "birth_date": "May 13, 1929", "color": "Blk & tn",
        "owner": "Alexander Gallan", "owner_location": None,
        "breeder": "E. De L. Fouque", "breeder_location": "Media, Pa.",
        "sire": "Red Roof Rufus", "sire_registration_number": "491422",
        "dam": "Babette v Jagerhof", "dam_registration_number": "521089",
        "source": meta_l60_c3
    },
    {
        "name": "LOKI V HOLSTEIN", "sex": "Male", "registration_number": "750934",
        "birth_date": "Apr. 14, 1930", "color": "Blk & tn",
        "owner": "Ferruccio Vitale", "owner_location": None,
        "breeder": "Kettle Cove Kennels", "breeder_location": "Magnolia, Mass.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Alphabet of Dawn", "dam_registration_number": "681563",
        "source": meta_l60_c3
    },
    {
        "name": "LOLA OF MIDDLETOWN", "sex": "Female", "registration_number": "750619",
        "birth_date": "Sept. 4, 1929", "color": "Rd & tn",
        "owner": "W. N. McCoy", "owner_location": "Middletown, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Lola v Augarten", "dam_registration_number": "724400",
        "source": meta_l60_c3
    },
    {
        "name": "LONG LANE CARNIVAL", "sex": "Female", "registration_number": "752309",
        "birth_date": "Dec. 7, 1929", "color": "Blk & tn",
        "owner": "K. B. Boker", "owner_location": "Far Hills, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Koningstad Nicholas", "sire_registration_number": "727756",
        "dam": "Ellie of Westphalia", "dam_registration_number": "523350",
        "source": meta_l60_c3
    },
    {
        "name": "LONG LANE MARDI GRAS", "sex": "Female", "registration_number": "752310",
        "birth_date": "Dec. 7, 1929", "color": "Blk & tn",
        "owner": "K. B. Boker", "owner_location": "Far Hills, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Koningstad Nicholas", "sire_registration_number": "727756",
        "dam": "Ellie of Westphalia", "dam_registration_number": "523350",
        "source": meta_l60_c3
    },
    {
        "name": "MARCO V NIBELUNGENHORT", "sex": "Male", "registration_number": "752312",
        "birth_date": "June 4, 1930", "color": "Blk & tn",
        "owner": "Calvin B. Meck", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Dot v Christman", "dam_registration_number": "460743",
        "source": meta_l60_c3
    },
    {
        "name": "MIA VON WEIGAND", "sex": "Female", "registration_number": "751122",
        "birth_date": "Nov. 15, 1928", "color": "Blk & tn",
        "owner": "Mrs. Emma M. Jepsen", "owner_location": None,
        "breeder": "Mrs. George Land", "breeder_location": "Huntington Park, Calif.",
        "sire": "Burschel v Weigand", "sire_registration_number": "652099",
        "dam": "Oak Knoll Erda v Melrapp", "dam_registration_number": "387625",
        "source": meta_l60_c3
    },
    {
        "name": "NERO II", "sex": "Male", "registration_number": "720006",
        "birth_date": "Jan. 6, 1930", "color": "Blk & tn",
        "owner": "Ferdinand Szolinger", "owner_location": None,
        "breeder": "Hugo Brenninkmeyer", "breeder_location": "Granite City, Ill.",
        "sire": "Rich v Rulenburg", "sire_registration_number": "698612",
        "dam": "Senta v Tecklenburg", "dam_registration_number": "713600",
        "source": meta_l60_c3
    },
    {
        "name": "NUTTALL'S RED", "sex": "Male", "registration_number": "749373",
        "birth_date": "May 29, 1929", "color": "Rd & tn",
        "owner": "H. M. Nuttall", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Hektor Plato", "sire_registration_number": "517072",
        "dam": "Nuttall's Tobie", "dam_registration_number": "608303",
        "source": meta_l60_c3
    },
    {
        "name": "OXBO ARI", "sex": "Male", "registration_number": "749948",
        "birth_date": "Feb. 16, 1930", "color": "Blk & tn",
        "owner": "F. C. Fuqua", "owner_location": None,
        "breeder": "Frank Blattler", "breeder_location": "Berkeley, Calif.",
        "sire": "Emir Lentulus", "sire_registration_number": "714460",
        "dam": "Valuta v d Blankenburg", "dam_registration_number": "730071",
        "source": meta_l60_c3
    },
    {
        "name": "OXBO NED", "sex": "Male", "registration_number": "751092",
        "birth_date": "Jan. 30, 1930", "color": "Blk & tn",
        "owner": "F. C. Fuqua", "owner_location": "Seattle, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Carlo v Belger", "sire_registration_number": "533904",
        "dam": "Gerti v Hohenschwanau", "dam_registration_number": "670137",
        "source": meta_l60_c3
    },
    {
        "name": "PERRY'S DELF V SAINT SEBOLD", "sex": "Male", "registration_number": "750919",
        "birth_date": "Mar. 15, 1930", "color": "Blk & tn",
        "owner": "Lawrence Schum", "owner_location": None,
        "breeder": "Perry Kennels", "breeder_location": "Erie, Pa.",
        "sire": "Delf v d Karthaeuserklause", "sire_registration_number": "583005",
        "dam": "Perry's Rhea v Saint Sebold", "dam_registration_number": "544298",
        "source": meta_l60_c3
    },
    {
        "name": "PRINCESS DOT OF PONTCHARTRAIN", "sex": "Female", "registration_number": "751006",
        "birth_date": "July 5, 1929", "color": "Blk, rd",
        "owner": "J. Hoyt Wilson", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Anita of Pontchartrain", "dam_registration_number": "658452",
        "source": meta_l60_c3
    },
    {
        "name": "PRINCESS GRETA", "sex": "Female", "registration_number": "750507",
        "birth_date": "Jan. 4, 1930", "color": "Blk, tn mkgs",
        "owner": "Geo. F. Mueller", "owner_location": None,
        "breeder": "F. G. Morton", "breeder_location": "Green, Kan.",
        "sire": "Major v Burgwall III", "sire_registration_number": "728161",
        "dam": "Lady Diana", "dam_registration_number": "727041",
        "source": meta_l60_c3
    },
    {
        "name": "PRINTZ V WOLFENBORGER", "sex": "Male", "registration_number": "749242",
        "birth_date": "Aug. 4, 1929", "color": "Rd br, tn mkgs",
        "owner": "E. A. Esker", "owner_location": None,
        "breeder": "Bert Young", "breeder_location": "Granville, Ohio",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Alice Blue Gown", "dam_registration_number": "492047",
        "source": meta_l60_c3
    },
    {
        "name": "PRINZ V ROMERHOF", "sex": "Male", "registration_number": "751791",
        "birth_date": "Mar. 4, 1930", "color": "Rd",
        "owner": "Mr. and Mrs. George Engelskirchen", "owner_location": None,
        "breeder": "Mrs. Math Brausch", "breeder_location": "Chicago, Ill.",
        "sire": "Peter v Roemerhof", "sire_registration_number": "616494",
        "dam": "Lady v Wilhelm", "dam_registration_number": "699515",
        "source": meta_l60_c3
    },
    {
        "name": "REXWAY RED", "sex": "Female", "registration_number": "748063",
        "birth_date": "Mar. 14, 1930", "color": "Rd, rust mkgs",
        "owner": "J. L. Brown", "owner_location": None,
        "breeder": "Evelyn Masson", "breeder_location": "Eureka, Calif.",
        "sire": "Sig v Sigalsburg", "sire_registration_number": "659175",
        "dam": "Mugsy v d Robinson", "dam_registration_number": "425459",
        "source": meta_l60_c3
    },
    {
        "name": "RIVAL OF MIDDLETOWN", "sex": "Male", "registration_number": "750622",
        "birth_date": "June 4, 1929", "color": "Blk & tn",
        "owner": "W. N. McCoy", "owner_location": "Middletown, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Rhea of Middletown", "dam_registration_number": "648661",
        "source": meta_l60_c3
    },
    {
        "name": "ROMA V ROEMERHOF", "sex": "Female", "registration_number": "749740",
        "birth_date": "Mar. 4, 1930", "color": "Blk & tn",
        "owner": "Louis D. Minsk", "owner_location": None,
        "breeder": "Mrs. Math Brausch", "breeder_location": "Chicago, Ill.",
        "sire": "Peter v Roemerhof", "sire_registration_number": "616494",
        "dam": "Lady v Wilhelm", "dam_registration_number": "699515",
        "source": meta_l60_c3
    }
]

# Leaf 61, Column 1 (14 dogs down to PINSCHERS (Miniature))
c4_dogs = [
    {
        "name": "ROWDY V ROMER", "sex": "Male", "registration_number": "750605",
        "birth_date": "May 25, 1929", "color": "Blk & tn",
        "owner": "R. J. Burdge", "owner_location": None,
        "breeder": "J. H. Vrancken", "breeder_location": "Columbus, Ohio",
        "sire": "Rowdy Strobel", "sire_registration_number": "627427",
        "dam": "Queen v Rotterdam", "dam_registration_number": "541792",
        "source": meta_l61_c1
    },
    {
        "name": "RUDOLPH OF MIDDLETOWN", "sex": "Male", "registration_number": "750620",
        "birth_date": "June 4, 1929", "color": "Blk & tn",
        "owner": "W. N. McCoy", "owner_location": "Middletown, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Rhea of Middletown", "dam_registration_number": "648661",
        "source": meta_l61_c1
    },
    {
        "name": "RUNDIE OF MIDDLETOWN", "sex": "Female", "registration_number": "750621",
        "birth_date": "June 4, 1929", "color": "Blk & tn",
        "owner": "W. N. McCoy", "owner_location": "Middletown, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Rhea of Middletown", "dam_registration_number": "648661",
        "source": meta_l61_c1
    },
    {
        "name": "SCHNAPPS", "sex": "Male", "registration_number": "751991",
        "birth_date": "July 18, 1929", "color": "Br, rd mkgs",
        "owner": "F. E. Kennedy", "owner_location": None,
        "breeder": "Helen Krecker", "breeder_location": "Stonehurst, Pa.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Schatze v Horstburg", "dam_registration_number": "689932",
        "source": meta_l61_c1
    },
    {
        "name": "SISTER V LINDENBERG", "sex": "Female", "registration_number": "752228",
        "birth_date": "July 6, 1929", "color": "Blk & rust",
        "owner": "H. F. Aldrich", "owner_location": "Spokane, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Mia v Lindenberg", "dam_registration_number": "598397",
        "source": meta_l61_c1
    },
    {
        "name": "STELLA V LUDENDORF", "sex": "Female", "registration_number": "748779",
        "birth_date": "Dec. 5, 1929", "color": "Blk & tn",
        "owner": "Albert Blazek", "owner_location": None,
        "breeder": "Jerry Schnabl", "breeder_location": "Riverside, Ill.",
        "sire": "Fritz v Duffield", "sire_registration_number": "704573",
        "dam": "Freda Duffield", "dam_registration_number": "608113",
        "source": meta_l61_c1
    },
    {
        "name": "TASSO V RENNBERG", "sex": "Male", "registration_number": "747571",
        "birth_date": "Dec. 19, 1928", "color": "Rd & tn",
        "owner": "Rudolph Platzer", "owner_location": None,
        "breeder": "Harry H. Brandt", "breeder_location": "Cincinnati, Ohio",
        "sire": "Harry Rennberg", "sire_registration_number": "731621",
        "dam": "Asta Waldschloss II", "dam_registration_number": "646360",
        "source": meta_l61_c1
    },
    {
        "name": "TELL V D HORSTBURG", "sex": "Male", "registration_number": "751391",
        "birth_date": "Aug. 17, 1929", "color": "Rd & tn",
        "owner": "George F. Rieger", "owner_location": None,
        "breeder": "William Goldbecker", "breeder_location": "New Haven, Conn.",
        "sire": "Baron v Richthofen", "sire_registration_number": "526664",
        "dam": "Zita v Bramberg", "dam_registration_number": "705275",
        "source": meta_l61_c1
    },
    {
        "name": "TOC OF KETTLE COVE", "sex": "Male", "registration_number": "748835",
        "birth_date": "Apr. 14, 1930", "color": "Blk & tn",
        "owner": "Kettle Cove Kennels", "owner_location": "Magnolia, Mass.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Alphabet of Dawn", "dam_registration_number": "681563",
        "source": meta_l61_c1
    },
    {
        "name": "ULRICH'S HANS", "sex": "Male", "registration_number": "748944",
        "birth_date": "July 17, 1928", "color": "Rd & tn",
        "owner": "Henry Ulrich", "owner_location": None,
        "breeder": "Bert Young", "breeder_location": "Granville, Ohio",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Alice Blue Gown", "dam_registration_number": "492047",
        "source": meta_l61_c1
    },
    {
        "name": "WIRLEY EUCHNER", "sex": "Female", "registration_number": "747753",
        "birth_date": "Dec. 23, 1927", "color": "Blk & tn",
        "owner": "F. H. Heffereich", "owner_location": None,
        "breeder": "H. Bolin", "breeder_location": "Columbus, Ohio",
        "sire": "Toby", "sire_registration_number": "491065",
        "dam": "Hilda Hoyler", "dam_registration_number": "495893",
        "source": meta_l61_c1
    },
    {
        "name": "ZELDA V ZINGSHEIM", "sex": "Female", "registration_number": "751790",
        "birth_date": "Sept. 3, 1929", "color": "Blk & tn",
        "owner": "Mr. and Mrs. George Engelskirchen", "owner_location": None,
        "breeder": "M. L. Zingsheim", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Betsy v Wilhelm", "dam_registration_number": "623310",
        "source": meta_l61_c1
    },
    {
        "name": "ZOE V SIEGERPARK", "sex": "Female", "registration_number": "749459",
        "birth_date": "Feb. 10, 1929", "color": "Blk & rd",
        "owner": "Mr. and Mrs. S. R. Baker", "owner_location": None,
        "breeder": "Edward A. Hunter", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Marko v Siegerpark", "sire_registration_number": "601008",
        "dam": "Dhu Varren's Elise", "dam_registration_number": "649766",
        "source": meta_l61_c1
    },
    {
        "name": "ZURKE V ROMER", "sex": "Female", "registration_number": "750606",
        "birth_date": "Sept. 19, 1928", "color": "Blk & tn",
        "owner": "R. J. Burdge", "owner_location": None,
        "breeder": "J. A. Finnicum", "breeder_location": "Columbus, Ohio",
        "sire": "Leuthold of Pontchartrain", "sire_registration_number": "629194",
        "dam": "Bella of Pontchartrain", "dam_registration_number": "578596",
        "source": meta_l61_c1
    }
]

all_30_10 = c1_dogs + c2_dogs + c3_dogs + c4_dogs
print(f"Total compiled 1930-10 dogs: {len(all_30_10)}")
print(f"  Leaf 60 Col 1: {len(c1_dogs)}")
print(f"  Leaf 60 Col 2: {len(c2_dogs)}")
print(f"  Leaf 60 Col 3: {len(c3_dogs)}")
print(f"  Leaf 61 Col 1: {len(c4_dogs)}")

Path("stud-scrape/data/verified_1930_10.json").write_text(json.dumps(all_30_10, indent=2), encoding="utf-8")
print("Saved verified 1930-10 records.")
