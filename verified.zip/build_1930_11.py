import json
from pathlib import Path

meta_l48_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-11-01_47_11", "date": "1930-11-01", "volume": "47", "issue": "11", "leaf": 48, "column": 3}
meta_l49_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-11-01_47_11", "date": "1930-11-01", "volume": "47", "issue": "11", "leaf": 49, "column": 1}
meta_l49_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-11-01_47_11", "date": "1930-11-01", "volume": "47", "issue": "11", "leaf": 49, "column": 2}

# Leaf 48, Column 3 (Starts under PINSCHERS (Doberman) - 22 dogs)
c1_dogs = [
    {
        "name": "CITI OF KETTLE COVE", "sex": "Female", "registration_number": "753125",
        "birth_date": "Dec. 24, 1929", "color": "Blk rd",
        "owner": "Kettle Cove Kennels", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Ilisa of Pontchartrain", "dam_registration_number": "571491",
        "source": meta_l48_c3
    },
    {
        "name": "COLBERT'S ZIG", "sex": "Male", "registration_number": "754260",
        "birth_date": "May 14, 1928", "color": "Blk & tn",
        "owner": "Charles R. Colbert", "owner_location": None,
        "breeder": "Chas. Lange", "breeder_location": "Millvale, Pa.",
        "sire": "Karb's Jupiter", "sire_registration_number": "445136",
        "dam": "Perry's Queenie v Saint Sebald", "dam_registration_number": "597220",
        "source": meta_l48_c3
    },
    {
        "name": "DUKE OF FONTRAINE", "sex": "Male", "registration_number": "754312",
        "birth_date": "Oct. 21, 1928", "color": "Blk & rust",
        "owner": "Mrs. J. J. Swift", "owner_location": None,
        "breeder": "A. C. Wales", "breeder_location": "Akron, Ohio",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Reva of Pontchartrain", "dam_registration_number": "624345",
        "source": meta_l48_c3
    },
    {
        "name": "FADA OF DAWN", "sex": "Female", "registration_number": "754577",
        "birth_date": "Aug. 10, 1930", "color": "Blk & br",
        "owner": "Chas. C. Robbins", "owner_location": None,
        "breeder": "E. J. W. Fink", "breeder_location": "Mishawaka, Ind.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Astrid of Dawn", "dam_registration_number": "727910",
        "source": meta_l48_c3
    },
    {
        "name": "FEZ OF DAWN", "sex": "Male", "registration_number": "754579",
        "birth_date": "Aug. 10, 1930", "color": "Blk & br",
        "owner": "Chas. C. Robbins", "owner_location": None,
        "breeder": "E. J. W. Fink", "breeder_location": "Mishawaka, Ind.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Astrid of Dawn", "dam_registration_number": "727910",
        "source": meta_l48_c3
    },
    {
        "name": "FIRE OF DAWN", "sex": "Male", "registration_number": "754583",
        "birth_date": "Aug. 10, 1930", "color": "Blk & br",
        "owner": "Chas. C. Robbins", "owner_location": None,
        "breeder": "E. J. W. Fink", "breeder_location": "Mishawaka, Ind.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Astrid of Dawn", "dam_registration_number": "727910",
        "source": meta_l48_c3
    },
    {
        "name": "FISKE OF DAWN", "sex": "Male", "registration_number": "754584",
        "birth_date": "Aug. 10, 1930", "color": "Blk & br",
        "owner": "Chas. C. Robbins", "owner_location": None,
        "breeder": "E. J. W. Fink", "breeder_location": "Mishawaka, Ind.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Astrid of Dawn", "dam_registration_number": "727910",
        "source": meta_l48_c3
    },
    {
        "name": "FLAME OF DAWN", "sex": "Female", "registration_number": "754576",
        "birth_date": "Aug. 10, 1930", "color": "Blk & br",
        "owner": "Chas. C. Robbins", "owner_location": None,
        "breeder": "E. J. W. Fink", "breeder_location": "Mishawaka, Ind.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Astrid of Dawn", "dam_registration_number": "727910",
        "source": meta_l48_c3
    },
    {
        "name": "FLICK OF DAWN", "sex": "Male", "registration_number": "754581",
        "birth_date": "Aug. 10, 1930", "color": "Blk & br",
        "owner": "Chas. C. Robbins", "owner_location": None,
        "breeder": "E. J. W. Fink", "breeder_location": "Mishawaka, Ind.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Astrid of Dawn", "dam_registration_number": "727910",
        "source": meta_l48_c3
    },
    {
        "name": "FLINK OF DAWN", "sex": "Female", "registration_number": "754578",
        "birth_date": "Aug. 10, 1930", "color": "Blk & br",
        "owner": "Chas. C. Robbins", "owner_location": None,
        "breeder": "E. J. W. Fink", "breeder_location": "Mishawaka, Ind.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Astrid of Dawn", "dam_registration_number": "727910",
        "source": meta_l48_c3
    },
    {
        "name": "FLORA V HEADING", "sex": "Female", "registration_number": "753883",
        "birth_date": "Aug. 10, 1929", "color": "Blk & tn",
        "owner": "Emil Henrich", "owner_location": None,
        "breeder": "Geo. H. Jones", "breeder_location": "Danville, Ill.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Princess v Rudolphsburg", "dam_registration_number": "569711",
        "source": meta_l48_c3
    },
    {
        "name": "FOLLO OF DAWN", "sex": "Male", "registration_number": "754585",
        "birth_date": "Aug. 10, 1930", "color": "Blk & br",
        "owner": "Chas. C. Robbins", "owner_location": None,
        "breeder": "E. J. W. Fink", "breeder_location": "Mishawaka, Ind.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Astrid of Dawn", "dam_registration_number": "727910",
        "source": meta_l48_c3
    },
    {
        "name": "FOXIE OF DAWN", "sex": "Female", "registration_number": "754580",
        "birth_date": "Aug. 10, 1930", "color": "Blk & br",
        "owner": "Chas. C. Robbins", "owner_location": None,
        "breeder": "E. J. W. Fink", "breeder_location": "Mishawaka, Ind.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Astrid of Dawn", "dam_registration_number": "727910",
        "source": meta_l48_c3
    },
    {
        "name": "FRITZ V CLAUS", "sex": "Male", "registration_number": "754926",
        "birth_date": "Aug. 4, 1929", "color": "Tn & blk",
        "owner": "D. H. Startsman", "owner_location": None,
        "breeder": "A. D. Harrison", "breeder_location": "Madisonville, Ohio",
        "sire": "Tylor v Claus", "sire_registration_number": "625088",
        "dam": "Asta v Waldschloss II", "dam_registration_number": "646360",
        "source": meta_l48_c3
    },
    {
        "name": "FRITZ OF DAWN", "sex": "Male", "registration_number": "754582",
        "birth_date": "Aug. 10, 1930", "color": "Blk & br",
        "owner": "Chas. C. Robbins", "owner_location": None,
        "breeder": "E. J. W. Fink", "breeder_location": "Mishawaka, Ind.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Astrid of Dawn", "dam_registration_number": "727910",
        "source": meta_l48_c3
    },
    {
        "name": "FRITZ V HILZABURG", "sex": "Male", "registration_number": "753460",
        "birth_date": "June 5, 1930", "color": "Rd, tn mkgs",
        "owner": "E. W. Allen", "owner_location": None,
        "breeder": "Joseph S. Treacy", "breeder_location": "Manchester, N. H.",
        "sire": "Captain Kidd", "sire_registration_number": "561912",
        "dam": "Granite Hill Goosestep", "dam_registration_number": "750210",
        "source": meta_l48_c3
    },
    {
        "name": "FRITZ OF MICKBURN", "sex": "Male", "registration_number": "753360",
        "birth_date": "Oct. 19, 1927", "color": "Rd, tn mkgs",
        "owner": "Mickburn Kennels", "owner_location": "Eldorado, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Centa v Rinkenbuehl", "dam_registration_number": "316606",
        "source": meta_l48_c3
    },
    {
        "name": "FRITZ V RICH", "sex": "Male", "registration_number": "754140",
        "birth_date": "Apr. 26, 1929", "color": "Rd & tn",
        "owner": "Waldo Gehring", "owner_location": None,
        "breeder": "William A. Barron", "breeder_location": "So. Manchester, Conn.",
        "sire": "Baron v Richthofen", "sire_registration_number": "526664",
        "dam": "Dina v Hetzendorf", "dam_registration_number": "504499",
        "source": meta_l48_c3
    },
    {
        "name": "GABBO V ARONAEL", "sex": "Male", "registration_number": "753459",
        "birth_date": "Dec. 14, 1929", "color": "Blk & tn",
        "owner": "Mrs. A. J. Dooner", "owner_location": None,
        "breeder": "B. Delacourt", "breeder_location": "Los Angeles, Calif.",
        "sire": "Max v Strossen", "sire_registration_number": "509139",
        "dam": "Betty v Hohenzollernpark", "dam_registration_number": "674822",
        "source": meta_l48_c3
    },
    {
        "name": "GRAF V ROGERSCHMIDT", "sex": "Male", "registration_number": "752928",
        "birth_date": "May 2, 1930", "color": "Blk, rd mkgs",
        "owner": "Rogerschmidt Kennels", "owner_location": "Bloomingburg, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Apollo v Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Roma v Popp", "dam_registration_number": "694843",
        "source": meta_l48_c3
    },
    {
        "name": "GRETCHEN OF BORNHOLM", "sex": "Female", "registration_number": "753173",
        "birth_date": "Oct. 11, 1927", "color": "Blk, rust mkgs",
        "owner": "McKinley J. Bohannon", "owner_location": None,
        "breeder": "Henry W. Bopp", "breeder_location": "Terre Haute, Ind.",
        "sire": "A. Hindoo of Pontchartrain", "sire_registration_number": "440792",
        "dam": "Ronne of Bornholm", "dam_registration_number": "528650",
        "source": meta_l48_c3
    },
    {
        "name": "HERR FRITZ", "sex": "Male", "registration_number": "753996",
        "birth_date": "Oct. 7, 1929", "color": "Blk & tn",
        "owner": "W. Wellington George", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Diethelm Fra Duncan", "sire_registration_number": "722682",
        "dam": "Lyndora Fra Duncan", "dam_registration_number": "739761",
        "source": meta_l48_c3
    }
]

# Leaf 49, Column 1 (22 dogs)
c2_dogs = [
    {
        "name": "HERR LOUIS FRITZ V PFALZERLAND", "sex": "Male", "registration_number": "752787",
        "birth_date": "Feb. 4, 1923", "color": "Blk & tn",
        "owner": "Mary G. Bushinger", "owner_location": None,
        "breeder": "Mrs. Frank O. Thaxter", "breeder_location": "Stoughton, Mass.",
        "sire": "Count Marx v Pfalzerland", "sire_registration_number": "329421",
        "dam": "Lady Van Buren", "dam_registration_number": "325271",
        "source": meta_l49_c1
    },
    {
        "name": "HILDA JANE", "sex": "Female", "registration_number": "754039",
        "birth_date": "July 8, 1929", "color": "Blk & br",
        "owner": "Charles A. Clark", "owner_location": "Leicester, Mass.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Hasso v Bassewitz", "sire_registration_number": "517338",
        "dam": "Hida v Stott", "dam_registration_number": "534575",
        "source": meta_l49_c1
    },
    {
        "name": "HILDA V WYCK", "sex": "Female", "registration_number": "755907",
        "birth_date": "Nov. 2, 1929", "color": "Bl & tn",
        "owner": "J. W. Magruder", "owner_location": None,
        "breeder": "J. H. Vrancken", "breeder_location": "Columbus, Ohio",
        "sire": "Jan v Roermond", "sire_registration_number": "544142",
        "dam": "Queen Rotterdam", "dam_registration_number": "541792",
        "source": meta_l49_c1
    },
    {
        "name": "HYDE OF OXBO", "sex": "Male", "registration_number": "753498",
        "birth_date": "Feb. 16, 1930", "color": "Br & tn",
        "owner": "F. C. Fuqua", "owner_location": None,
        "breeder": "Frank Blattler", "breeder_location": "Berkeley, Calif.",
        "sire": "Emir Lentulus", "sire_registration_number": "714460",
        "dam": "Valuta v d Blankenburg", "dam_registration_number": "730071",
        "source": meta_l49_c1
    },
    {
        "name": "LADY V ANDRAJY", "sex": "Female", "registration_number": "755902",
        "birth_date": "Dec. 17, 1928", "color": "Blk & tn",
        "owner": "Aida v Preissig", "owner_location": None,
        "breeder": "Bart Delacourt", "breeder_location": "Los Angeles, Calif.",
        "sire": "Max v Strossen", "sire_registration_number": "509139",
        "dam": "Asta v Hoenzollernpark", "dam_registration_number": "661506",
        "source": meta_l49_c1
    },
    {
        "name": "LEAH OF APOLDA", "sex": "Female", "registration_number": "754294",
        "birth_date": "May 15, 1926", "color": "Blk & tn",
        "owner": "George A. Stickroth", "owner_location": None,
        "breeder": "Wendlin Bedacht", "breeder_location": "Toledo, Ohio",
        "sire": "Westphalia Dyno v Wiesengrund", "sire_registration_number": "365520",
        "dam": "Mono v Rheim", "dam_registration_number": "526296",
        "source": meta_l49_c1
    },
    {
        "name": "LEA V D HORSTBURG", "sex": "Female", "registration_number": "754827",
        "birth_date": "Aug. 1, 1929", "color": "Rd, rd rust mkgs",
        "owner": "Mary Cobb Wilson", "owner_location": "Springfield, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Trail Em Adonis", "sire_registration_number": "709104",
        "dam": "Huerta v d Horstburg", "dam_registration_number": "712028",
        "source": meta_l49_c1
    },
    {
        "name": "MARGOT V REYNO", "sex": "Female", "registration_number": "755611",
        "birth_date": "May 22, 1927", "color": "Blk & tn",
        "owner": "Maurice V. Reynolds", "owner_location": "Lake Villa, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Troll v Jaegerhof", "sire_registration_number": "465630",
        "dam": "Alma v d Sieghohle", "dam_registration_number": "633884",
        "source": meta_l49_c1
    },
    {
        "name": "MARTO V ROLANS", "sex": "Female", "registration_number": "755226",
        "birth_date": "June 10, 1929", "color": "Blk & rn",
        "owner": "R. E. Fleming", "owner_location": None,
        "breeder": "Edw. A. Hunter", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Marko v Siegerpark", "sire_registration_number": "601008",
        "dam": "Norma v Streslau", "dam_registration_number": "586734",
        "source": meta_l49_c1
    },
    {
        "name": "MITZLEBURG V HAGERMAN", "sex": "Female", "registration_number": "756297",
        "birth_date": "Mar. 8, 1927", "color": "Blk & tn",
        "owner": "Ernest G. Eldred", "owner_location": None,
        "breeder": "H. Gurtler", "breeder_location": "Rochester, N. Y.",
        "sire": "Werner v Stolzenfels", "sire_registration_number": "577357",
        "dam": "Gretel v Stolzenfels", "dam_registration_number": "576114",
        "source": meta_l49_c1
    },
    {
        "name": "NITTA YUMA'S FOUNTAINE", "sex": "Male", "registration_number": "754953",
        "birth_date": "June 9, 1929", "color": "Rd, rust mkgs",
        "owner": "W. L. Lyons Brown", "owner_location": None,
        "breeder": "W. J. Lyons, Jr.", "breeder_location": "Harrods Creek, Ky.",
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Centa v Rinkenbuehl", "dam_registration_number": "316606",
        "source": meta_l49_c1
    },
    {
        "name": "NOLA V FALKENTURM", "sex": "Female", "registration_number": "752594",
        "birth_date": "Jan. 20, 1930", "color": "Rd & rust",
        "owner": "Leslie L. Romine", "owner_location": "Livingston, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Max De Haven", "sire_registration_number": "604075",
        "dam": "Gretta v Falkenturm", "dam_registration_number": "725314",
        "source": meta_l49_c1
    },
    {
        "name": "NORA OF NASHVILLE", "sex": "Female", "registration_number": "753949",
        "birth_date": "Nov. 17, 1929", "color": "Blk, tn mkgs",
        "owner": "Oscar L. Simpson", "owner_location": None,
        "breeder": "Wayne D. King", "breeder_location": "Bridgeport, Ohio",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Asta v Nashville", "dam_registration_number": "675400",
        "source": meta_l49_c1
    },
    {
        "name": "OTTO V ROGERSCHMIDT", "sex": "Male", "registration_number": "752926",
        "birth_date": "May 2, 1930", "color": "Blk, rd mkgs",
        "owner": "Rogerschmidt Kennels", "owner_location": "Bloomingburg, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Apollo v Schuetzeneck", "sire_registration_number": "462894",
        "dam": "Roma v Popp", "dam_registration_number": "694843",
        "source": meta_l49_c1
    },
    {
        "name": "PEARSON'S PATSY", "sex": "Female", "registration_number": "753206",
        "birth_date": "Apr. 18, 1930", "color": "Blk & tn",
        "owner": "Jessie L. Pearson", "owner_location": None,
        "breeder": "Joseph A. Simpson", "breeder_location": "Detroit, Mich.",
        "sire": "Hektor Plato", "sire_registration_number": "517072",
        "dam": "Simpson's Mitzeral", "dam_registration_number": "678209",
        "source": meta_l49_c1
    },
    {
        "name": "PEPPY V NURSCHAN", "sex": "Female", "registration_number": "755498",
        "birth_date": "July 27, 1928", "color": "Dk br, tn mkgs",
        "owner": "N. M. Freund", "owner_location": None,
        "breeder": "Roy Scholz", "breeder_location": "St. Louis, Mo.",
        "sire": "Dolf v Forst", "sire_registration_number": "570944",
        "dam": "Lizett Angola v Liepzic", "dam_registration_number": "616198",
        "source": meta_l49_c1
    },
    {
        "name": "PONTCHARTRAIN'S PRINCESS TORA", "sex": "Female", "registration_number": "753052",
        "birth_date": "Nov. 29, 1928", "color": "Blk rd",
        "owner": "Mr. and Mrs. Philip J. Rhein", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Hertha of Pontchartrain", "dam_registration_number": "610096",
        "source": meta_l49_c1
    },
    {
        "name": "PRINCESS PAN OF PONTCHARTRAIN", "sex": "Female", "registration_number": "752818",
        "birth_date": "Apr. 12, 1930", "color": "Blk rd",
        "owner": "Fred R. Kingman", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721108",
        "dam": "Hertha of Pontchartrain", "dam_registration_number": "610096",
        "source": meta_l49_c1
    },
    {
        "name": "PRINZ CARLO V D FRIEDRICKSHOF", "sex": "Male", "registration_number": "755575",
        "birth_date": "Nov. 8, 1926", "color": "Blk, tn mkgs",
        "owner": "Stanley T. Oliver", "owner_location": None,
        "breeder": "Harold W. Hopkins", "breeder_location": "Brockton, Mass.",
        "sire": "Prinz Carlo v d Hansastadt", "sire_registration_number": "462393",
        "dam": "Princess Vaunghie", "dam_registration_number": "497721",
        "source": meta_l49_c1
    },
    {
        "name": "PRINZ DOLF OF PONTCHARTRAIN", "sex": "Male", "registration_number": "754828",
        "birth_date": "July 5, 1929", "color": "Blk rd",
        "owner": "Robert Pembleton", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Anita of Pontchartrain", "dam_registration_number": "658425",
        "source": meta_l49_c1
    },
    {
        "name": "PRINZ FRANZ OF PONTCHARTRAIN", "sex": "Male", "registration_number": "755764",
        "birth_date": "Oct. 6, 1929", "color": "Blk rd",
        "owner": "Mr. and Mrs. George C. Stokes", "owner_location": None,
        "breeder": "G. O. Gorham", "breeder_location": "Royal Oak, Mich.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Fraulin of Pontchartrain", "dam_registration_number": "737064",
        "source": meta_l49_c1
    },
    {
        "name": "PRINZ PETER OF PONTCHARTRAIN", "sex": "Male", "registration_number": "752819",
        "birth_date": "Apr. 12, 1930", "color": "Blk rd",
        "owner": "Casper J. Bowman, Jr.", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721108",
        "dam": "Hertha of Pontchartrain", "dam_registration_number": "610096",
        "source": meta_l49_c1
    }
]

# Leaf 49, Column 2 (Top down to PINSCHER (Miniature) - 3 dogs)
c3_dogs = [
    {
        "name": "TROLL V LICHTENHOH", "sex": "Male", "registration_number": "753305",
        "birth_date": "July 18, 1924", "color": "Blk rd",
        "owner": "August Jurgens", "owner_location": None,
        "breeder": "Josef Pfeiffer", "breeder_location": "Austria",
        "sire": "Troll Kornhauser", "sire_registration_number": None,
        "dam": "Gratzia Nixe", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Aron Menshengen", "registration_number": None},
            {"role": "dam_of_dam", "name": "Gratzia Prinzess Stella", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Prinz v Rothemark", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Marlitt v Eckartstein", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Prinz v Rothenmark", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Selma Pocher", "registration_number": None},
            {"role": "sire_of_sire", "name": "Rolf v Sandhof", "registration_number": None},
            {"role": "dam_of_sire", "name": "Lidy Kornhauser", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Kuno Umstadt", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Isis Sundersbuhl", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Prinz v Rothemark", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Lidy v Sandhof", "registration_number": None}
        ],
        "source": meta_l49_c2
    },
    {
        "name": "TROLL OF PONTCHARTRAIN", "sex": "Male", "registration_number": "756278",
        "birth_date": "Feb. 6, 1929", "color": "Blk, rd",
        "owner": "M. P. Springer", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Neba v Streslau", "dam_registration_number": "539732",
        "source": meta_l49_c2
    },
    {
        "name": "TRUDIE WILLIAMS", "sex": "Female", "registration_number": "755169",
        "birth_date": "Nov. 11, 1928", "color": "Blk & tn",
        "owner": "Frank C. Williams", "owner_location": None,
        "breeder": "F. C. Bowles", "breeder_location": "Hartville, Ohio",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Tisch v Bornholm", "dam_registration_number": "401095",
        "source": meta_l49_c2
    }
]

all_30_11 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1930-11 dogs: {len(all_30_11)}")
print(f"  Leaf 48 Col 3: {len(c1_dogs)}")
print(f"  Leaf 49 Col 1: {len(c2_dogs)}")
print(f"  Leaf 49 Col 2: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1930_11.json").write_text(json.dumps(all_30_11, indent=2), encoding="utf-8")
print("Saved verified 1930-11 records.")
