import json
from pathlib import Path

meta_l48_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-12-01_47_12", "date": "1930-12-01", "volume": "47", "issue": "12", "leaf": 48, "column": 1}
meta_l48_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-12-01_47_12", "date": "1930-12-01", "volume": "47", "issue": "12", "leaf": 48, "column": 2}
meta_l48_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1930-12-01_47_12", "date": "1930-12-01", "volume": "47", "issue": "12", "leaf": 48, "column": 3}

# Leaf 48, Column 1 (Starts under PINSCHERS (Doberman) - 17 dogs)
c1_dogs = [
    {
        "name": "ASTA V ECKHARDSTEIN", "sex": "Female", "registration_number": "760462",
        "birth_date": "Nov. 11, 1927", "color": "Rd",
        "owner": "Bertha V. Brown", "owner_location": None,
        "breeder": "Ralph T. Miller", "breeder_location": "Philadelphia, Pa.",
        "sire": "Trail 'Em Horstburg", "sire_registration_number": "545469",
        "dam": "Asta v d Frankenfurt", "dam_registration_number": "627856",
        "source": meta_l48_c1
    },
    {
        "name": "ASTA V D MILHEIM", "sex": "Female", "registration_number": "758000",
        "birth_date": "Jan. 13, 1928", "color": "Rd & tn",
        "owner": "J. J. Hackett", "owner_location": None,
        "breeder": "E. F. Rossiter", "breeder_location": "E. Akron, Ohio",
        "sire": "Major v Burgwall", "sire_registration_number": "436981",
        "dam": "Eulah v Saint Sebald", "dam_registration_number": "628467",
        "source": meta_l48_c1
    },
    {
        "name": "BUNNY'S BIG BOY", "sex": "Male", "registration_number": "759192",
        "birth_date": "Jan. 6, 1930", "color": "Blk & tn",
        "owner": "H. Conrad Hare", "owner_location": "West New York, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Big Boy of White Gate", "sire_registration_number": "572868",
        "dam": "Doctor's Bertchen", "dam_registration_number": "627181",
        "source": meta_l48_c1
    },
    {
        "name": "CILLY V D EMILIENHOHE", "sex": "Female", "registration_number": "759359",
        "birth_date": "May 13, 1926", "color": "Br & rd",
        "owner": "Wm. J. Waas", "owner_location": None,
        "breeder": "Jos. Haberzeth", "breeder_location": "Czechoslovakia",
        "sire": "Banjo v Fuchsberg", "sire_registration_number": None,
        "dam": "Arma v Marienwerth", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Aldo v Frankenhof", "registration_number": None},
            {"role": "dam_of_dam", "name": "Lotte v Nordhusia", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Dolf v Wiesengrund", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Ehlers Loni", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Ami v Cuba", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Santa v Schmolln", "registration_number": None},
            {"role": "sire_of_sire", "name": "Banjo v d Goldenen Hohe", "registration_number": None},
            {"role": "dam_of_sire", "name": "Charlotte v d Lausitz", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Blitz v d Lausitz", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Bessy v Monchswal", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Arnfried v Brandis", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Erika v Parthengrund", "registration_number": None}
        ],
        "source": meta_l48_c1
    },
    {
        "name": "COUNT FELIX OF PONTCHARTRAIN", "sex": "Male", "registration_number": "758380",
        "birth_date": "Feb. 28, 1930", "color": "Blk & tn",
        "owner": "Francis M. Sherwin", "owner_location": None,
        "breeder": "H. M. Nuttall", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Lutzie of Dhu Varren", "dam_registration_number": "682898",
        "source": meta_l48_c1
    },
    {
        "name": "DIANE FREIIN V SCHUTZENECK", "sex": "Female", "registration_number": "757477",
        "birth_date": "Mar. 6, 1929", "color": "Fn & tn",
        "owner": "Vodrie R. Smith", "owner_location": None,
        "breeder": "Paul F. Beagan", "breeder_location": "Staten Island, N. Y.",
        "sire": "Teddy Veracity", "sire_registration_number": "356479",
        "dam": "Diana De Haven", "dam_registration_number": "554580",
        "source": meta_l48_c1
    },
    {
        "name": "DOLABELLE OF PONTCHARTRAIN", "sex": "Female", "registration_number": "758479",
        "birth_date": "July 5, 1929", "color": "Blk & rd",
        "owner": "Mabelthea G. Heisley", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Anita of Pontchartrain", "dam_registration_number": "658425",
        "source": meta_l48_c1
    },
    {
        "name": "EDITH OF PONTCHARTRAIN", "sex": "Female", "registration_number": "757517",
        "birth_date": "July 18, 1928", "color": "Blk with rust mkgs",
        "owner": "Glenn S. Staines", "owner_location": None,
        "breeder": "William O. McClane", "breeder_location": "Chicago, Ill.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Flora v Buetersburg of Ardwin", "dam_registration_number": "499562",
        "source": meta_l48_c1
    },
    {
        "name": "FADA V SIGALSBURG", "sex": "Female", "registration_number": "759493",
        "birth_date": "June 3, 1929", "color": "Blk & tn",
        "owner": "Ed. Johnson", "owner_location": None,
        "breeder": "Mrs. R. E. Byrd", "breeder_location": "Erie, Pa.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Dolly v Dombachtal of Perry", "dam_registration_number": "555513",
        "source": meta_l48_c1
    },
    {
        "name": "FAVORIT V D WIETZE'S QUEEN", "sex": "Female", "registration_number": "757597",
        "birth_date": "Feb. 24, 1927", "color": "Blk & tn",
        "owner": "Henry C. Glissmann", "owner_location": None,
        "breeder": "Mrs. Carl Thiemann", "breeder_location": "Omaha, Nebr.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Brunhild v Wiedensahl", "dam_registration_number": "489276",
        "source": meta_l48_c1
    },
    {
        "name": "FLOWTON'S ARNO V SPREE", "sex": "Male", "registration_number": "758108",
        "birth_date": "May 30, 1925", "color": "Blk, tn mkgs",
        "owner": "J. Gilmore Fletcher", "owner_location": None,
        "breeder": "John Boshler, Jr.", "breeder_location": "Hempstead, L. I., N. Y.",
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Reins v Rennstieg", "dam_registration_number": "314580",
        "source": meta_l48_c1
    },
    {
        "name": "FREDJA OF PONTCHARTRAIN", "sex": "Male", "registration_number": "759497",
        "birth_date": "Sept. 25, 1929", "color": "Blk & rd",
        "owner": "Jack L. Fisher", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Hesta of Pontchartrain", "dam_registration_number": "607184",
        "source": meta_l48_c1
    },
    {
        "name": "FRIEDA V BLANKENBURG", "sex": "Female", "registration_number": "759077",
        "birth_date": "Apr. 23, 1929", "color": "Blk & tn",
        "owner": "Jay D. Conner", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "Cupertino, Calif.",
        "sire": "Graf v Blankenburg", "sire_registration_number": "629406",
        "dam": "Altara v Riga", "dam_registration_number": "699653",
        "source": meta_l48_c1
    },
    {
        "name": "FRITZ V SARSTRAND", "sex": "Male", "registration_number": "759560",
        "birth_date": "Oct. 21, 1928", "color": "Blk, deep rust",
        "owner": "C. N. Wise", "owner_location": None,
        "breeder": "A. C. Wales", "breeder_location": "Akron, Ohio",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Reva of Pontchartrain", "dam_registration_number": "624345",
        "source": meta_l48_c1
    },
    {
        "name": "FRITZ V STRESOW", "sex": "Male", "registration_number": "759925",
        "birth_date": "Oct. 25, 1929", "color": "Rd & tn",
        "owner": "Wendell R. Lerch", "owner_location": None,
        "breeder": "J. J. Hackett", "breeder_location": "East Akron, Ohio",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Asta v d Milheim", "dam_registration_number": "758000",
        "source": meta_l48_c1
    },
    {
        "name": "GRETA V MORRIS", "sex": "Female", "registration_number": "757314",
        "birth_date": "July 21, 1928", "color": "Blk & br",
        "owner": "Walter A. Morris", "owner_location": None,
        "breeder": "Alfred Piza, Jr.", "breeder_location": "N. Y. City",
        "sire": "Benno v Roemerhof", "sire_registration_number": "517073",
        "dam": "Ixy v Piza", "dam_registration_number": "655961",
        "source": meta_l48_c1
    },
    {
        "name": "HAIGHT'S FRITZ V SPREEWALD", "sex": "Male", "registration_number": "760430",
        "birth_date": "Aug. 10, 1930", "color": "Blk, br mkgs",
        "owner": "Miss M. E. Fox", "owner_location": None,
        "breeder": "C. W. Haight", "breeder_location": "East Chicago, Ind.",
        "sire": "Jones' Lindy v Klostersee", "sire_registration_number": "662864",
        "dam": "Duchess v Opasik", "dam_registration_number": "725271",
        "source": meta_l48_c1
    },
    {
        "name": "HANSEL V CALIFORNIA", "sex": "Male", "registration_number": "760127",
        "birth_date": "May 18, 1930", "color": "Blk & tn",
        "owner": "Mrs. Irwin H. Rice", "owner_location": None,
        "breeder": "Don Curley", "breeder_location": "San Mateo, Calif.",
        "sire": "Byng v Blankenburg", "sire_registration_number": "699348",
        "dam": "Jewell v Bofferding", "dam_registration_number": "461839",
        "source": meta_l48_c1
    },
    {
        "name": "HECTOR OF OXBO", "sex": "Male", "registration_number": "760360",
        "birth_date": "Aug. 11, 1930", "color": "Blk & tn",
        "owner": "Jack G. Comyn", "owner_location": None,
        "breeder": "F. C. Fuqua", "breeder_location": "Seattle, Wash.",
        "sire": "Carlo v Belger", "sire_registration_number": "533994",
        "dam": "Hilda v Skyel Fisk Oer", "dam_registration_number": "713104",
        "source": meta_l48_c1
    },
    {
        "name": "JURGENS' BIG BOY", "sex": "Male", "registration_number": "759861",
        "birth_date": "Feb. 17, 1927", "color": "Blk & tn",
        "owner": "August Jurgens, Jr.", "owner_location": "Chicago, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Troll v Lichtenhoh", "sire_registration_number": "753305",
        "dam": "Alma v Schlesien", "dam_registration_number": "753304",
        "source": meta_l48_c1
    },
    {
        "name": "KARLS V D DASTNICKBERG", "sex": "Male", "registration_number": "757571",
        "birth_date": None, "color": None,
        "owner": "Alfred J. Bertelli", "owner_location": "Arlington, Mass.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "", "sire_registration_number": None,
        "dam": "", "dam_registration_number": None,
        "source": meta_l48_c1
    }
]

# Leaf 48, Column 2 (16 dogs)
c2_dogs = [
    {
        "name": "NADA RILDA", "sex": "Female", "registration_number": "758589",
        "birth_date": "Apr. 18, 1928", "color": "Blk & tn",
        "owner": "F. E. Shields", "owner_location": None,
        "breeder": "J. F. Planz", "breeder_location": "Akron, Ohio",
        "sire": "Prinz Favorite v d Koningsted", "sire_registration_number": "420325",
        "dam": "Rowdy Rilda", "dam_registration_number": "653358",
        "source": meta_l48_c2
    },
    {
        "name": "NUTTALL'S JIM", "sex": "Male", "registration_number": "756889",
        "birth_date": "Feb. 28, 1930", "color": "Blk & tn",
        "owner": "H. M. Nuttall", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Lutzie of Dhu Varren", "dam_registration_number": "682898",
        "source": meta_l48_c2
    },
    {
        "name": "NUTTALL'S KATE", "sex": "Female", "registration_number": "756888",
        "birth_date": "Feb. 28, 1930", "color": "Blk & tn",
        "owner": "H. M. Nuttall", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Lutzie of Dhu Varren", "dam_registration_number": "682898",
        "source": meta_l48_c2
    },
    {
        "name": "PINCH V BURWALD", "sex": "Male", "registration_number": "757405",
        "birth_date": "Mar. 3, 1930", "color": "Blk, rust mkgs",
        "owner": "Trooper E. V. Jarvis", "owner_location": None,
        "breeder": "W. L. Lyons, Jr.", "breeder_location": "Harrods Creek, Ky.",
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Ellen v Friedewald", "dam_registration_number": "574498",
        "source": meta_l48_c2
    },
    {
        "name": "PRINCESS CIL O'PONTCHARTRAIN", "sex": "Female", "registration_number": "759926",
        "birth_date": "Dec. 24, 1929", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Ilisa of Pontchartrain", "dam_registration_number": "571491",
        "source": meta_l48_c2
    },
    {
        "name": "PRINZ CITO OF PONTCHARTRAIN", "sex": "Male", "registration_number": "757518",
        "birth_date": "Dec. 24, 1929", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Ilisa of Pontchartrain", "dam_registration_number": "571491",
        "source": meta_l48_c2
    },
    {
        "name": "PRINZ COSTE OF PONTCHARTRAIN", "sex": "Male", "registration_number": "757678",
        "birth_date": "Dec. 24, 1929", "color": "Blk & rd",
        "owner": "M. P. Springer", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Ilisa of Pontchartrain", "dam_registration_number": "571491",
        "source": meta_l48_c2
    },
    {
        "name": "PRINZESSIN V KUEHNSACH", "sex": "Female", "registration_number": "758842",
        "birth_date": "May 20, 1930", "color": "Blk, tn mkgs",
        "owner": "William Frederick Kuehn", "owner_location": None,
        "breeder": "Wayne D. King", "breeder_location": "Bridgeport, Ohio",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Asta v Nashville", "dam_registration_number": "675400",
        "source": meta_l48_c2
    },
    {
        "name": "PRINZ PEER OF PONTCHARTRAIN", "sex": "Male", "registration_number": "757625",
        "birth_date": "Apr. 12, 1930", "color": "Blk & rd",
        "owner": "John Sherwin, Jr.", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Hertha of Pontchartrain", "dam_registration_number": "610096",
        "source": meta_l48_c2
    },
    {
        "name": "PRINZ V SIGALSBURG", "sex": "Male", "registration_number": "758942",
        "birth_date": "May 28, 1930", "color": "Blk, tn mkgs",
        "owner": "P. L. Matson", "owner_location": "Warren, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Bella v Sigalsburg", "dam_registration_number": "694844",
        "source": meta_l48_c2
    },
    {
        "name": "RUFF V WHOOPEE", "sex": "Male", "registration_number": "757566",
        "birth_date": "July 18, 1928", "color": "Blk & rd",
        "owner": "C. W. Bradley", "owner_location": None,
        "breeder": "William O. McClane", "breeder_location": "Chicago, Ill.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Flora v Buetersburg of Ardwin", "dam_registration_number": "499562",
        "source": meta_l48_c2
    },
    {
        "name": "RUSTY V REXELLA", "sex": "Male", "registration_number": "757451",
        "birth_date": "May 3, 1929", "color": "Blk & rust",
        "owner": "Chas. L. Smith", "owner_location": None,
        "breeder": "A. T. Smurthwaite", "breeder_location": "Salt Lake City, Utah",
        "sire": "Rex v Rottal", "sire_registration_number": "401310",
        "dam": "Gretchen v Rexella", "dam_registration_number": "655245",
        "source": meta_l48_c2
    },
    {
        "name": "SCHEINS MAICHEN II", "sex": "Female", "registration_number": "756925",
        "birth_date": "Apr. 17, 1928", "color": "Blk & tn",
        "owner": "Frank Yahraus", "owner_location": None,
        "breeder": "Bert S. Halle, Sr.", "breeder_location": "Cleveland, Ohio",
        "sire": "Von Bleitzen Waldlust", "sire_registration_number": "586153",
        "dam": "Scheins Maichen", "dam_registration_number": "558425",
        "source": meta_l48_c2
    },
    {
        "name": "SIGRID V D HOEHEN", "sex": "Female", "registration_number": "759604",
        "birth_date": "Feb. 2, 1930", "color": "Blk, rust mkgs",
        "owner": "Mrs. M. Von Hoegen", "owner_location": "Towaco, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Baroness Atora v d Hoehen", "dam_registration_number": "554720",
        "source": meta_l48_c2
    },
    {
        "name": "SO BIG V DOMBACHTAL", "sex": "Male", "registration_number": "757167",
        "birth_date": "Mar. 30, 1930", "color": "Blk & rust tn",
        "owner": "Mrs. Edna Woitt", "owner_location": None,
        "breeder": "Mrs. Margaret Schang", "breeder_location": "Seattle, Wash.",
        "sire": "Fritzie v Dombachtal", "sire_registration_number": "703639",
        "dam": "Celia v Sigalsburg", "dam_registration_number": "705091",
        "source": meta_l48_c2
    }
]

# Leaf 48, Column 3 top (5 dogs down to POINTERS)
c3_dogs = [
    {
        "name": "SVEN V D HOEHEN", "sex": "Male", "registration_number": "759605",
        "birth_date": "Feb. 2, 1930", "color": "Blk, rust mkgs",
        "owner": "Mrs. M. Von Hoegen", "owner_location": "Towaco, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Baroness Atora v d Hoehen", "dam_registration_number": "554720",
        "source": meta_l48_c3
    },
    {
        "name": "TASSO V D HOEHEN", "sex": "Male", "registration_number": "759606",
        "birth_date": "Feb. 15, 1930", "color": "Br, tn mkgs",
        "owner": "Mrs. M. Von Hoegen", "owner_location": "Towaco, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Elodia v d Hoehen", "dam_registration_number": "683705",
        "source": meta_l48_c3
    },
    {
        "name": "TELL V D HOEHEN", "sex": "Male", "registration_number": "759607",
        "birth_date": "Feb. 15, 1930", "color": "Blk, tn mkgs",
        "owner": "Mrs. M. Von Hoegen", "owner_location": "Towaco, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Elodia v d Hoehen", "dam_registration_number": "683705",
        "source": meta_l48_c3
    },
    {
        "name": "TROLL V D HOEHEN", "sex": "Male", "registration_number": "759608",
        "birth_date": "Feb. 15, 1930", "color": "Blk, tn mkgs",
        "owner": "Mrs. M. Von Hoegen", "owner_location": "Towaco, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Elodia v d Hoehen", "dam_registration_number": "683705",
        "source": meta_l48_c3
    },
    {
        "name": "VIAN OF JONEDITH", "sex": "Female", "registration_number": "758579",
        "birth_date": "Aug. 6, 1928", "color": "Blk & tn",
        "owner": "Vincent P. McCall", "owner_location": None,
        "breeder": "Emil Pfeiffer", "breeder_location": "Woodside, N. Y. City",
        "sire": "Cy of Syosset", "sire_registration_number": "558079",
        "dam": "Jill of Jonedith", "dam_registration_number": "595853",
        "source": meta_l48_c3
    }
]

all_30_12 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1930-12 dogs: {len(all_30_12)}")
print(f"  Leaf 48 Col 1: {len(c1_dogs)}")
print(f"  Leaf 48 Col 2: {len(c2_dogs)}")
print(f"  Leaf 48 Col 3: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1930_12.json").write_text(json.dumps(all_30_12, indent=2), encoding="utf-8")
print("Saved verified 1930-12 records.")
