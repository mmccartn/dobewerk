import json
from pathlib import Path

meta_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-01-01_48_1", "date": "1931-01-01", "volume": "48", "issue": "1", "leaf": 42, "column": 1}
meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-01-01_48_1", "date": "1931-01-01", "volume": "48", "issue": "1", "leaf": 42, "column": 2}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-01-01_48_1", "date": "1931-01-01", "volume": "48", "issue": "1", "leaf": 42, "column": 3}

# Leaf 42, Column 1 bottom (Starts under PINSCHERS (Doberman) - 9 dogs)
c1_dogs = [
    {
        "name": "ABRAMS' ACE OF HEARTS", "sex": "Female", "registration_number": "761549",
        "birth_date": "Nov. 10, 1929", "color": "Rd, rust mkgs",
        "owner": "Katheryn Abrams", "owner_location": None,
        "breeder": "W. L. Lyons, Jr.", "breeder_location": "Harrods Creek, Ky.",
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Nitta Yuma's Mitzi", "dam_registration_number": "760653",
        "source": meta_c1
    },
    {
        "name": "ALEXANDRIA V D HOHEN", "sex": "Female", "registration_number": "763497",
        "birth_date": "Feb. 11, 1930", "color": "Rd, tn mkgs",
        "owner": "Frank M. Gould", "owner_location": "N. Y. City",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Erda v d Hohen", "dam_registration_number": "683706",
        "source": meta_c1
    },
    {
        "name": "ALEX V D HOHEN", "sex": "Male", "registration_number": "763496",
        "birth_date": "Feb. 11, 1930", "color": "Rd, tn mkgs",
        "owner": "Frank M. Gould", "owner_location": "N. Y. City",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Erda v d Hohen", "dam_registration_number": "683706",
        "source": meta_c1
    },
    {
        "name": "ANITRA V FALKENTURM", "sex": "Female", "registration_number": "761427",
        "birth_date": "Jan. 15, 1929", "color": "Blk & rust",
        "owner": "Milo W. Wilder, Jr.", "owner_location": None,
        "breeder": "Leslie L. Romine", "breeder_location": "Livingston, N. J.",
        "sire": "Max De Haven", "sire_registration_number": "604075",
        "dam": "Hilda v Falkenturm", "dam_registration_number": "637640",
        "source": meta_c1
    },
    {
        "name": "AURORA V D HOHEN", "sex": "Female", "registration_number": "763498",
        "birth_date": "Feb. 11, 1930", "color": "Rd & tn",
        "owner": "Frank M. Gould", "owner_location": "N. Y. City",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Erda v d Hohen", "dam_registration_number": "683706",
        "source": meta_c1
    },
    {
        "name": "AXEL V D HOHEN", "sex": "Male", "registration_number": "763499",
        "birth_date": "Feb. 11, 1930", "color": "Br & tn",
        "owner": "Frank M. Gould", "owner_location": "N. Y. City",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Erda v d Hohen", "dam_registration_number": "683706",
        "source": meta_c1
    },
    {
        "name": "BARNACLE BILL", "sex": "Male", "registration_number": "760674",
        "birth_date": "Jan. 24, 1930", "color": "Blk & tn",
        "owner": "Charles Lohre", "owner_location": None,
        "breeder": "James M. Dempsey", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Dina Dempsey", "dam_registration_number": "728138",
        "source": meta_c1
    },
    {
        "name": "BEETA V BARON", "sex": "Female", "registration_number": "761778",
        "birth_date": "Mar. 20, 1928", "color": "Blk & tn",
        "owner": "Marshall F. Bidwell", "owner_location": "South Windsor, Conn.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Baron v Richthofen", "sire_registration_number": "526664",
        "dam": "Adda v Kanonenstadt", "dam_registration_number": "534153",
        "source": meta_c1
    },
    {
        "name": "BILL (GEORGES)", "sex": "Male", "registration_number": "762582",
        "birth_date": "June 8, 1926", "color": "Blk rd",
        "owner": "Adolphe Bentz", "owner_location": None,
        "breeder": "C. Georges", "breeder_location": "Germany",
        "sire": "Fels v d Eckardtsburg", "sire_registration_number": None,
        "dam": "Alma de St. Odile", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Cyranno v d Romerschanz", "registration_number": None},
            {"role": "dam_of_dam", "name": "Bella de la Mainau", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Arthur v Hindendorff", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Florette v Schweningen", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Achim v Langerode", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Cassia v Grammont", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_sire", "name": "Isolde v Coln", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Marko v Jagerhof", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Ruska v Coln", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Achim v Langerode", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Leddy v d Blankenburg", "registration_number": None}
        ],
        "source": meta_c1
    }
]

# Leaf 42, Column 2 (21 dogs)
c2_dogs = [
    {
        "name": "BONA OF LAWNWOOD COURT", "sex": "Female", "registration_number": "763964",
        "birth_date": "April 10, 1928", "color": "Blk & tn",
        "owner": "Laura B. Gibson", "owner_location": None,
        "breeder": "Reyem Kennels", "breeder_location": "Hales Corners, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Bona v d Residenz", "dam_registration_number": "410865",
        "source": meta_c2
    },
    {
        "name": "BROWNIE V BARON", "sex": "Female", "registration_number": "761779",
        "birth_date": "July 16, 1928", "color": "Rd, tn mkgs",
        "owner": "Marshall F. Bidwell", "owner_location": "South Windsor, Conn.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Baron v Richthofen", "sire_registration_number": "526664",
        "dam": "Cleopatra v Nordheim", "dam_registration_number": "529687",
        "source": meta_c2
    },
    {
        "name": "BUBBLES V STRAHL", "sex": "Female", "registration_number": "762423",
        "birth_date": "Mar. 29, 1929", "color": "Blk & tn",
        "owner": "Mr. and Mrs. Edward F. Strahl", "owner_location": None,
        "breeder": "W. O. McClane", "breeder_location": "Chicago, Ill.",
        "sire": "Gustl v Tannenhaus", "sire_registration_number": "677473",
        "dam": "Sallie v Allie", "dam_registration_number": "605877",
        "source": meta_c2
    },
    {
        "name": "CHAR FREIHERR V HAMBURG", "sex": "Male", "registration_number": "761244",
        "birth_date": "Nov. 4, 1929", "color": "Blk & rust rd",
        "owner": "William Cords", "owner_location": None,
        "breeder": "Otto Klaus", "breeder_location": "Detroit, Mich.",
        "sire": "Char v Neckarsulm", "sire_registration_number": "752742",
        "dam": "Grafin Klaus v Belling", "dam_registration_number": "505583",
        "source": meta_c2
    },
    {
        "name": "DIANA BLACKJACK", "sex": "Female", "registration_number": "763431",
        "birth_date": "July 12, 1930", "color": "Blk, rd tn mkgs",
        "owner": "Joseph F. Yost", "owner_location": None,
        "breeder": "Sofie Frolich", "breeder_location": "Cincinnati, Ohio",
        "sire": "Falko Margaretenau", "sire_registration_number": "740710",
        "dam": "Ada Black Jack", "dam_registration_number": "740713",
        "source": meta_c2
    },
    {
        "name": "DOBER V BUELOW", "sex": "Male", "registration_number": "761992",
        "birth_date": "Aug. 1, 1929", "color": "Blk, rust rd",
        "owner": "Caesar Gruenspahn", "owner_location": None,
        "breeder": "Mrs. C. A. Bergman", "breeder_location": "Ottumwa, Iowa",
        "sire": "Rudolph v d Rudolphsburg", "sire_registration_number": "493363",
        "dam": "Dolly v Jaegershof", "dam_registration_number": "719690",
        "source": meta_c2
    },
    {
        "name": "DUKE V DIETRICH", "sex": "Male", "registration_number": "761914",
        "birth_date": "Aug. 26, 1930", "color": "Blk & tn",
        "owner": "Paul Dietrich", "owner_location": None,
        "breeder": "Philip Gruber", "breeder_location": "Chicago, Ill.",
        "sire": "Lindy v Forsberg", "sire_registration_number": "670607",
        "dam": "Olga v Hoffeld", "dam_registration_number": "676436",
        "source": meta_c2
    },
    {
        "name": "ETCHEN DE HAVEN", "sex": "Female", "registration_number": "760662",
        "birth_date": "Jan. 22, 1929", "color": "Blk & br",
        "owner": "Leslie L. Romine", "owner_location": None,
        "breeder": "R. C. Bauman", "breeder_location": "Nutley, N. J.",
        "sire": "Max De Haven", "sire_registration_number": "604075",
        "dam": "Lady v Homehill II", "dam_registration_number": "750119",
        "source": meta_c2
    },
    {
        "name": "FEE V HEIMFELD", "sex": "Female", "registration_number": "761810",
        "birth_date": "Aug. 17, 1929", "color": "Blk & rd",
        "owner": "M. P. Springer", "owner_location": None,
        "breeder": "Herm. Burmester", "breeder_location": "Germany",
        "sire": "Alto v Sigalsburg", "sire_registration_number": None,
        "dam": "Ursula v Lugumkloster", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Amor v Gotterfelsen", "registration_number": None},
            {"role": "dam_of_dam", "name": "Martha v Marthastein", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Treu v Butersburg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Rita Rinneberg", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Melitta v Parthengrund", "registration_number": None},
            {"role": "sire_of_sire", "name": "Lux v d Blankenburg", "registration_number": "571492"},
            {"role": "dam_of_sire", "name": "Lotte v Roneckenstein", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Dora v Wiesengrund", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "FRITKIN V TINGLE", "sex": "Male", "registration_number": "763550",
        "birth_date": "Apr. 23, 1930", "color": "Blk & tn",
        "owner": "A. D. Tingle", "owner_location": None,
        "breeder": "D. C. Philipp", "breeder_location": "Wichita, Kan.",
        "sire": "Dietrich v d Barbarosahoehle", "sire_registration_number": "561617",
        "dam": "Ellisa v Nuremberg", "dam_registration_number": "692976",
        "source": meta_c2
    },
    {
        "name": "FRITZ V BECK", "sex": "Male", "registration_number": "762727",
        "birth_date": "July 27, 1927", "color": "Mhgy & tn",
        "owner": "William M. H. Beck, Jr.", "owner_location": None,
        "breeder": "The Beck Kennels", "breeder_location": "Middleboro, Mass.",
        "sire": "Verson v d Beck", "sire_registration_number": "539976",
        "dam": "Hanetta v d Beck", "dam_registration_number": "539973",
        "source": meta_c2
    },
    {
        "name": "FRITZ V HORSTBURG", "sex": "Male", "registration_number": "761306",
        "birth_date": "Aug. 7, 1929", "color": "Blk, tn mkgs",
        "owner": "Mrs. Lon Ross", "owner_location": None,
        "breeder": "H. F. Steffan", "breeder_location": "Indianapolis, Ind.",
        "sire": "Tuck v d Horstburg", "sire_registration_number": "604645",
        "dam": "Laska v Nibelungenhort", "dam_registration_number": "708971",
        "source": meta_c2
    },
    {
        "name": "GERTA V WALDSCHLOSS", "sex": "Female", "registration_number": "762942",
        "birth_date": "Aug. 17, 1926", "color": "Blk & tn",
        "owner": "Harry S. Irwin", "owner_location": None,
        "breeder": "J. H. Vrancken", "breeder_location": "Columbus, Ohio",
        "sire": "Arnold v Cartenberg", "sire_registration_number": "435139",
        "dam": "Hilda Hoyler", "dam_registration_number": "495893",
        "source": meta_c2
    },
    {
        "name": "GESA V GOLDGRUND", "sex": "Female", "registration_number": "762495",
        "birth_date": "Aug. 8, 1926", "color": "Blk & rd",
        "owner": "Miss Bessie P. Hunt", "owner_location": None,
        "breeder": "Robert Naumann", "breeder_location": "Germany",
        "sire": "Bodo v Goldgrund", "sire_registration_number": None,
        "dam": "Helga v d Schulzburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Lux v d Blankenburg", "registration_number": "571492"},
            {"role": "dam_of_dam", "name": "Anita v Goldgrund", "registration_number": "454887"},
            {"role": "sire_of_sire", "name": "Norbert v Friedewald", "registration_number": None},
            {"role": "dam_of_sire", "name": "Hela v Gotterfelsen", "registration_number": "402278"},
            {"role": "sire_of_paternal_grandsire", "name": "Astor v d Residenz", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Freya Ripper", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "GIRLIE", "sex": "Female", "registration_number": "763706",
        "birth_date": "Mar. 22, 1930", "color": "Blk & tn",
        "owner": "Carl A. Tritten", "owner_location": "Utica, N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Pat v Stolzenfels", "sire_registration_number": "746034",
        "dam": "Alma Fra Duncan", "dam_registration_number": "574806",
        "source": meta_c2
    },
    {
        "name": "GRETCHEN'S GUARD", "sex": "Male", "registration_number": "762882",
        "birth_date": "Aug. 9, 1930", "color": "Rd & tn",
        "owner": "Fritz L. Meeske", "owner_location": None,
        "breeder": "Marshall F. Bidwell", "breeder_location": "South Windsor, Conn.",
        "sire": "Gretchen Flash", "sire_registration_number": "638956",
        "dam": "Rozeta v Baron", "dam_registration_number": "714011",
        "source": meta_c2
    },
    {
        "name": "JUDA V WENGSTERN", "sex": "Female", "registration_number": "763735",
        "birth_date": "Jan. 24, 1930", "color": "Blk & tn",
        "owner": "Mrs. Dennis Rupp", "owner_location": None,
        "breeder": "James M. Dempsey", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Dina Dempsey", "dam_registration_number": "728138",
        "source": meta_c2
    },
    {
        "name": "LAX V ROMER", "sex": "Male", "registration_number": "762382",
        "birth_date": "Oct. 3, 1927", "color": "Rd & tn",
        "owner": "J. H. Vrancken", "owner_location": None,
        "breeder": "W. N. McCoy", "breeder_location": "Middletown, Ohio",
        "sire": "A Rappo of Pontchartrain", "sire_registration_number": "439031",
        "dam": "Gira v Niberlungenhordt", "dam_registration_number": "491924",
        "source": meta_c2
    },
    {
        "name": "LEX V POPP", "sex": "Male", "registration_number": "762241",
        "birth_date": "Feb. 19, 1930", "color": "Blk & tn",
        "owner": "T. E. Popp", "owner_location": "West Allis, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dortell v Popp", "dam_registration_number": "526001",
        "source": meta_c2
    },
    {
        "name": "LOTTE V SIMMENAU", "sex": "Female", "registration_number": "762222",
        "birth_date": "Nov. 17, 1926", "color": "Blk & tn",
        "owner": "Howard K. Mohr", "owner_location": None,
        "breeder": "Carl Winkler", "breeder_location": "Germany",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Lotte v Roneckenstein", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_dam", "name": "Dora v Wiesengrund", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Lea v Weissenfels", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_sire", "name": "Achim v Langerode", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Leddy v d Blankenburg", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "MARGO V BURGHOLZ", "sex": "Female", "registration_number": "762197",
        "birth_date": "July 7, 1930", "color": "Rd, rust mkgs",
        "owner": "N. Hyldahl", "owner_location": None,
        "breeder": "R. L. Ward", "breeder_location": "Batavia, Iowa",
        "sire": "Fritz of Mickburn", "sire_registration_number": "753360",
        "dam": "Jil v Jaegershof", "dam_registration_number": "703280",
        "source": meta_c2
    }
]

# Leaf 42, Column 3 (20 dogs down to PINSCHERS (Miniature))
c3_dogs = [
    {
        "name": "MAXSTEIN", "sex": "Male", "registration_number": "760853",
        "birth_date": "May 8, 1930", "color": "Blk & tn",
        "owner": "Geo. K. Mackie, Jr.", "owner_location": None,
        "breeder": "Mr. and Mrs. Geo. Tucker", "breeder_location": "Flint, Mich.",
        "sire": "The Imperator of Rhinegold", "sire_registration_number": "653798",
        "dam": "Norma v Streslau", "dam_registration_number": "586734",
        "source": meta_c3
    },
    {
        "name": "MAX V TANNENBURGH", "sex": "Male", "registration_number": "763627",
        "birth_date": "May 13, 1930", "color": "Blk & tn",
        "owner": "Louis C. Lemberger", "owner_location": None,
        "breeder": "Emil Aschner", "breeder_location": "Brentwood, Pa.",
        "sire": "Bodo v Petersbach", "sire_registration_number": "605198",
        "dam": "Alma de la Ville de Bale", "dam_registration_number": "605199",
        "source": meta_c3
    },
    {
        "name": "MEISTER V HOLLYWOOD", "sex": "Male", "registration_number": "763704",
        "birth_date": "Nov. 4, 1929", "color": "Blk & rust rd",
        "owner": "Bernard J. Hollywood", "owner_location": None,
        "breeder": "Otto Klaus", "breeder_location": "Detroit, Mich.",
        "sire": "Char v Neckarsulm", "sire_registration_number": "752742",
        "dam": "Grafin Klaus v Belling", "dam_registration_number": "505583",
        "source": meta_c3
    },
    {
        "name": "MITZY V GRETCHEN", "sex": "Female", "registration_number": "760854",
        "birth_date": "July 8, 1930", "color": "Blk, tn mkgs",
        "owner": "Lee G. Reader", "owner_location": None,
        "breeder": "Geo. M. Henderson", "breeder_location": "Huntington, W. Va.",
        "sire": "Claus v d Spree Junior", "sire_registration_number": "512026",
        "dam": "Brunhilde of Bornholm", "dam_registration_number": "592815",
        "source": meta_c3
    },
    {
        "name": "NITTA YUMA'S MITZI", "sex": "Female", "registration_number": "760653",
        "birth_date": "Feb. 10, 1928", "color": "Blk & tn, rust & rd mkgs",
        "owner": "W. L. Lyons, Jr.", "owner_location": None,
        "breeder": "P. L. Atherton", "breeder_location": "Glenview, Ky.",
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Trail 'Em Memories", "dam_registration_number": "565660",
        "source": meta_c3
    },
    {
        "name": "PRINCESS NAN O' PONTCHARTRAIN", "sex": "Female", "registration_number": "761022",
        "birth_date": "May 24, 1930", "color": "Blk & rd",
        "owner": "Geo. W. Keith", "owner_location": None,
        "breeder": "Glenn Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Ilisa of Pontchartrain", "dam_registration_number": "571491",
        "source": meta_c3
    },
    {
        "name": "PRINZ PALO OF PONTCHARTRAIN", "sex": "Male", "registration_number": "762853",
        "birth_date": "Apr. 12, 1930", "color": "Blk & rd",
        "owner": "Richard W. Woolworth", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Hertha of Pontchartrain", "dam_registration_number": "610096",
        "source": meta_c3
    },
    {
        "name": "RAPPO V WEBERTAL", "sex": "Male", "registration_number": "764139",
        "birth_date": "May 28, 1927", "color": "Blk & rd",
        "owner": "Henry Scheuermann", "owner_location": None,
        "breeder": "Emil Nicolay", "breeder_location": "Germany",
        "sire": "Belling v Falkensee", "sire_registration_number": None,
        "dam": "Lotti v Hindenburgwall", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Edelblut v Schlieperhof", "registration_number": None},
            {"role": "dam_of_dam", "name": "Akta v Louisengrun", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Zeuss v Parthengrund", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Akla v d guldenen Au", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Nelly Seipp", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Fanny v Stresow", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Lotte v Stresow", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_c3
    },
    {
        "name": "RUSCA V HORSTBURG", "sex": "Female", "registration_number": "761305",
        "birth_date": "Aug. 7, 1929", "color": "Blk, tn mkgs",
        "owner": "R. Wynn S. Owen", "owner_location": None,
        "breeder": "H. F. Steffan", "breeder_location": "Indianapolis, Ind.",
        "sire": "Tuck v d Horstburg", "sire_registration_number": "604645",
        "dam": "Laska v Nibelungenhort", "dam_registration_number": "708971",
        "source": meta_c3
    },
    {
        "name": "TED", "sex": "Male", "registration_number": "763707",
        "birth_date": "Mar. 22, 1930", "color": "Blk & tn",
        "owner": "Harry Sayre Benjamin", "owner_location": None,
        "breeder": "Carl A. Tritten", "breeder_location": "Utica, N. Y.",
        "sire": "Pat v Stolzenfels", "sire_registration_number": "746034",
        "dam": "Alma Fra Duncan", "dam_registration_number": "574806",
        "source": meta_c3
    },
    {
        "name": "TIGER V NIBELUNGENHORT", "sex": "Male", "registration_number": "760688",
        "birth_date": "July 26, 1929", "color": "Blk & tn",
        "owner": "Stuart McGuire", "owner_location": "Portland, Ore.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Count Spike v Nibelungenhort", "sire_registration_number": "698933",
        "dam": "Dolly v Reyem", "dam_registration_number": "538466",
        "source": meta_c3
    },
    {
        "name": "TILDA V BETS", "sex": "Female", "registration_number": "761970",
        "birth_date": "Oct. 2, 1928", "color": "Blk & tn",
        "owner": "Wm. E. Frost", "owner_location": None,
        "breeder": "Lee Betsinger", "breeder_location": "Los Angeles, Calif.",
        "sire": "Dobe v Bets", "sire_registration_number": "451013",
        "dam": "Betty v Bets", "dam_registration_number": "489719",
        "source": meta_c3
    },
    {
        "name": "TOPPO V SIGALSBURG II", "sex": "Male", "registration_number": "762998",
        "birth_date": "Oct. 2, 1929", "color": "Blk & tn",
        "owner": "Mrs. Elmer Schweninger", "owner_location": "Cincinnati, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Toppo v Sigalsburg", "sire_registration_number": "670191",
        "dam": "Lindy v Benno", "dam_registration_number": "710927",
        "source": meta_c3
    },
    {
        "name": "TRADITION OF DAWN", "sex": "Male", "registration_number": "763997",
        "birth_date": "Mar. 8, 1930", "color": "Blk & rd",
        "owner": "Elliott S. Bartlett", "owner_location": None,
        "breeder": "H. S. Newsom", "breeder_location": "Chicago, Ill.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Werra v Ostersee", "dam_registration_number": "467468",
        "source": meta_c3
    },
    {
        "name": "URSULA V D HOHEN", "sex": "Female", "registration_number": "764171",
        "birth_date": "Apr. 23, 1930", "color": "Br, rd mkgs",
        "owner": "G. Owen Bonawit", "owner_location": None,
        "breeder": "Mrs. M. von Hoegen", "breeder_location": "Towaco, N. J.",
        "sire": "D'Artagnan v d Hohen", "sire_registration_number": "594257",
        "dam": "Ilisa v d Hohen", "dam_registration_number": "735502",
        "source": meta_c3
    },
    {
        "name": "VODKA V SHOENAU", "sex": "Male", "registration_number": "763628",
        "birth_date": "Sept. 20, 1930", "color": "Rust br & tn",
        "owner": "Bennett Davis", "owner_location": None,
        "breeder": "R. J. Albrecht", "breeder_location": "Pittsburgh, Pa.",
        "sire": "Carlo v Shoenau", "sire_registration_number": "742490",
        "dam": "Alfra v Klostree", "dam_registration_number": "669159",
        "source": meta_c3
    },
    {
        "name": "VON DONA V D DASTENECKBERG", "sex": "Female", "registration_number": "761484",
        "birth_date": "Apr. 28, 1930", "color": "Br & tn",
        "owner": "Leonard Rams", "owner_location": None,
        "breeder": "Alfred J. Bertelli", "breeder_location": "Arlington, Mass.",
        "sire": "Bodo v Musenbach", "sire_registration_number": "332043",
        "dam": "Alice v d Charlesbank", "dam_registration_number": "688358",
        "source": meta_c3
    },
    {
        "name": "WERA V BOCKHOF", "sex": "Female", "registration_number": "761174",
        "birth_date": "Feb. 17, 1927", "color": "Blk & tn",
        "owner": "Vincent Bocek", "owner_location": None,
        "breeder": "August Jurgens", "breeder_location": "Ridgeland, Miss.",
        "sire": "Troll v Lichtenhoh", "sire_registration_number": "753305",
        "dam": "Alma v Schlesien", "dam_registration_number": "753304",
        "source": meta_c3
    },
    {
        "name": "WOLF", "sex": "Male", "registration_number": "761613",
        "birth_date": "May 13, 1930", "color": "Rd & tn",
        "owner": "Anton A. J. Muenchen", "owner_location": None,
        "breeder": "Emil Aschner", "breeder_location": "Brentwood, Pa.",
        "sire": "Bodo v Petersbach", "sire_registration_number": "605198",
        "dam": "Alma de la Ville de Bale", "dam_registration_number": "605199",
        "source": meta_c3
    }
]

all_31_01 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1931-01 dogs: {len(all_31_01)}")
print(f"  Leaf 42 Col 1: {len(c1_dogs)}")
print(f"  Leaf 42 Col 2: {len(c2_dogs)}")
print(f"  Leaf 42 Col 3: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1931_01.json").write_text(json.dumps(all_31_01, indent=2), encoding="utf-8")
print("Saved verified 1931-01 records.")
