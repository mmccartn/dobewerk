import json
from pathlib import Path

meta_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-02-01_48_2", "date": "1931-02-01", "volume": "48", "issue": "2", "leaf": 50, "column": 1}
meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-02-01_48_2", "date": "1931-02-01", "volume": "48", "issue": "2", "leaf": 50, "column": 2}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-02-01_48_2", "date": "1931-02-01", "volume": "48", "issue": "2", "leaf": 50, "column": 3}

# Leaf 50, Column 1 bottom (Starts under PINSCHERS (Doberman) - 4 dogs)
c1_dogs = [
    {
        "name": "ALFREDA V ELLA-SMITH", "sex": "Female", "registration_number": "768437",
        "birth_date": "Sept. 5, 1930", "color": "Blk & tn",
        "owner": "Ella B. Smith", "owner_location": "Lebanon, Ind.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Ceralvo Fra Duncan", "sire_registration_number": "589274",
        "dam": "Tooky of Kentucky", "dam_registration_number": "625717",
        "source": meta_c1
    },
    {
        "name": "ARNOLD V MENUCHA", "sex": "Male", "registration_number": "766262",
        "birth_date": "Nov. 6, 1929", "color": "Blk & br",
        "owner": "H. C. Ryman", "owner_location": None,
        "breeder": "J. L. Meier", "breeder_location": "Portland, Ore.",
        "sire": "Amor Koessler", "sire_registration_number": "737978",
        "dam": "Lady Blue", "dam_registration_number": "473055",
        "source": meta_c1
    },
    {
        "name": "AUG OF OXBO", "sex": "Male", "registration_number": "766894",
        "birth_date": "Aug. 21, 1930", "color": "Blk & tn",
        "owner": "F. C. Fuqua", "owner_location": "Seattle, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Ari v d Blankenburg", "sire_registration_number": "730206",
        "dam": "Peggy of Mickburn", "dam_registration_number": "544118",
        "source": meta_c1
    },
    {
        "name": "BELLA V D SPREE", "sex": "Female", "registration_number": "768337",
        "birth_date": "Sept. 2, 1926", "color": "Blk & tn",
        "owner": "Oscar G. Bauman", "owner_location": None,
        "breeder": "H. S. Forgrave", "breeder_location": "St. Joseph, Mo.",
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Lotta v Hecke", "dam_registration_number": "286952",
        "source": meta_c1
    }
]

# Leaf 50, Column 2 (21 dogs)
c2_dogs = [
    {
        "name": "BENNO V FALKENTURM", "sex": "Male", "registration_number": "765005",
        "birth_date": "June 8, 1929", "color": "Blk & rust",
        "owner": "Adolph F. Widmer", "owner_location": None,
        "breeder": "Leslie L. Romine", "breeder_location": "Livingston, N. J.",
        "sire": "Max De Haven", "sire_registration_number": "604075",
        "dam": "Sonia v Falkenturm", "dam_registration_number": "637639",
        "source": meta_c2
    },
    {
        "name": "BERRY'S ROTE KOENIGIN", "sex": "Female", "registration_number": "764478",
        "birth_date": "Mar. 17, 1929", "color": "Rd & tn",
        "owner": "C. T. Berry", "owner_location": None,
        "breeder": "Harold E. Stickel", "breeder_location": "West Milton, Ohio",
        "sire": "Duke v d Jeannettesburg", "sire_registration_number": "722282",
        "dam": "Jacqueline of Spring View", "dam_registration_number": "715109",
        "source": meta_c2
    },
    {
        "name": "BIG BOY II", "sex": "Male", "registration_number": "765561",
        "birth_date": "Apr. 7, 1926", "color": "Blk & mhgy",
        "owner": "Louis B. Handy", "owner_location": None,
        "breeder": "Charles C. Langille", "breeder_location": "Marshfield, Mass.",
        "sire": "Nero v Telless", "sire_registration_number": "412981",
        "dam": "Leddi v Telless", "dam_registration_number": "435137",
        "source": meta_c2
    },
    {
        "name": "BLANKA V DUBLA", "sex": "Female", "registration_number": "767705",
        "birth_date": "July 27, 1930", "color": "Blk & rust rd",
        "owner": "Paul B. Wallace", "owner_location": "Buchanan, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Baroness Dubla v d Hoehen", "dam_registration_number": "619318",
        "source": meta_c2
    },
    {
        "name": "CITTA", "sex": "Female", "registration_number": "768152",
        "birth_date": "Nov. 11, 1929", "color": "Blk, rd mkgs",
        "owner": "Henry Bieberson, Jr.", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Astor Gottschalk", "sire_registration_number": "639147",
        "dam": "Anita v Grossmannstein", "dam_registration_number": "605203",
        "source": meta_c2
    },
    {
        "name": "DINA V REYNO", "sex": "Female", "registration_number": "767910",
        "birth_date": "Oct. 6, 1928", "color": "Blk & rd",
        "owner": "M. V. Reynolds", "owner_location": None,
        "breeder": "Chas. J. Nassburg", "breeder_location": "Detroit, Mich.",
        "sire": "Astor of Nordett Farms", "sire_registration_number": "514904",
        "dam": "Anita of Belberg", "dam_registration_number": "571084",
        "source": meta_c2
    },
    {
        "name": "DOBIE OF LINVILLA", "sex": "Female", "registration_number": "767953",
        "birth_date": "May 13, 1929", "color": "Rd & rust br",
        "owner": "Arthur S. Linvill", "owner_location": None,
        "breeder": "E. De L. Fouque", "breeder_location": "Media, Pa.",
        "sire": "Red Roof Rufus", "sire_registration_number": "491422",
        "dam": "Babette v Jagerhof", "dam_registration_number": "521089",
        "source": meta_c2
    },
    {
        "name": "DUKE ARTUS V GRAMMONT", "sex": "Male", "registration_number": "766529",
        "birth_date": "July 27, 1930", "color": "Blk & rust red",
        "owner": "J. H. Patterson", "owner_location": None,
        "breeder": "Paul B. Wallace", "breeder_location": "Buchanan, Mich.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Baroness Dubla v d Hoehen", "dam_registration_number": "619318",
        "source": meta_c2
    },
    {
        "name": "DUKE V FOUTS", "sex": "Male", "registration_number": "768286",
        "birth_date": "Jan. 30, 1929", "color": "Blk & tn",
        "owner": "Charlie Fouts", "owner_location": None,
        "breeder": "M. A. Boylan", "breeder_location": "Omaha, Nebr.",
        "sire": "Mi-Bo v Boylan", "sire_registration_number": "734506",
        "dam": "Lue v Wiedensahl", "dam_registration_number": "743218",
        "source": meta_c2
    },
    {
        "name": "ELMCROFT KING NIKO II", "sex": "Male", "registration_number": "767416",
        "birth_date": "Aug. 21, 1928", "color": "Blk & tn",
        "owner": "McClellan Whipkey", "owner_location": None,
        "breeder": "R. Ray McLaughlin", "breeder_location": "Canada",
        "sire": "Alamo of Arkeden", "sire_registration_number": "465166",
        "dam": "Elmcroft Neta", "dam_registration_number": "465935",
        "source": meta_c2
    },
    {
        "name": "FOXHALLS PRINCE ALPHONSE", "sex": "Male", "registration_number": "767733",
        "birth_date": "March 26, 1930", "color": "Blk & tn",
        "owner": "C. W. Haight", "owner_location": None,
        "breeder": "Miss M. E. Fox", "breeder_location": "Canada",
        "sire": "Ralf v Havelberg", "sire_registration_number": None,
        "dam": "Nora v Hutten", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Vivadora Blitz Nibel-Hort", "registration_number": "522160"},
            {"role": "dam_of_dam", "name": "Helga", "registration_number": "532012"},
            {"role": "sire_of_sire", "name": "Arko v d Ritterhorst", "registration_number": "378379"},
            {"role": "dam_of_sire", "name": "Asta v Havelberg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Burschel v Simmenau", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Asta v Oststern", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "FRANZ OF DAWN", "sex": "Male", "registration_number": "767071",
        "birth_date": "Mar. 31, 1930", "color": "Blk & tn",
        "owner": "Henry S. Rademacher", "owner_location": None,
        "breeder": "Kettle Cove Kennels", "breeder_location": "Magnolia, Mass.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Lotte v Berghofen", "dam_registration_number": "695157",
        "source": meta_c2
    },
    {
        "name": "FRAULEIN HINDER", "sex": "Female", "registration_number": "767911",
        "birth_date": "July 18, 1926", "color": "Blk & tn",
        "owner": "Seeley N. Levy", "owner_location": None,
        "breeder": "Perry Kennels", "breeder_location": "Erie, Pa.",
        "sire": "Perry's Hasso v Saint Sebald", "sire_registration_number": "546165",
        "dam": "Guda v Telless", "dam_registration_number": "319376",
        "source": meta_c2
    },
    {
        "name": "FRITZ V JAEGERHOF", "sex": "Male", "registration_number": "766518",
        "birth_date": "July 7, 1930", "color": "Blk, rd rust mkgs",
        "owner": "O. B. Craig", "owner_location": None,
        "breeder": "R. L. Ward", "breeder_location": "Batavia, Iowa",
        "sire": "Fritz of Mickburn", "sire_registration_number": "753360",
        "dam": "Jil v Jaegerhof", "dam_registration_number": "703280",
        "source": meta_c2
    },
    {
        "name": "FRITZ JEAN ANNE", "sex": "Male", "registration_number": "766449",
        "birth_date": "July 27, 1930", "color": "Blk & tn",
        "owner": "M. E. Wilson", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Hathor Fra Duncan", "dam_registration_number": "743870",
        "source": meta_c2
    },
    {
        "name": "FRITZ V ZEPPELIN", "sex": "Male", "registration_number": "765306",
        "birth_date": "May 18, 1930", "color": "Blk & tn",
        "owner": "Mrs. Loretta Knickerbocker", "owner_location": None,
        "breeder": "Don Curley", "breeder_location": "San Mateo, Calif.",
        "sire": "Byng v Blankenburg", "sire_registration_number": "699348",
        "dam": "Jewell v Bofferding", "dam_registration_number": "461839",
        "source": meta_c2
    },
    {
        "name": "GRAF V WALDESRUH", "sex": "Male", "registration_number": "766811",
        "birth_date": "Nov. 19, 1929", "color": "Blk & tn",
        "owner": "F. W. Randolph", "owner_location": None,
        "breeder": "Joseph Hodina", "breeder_location": "Lyons, Ill.",
        "sire": "Fritz v Duffield", "sire_registration_number": "704573",
        "dam": "Queen Dutch", "dam_registration_number": "605234",
        "source": meta_c2
    },
    {
        "name": "GRETA OF REVEILLE", "sex": "Female", "registration_number": "765670",
        "birth_date": "July 18, 1929", "color": "Blk, tn mkgs",
        "owner": "Arthur James", "owner_location": None,
        "breeder": "Helen Krecker", "breeder_location": "Stonehurst, Pa.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Schatze v Horstburg", "dam_registration_number": "689932",
        "source": meta_c2
    },
    {
        "name": "GRETCHEN V D NIBELUNGENHORT II", "sex": "Female", "registration_number": "767033",
        "birth_date": "Dec. 5, 1928", "color": "Blk & tn",
        "owner": "Ned W. Town", "owner_location": None,
        "breeder": "J. F. Webb", "breeder_location": "Wenatchee, Wash.",
        "sire": "Count Monte v Nibelungenhort", "sire_registration_number": "379730",
        "dam": "Edna v Geholz", "dam_registration_number": "382664",
        "source": meta_c2
    },
    {
        "name": "HEDDA V LUXENBURG", "sex": "Female", "registration_number": "766178",
        "birth_date": "May 24, 1930", "color": "Rd & rust",
        "owner": "W. P. Overman", "owner_location": None,
        "breeder": "Geo. H. Jones", "breeder_location": "Danville, Ill.",
        "sire": "Prince Claus of Pontchartrain", "sire_registration_number": "710286",
        "dam": "Citti v Wilbrink", "dam_registration_number": "601009",
        "source": meta_c2
    },
    {
        "name": "ILMO V D WINTERBURG", "sex": "Male", "registration_number": "766373",
        "birth_date": "June 6, 1927", "color": "Blk rd",
        "owner": "Ross Cunningham", "owner_location": None,
        "breeder": "Karl Winter", "breeder_location": "Germany",
        "sire": "Jolly v d Minneburg", "sire_registration_number": None,
        "dam": "Ferri v d Winterburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Benno v d Roemerhof", "registration_number": "517073"},
            {"role": "dam_of_dam", "name": "Lotte v Brennetsried", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Waldo Gluck Auf Penzberg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Freya Kadletz", "registration_number": None},
            {"role": "sire_of_sire", "name": "Ari v Sigalsburg", "registration_number": "517070"},
            {"role": "dam_of_sire", "name": "Birke v Vortrupp", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Diethelm v Hindendorff", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Blute Hoch Wart", "registration_number": None}
        ],
        "source": meta_c2
    }
]

# Leaf 50, Column 3 (18 dogs down to PINSCHERS (Miniature))
c3_dogs = [
    {
        "name": "KINKA V BADER", "sex": "Female", "registration_number": "767070",
        "birth_date": "May 5, 1930", "color": "Blk & tn",
        "owner": "H. R. Bader", "owner_location": None,
        "breeder": "W. S. Bader", "breeder_location": "Arlington, N. J.",
        "sire": "Alex v Polzei", "sire_registration_number": "494371",
        "dam": "Kinka v Schmidt", "dam_registration_number": "645634",
        "source": meta_c3
    },
    {
        "name": "LADY BEBE REWIK", "sex": "Female", "registration_number": "768311",
        "birth_date": "Aug. 14, 1928", "color": "Blk & tn",
        "owner": "Rosa H. Kemble", "owner_location": None,
        "breeder": "H. B. Smith", "breeder_location": "Tulsa, Okla.",
        "sire": "Sortee v d Blankenspree", "sire_registration_number": "669319",
        "dam": "Falko v d Blankenspree", "dam_registration_number": "669318",
        "source": meta_c3
    },
    {
        "name": "LONA V BADER", "sex": "Female", "registration_number": "767069",
        "birth_date": "May 5, 1930", "color": "Blk & tn",
        "owner": "Edward Koerner", "owner_location": None,
        "breeder": "W. S. Bader", "breeder_location": "Arlington, N. J.",
        "sire": "Alex v Polzei", "sire_registration_number": "494371",
        "dam": "Kinka v Schmidt", "dam_registration_number": "645634",
        "source": meta_c3
    },
    {
        "name": "LOTTE V STRELSOW", "sex": "Female", "registration_number": "766548",
        "birth_date": "March 22, 1927", "color": "Blk & rd",
        "owner": "Howard K. Mohr", "owner_location": None,
        "breeder": "Germany", "breeder_location": "Germany",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Lotte v Stresow", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Bodo v Siegerpark", "registration_number": None},
            {"role": "dam_of_dam", "name": "Blanka v Stresow", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Prinz Modern v Ilm Athen", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Edda v Scharfenstein", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Horst v d Krahenhohe", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Adda v d Krahenhohe", "registration_number": None}
        ],
        "source": meta_c3
    },
    {
        "name": "MAJOR FORSBERG", "sex": "Male", "registration_number": "766374",
        "birth_date": "Aug. 12, 1930", "color": "Blk & tn",
        "owner": "F. A. Tripp", "owner_location": None,
        "breeder": "Hjalmar G. Forsberg", "breeder_location": "Chicago, Ill.",
        "sire": "Lindy v Forsberg", "sire_registration_number": "670607",
        "dam": "Mitzie v Hoffeld", "dam_registration_number": "633805",
        "source": meta_c3
    },
    {
        "name": "MARS V SIMMENAU", "sex": "Male", "registration_number": "766282",
        "birth_date": "Sept. 22, 1927", "color": "Blk rd",
        "owner": "Ben H. Wilson", "owner_location": None,
        "breeder": "Carl Winkler", "breeder_location": "Germany",
        "sire": "Alto v Sigalsburg", "sire_registration_number": None,
        "dam": "Lotte v Roneckenstein", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_dam", "name": "Dora v Wiesengrund", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Lea v Weissenfels", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Achim v Langerode", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Leddy v d Blankenburg", "registration_number": None},
            {"role": "sire_of_sire", "name": "Lux v d Blankenburg", "registration_number": "571492"},
            {"role": "dam_of_sire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_c3
    },
    {
        "name": "MATHA OF WALLACE HOF", "sex": "Female", "registration_number": "767706",
        "birth_date": "July 27, 1930", "color": "Blk & rust rd",
        "owner": "Paul B. Wallace", "owner_location": "Buchanan, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Baroness Dubla v d Hoehen", "dam_registration_number": "619318",
        "source": meta_c3
    },
    {
        "name": "MIA V SCHAFFENHOF", "sex": "Female", "registration_number": "767073",
        "birth_date": "May 2, 1928", "color": "Blk & tn",
        "owner": "Frank M. Scaggs", "owner_location": None,
        "breeder": "Leo P. Debes", "breeder_location": "Wichita, Kans.",
        "sire": "Randie", "sire_registration_number": "705856",
        "dam": "Fritzie v d Schaffen", "dam_registration_number": "605206",
        "source": meta_c3
    },
    {
        "name": "MITZI DEE V POPP", "sex": "Female", "registration_number": "767072",
        "birth_date": "Nov. 11, 1928", "color": "Blk, tn mkgs",
        "owner": "Thomas W. Davies", "owner_location": None,
        "breeder": "T. E. Popp", "breeder_location": "West Allis, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dortell v Popp", "dam_registration_number": "526001",
        "source": meta_c3
    },
    {
        "name": "MITZI V D HOEHEN", "sex": "Female", "registration_number": "765355",
        "birth_date": "Oct. 2, 1928", "color": "Blk & tn",
        "owner": "John L. Gerber", "owner_location": None,
        "breeder": "Mrs. M. von Hoegen", "breeder_location": "Towaco, N. J.",
        "sire": "Max De Haven", "sire_registration_number": "604075",
        "dam": "Coryl v Avonthal", "dam_registration_number": "506373",
        "source": meta_c3
    },
    {
        "name": "MODERNE V SIMMENAU", "sex": "Female", "registration_number": "768285",
        "birth_date": "Sept. 22, 1927", "color": "Blk rd",
        "owner": "Ben H. Wilson", "owner_location": None,
        "breeder": "Carl Winkler", "breeder_location": "Germany",
        "sire": "Alto v Sigalsburg", "sire_registration_number": None,
        "dam": "Lotte v Roneckenstein", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_dam", "name": "Dora v Wiesengrund", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Lea v Weissenfels", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Achim v Langerode", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Leddy v d Blankenburg", "registration_number": None},
            {"role": "sire_of_sire", "name": "Lux v d Blankenburg", "registration_number": "571492"},
            {"role": "dam_of_sire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_c3
    },
    {
        "name": "MOOSE V NIBELUNGENHORT", "sex": "Male", "registration_number": "767417",
        "birth_date": "Sept. 30, 1928", "color": "Blk & tn",
        "owner": "McClellan Whipkey", "owner_location": None,
        "breeder": "Mrs. A. M. Morrell", "breeder_location": "Canada",
        "sire": "Saint Croix Duke", "sire_registration_number": None,
        "dam": "Saint Croix Flash", "dam_registration_number": None,
        "source": meta_c3
    },
    {
        "name": "NETTIE OF PONTCHARTRAIN", "sex": "Female", "registration_number": "767074",
        "birth_date": "July 5, 1929", "color": "Blk, rd mkgs",
        "owner": "W. M. Karrh", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Anita of Pontchartrain", "dam_registration_number": "658425",
        "source": meta_c3
    },
    {
        "name": "NOLAN'S PATTY V HORSTBURG", "sex": "Female", "registration_number": "764835",
        "birth_date": "Oct. 10, 1929", "color": "Rd, rust mkgs",
        "owner": "Walter Nolan", "owner_location": None,
        "breeder": "Frank X. Simon", "breeder_location": "Philadelphia, Pa.",
        "sire": "Riff Rudolph v Horstburg", "sire_registration_number": "665178",
        "dam": "Lady Kwik", "dam_registration_number": "707649",
        "source": meta_c3
    },
    {
        "name": "OCHSNER'S CLAUS", "sex": "Male", "registration_number": "765955",
        "birth_date": "June 25, 1930", "color": "Blk & tn",
        "owner": "Dr. S. E. Ochsner", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Robinson's Princess", "dam_registration_number": "644053",
        "source": meta_c3
    },
    {
        "name": "OCHSNER'S FREIA", "sex": "Female", "registration_number": "765956",
        "birth_date": "June 25, 1930", "color": "Blk & tn",
        "owner": "Dr. S. E. Ochsner", "owner_location": "Milwaukee, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Robinson's Princess", "dam_registration_number": "644053",
        "source": meta_c3
    },
    {
        "name": "OCHSNER'S FRIGGA", "sex": "Female", "registration_number": "765957",
        "birth_date": "May 13, 1930", "color": "Blk & tn",
        "owner": "Dr. S. E. Ochsner", "owner_location": "Milwaukee, Wis.",
        "breeder": "White Gate Kennels", "breeder_location": "Willow Grove, Pa.",
        "sire": "Koningstad Amerant of White Gate", "sire_registration_number": "495734",
        "dam": "Angola of White Gate", "dam_registration_number": "695418",
        "source": meta_c3
    },
    {
        "name": "PAULA V WALDHOF", "sex": "Female", "registration_number": "765356",
        "birth_date": "Dec. 14, 1928", "color": "Blk, rust mkgs",
        "owner": "Mrs. Maud E. Bushinger", "owner_location": None,
        "breeder": "Harry F. Smith", "breeder_location": "Springfield, Mass.",
        "sire": "Ritz Carlton", "sire_registration_number": "485720",
        "dam": "Paula Gretel", "dam_registration_number": "713077",
        "source": meta_c3
    },
    {
        "name": "PEACHES V D ROTTAL", "sex": "Female", "registration_number": "765954",
        "birth_date": "July 15, 1928", "color": "Blk & tn",
        "owner": "John B. O'Connor", "owner_location": None,
        "breeder": "Phil Hagerman", "breeder_location": "Chicago, Ill.",
        "sire": "Asko v Bolanden", "sire_registration_number": "432279",
        "dam": "Princess Bea v Silverberg", "dam_registration_number": "403875",
        "source": meta_c3
    }
]

all_31_02 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1931-02 dogs: {len(all_31_02)}")
print(f"  Leaf 50 Col 1: {len(c1_dogs)}")
print(f"  Leaf 50 Col 2: {len(c2_dogs)}")
print(f"  Leaf 50 Col 3: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1931_02.json").write_text(json.dumps(all_31_02, indent=2), encoding="utf-8")
print("Saved verified 1931-02 records.")
