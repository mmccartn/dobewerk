import json
from pathlib import Path

meta_l38_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-03-01_48_3", "date": "1931-03-01", "volume": "48", "issue": "3", "leaf": 38, "column": 3}
meta_l39_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-03-01_48_3", "date": "1931-03-01", "volume": "48", "issue": "3", "leaf": 39, "column": 1}
meta_l39_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-03-01_48_3", "date": "1931-03-01", "volume": "48", "issue": "3", "leaf": 39, "column": 2}

# Leaf 38, Column 3 (Starts under PINSCHERS (Doberman) - 8 dogs)
c1_dogs = [
    {
        "name": "ARI OF FORT SUTTER", "sex": "Male", "registration_number": "770459",
        "birth_date": "Feb. 16, 1930", "color": "Blk & tn",
        "owner": "Lawrence J. Steinhardt", "owner_location": None,
        "breeder": "Frank Blattler", "breeder_location": "Berkeley, Calif.",
        "sire": "Emir Lentulus", "sire_registration_number": "714460",
        "dam": "Valuta v d Blankenburg", "dam_registration_number": "730071",
        "source": meta_l38_c3
    },
    {
        "name": "BEAU BARON V TORREZ", "sex": "Male", "registration_number": "769076",
        "birth_date": "Oct. 1, 1930", "color": "Blk & tn",
        "owner": "Mr. and Mrs. Edw. F. Koepke", "owner_location": None,
        "breeder": "Ernest C. Torrez", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Burga v Torrez", "dam_registration_number": "628206",
        "source": meta_l38_c3
    },
    {
        "name": "BEBE V TORREZ", "sex": "Female", "registration_number": "770997",
        "birth_date": "Oct. 1, 1930", "color": "Blk & tn",
        "owner": "Delia Drew King", "owner_location": None,
        "breeder": "Ernest C. Torrez", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Burga v Torrez", "dam_registration_number": "628206",
        "source": meta_l38_c3
    },
    {
        "name": "BERA V HOMEHILL", "sex": "Female", "registration_number": "771095",
        "birth_date": "June 16, 1928", "color": "Blk & tn",
        "owner": "Mrs. G. A. Rentschler", "owner_location": "Hamilton, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Lady v Homehill", "dam_registration_number": "565329",
        "source": meta_l38_c3
    },
    {
        "name": "BOOTS", "sex": "Male", "registration_number": "770698",
        "birth_date": "Sept. 2, 1930", "color": "Blk & tn",
        "owner": "Wm. C. Richardson", "owner_location": None,
        "breeder": "N. M. Freund", "breeder_location": "St. Louis, Mo.",
        "sire": "Artus v Lenburg", "sire_registration_number": "733269",
        "dam": "Peppy v Murchan", "dam_registration_number": "755498",
        "source": meta_l38_c3
    },
    {
        "name": "CLEA V STARKANHART", "sex": "Female", "registration_number": "769173",
        "birth_date": "Sept. 15, 1928", "color": "Blk & rd",
        "owner": "F. C. Bowles", "owner_location": "Hartville, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Rena v Starkanhart", "dam_registration_number": "607477",
        "source": meta_l38_c3
    },
    {
        "name": "DINGO", "sex": "Female", "registration_number": "769472",
        "birth_date": "Jan. 12, 1927", "color": "Blk, rust mkgs",
        "owner": "Hans Wienhold", "owner_location": None,
        "breeder": "G. F. Dechert", "breeder_location": "Rising City, Nebr.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Freda v Luschenhof", "dam_registration_number": "533879",
        "source": meta_l38_c3
    },
    {
        "name": "DUKE F", "sex": "Male", "registration_number": "771664",
        "birth_date": "Sept. 22, 1928", "color": "Chlte br & tn",
        "owner": "Joseph Haid", "owner_location": None,
        "breeder": "Fanny Cordero", "breeder_location": "Flushing, L. I., N. Y.",
        "sire": "Peter Pan of Leipzig", "sire_registration_number": "501109",
        "dam": "Ellis of Arkeden", "dam_registration_number": "601591",
        "source": meta_l38_c3
    }
]

# Leaf 39, Column 1 (22 dogs)
c2_dogs = [
    {
        "name": "FELIX V HORWEEN EISENDRATH", "sex": "Male", "registration_number": "771583",
        "birth_date": "May 26, 1930", "color": "Blk & tn",
        "owner": "William N. Eisendrath, Jr.", "owner_location": None,
        "breeder": "E. J. Carthey", "breeder_location": "Davenport, Iowa",
        "sire": "Lindy v Forsberg", "sire_registration_number": "670607",
        "dam": "Lady Sigalsburg", "dam_registration_number": "658780",
        "source": meta_l39_c1
    },
    {
        "name": "FERRY V D BARBAROSSAHOHLE", "sex": "Male", "registration_number": "769803",
        "birth_date": "Sept. 3, 1928", "color": "Blk rd",
        "owner": "Theodore Kleinmanns", "owner_location": None,
        "breeder": "Gustave Bodewig", "breeder_location": "Germany",
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Dilly v Stolzenberg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Troll v d Blankenburg", "registration_number": "553218"},
            {"role": "dam_of_dam", "name": "Lotte v Simmenau", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Alex v Simmenau", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Gudrun v Hornegg", "registration_number": None}
        ],
        "source": meta_l39_c1
    },
    {
        "name": "FRANCO FRA DUNCAN", "sex": "Male", "registration_number": "770190",
        "birth_date": "July 5, 1928", "color": "Blk & tn",
        "owner": "C. A. Duncan", "owner_location": None,
        "breeder": "H. L. Foran", "breeder_location": "Grand Island, Nebr.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Frieda The Great", "dam_registration_number": "666262",
        "source": meta_l39_c1
    },
    {
        "name": "FREDA V DUFFIELD P", "sex": "Female", "registration_number": "769279",
        "birth_date": "Dec. 5, 1929", "color": "Blk & tn",
        "owner": "Frank Pechousek", "owner_location": None,
        "breeder": "Jerry Schnabl", "breeder_location": "Riverside, Ill.",
        "sire": "Fritz v Duffield", "sire_registration_number": "704573",
        "dam": "Freda from Duffield", "dam_registration_number": "608113",
        "source": meta_l39_c1
    },
    {
        "name": "FREIDA V ROGERSCHMIDT", "sex": "Female", "registration_number": "769460",
        "birth_date": "July 22, 1930", "color": "Blk, tn mkgs",
        "owner": "Rogerschmidt Kennels", "owner_location": "Bloomingburg, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Princess Flora of Pontchartrain", "dam_registration_number": "710290",
        "source": meta_l39_c1
    },
    {
        "name": "GRAF ZEPPELIN", "sex": "Male", "registration_number": "770097",
        "birth_date": "Oct. 6, 1930", "color": "Blk & tn",
        "owner": "Conrad Wacker", "owner_location": None,
        "breeder": "Hermann Wohlgemuth", "breeder_location": "Philadelphia, Pa.",
        "sire": "Otto v Parthengrund", "sire_registration_number": "663925",
        "dam": "Hulda v d Winterburg", "dam_registration_number": "668994",
        "source": meta_l39_c1
    },
    {
        "name": "GRETA V ROGERSCHMIDT", "sex": "Female", "registration_number": "769462",
        "birth_date": "July 22, 1930", "color": "Blk, tn mkgs",
        "owner": "Rogerschmidt Kennels", "owner_location": "Bloomingburg, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Princess Flora of Pontchartrain", "dam_registration_number": "710290",
        "source": meta_l39_c1
    },
    {
        "name": "GRETCHEN V BLANKENBURG", "sex": "Female", "registration_number": "771800",
        "birth_date": "Oct. 4, 1930", "color": "Rd & tn",
        "owner": "Mrs. F. Bergschicker and Miss E. Schmidt", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "Cupertino, Calif.",
        "sire": "Burschel v Falkensee", "sire_registration_number": "553217",
        "dam": "Bona v Deckersburg", "dam_registration_number": "553222",
        "source": meta_l39_c1
    },
    {
        "name": "GRETTA V PERBOCK", "sex": "Female", "registration_number": "770965",
        "birth_date": "Apr. 26, 1930", "color": "Blk, mhgy mkgs",
        "owner": "Sam W. B. Colin", "owner_location": None,
        "breeder": "Margaret E. Bock", "breeder_location": "Santa Barbara, Calif.",
        "sire": "Duke v Strossen", "sire_registration_number": "500005",
        "dam": "Asta v Tilhagen", "dam_registration_number": "530158",
        "source": meta_l39_c1
    },
    {
        "name": "HAPPY BOY", "sex": "Male", "registration_number": "770857",
        "birth_date": "Sept. 3, 1926", "color": "Chlte & tn",
        "owner": "H. J. Westendorf", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Dot v Christman", "dam_registration_number": "460743",
        "source": meta_l39_c1
    },
    {
        "name": "HOPE OF RURITANIA", "sex": "Female", "registration_number": "768959",
        "birth_date": "Nov. 15, 1930", "color": "Br & tn",
        "owner": "Nicholas Lovece", "owner_location": "Brooklyn, N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Uriana v Waldeck", "dam_registration_number": "702562",
        "source": meta_l39_c1
    },
    {
        "name": "ILKA BURGHALDT", "sex": "Female", "registration_number": "769663",
        "birth_date": "Aug. 23, 1930", "color": "Blk & tn",
        "owner": "William N. Schreier", "owner_location": None,
        "breeder": "C. E. Sexton, Jr.", "breeder_location": "Randolph, Iowa",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Betty v Popp", "dam_registration_number": "702787",
        "source": meta_l39_c1
    },
    {
        "name": "KESSLER'S HANSEL", "sex": "Male", "registration_number": "769503",
        "birth_date": "Sept. 21, 1929", "color": "Br, tn mkgs",
        "owner": "Pauline Shumack Kessler", "owner_location": None,
        "breeder": "Nick Geiser", "breeder_location": "Norwood, Ohio",
        "sire": "Cito v d Margaretanau", "sire_registration_number": "685406",
        "dam": "Ancola of Bornholm", "dam_registration_number": "652237",
        "source": meta_l39_c1
    },
    {
        "name": "LADY LEE V SIGALSBURG", "sex": "Female", "registration_number": "770828",
        "birth_date": "Sept. 18, 1930", "color": "Blk & tn",
        "owner": "Harry Foster", "owner_location": None,
        "breeder": "Mrs. Elmer Schweninger", "breeder_location": "Cincinnati, Ohio",
        "sire": "Toro v Hortsburg", "sire_registration_number": "696927",
        "dam": "Trudie v Sigalsburg", "dam_registration_number": "765607",
        "source": meta_l39_c1
    },
    {
        "name": "MAJOR V GROSSMOUNT", "sex": "Male", "registration_number": "771441",
        "birth_date": "May 24, 1930", "color": "Rd & rust",
        "owner": "G. C. Jaco", "owner_location": None,
        "breeder": "Geo. H. Jones", "breeder_location": "Danville, Ill.",
        "sire": "Prince Claus of Pontchartrain", "sire_registration_number": "710286",
        "dam": "Citti v Wilbrink", "dam_registration_number": "601009",
        "source": meta_l39_c1
    },
    {
        "name": "MARKO V HATZENBURG", "sex": "Male", "registration_number": "770827",
        "birth_date": "Oct. 27, 1930", "color": "Blk, rust mkgs",
        "owner": "A. W. Hatfield", "owner_location": None,
        "breeder": "G. W. Hatfield, Jr.", "breeder_location": "Williamson, W. Va.",
        "sire": "Marko v Siegerpark", "sire_registration_number": "601008",
        "dam": "Prinzess Fidelia v Burgholz", "dam_registration_number": "735298",
        "source": meta_l39_c1
    },
    {
        "name": "MITZIE V D SIGALSBURG", "sex": "Female", "registration_number": "771119",
        "birth_date": "Feb. 16, 1930", "color": "Br & tn",
        "owner": "Frederick O. Betz", "owner_location": None,
        "breeder": "E. E. Carrier", "breeder_location": "Summerville, Pa.",
        "sire": "Hans v Dombachtal", "sire_registration_number": "606668",
        "dam": "Brunhilde v Sigalsburg", "dam_registration_number": "667532",
        "source": meta_l39_c1
    },
    {
        "name": "NAVIGATOR OF PONTCHARTRAIN", "sex": "Male", "registration_number": "768988",
        "birth_date": "May 24, 1930", "color": "Blk rd",
        "owner": "Geo. A. Taylor", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Ilisa of Pontchartrain", "dam_registration_number": "571491",
        "source": meta_l39_c1
    },
    {
        "name": "PRINCE RUDOLF OF RURITANIA", "sex": "Male", "registration_number": "768956",
        "birth_date": "Nov. 15, 1930", "color": "Br & tn",
        "owner": "Nicholas Lovece", "owner_location": "Brooklyn, N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Uriana v Waldeck", "dam_registration_number": "702562",
        "source": meta_l39_c1
    },
    {
        "name": "PRINCESS FLAVIA OF RURITANIA", "sex": "Female", "registration_number": "768958",
        "birth_date": "Nov. 15, 1930", "color": "Br & tn",
        "owner": "Nicholas Lovece", "owner_location": "Brooklyn, N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Uriana v Waldeck", "dam_registration_number": "702562",
        "source": meta_l39_c1
    },
    {
        "name": "PRINCESS OF RURITANIA", "sex": "Female", "registration_number": "768960",
        "birth_date": "Nov. 15, 1930", "color": "Br & tn",
        "owner": "Nicholas Lovece", "owner_location": "Brooklyn, N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Uriana v Waldeck", "dam_registration_number": "702562",
        "source": meta_l39_c1
    },
    {
        "name": "PRINZ V ROGERSCHMIDT", "sex": "Male", "registration_number": "769463",
        "birth_date": "July 22, 1930", "color": "Blk, tn mkgs",
        "owner": "Rogerschmidt Kennels", "owner_location": "Bloomingburg, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Princess Flora of Pontchartrain", "dam_registration_number": "710290",
        "source": meta_l39_c1
    }
]

# Leaf 39, Column 2 (17 dogs down to PINSCHERS (Miniature))
c3_dogs = [
    {
        "name": "PUNSCH V GROSSMOUNT", "sex": "Male", "registration_number": "770996",
        "birth_date": "July 22, 1930", "color": "Blk & rd",
        "owner": "Frank O. King", "owner_location": None,
        "breeder": "G. C. Jaco", "breeder_location": "Uniontown, Pa.",
        "sire": "Peter v Roemerhof", "sire_registration_number": "616494",
        "dam": "Nada v Grossmount", "dam_registration_number": "737077",
        "source": meta_l39_c2
    },
    {
        "name": "RAPPO OF TOPPO", "sex": "Male", "registration_number": "769775",
        "birth_date": "May 30, 1930", "color": "Blk & tn",
        "owner": "Harry Dunn", "owner_location": None,
        "breeder": "Dorothy Bolce", "breeder_location": "Mt. Healthy, Ohio",
        "sire": "Toppo v Sigalsburg", "sire_registration_number": "670191",
        "dam": "Gretel v Horstburg", "dam_registration_number": "670190",
        "source": meta_l39_c2
    },
    {
        "name": "RED RIVAL VAN SCHOICK", "sex": "Male", "registration_number": "772026",
        "birth_date": "Mar. 20, 1930", "color": "Rd & tn",
        "owner": "W. C. Whitthorne", "owner_location": None,
        "breeder": "Pearle M. Wilson", "breeder_location": "Nashville, Tenn.",
        "sire": "Ochsner's Son of Rival", "sire_registration_number": "612378",
        "dam": "Nanette of Jonedith", "dam_registration_number": "549148",
        "source": meta_l39_c2
    },
    {
        "name": "ROGERSCHMIDT'S FAVORIT", "sex": "Male", "registration_number": "769464",
        "birth_date": "July 22, 1930", "color": "Blk, tn mkgs",
        "owner": "Rogerschmidt Kennels", "owner_location": "Bloomingburg, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Princess Flora of Pontchartrain", "dam_registration_number": "710290",
        "source": meta_l39_c2
    },
    {
        "name": "ROGERSCHMIDT'S LADY FAVORIT", "sex": "Female", "registration_number": "769459",
        "birth_date": "July 22, 1930", "color": "Blk, tn mkgs",
        "owner": "Rogerschmidt Kennels", "owner_location": "Bloomingburg, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Princess Flora of Pontchartrain", "dam_registration_number": "710290",
        "source": meta_l39_c2
    },
    {
        "name": "ROGERSCHMIDT'S MITZI", "sex": "Female", "registration_number": "769461",
        "birth_date": "July 22, 1930", "color": "Blk, tn mkgs",
        "owner": "Rogerschmidt Kennels", "owner_location": "Bloomingburg, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Princess Flora of Pontchartrain", "dam_registration_number": "710290",
        "source": meta_l39_c2
    },
    {
        "name": "ROLF V LEUTHOBELLE", "sex": "Male", "registration_number": "771842",
        "birth_date": "Dec. 20, 1929", "color": "Blk, br mkgs",
        "owner": "Mary M. Alcorn", "owner_location": None,
        "breeder": "Walton G. Alcorn", "breeder_location": "Columbus, Ohio",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Hilda v Leuthobelle", "dam_registration_number": "699983",
        "source": meta_l39_c2
    },
    {
        "name": "RUDOLF ELPHBERG OF RURITANIA", "sex": "Male", "registration_number": "768957",
        "birth_date": "Nov. 15, 1930", "color": "Rd & tn",
        "owner": "Nicholas Lovece", "owner_location": "Brooklyn, N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Uriana v Waldeck", "dam_registration_number": "702562",
        "source": meta_l39_c2
    },
    {
        "name": "RUDOLF OF RURITANIA", "sex": "Male", "registration_number": "768955",
        "birth_date": "Nov. 15, 1930", "color": "Br & tn",
        "owner": "Nicholas Lovece", "owner_location": "Brooklyn, N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Uriana Waldeck", "dam_registration_number": "702562",
        "source": meta_l39_c2
    },
    {
        "name": "SENOR DON", "sex": "Male", "registration_number": "769732",
        "birth_date": "May 10, 1928", "color": "Blk & tn",
        "owner": "Leonard G. Herman", "owner_location": None,
        "breeder": "O. K. Lindquist", "breeder_location": "Detroit, Mich.",
        "sire": "A Rappo of Pontchartrain", "sire_registration_number": "439031",
        "dam": "Kona Nibelungenhort", "dam_registration_number": "647954",
        "source": meta_l39_c2
    },
    {
        "name": "STRELSAU OF RURITANIA", "sex": "Male", "registration_number": "768954",
        "birth_date": "Nov. 15, 1930", "color": "Blk & tn",
        "owner": "Nicholas Lovece", "owner_location": "Brooklyn, N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Uriana v Waldeck", "dam_registration_number": "702562",
        "source": meta_l39_c2
    },
    {
        "name": "TELL V SCHLINGELHOF", "sex": "Male", "registration_number": "769278",
        "birth_date": "Dec. 5, 1929", "color": "Blk & tn",
        "owner": "Joseph Skorepa", "owner_location": None,
        "breeder": "Jerry Schnabl", "breeder_location": "Riverside, Ill.",
        "sire": "Fritz v Duffield", "sire_registration_number": "704573",
        "dam": "Freda from Duffield", "dam_registration_number": "608113",
        "source": meta_l39_c2
    },
    {
        "name": "TICKER", "sex": "Male", "registration_number": "771259",
        "birth_date": "July 24, 1930", "color": "Blk & rd",
        "owner": "Karl W. Haller", "owner_location": None,
        "breeder": "Edward K. Crosby", "breeder_location": "Wheeling, W. Va.",
        "sire": "Lex v Grossmount", "sire_registration_number": "730466",
        "dam": "Gaby of Pontchartrain", "dam_registration_number": "553020",
        "source": meta_l39_c2
    },
    {
        "name": "TOBIE V ROEMERHOF", "sex": "Female", "registration_number": "768763",
        "birth_date": "Sept. 14, 1930", "color": "Blk & tn",
        "owner": "Russell C. Taylor", "owner_location": None,
        "breeder": "F. B. Brewster", "breeder_location": "Palos Park, Ill.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Prinzess B. v Roemerhof", "dam_registration_number": "641312",
        "source": meta_l39_c2
    },
    {
        "name": "URIAN V D HOHEN", "sex": "Male", "registration_number": "771799",
        "birth_date": "Apr. 23, 1930", "color": "Blk, tn mkgs",
        "owner": "Philip Connors", "owner_location": None,
        "breeder": "Mrs. M. von Hoegen", "breeder_location": "Towaco, N. J.",
        "sire": "D'Artagnan v d Hohen", "sire_registration_number": "594257",
        "dam": "Ilisa v d Hohen", "dam_registration_number": "735502",
        "source": meta_l39_c2
    },
    {
        "name": "WARRIOR OF DAWN", "sex": "Male", "registration_number": "770345",
        "birth_date": "Feb. 27, 1930", "color": "Blk, rd",
        "owner": "Dorothy Boenicke", "owner_location": None,
        "breeder": "H. S. Newsom", "breeder_location": "Chicago, Ill.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Schatz v Ostersee", "dam_registration_number": "514975",
        "source": meta_l39_c2
    },
    {
        "name": "ZEV V DELACOURT", "sex": "Male", "registration_number": "770591",
        "birth_date": "Mar. 6, 1929", "color": "Blk & tn",
        "owner": "F. T. Hickcox", "owner_location": None,
        "breeder": "Mrs. B. Delacourt", "breeder_location": "Los Angeles, Calif.",
        "sire": "Troll Son v d Blankenburg", "sire_registration_number": "618743",
        "dam": "Reno v Strossen", "dam_registration_number": "664506",
        "source": meta_l39_c2
    },
    {
        "name": "ZITA V ZINGSHEIM", "sex": "Female", "registration_number": "771584",
        "birth_date": "Sept. 3, 1929", "color": "Blk & tn",
        "owner": "Mr. and Mrs. M. L. Zingsheim", "owner_location": "Chicago, Ill.",
        "breeder": "M. L. Zingsheim", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Betsy v Wilhelm", "dam_registration_number": "623310",
        "source": meta_l39_c2
    }
]

all_31_03 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1931-03 dogs: {len(all_31_03)}")
print(f"  Leaf 38 Col 3: {len(c1_dogs)}")
print(f"  Leaf 39 Col 1: {len(c2_dogs)}")
print(f"  Leaf 39 Col 2: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1931_03.json").write_text(json.dumps(all_31_03, indent=2), encoding="utf-8")
print("Saved verified 1931-03 records.")
