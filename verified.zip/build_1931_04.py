import json
from pathlib import Path

meta_l33_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-04-01_48_4", "date": "1931-04-01", "volume": "48", "issue": "4", "leaf": 33, "column": 2}
meta_l33_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-04-01_48_4", "date": "1931-04-01", "volume": "48", "issue": "4", "leaf": 33, "column": 3}
meta_l34_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-04-01_48_4", "date": "1931-04-01", "volume": "48", "issue": "4", "leaf": 34, "column": 1}

# Leaf 33, Column 2 bottom (4 dogs)
c1_dogs = [
    {
        "name": "ADONIS V DOMBACHTAL", "sex": "Male", "registration_number": "773505",
        "birth_date": "June 3, 1929", "color": "Blk & tn",
        "owner": "Joseph J. Murphy", "owner_location": None,
        "breeder": "Mrs. R. E. Byrd", "breeder_location": "Erie, Pa.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Dolly v Dombachtal of Perry", "dam_registration_number": "555513",
        "source": meta_l33_c2
    },
    {
        "name": "ALTO V SEDREVLA", "sex": "Male", "registration_number": "773904",
        "birth_date": "May 20, 1930", "color": "Blk & tn",
        "owner": "Miss Bessie Davidson", "owner_location": None,
        "breeder": "Karl P.'s Graeuwen", "breeder_location": "W. Caldwell, N. J.",
        "sire": "Otello of Pontchartrain", "sire_registration_number": "667919",
        "dam": "Fay v Sedrevla", "dam_registration_number": "695049",
        "source": meta_l33_c2
    },
    {
        "name": "AMIGO V PERBOCK", "sex": "Male", "registration_number": "773408",
        "birth_date": "Apr. 26, 1930", "color": "Blk, mhgy mkgs",
        "owner": "John J. Mitchell", "owner_location": None,
        "breeder": "Margaret E. Bock", "breeder_location": "Santa Barbara, Calif.",
        "sire": "Duke v Strossen", "sire_registration_number": "500005",
        "dam": "Asta v Tilhagen", "dam_registration_number": "530158",
        "source": meta_l33_c2
    },
    {
        "name": "AMOS COLLINGBOURNE", "sex": "Male", "registration_number": "773770",
        "birth_date": "July 24, 1929", "color": "Blk & tn",
        "owner": "A. B. Collingbourne", "owner_location": None,
        "breeder": "E. J. Robinson", "breeder_location": "Milwaukee, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Mia v Stresow", "dam_registration_number": "559952",
        "source": meta_l33_c2
    }
]

# Leaf 33, Column 3 (19 dogs)
c2_dogs = [
    {
        "name": "ARLO V D RONECKENSTEIN", "sex": "Male", "registration_number": "774442",
        "birth_date": "Aug. 21, 1930", "color": "Blk & tn",
        "owner": "Richard F. Graham", "owner_location": None,
        "breeder": "F. C. Fuqua", "breeder_location": "Seattle, Wash.",
        "sire": "Ari v d Blankenburg", "sire_registration_number": "730206",
        "dam": "Peggy of Mickburn", "dam_registration_number": "544118",
        "source": meta_l33_c3
    },
    {
        "name": "ASTA V D FRANKENHOHE", "sex": "Female", "registration_number": "773573",
        "birth_date": "June 10, 1927", "color": "Br & rd",
        "owner": "John M. Watson, Jr.", "owner_location": None,
        "breeder": "Karl Gross", "breeder_location": "Germany",
        "sire": "Hasso v d Lausitz", "sire_registration_number": None,
        "dam": "Carmen (gen. Citty) Edelhauser", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Billo v Dombachtal", "registration_number": None},
            {"role": "dam_of_dam", "name": "Gerda v Rufienenschlossl", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Wodan Gluck-Auf Penzberg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Flora v Maxfeld", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Dard v Hindendorff", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Alma v Waidachgrund", "registration_number": None},
            {"role": "sire_of_sire", "name": "Armin v Hagelsberg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Charlotte v d Lausitz", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Blitz v d Lausitz", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Bessy v Monchswald", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Salto v Rottal", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Beda Armingard v Nibelungenhort", "registration_number": None}
        ],
        "source": meta_l33_c3
    },
    {
        "name": "BERTOLD V SEIGRIST", "sex": "Male", "registration_number": "772306",
        "birth_date": "June 9, 1929", "color": "Rd, rd rust mkgs",
        "owner": "W. L. Lyons, Jr.", "owner_location": "Harrods Creek, Ky.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Centa v Rinkenbuehl", "dam_registration_number": "316606",
        "source": meta_l33_c3
    },
    {
        "name": "BIMBO V GROSSMOUNT", "sex": "Male", "registration_number": "774767",
        "birth_date": "July 22, 1930", "color": "Rd & rust",
        "owner": "R. B. Fleming", "owner_location": None,
        "breeder": "G. C. Jaco", "breeder_location": "Uniontown, Pa.",
        "sire": "Peter v Roemerhoff", "sire_registration_number": "616494",
        "dam": "Nada v Grossmount", "dam_registration_number": "737077",
        "source": meta_l33_c3
    },
    {
        "name": "BISMARK", "sex": "Male", "registration_number": "772305",
        "birth_date": "Sept. 22, 1929", "color": "Blk & tn",
        "owner": "Thos. Anderson", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Rowdy v d Kiningstadt", "sire_registration_number": "634465",
        "dam": "Gilda Fra Duncan", "dam_registration_number": "678513",
        "source": meta_l33_c3
    },
    {
        "name": "BOBBY TELLESS", "sex": "Female", "registration_number": "773057",
        "birth_date": "Apr. 14, 1928", "color": "Blk & tn",
        "owner": "J. F. Burks", "owner_location": None,
        "breeder": "Mrs. D. D. Critchlow", "breeder_location": "Oklahoma City, Okla.",
        "sire": "Kungs v Riga", "sire_registration_number": "492581",
        "dam": "Gretta v d Gracht", "dam_registration_number": "560749",
        "source": meta_l33_c3
    },
    {
        "name": "CAPITAN V EISENHARDT", "sex": "Male", "registration_number": "774300",
        "birth_date": "Apr. 30, 1930", "color": "Blk, tn mkgs",
        "owner": "Geo. H. Hacke", "owner_location": None,
        "breeder": "Mrs. J. Thompson White", "breeder_location": "Hickory, Pa.",
        "sire": "Sigmund v Eisenhardt", "sire_registration_number": "558774",
        "dam": "Reva from Akron", "dam_registration_number": "706961",
        "source": meta_l33_c3
    },
    {
        "name": "CIRO", "sex": "Male", "registration_number": "772820",
        "birth_date": "May 9, 1930", "color": "Blk, rust rd mkgs",
        "owner": "Edward Dobkin", "owner_location": None,
        "breeder": "W. H. Dillinger and J. T. Clements", "breeder_location": "Daytona Beach, Fla.",
        "sire": "Prince Max of Pontchartrain", "sire_registration_number": "745274",
        "dam": "Kickey Rinkenbuehl Burgholz", "dam_registration_number": "722281",
        "source": meta_l33_c3
    },
    {
        "name": "DARK LADY", "sex": "Female", "registration_number": "774484",
        "birth_date": "July 27, 1929", "color": "Blk & tn",
        "owner": "H. J. Westendorf", "owner_location": None,
        "breeder": "Sofie Froelich", "breeder_location": "Cincinnati, Ohio",
        "sire": "Cito v d Margaretanau", "sire_registration_number": "685406",
        "dam": "Angola v d Margaretanau", "dam_registration_number": "685402",
        "source": meta_l33_c3
    },
    {
        "name": "DIXIE MAID", "sex": "Female", "registration_number": "774830",
        "birth_date": "Nov. 6, 1928", "color": "Blk & rd tn",
        "owner": "H. J. Hemmerling", "owner_location": None,
        "breeder": "Ivan E. Clark", "breeder_location": "Concord, Nebr.",
        "sire": "Arko v Altendorf", "sire_registration_number": "662742",
        "dam": "Concord Peggy", "dam_registration_number": "661726",
        "source": meta_l33_c3
    },
    {
        "name": "DUKE LU II", "sex": "Male", "registration_number": "772730",
        "birth_date": "Jan. 1, 1930", "color": "Br & tn",
        "owner": "Luigi Di Scala", "owner_location": None,
        "breeder": "Gus Stoffels", "breeder_location": "Nutley, N. J.",
        "sire": "Yvon of Edjo", "sire_registration_number": "689593",
        "dam": "Rea of New Jersey", "dam_registration_number": "685584",
        "source": meta_l33_c3
    },
    {
        "name": "DUNKEL V OCHSNER", "sex": "Male", "registration_number": "774508",
        "birth_date": "Apr. 12, 1930", "color": "Blk, tn mkgs",
        "owner": "Mrs. David Terry Kimbrough, Jr.", "owner_location": None,
        "breeder": "Miles Williams", "breeder_location": "Nashville, Tenn.",
        "sire": "Ochsner's Son of Rival", "sire_registration_number": "612378",
        "dam": "Guda of Ballycoreagh", "dam_registration_number": "599126",
        "source": meta_l33_c3
    },
    {
        "name": "FITZBLU V CONEMEDIA", "sex": "Male", "registration_number": "775168",
        "birth_date": "Sept. 8, 1928", "color": "Bl & tn",
        "owner": "R. Blair Stewart", "owner_location": None,
        "breeder": "Dr. and Mrs. R. D. Coneley", "breeder_location": "Lima, Pa.",
        "sire": "Riff Rudolph v Horstburg", "sire_registration_number": "665178",
        "dam": "Green Gables Ponjola", "dam_registration_number": "577213",
        "source": meta_l33_c3
    },
    {
        "name": "FRITZ V BAEDERSDORF", "sex": "Male", "registration_number": "774306",
        "birth_date": "May 5, 1930", "color": "Blk & tn mkgs",
        "owner": "Malcolm La Prade", "owner_location": None,
        "breeder": "W. S. Bader", "breeder_location": "Arlington, N. J.",
        "sire": "Alex v Polzei", "sire_registration_number": "494371",
        "dam": "Kinka v Schmidt", "dam_registration_number": "645634",
        "source": meta_l33_c3
    },
    {
        "name": "FRITZ V RINKENBUEHL", "sex": "Male", "registration_number": "773549",
        "birth_date": "July 21, 1930", "color": "Blk, rd rust mkgs",
        "owner": "M. J. Norton", "owner_location": None,
        "breeder": "W. L. Lyons, Jr.", "breeder_location": "Harrods Creek, Ky.",
        "sire": "Prince Alexis of Ardenne", "sire_registration_number": "599344",
        "dam": "Centa v Rinkenbuehl", "dam_registration_number": "316606",
        "source": meta_l33_c3
    },
    {
        "name": "GRETA V NIBELUNGENHORT II", "sex": "Female", "registration_number": "775154",
        "birth_date": "Sept. 26, 1929", "color": "Rd & tn",
        "owner": "W. P. Freyberg", "owner_location": None,
        "breeder": "J. P. Porter", "breeder_location": "Dayton, Ohio",
        "sire": "Ariovist v Nibelungenhort", "sire_registration_number": "524279",
        "dam": "Rowdy Girl", "dam_registration_number": "685589",
        "source": meta_l33_c3
    },
    {
        "name": "GRETCHEN V SPORTHOF", "sex": "Female", "registration_number": "773853",
        "birth_date": "Nov. 7, 1927", "color": "Blk & tn",
        "owner": "Sarah A. Galiano", "owner_location": "Stoneham, Mass.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Zoic Edel v Sporthof", "sire_registration_number": "409773",
        "dam": "Adele v Gruenbaum", "dam_registration_number": "578369",
        "source": meta_l33_c3
    },
    {
        "name": "HORA OF RURITANIA", "sex": "Female", "registration_number": "772847",
        "birth_date": "Nov. 15, 1930", "color": "Br & tn",
        "owner": "Nicholas Lovece", "owner_location": "Brooklyn, N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Uriana v Waldeck", "dam_registration_number": "702562",
        "source": meta_l33_c3
    },
    {
        "name": "JACK'S TRIXIE", "sex": "Female", "registration_number": "774429",
        "birth_date": "Aug. 5, 1930", "color": "Blk & tn",
        "owner": "John Shuttleworth", "owner_location": None,
        "breeder": "Grenfell Slater", "breeder_location": "N. Y. City",
        "sire": "Tiger v Leipzig", "sire_registration_number": "464001",
        "dam": "Nuttall's Beauty", "dam_registration_number": "608304",
        "source": meta_l33_c3
    },
    {
        "name": "JANS V REYNO", "sex": "Male", "registration_number": "774172",
        "birth_date": "Oct. 3, 1927", "color": "Blk & tn",
        "owner": "M. V. Reynolds", "owner_location": None,
        "breeder": "E. J. Robinson", "breeder_location": "Milwaukee, Wis.",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Dorle v Leipzig", "dam_registration_number": "462575",
        "source": meta_l33_c3
    }
]

# Leaf 34, Column 1 (21 dogs down to POINTERS)
c3_dogs = [
    {
        "name": "KLAUS V D WINTERBURG", "sex": "Male", "registration_number": "772923",
        "birth_date": "June 30, 1928", "color": "Blk rd",
        "owner": "J. D. Witter", "owner_location": None,
        "breeder": "Karl Winter", "breeder_location": "Germany",
        "sire": "Edel v d Barbarossahohle", "sire_registration_number": None,
        "dam": "Ferri v d Winterburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Benno v d Romerhof", "registration_number": "517073"},
            {"role": "dam_of_dam", "name": "Lotte v Brennetsried", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Waldo Gluck Auf Penzberg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Freya Kadletz", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Dilly v Stolzenberg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Lotte v Simmenau", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_l34_c1
    },
    {
        "name": "KUNCANOWET JEAN V SPORTHOF", "sex": "Male", "registration_number": "773862",
        "birth_date": "Sept. 21, 1928", "color": "Blk & tn",
        "owner": "Wade H. Knowlton", "owner_location": None,
        "breeder": "Joseph S. Treacy", "breeder_location": "Manchester, N. H.",
        "sire": "Zoic Edel v Sporthof", "sire_registration_number": "409773",
        "dam": "Maidshen v Granite Hill", "dam_registration_number": "668106",
        "source": meta_l34_c1
    },
    {
        "name": "KURT OF DAWN", "sex": "Male", "registration_number": "774072",
        "birth_date": "June 15, 1929", "color": "Blk & rd",
        "owner": "Chas. O. Robbins", "owner_location": None,
        "breeder": "H. S. Newsom", "breeder_location": "Wheaton, Ill.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Schatz v Ostersee", "dam_registration_number": "514975",
        "source": meta_l34_c1
    },
    {
        "name": "LADY CLAIRE V TANNENHAUS", "sex": "Female", "registration_number": "774744",
        "birth_date": "Nov. 26, 1929", "color": "Blk & rust",
        "owner": "Carl H. Lambach", "owner_location": None,
        "breeder": "E. J. Carthey", "breeder_location": "Davenport, Ia.",
        "sire": "Gustl v Tannenhaus", "sire_registration_number": "677473",
        "dam": "Lady Sigalsburg", "dam_registration_number": "658780",
        "source": meta_l34_c1
    },
    {
        "name": "LADY LUCK", "sex": "Female", "registration_number": "772582",
        "birth_date": "Nov. 7, 1929", "color": "Blk & tn",
        "owner": "Frederick M. Ganz", "owner_location": None,
        "breeder": "J. L. Meier", "breeder_location": "Portland, Ore.",
        "sire": "Amor Koessler", "sire_registration_number": "737978",
        "dam": "Lady Blue", "dam_registration_number": "473055",
        "source": meta_l34_c1
    },
    {
        "name": "LOGE V DAWN", "sex": "Female", "registration_number": "773902",
        "birth_date": "Mar. 31, 1930", "color": "Blk & tn",
        "owner": "N. H. Meiners", "owner_location": None,
        "breeder": "Kettle Cove Kennels", "breeder_location": "Magnolia, Mass.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Lotte v Berghofen", "dam_registration_number": "695157",
        "source": meta_l34_c1
    },
    {
        "name": "LUXENIL LUXEMBURG", "sex": "Male", "registration_number": "773166",
        "birth_date": "July 5, 1930", "color": "Blk, tn mkgs",
        "owner": "Bazil A. Darcey", "owner_location": None,
        "breeder": "Georgine Y. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Bodo v Askanierland", "sire_registration_number": "736236",
        "dam": "Bernie v Wilsona", "dam_registration_number": "672372",
        "source": meta_l34_c1
    },
    {
        "name": "MARCO V SIGALSBURG", "sex": "Male", "registration_number": "775089",
        "birth_date": "Sept. 24, 1930", "color": "Blk & tn",
        "owner": "Miss Martha Lamar Ellis", "owner_location": None,
        "breeder": "T. E. Popp", "breeder_location": "West Allis, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dortell v Popp", "dam_registration_number": "526001",
        "source": meta_l34_c1
    },
    {
        "name": "NAOLA OF ALGONTONUTE", "sex": "Female", "registration_number": "774192",
        "birth_date": "Apr. 4, 1925", "color": "Blk & tn",
        "owner": "Thomas P. Walters", "owner_location": None,
        "breeder": "Reyem Kennels", "breeder_location": "Hales Corners, Wis.",
        "sire": "Westphalia Dyno v Wiesengrund", "sire_registration_number": "365520",
        "dam": "Bona v d Residenz", "dam_registration_number": "410865",
        "source": meta_l34_c1
    },
    {
        "name": "NEITSCHIE V SCHOENAU", "sex": "Male", "registration_number": "773351",
        "birth_date": "Jan. 29, 1930", "color": "Rust br & tn",
        "owner": "W. W. Martin", "owner_location": None,
        "breeder": "R. J. Albrecht", "breeder_location": "Pittsburgh, Pa.",
        "sire": "Carlo v Schoenau", "sire_registration_number": "742490",
        "dam": "Alfra v Klostersee", "dam_registration_number": "669159",
        "source": meta_l34_c1
    },
    {
        "name": "PRINCE VI", "sex": "Male", "registration_number": "772846",
        "birth_date": "Oct. 13, 1930", "color": "Blk & tn",
        "owner": "J. Harold Cassin", "owner_location": None,
        "breeder": "John Ninger", "breeder_location": "Bloomfield, N. J.",
        "sire": "Arno v Edjo", "sire_registration_number": "689776",
        "dam": "Ella v Roemerhof", "dam_registration_number": "711032",
        "source": meta_l34_c1
    },
    {
        "name": "PRINCESS", "sex": "Female", "registration_number": "774705",
        "birth_date": "June 6, 1929", "color": "Blk & tn",
        "owner": "Carl R. Weinkopt", "owner_location": None,
        "breeder": "Max F. Laessig", "breeder_location": "Philadelphia, Pa.",
        "sire": "Duke v Stolzenberg", "sire_registration_number": "639153",
        "dam": "Daisy V Meerane", "dam_registration_number": "625787",
        "source": meta_l34_c1
    },
    {
        "name": "PRINCESS KATHIE", "sex": "Female", "registration_number": "773905",
        "birth_date": "Nov. 17, 1929", "color": "Blk, tn mkgs",
        "owner": "Wm. Freudemann", "owner_location": None,
        "breeder": "Wayne D. King", "breeder_location": "Bridgeport, Ohio",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Asta v Nashville", "dam_registration_number": "675400",
        "source": meta_l34_c1
    },
    {
        "name": "PRINCESS PAT OF PONTCHARTRAIN", "sex": "Female", "registration_number": "775167",
        "birth_date": "Apr. 12, 1930", "color": "Blk & rd",
        "owner": "Mr. and Mrs. E. M. Plump", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721108",
        "dam": "Hertha of Pontchartrain", "dam_registration_number": "610096",
        "source": meta_l34_c1
    },
    {
        "name": "REX V", "sex": "Male", "registration_number": "772288",
        "birth_date": "June 13, 1928", "color": "Blk & tn",
        "owner": "Irvin F. Brensinger", "owner_location": None,
        "breeder": "Mrs. Hermann Wendt", "breeder_location": "Elmhurst, L. I., N. Y.",
        "sire": "Denno of Arkeden", "sire_registration_number": "558221",
        "dam": "Bessie v Rheinstein", "dam_registration_number": "564089",
        "source": meta_l34_c1
    },
    {
        "name": "SHATZ OF EDJO", "sex": "Male", "registration_number": "774507",
        "birth_date": "Jan. 1, 1930", "color": "Br & tn",
        "owner": "Joseph C. Blauner", "owner_location": None,
        "breeder": "Gus Stoffels", "breeder_location": "Nutley, N. J.",
        "sire": "Yvon of Edjo", "sire_registration_number": "689593",
        "dam": "Rea of New Jersey", "dam_registration_number": "685584",
        "source": meta_l34_c1
    },
    {
        "name": "TINA V D DASTNICKERBERG", "sex": "Female", "registration_number": "772593",
        "birth_date": "Apr. 28, 1930", "color": "Br & tn",
        "owner": "Alfred J. Bertelli", "owner_location": "Arlington, Mass.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Bodo v Musenbach", "sire_registration_number": "332043",
        "dam": "Alice v d Charlesbank", "dam_registration_number": "688358",
        "source": meta_l34_c1
    },
    {
        "name": "UNDINE V D HOHEN", "sex": "Female", "registration_number": "774485",
        "birth_date": "Apr. 23, 1930", "color": "Blk, tn mkgs",
        "owner": "Carlota Cagliardi", "owner_location": None,
        "breeder": "Mrs. M. von Hoegen", "breeder_location": "Towaco, N. J.",
        "sire": "D'Artagnan v d Hohen", "sire_registration_number": "594257",
        "dam": "Ilisa v d Hohen", "dam_registration_number": "735502",
        "source": meta_l34_c1
    },
    {
        "name": "UNGARN V D HORSTBURG", "sex": "Male", "registration_number": "772298",
        "birth_date": "Aug. 1, 1929", "color": "Blk, rd rust mkgs",
        "owner": "H. M. Kingery", "owner_location": None,
        "breeder": "Mary Cobb Wilson", "breeder_location": "Springfield, Pa.",
        "sire": "Trail 'Em Adonis", "sire_registration_number": "709104",
        "dam": "Huerta v d Horstburg", "dam_registration_number": "712028",
        "source": meta_l34_c1
    },
    {
        "name": "VALENZ V D HOHEN", "sex": "Male", "registration_number": "774031",
        "birth_date": "Aug. 2, 1930", "color": "Blk, tn mkgs",
        "owner": "Mrs. M. von Hoegen", "owner_location": "Towaco, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lenz v Simmenau", "sire_registration_number": "737795",
        "dam": "Elodia v d Hohen", "dam_registration_number": "683705",
        "source": meta_l34_c1
    },
    {
        "name": "VON HELGER", "sex": "Male", "registration_number": "773207",
        "birth_date": "Apr. 23, 1930", "color": "Blk & tn",
        "owner": "Bryon G. Stout, Jr.", "owner_location": None,
        "breeder": "D. C. Philipp", "breeder_location": "Wichita, Kans.",
        "sire": "Dietrich v d Barbarossahoehle", "sire_registration_number": "561617",
        "dam": "Ellisa v Nuremberg", "dam_registration_number": "692976",
        "source": meta_l34_c1
    }
]

all_31_04 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1931-04 dogs: {len(all_31_04)}")
print(f"  Leaf 33 Col 2: {len(c1_dogs)}")
print(f"  Leaf 33 Col 3: {len(c2_dogs)}")
print(f"  Leaf 34 Col 1: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1931_04.json").write_text(json.dumps(all_31_04, indent=2), encoding="utf-8")
print("Saved verified 1931-04 records.")
