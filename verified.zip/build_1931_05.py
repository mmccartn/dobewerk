import json
from pathlib import Path

meta_l55_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-05-01_48_5", "date": "1931-05-01", "volume": "48", "issue": "5", "leaf": 55, "column": 1}
meta_l55_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-05-01_48_5", "date": "1931-05-01", "volume": "48", "issue": "5", "leaf": 55, "column": 2}
meta_l55_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-05-01_48_5", "date": "1931-05-01", "volume": "48", "issue": "5", "leaf": 55, "column": 3}
meta_l56_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-05-01_48_5", "date": "1931-05-01", "volume": "48", "issue": "5", "leaf": 56, "column": 1}

# Leaf 55, Column 1 (Starts under PINSCHERS (Doberman) - 16 dogs)
c1_dogs = [
    {
        "name": "ALERT V KRANICHSTEIN", "sex": "Male", "registration_number": "777353",
        "birth_date": "Sept. 4, 1929", "color": "Rd & tn",
        "owner": "George J. Lang", "owner_location": None,
        "breeder": "W. N. McCoy", "breeder_location": "Middletown, Ohio",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Lola v Augarten", "dam_registration_number": "724400",
        "source": meta_l55_c1
    },
    {
        "name": "ANITA V SEDREVLA", "sex": "Female", "registration_number": "776682",
        "birth_date": "May 20, 1930", "color": "Blk & tn",
        "owner": "Karl P.'s Graeuwen", "owner_location": "W. Caldwell, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Otello of Pontchartrain", "sire_registration_number": "667919",
        "dam": "Fay v Sedrevla", "dam_registration_number": "695049",
        "source": meta_l55_c1
    },
    {
        "name": "BEAUTY V SEEHAGEN", "sex": "Female", "registration_number": "777720",
        "birth_date": "May 29, 1929", "color": "Blk & tn",
        "owner": "Willis James", "owner_location": None,
        "breeder": "Harry Morris", "breeder_location": "Denver, Colo.",
        "sire": "Barry v Seehagen", "sire_registration_number": "463068",
        "dam": "Gerda v Wiedensahl", "dam_registration_number": "640908",
        "source": meta_l55_c1
    },
    {
        "name": "BELLA V HORNEGG", "sex": "Female", "registration_number": "776834",
        "birth_date": "Apr. 28, 1929", "color": "Blk, rust mkgs",
        "owner": "W. J. Paradowski", "owner_location": None,
        "breeder": "John F. Carey", "breeder_location": "Joliet, Ill.",
        "sire": "Dolf v Taunusblick", "sire_registration_number": "438104",
        "dam": "Mina Faithful", "dam_registration_number": "611899",
        "source": meta_l55_c1
    },
    {
        "name": "BELL V BISMARK", "sex": "Female", "registration_number": "780154",
        "birth_date": "Oct. 21, 1928", "color": "Blk & rust",
        "owner": "W. H. Wilhelm", "owner_location": None,
        "breeder": "A. C. Wales", "breeder_location": "Akron, Ohio",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Reva of Pontchartrain", "dam_registration_number": "624345",
        "source": meta_l55_c1
    },
    {
        "name": "BIJOU V MACWAHOC", "sex": "Female", "registration_number": "778504",
        "birth_date": "May 27, 1925", "color": "Blk & tn",
        "owner": "Edward P. Kelly", "owner_location": None,
        "breeder": "Roline P. Wyman", "breeder_location": "Arlington, Mass.",
        "sire": "Koppe v Macwahoc", "sire_registration_number": "340733",
        "dam": "Kaiserine v Macwahoc", "dam_registration_number": "355729",
        "source": meta_l55_c1
    },
    {
        "name": "BLITZ", "sex": "Male", "registration_number": "779648",
        "birth_date": "Jan. 21, 1931", "color": "Blk & tn",
        "owner": "Sol Greenberger", "owner_location": None,
        "breeder": "Gertrude Baker", "breeder_location": "Philadelphia, Pa.",
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Princess Favorieta", "dam_registration_number": "721388",
        "source": meta_l55_c1
    },
    {
        "name": "BLITZEN V SIGALSBURG", "sex": "Male", "registration_number": "780002",
        "birth_date": "June 13, 1930", "color": "Blk, tn mkgs",
        "owner": "Irving C. Roemer", "owner_location": None,
        "breeder": "Robert Boyd", "breeder_location": "Mill Valley, Calif.",
        "sire": "Tobe v Bets", "sire_registration_number": "547005",
        "dam": "Clausetta v d Sigalsburg", "dam_registration_number": "659176",
        "source": meta_l55_c1
    },
    {
        "name": "BODO V OFFENBACH", "sex": "Male", "registration_number": "778180",
        "birth_date": "July 30, 1929", "color": "Blk & tn",
        "owner": "Amos J. Steel", "owner_location": None,
        "breeder": "O. C. Draheim", "breeder_location": "Fairchild, Wis.",
        "sire": "Gunter v d Residenz", "sire_registration_number": "605528",
        "dam": "Tooky of Kentucky", "dam_registration_number": "625717",
        "source": meta_l55_c1
    },
    {
        "name": "BONITA V GOLDGRUND", "sex": "Female", "registration_number": "775424",
        "birth_date": "Oct. 3, 1927", "color": "Blk & tn",
        "owner": "Bessie Perry Hunt", "owner_location": None,
        "breeder": "Leroy Williams", "breeder_location": "Mobile, Ala.",
        "sire": "Claus v d Berne", "sire_registration_number": None,
        "dam": "Gesa v Goldgrund", "dam_registration_number": "762495",
        "extended_ancestry": [
            {"role": "sire_of_sire", "name": "Arno v Bassewitz", "registration_number": None},
            {"role": "dam_of_sire", "name": "Lony v Elbstrom", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Lord v Norden", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Ledy v Gardenia", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Jutta v d Berne", "registration_number": None}
        ],
        "source": meta_l55_c1
    },
    {
        "name": "CHRISTINE V NIBELUNGENHORT", "sex": "Female", "registration_number": "779551",
        "birth_date": "Dec. 17, 1929", "color": "Blk & tn",
        "owner": "Charles Livesey", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Hathor Fra Duncan", "dam_registration_number": "743870",
        "source": meta_l55_c1
    },
    {
        "name": "CLAUSIE V RUDOLPHSBURG", "sex": "Female", "registration_number": "778485",
        "birth_date": "Feb. 20, 1930", "color": "Blk, rust mkgs",
        "owner": "Mrs. C. A. Bergman", "owner_location": "Ottumwa, Iowa",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Ali Pascha v Striesen", "sire_registration_number": "459899",
        "dam": "Dolly v Jaegershof", "dam_registration_number": "719690",
        "source": meta_l55_c1
    },
    {
        "name": "CLAUS V VERSTAMME", "sex": "Male", "registration_number": "780124",
        "birth_date": "Nov. 23, 1930", "color": "Rd",
        "owner": "James C. Daily", "owner_location": None,
        "breeder": "F. R. Kingman", "breeder_location": "N. Y. City",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Mitzie II v Blankenburg", "dam_registration_number": "735682",
        "source": meta_l55_c1
    },
    {
        "name": "DEMONA VAN ZUID-HOLLAND", "sex": "Female", "registration_number": "777836",
        "birth_date": "May 23, 1928", "color": "Blk & rd",
        "owner": "John Heinis", "owner_location": None,
        "breeder": "F. P. F. v d Berg", "breeder_location": "Holland",
        "sire": "Amor van Zuid-Holland", "sire_registration_number": None,
        "dam": "Demona v Romerhof", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Benno v Romerhof", "registration_number": None},
            {"role": "dam_of_dam", "name": "Bubine van de Koningstad", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Rival's Adonis", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Waltraute v Grammont", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Urian v Grammont", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Bubine v d Koningstad", "registration_number": None},
            {"role": "sire_of_sire", "name": "Amor v Gotterfelsen", "registration_number": None},
            {"role": "dam_of_sire", "name": "Draga van Engelenburg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Folkhardt v Grammont", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Grada v Grammont", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Melitta v Parthengrund", "registration_number": None}
        ],
        "source": meta_l55_c1
    },
    {
        "name": "DOBER OF FRANKFORD", "sex": "Male", "registration_number": "776047",
        "birth_date": "Dec. 23, 1930", "color": "Blk & rust rd",
        "owner": "Frederick C. Tillberg", "owner_location": None,
        "breeder": "Thomas C. Nolan", "breeder_location": "Philadelphia, Pa.",
        "sire": "Redroof Exorcist", "sire_registration_number": "637314",
        "dam": "Nolan's Pal", "dam_registration_number": "765292",
        "source": meta_l55_c1
    },
    {
        "name": "DOBIAS V GODELINDE", "sex": "Male", "registration_number": "779502",
        "birth_date": "Dec. 1, 1928", "color": "Br",
        "owner": "W. A. Hahn", "owner_location": None,
        "breeder": "J. W. Oltmanns", "breeder_location": "Watseka, Ill.",
        "sire": "Arko v Bottwartal", "sire_registration_number": "620924",
        "dam": "Godelinde v Wittmund", "dam_registration_number": "714982",
        "source": meta_l55_c1
    }
]

# Leaf 55, Column 2 (16 dogs)
c2_dogs = [
    {
        "name": "DON MIO", "sex": "Male", "registration_number": "777131",
        "birth_date": "Aug. 8, 1930", "color": "Blk & br",
        "owner": "Ferdinand Palma", "owner_location": None,
        "breeder": "Mrs. W. C. Schinning", "breeder_location": "Battle Creek, Mich.",
        "sire": "Fuhrmann v Zinsgut", "sire_registration_number": "610413",
        "dam": "Queen Beta Princess", "dam_registration_number": "676748",
        "source": meta_l55_c2
    },
    {
        "name": "ENNA OF MIDDLETOWN", "sex": "Female", "registration_number": "778867",
        "birth_date": "June 20, 1929", "color": "Rd & tn",
        "owner": "Thelma Baker", "owner_location": None,
        "breeder": "W. N. McCoy", "breeder_location": "Middletown, Ohio",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Jouda v Steigerwald", "dam_registration_number": "686413",
        "source": meta_l55_c2
    },
    {
        "name": "FELS V ZINGSHEIM", "sex": "Male", "registration_number": "776941",
        "birth_date": "Sept. 3, 1929", "color": "Blk & tn",
        "owner": "Fred S. King", "owner_location": None,
        "breeder": "M. L. Zingsheim", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Betsy v Wilhelm", "dam_registration_number": "623310",
        "source": meta_l55_c2
    },
    {
        "name": "FRANKO FRA DUNCAN", "sex": "Male", "registration_number": "777416",
        "birth_date": "July 25, 1930", "color": "Blk & tn",
        "owner": "D. H. Cowan", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Franco Fra Duncan", "sire_registration_number": "770190",
        "dam": "Wanda v d Spree", "dam_registration_number": "620062",
        "source": meta_l55_c2
    },
    {
        "name": "GRETA V LEUTHOBELLE", "sex": "Female", "registration_number": "778025",
        "birth_date": "Dec. 20, 1929", "color": "Blk, br mkgs",
        "owner": "Paul W. Harvey", "owner_location": None,
        "breeder": "Walton G. Alcorn", "breeder_location": "Columbus, Ohio",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Hilda v Leuthobelle", "dam_registration_number": "699983",
        "source": meta_l55_c2
    },
    {
        "name": "GRETCHEN V SHOENAU", "sex": "Female", "registration_number": "778090",
        "birth_date": "Sept. 20, 1930", "color": "Rust br & tn",
        "owner": "M. S. Redmond", "owner_location": None,
        "breeder": "R. J. Albrecht", "breeder_location": "Pittsburgh, Pa.",
        "sire": "Carlo v Schoenau", "sire_registration_number": "742490",
        "dam": "Alfra v Klostersee", "dam_registration_number": "669159",
        "source": meta_l55_c2
    },
    {
        "name": "GRETCHEN V D WILSONA", "sex": "Female", "registration_number": "778949",
        "birth_date": "Sept. 3, 1929", "color": "Blk, rd mkgs",
        "owner": "Carl Bauslack", "owner_location": None,
        "breeder": "Georgine Y. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Astor Gottschalk", "sire_registration_number": "639147",
        "dam": "Eddi v d Wilsona", "dam_registration_number": "676235",
        "source": meta_l55_c2
    },
    {
        "name": "HILLACRE ROWDY", "sex": "Male", "registration_number": "778563",
        "birth_date": "Oct. 27, 1929", "color": "Rd rust",
        "owner": "Robert Barnes", "owner_location": None,
        "breeder": "Robt. E. O'Connell", "breeder_location": "Ottumwa, Iowa",
        "sire": "Red Roof Rowdy", "sire_registration_number": "392482",
        "dam": "Judy of Friedrichshafen", "dam_registration_number": "663266",
        "source": meta_l55_c2
    },
    {
        "name": "JUDIE RUDOLPHSBURG", "sex": "Female", "registration_number": "778484",
        "birth_date": "Aug. 1, 1929", "color": "Blk, rust mkgs",
        "owner": "Mrs. C. A. Bergman", "owner_location": "Ottumwa, Iowa",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rudolph v d Rudolphsburg", "sire_registration_number": "493363",
        "dam": "Dolly v Jaegershof", "dam_registration_number": "719690",
        "source": meta_l55_c2
    },
    {
        "name": "LADY V BUXTER HUDE", "sex": "Female", "registration_number": "778023",
        "birth_date": "July 25, 1929", "color": "Blk & rd",
        "owner": "J. M. Argo", "owner_location": None,
        "breeder": "Edward A. Hunter", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Kitty v Rodeltal", "dam_registration_number": "706938",
        "source": meta_l55_c2
    },
    {
        "name": "LEDA OF FAIROAKS", "sex": "Female", "registration_number": "778992",
        "birth_date": "Aug. 27, 1930", "color": "Blk & rust rd",
        "owner": "Ernest L. Edler", "owner_location": None,
        "breeder": "Horace W. Feldman", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Prince Claus of Pontchartrain", "sire_registration_number": "710286",
        "dam": "Leda v Blankenburg", "dam_registration_number": "653576",
        "source": meta_l55_c2
    },
    {
        "name": "LIGHTNIN' MASSON", "sex": "Male", "registration_number": "777520",
        "birth_date": "Oct. 10, 1930", "color": "Rd, tn mkgs",
        "owner": "Ruffin Pratt", "owner_location": None,
        "breeder": "Harry Isaacs", "breeder_location": "Eureka, Calif.",
        "sire": "Sig v Sigalsburg", "sire_registration_number": "659175",
        "dam": "Trixie Masson", "dam_registration_number": "734149",
        "source": meta_l55_c2
    },
    {
        "name": "MALVE V DOMBACHTAL", "sex": "Female", "registration_number": "777300",
        "birth_date": "Aug. 25, 1929", "color": "Rd & rust",
        "owner": "George J. Lang", "owner_location": "Pittsburgh, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Hans v Dombachtal", "sire_registration_number": "606668",
        "dam": "Malve v Nibelungenhort", "dam_registration_number": "480163",
        "source": meta_l55_c2
    },
    {
        "name": "MAX V DRACHENFELS", "sex": "Male", "registration_number": "778379",
        "birth_date": "Dec. 10, 1929", "color": "Blk, rd",
        "owner": "Mary L. Dalton", "owner_location": None,
        "breeder": "Joseph Schmidt", "breeder_location": "Detroit, Mich.",
        "sire": "Alto v Westerholz", "sire_registration_number": None,
        "dam": "Gisela v d Karlsaue", "dam_registration_number": "750699",
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Claus v Wilbrink", "registration_number": None},
            {"role": "dam_of_dam", "name": "Freya v Westend", "registration_number": None},
            {"role": "sire_of_sire", "name": "Fedor v Butersburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Cilli v Schutsceneck", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Artus v Astenberg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Blanka v d Funkenburg", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Astor v Goldgrund", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Blanka v Halberstadt", "registration_number": None}
        ],
        "source": meta_l55_c2
    },
    {
        "name": "MINNEL V PRINCE LEO", "sex": "Female", "registration_number": "777391",
        "birth_date": "Dec. 17, 1928", "color": "Blk & tn, wh spot",
        "owner": "J. F. De Vine", "owner_location": None,
        "breeder": "Alice G. Cutts", "breeder_location": "Quantico, Va.",
        "sire": "Prince Leo Occidental", "sire_registration_number": "686204",
        "dam": "Baroness Arva v d Hoehen", "dam_registration_number": "536284",
        "source": meta_l55_c2
    },
    {
        "name": "MITZI V RADEGUND", "sex": "Female", "registration_number": "775943",
        "birth_date": "Aug. 19, 1927", "color": "Br, tn mkgs",
        "owner": "Hans A. Schuhart", "owner_location": None,
        "breeder": "Mae H. P. Bigler", "breeder_location": "Media, Pa.",
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Reida of Red Roof", "dam_registration_number": "326634",
        "source": meta_l55_c2
    }
]

# Leaf 55, Column 3 (20 dogs)
c3_dogs = [
    {
        "name": "MUGS OF APNA VILLA", "sex": "Female", "registration_number": "779386",
        "birth_date": "Aug. 27, 1930", "color": "Blk & rust rd",
        "owner": "Wm. H. Gates", "owner_location": None,
        "breeder": "Horace W. Feldman", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Prince Claus of Pontchartrain", "sire_registration_number": "710286",
        "dam": "Leda v Blankenburg", "dam_registration_number": "653576",
        "source": meta_l55_c3
    },
    {
        "name": "NIZER", "sex": "Male", "registration_number": "775734",
        "birth_date": "May 24, 1930", "color": "Blk & rd",
        "owner": "Mrs. Harry A. Sieck", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Ilisa of Pontchartrain", "dam_registration_number": "571491",
        "source": meta_l55_c3
    },
    {
        "name": "OTTO V STERNGRUND", "sex": "Male", "registration_number": "777240",
        "birth_date": "Oct. 17, 1927", "color": "Blk & tn",
        "owner": "Thomas B. Jackson", "owner_location": None,
        "breeder": "Geo. M. Henderson", "breeder_location": "Huntington, W. Va.",
        "sire": "Claus v d Spree Junior", "sire_registration_number": "512026",
        "dam": "Roni v Telless", "dam_registration_number": "391552",
        "source": meta_l55_c3
    },
    {
        "name": "PAULO V DASTNICKBERG", "sex": "Male", "registration_number": "775919",
        "birth_date": "Apr. 28, 1930", "color": "Br & tn",
        "owner": "Robert B. Harding", "owner_location": None,
        "breeder": "Alfred J. Bertelli", "breeder_location": "Arlington, Mass.",
        "sire": "Bodo v Musenbach", "sire_registration_number": "332043",
        "dam": "Alice v d Charlesbank", "dam_registration_number": "688358",
        "source": meta_l55_c3
    },
    {
        "name": "PEGGY OF APNA VILLA", "sex": "Female", "registration_number": "779387",
        "birth_date": "Aug. 27, 1930", "color": "Br & tn",
        "owner": "Wm. H. Gates", "owner_location": None,
        "breeder": "Horace W. Feldman", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Prince Claus of Pontchartrain", "sire_registration_number": "710286",
        "dam": "Leda v Blankenburg", "dam_registration_number": "653576",
        "source": meta_l55_c3
    },
    {
        "name": "PETER V HERTZ", "sex": "Male", "registration_number": "780001",
        "birth_date": "May 10, 1930", "color": "Blk & tn",
        "owner": "J. C. Hart", "owner_location": None,
        "breeder": "Tom McClelland", "breeder_location": "Vista, Calif.",
        "sire": "Samson v Strossen", "sire_registration_number": "731845",
        "dam": "Dobera v Macland", "dam_registration_number": "663791",
        "source": meta_l55_c3
    },
    {
        "name": "PRINCE ZMITRI OF STARKANHART", "sex": "Male", "registration_number": "778486",
        "birth_date": "Sept. 11, 1930", "color": "Blk & rust rd",
        "owner": "F. C. Bowles", "owner_location": "Hartville, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prince Claus of Pontchartrain", "sire_registration_number": "710286",
        "dam": "Tamar v Tilhagen", "dam_registration_number": "714860",
        "source": meta_l55_c3
    },
    {
        "name": "PRINZ BILLO V VERE", "sex": "Male", "registration_number": "775639",
        "birth_date": "Mar. 25, 1930", "color": "Blk, rd rust mkgs",
        "owner": "V. C. Blackman", "owner_location": None,
        "breeder": "W. L. Lyons, Jr.", "breeder_location": "Harrods Creek, Ky.",
        "sire": "Prince Alexis of Ardenne", "sire_registration_number": "599344",
        "dam": "Dea v d Reichsburg", "dam_registration_number": "552928",
        "source": meta_l55_c3
    },
    {
        "name": "PRINZ FRITZ V D KONINGSTADT", "sex": "Male", "registration_number": "777451",
        "birth_date": "Dec. 17, 1930", "color": "Blk & tn",
        "owner": "Donald L. Dolbin", "owner_location": None,
        "breeder": "E. De L. Fouque", "breeder_location": "Media, Pa.",
        "sire": "Redroof Exorcist", "sire_registration_number": "637314",
        "dam": "Babette v Jagerhof", "dam_registration_number": "521089",
        "source": meta_l55_c3
    },
    {
        "name": "PRINZ TROLL", "sex": "Male", "registration_number": "775638",
        "birth_date": "Dec. 17, 1930", "color": "Blk & tn",
        "owner": "Carl J. Orth, Jr.", "owner_location": None,
        "breeder": "E. De L. Fouque", "breeder_location": "Media, Pa.",
        "sire": "Redroof Exorcist", "sire_registration_number": "637314",
        "dam": "Babette v Jagerhof", "dam_registration_number": "521089",
        "source": meta_l55_c3
    },
    {
        "name": "QUEEN V BISMARK", "sex": "Female", "registration_number": "780155",
        "birth_date": "Oct. 21, 1928", "color": "Rd & tn",
        "owner": "W. H. Wilhelm", "owner_location": None,
        "breeder": "A. C. Wales", "breeder_location": "Akron, Ohio",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Reva of Pontchartrain", "dam_registration_number": "624345",
        "source": meta_l55_c3
    },
    {
        "name": "REX V SIGALSBURG", "sex": "Male", "registration_number": "777631",
        "birth_date": "Sept. 18, 1930", "color": "Blk & wh",
        "owner": "T. H. Schebrat", "owner_location": None,
        "breeder": "Mrs. Elmer Schweninger", "breeder_location": "Cincinnati, Ohio",
        "sire": "Toro v Hortsburg", "sire_registration_number": "696927",
        "dam": "Trudie v Sigalsburg", "dam_registration_number": "765607",
        "source": meta_l55_c3
    },
    {
        "name": "ROLF V HINDENDORFF", "sex": "Male", "registration_number": "776967",
        "birth_date": "June 12, 1925", "color": "Cinnamon",
        "owner": "Ray W. Preston", "owner_location": None,
        "breeder": "M. S. McCormick", "breeder_location": "Sumner, Iowa",
        "sire": "Alex v Kucks", "sire_registration_number": "475526",
        "dam": "Annetta", "dam_registration_number": "452684",
        "source": meta_l55_c3
    },
    {
        "name": "RUDI V NIBELUNGENHORT", "sex": "Male", "registration_number": "779881",
        "birth_date": "May 24, 1929", "color": "Blk & tn",
        "owner": "F. H. Williams", "owner_location": None,
        "breeder": "Georgia Christman", "breeder_location": "Harrodsburg, Ky.",
        "sire": "Rolf v Schendsenthal", "sire_registration_number": "624504",
        "dam": "Patsy v Nibelungenhort", "dam_registration_number": "721247",
        "source": meta_l55_c3
    },
    {
        "name": "RUDOLPH V KRANICHSTEIN", "sex": "Male", "registration_number": "777962",
        "birth_date": "Sept. 4, 1929", "color": "Blk & tn",
        "owner": "W. A. Rogers", "owner_location": None,
        "breeder": "W. N. McCoy", "breeder_location": "Middletown, Ohio",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Lola v Augarten", "dam_registration_number": "724400",
        "source": meta_l55_c3
    },
    {
        "name": "RUDY V SIGALSBURG", "sex": "Male", "registration_number": "777302",
        "birth_date": "Mar. 30, 1930", "color": "Blk & tn",
        "owner": "George J. Lang", "owner_location": "Pittsburgh, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Toppo v Sigalsburg", "sire_registration_number": "670191",
        "dam": "Malve v Nibelungenhort", "dam_registration_number": "480163",
        "source": meta_l55_c3
    },
    {
        "name": "SCHANTZ SOHN V CLAUS", "sex": "Male", "registration_number": "775205",
        "birth_date": "July 21, 1929", "color": "Blk & tn",
        "owner": "Portia Duncan Rosner", "owner_location": None,
        "breeder": "Laura B. Gibson", "breeder_location": "Hales Corners, Wis.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Adie v Reyem", "dam_registration_number": "517408",
        "source": meta_l55_c3
    },
    {
        "name": "SIGALSBURG KOLSTREE", "sex": "Female", "registration_number": "778483",
        "birth_date": "Aug. 1, 1929", "color": "Blk, rust mkgs",
        "owner": "Mrs. C. A. Bergman", "owner_location": "Ottumwa, Iowa",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rudolph v d Rudolphsburg", "sire_registration_number": "493363",
        "dam": "Dolly v Jaegershof", "dam_registration_number": "719690",
        "source": meta_l55_c3
    },
    {
        "name": "TEAK V D RHEINPERLE", "sex": "Male", "registration_number": "776719",
        "birth_date": "Aug. 3, 1929", "color": "Blk & tn",
        "owner": "Mrs. Everett H. Hagel", "owner_location": None,
        "breeder": "Daniel L. Hoffman", "breeder_location": "Chicago, Ill.",
        "sire": "Elmar v d Rheinperle", "sire_registration_number": "508311",
        "dam": "Bell v Huffmann", "dam_registration_number": "647069",
        "source": meta_l55_c3
    },
    {
        "name": "TO-BE", "sex": "Male", "registration_number": "778482",
        "birth_date": "Sept. 24, 1929", "color": "Blk, dk tn",
        "owner": "William A. Radford, Jr.", "owner_location": None,
        "breeder": "R. D. Radford", "breeder_location": "Hamilton, Ohio",
        "sire": "Claus v Homehill", "sire_registration_number": "716213",
        "dam": "Radford's Asta", "dam_registration_number": "679789",
        "source": meta_l55_c3
    }
]

# Leaf 56, Column 1 top (1 dog down to PINSCHERS (Miniature))
c4_dogs = [
    {
        "name": "VREDA V FRIEDEWALD", "sex": "Female", "registration_number": "777754",
        "birth_date": "Mar. 27, 1926", "color": "Rd & tn",
        "owner": "Ralph Brands", "owner_location": None,
        "breeder": "Carl A. Thiemann", "breeder_location": "Omaha, Nebr.",
        "sire": "Hasso v Altendorf", "sire_registration_number": "463070",
        "dam": "Alma v Waidachgrund", "dam_registration_number": "463069",
        "source": meta_l56_c1
    }
]

all_31_05 = c1_dogs + c2_dogs + c3_dogs + c4_dogs
print(f"Total compiled 1931-05 dogs: {len(all_31_05)}")
print(f"  Leaf 55 Col 1: {len(c1_dogs)}")
print(f"  Leaf 55 Col 2: {len(c2_dogs)}")
print(f"  Leaf 55 Col 3: {len(c3_dogs)}")
print(f"  Leaf 56 Col 1: {len(c4_dogs)}")

Path("stud-scrape/data/verified_1931_05.json").write_text(json.dumps(all_31_05, indent=2), encoding="utf-8")
print("Saved verified 1931-05 records.")
