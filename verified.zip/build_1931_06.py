import json
from pathlib import Path

meta_l39_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-06-01_48_6", "date": "1931-06-01", "volume": "48", "issue": "6", "leaf": 39, "column": 2}
meta_l39_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-06-01_48_6", "date": "1931-06-01", "volume": "48", "issue": "6", "leaf": 39, "column": 3}
meta_l40_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-06-01_48_6", "date": "1931-06-01", "volume": "48", "issue": "6", "leaf": 40, "column": 1}

# Leaf 39, Column 2 bottom (Starts under PINSCHERS (Doberman) - 10 dogs)
c1_dogs = [
    {
        "name": "ALTO OF HEIDELBERG", "sex": "Male", "registration_number": "782031",
        "birth_date": "May 12, 1929", "color": "Blk & rd",
        "owner": "G. Evans", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Rolla of Pontchartrain", "dam_registration_number": "613805",
        "source": meta_l39_c2
    },
    {
        "name": "ARNO OF HEIDELBERG", "sex": "Male", "registration_number": "782032",
        "birth_date": "May 12, 1929", "color": "Blk & rd",
        "owner": "Lewis W. Kunze", "owner_location": None,
        "breeder": "G. Evans", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Rolla of Pontchartrain", "dam_registration_number": "613805",
        "source": meta_l39_c2
    },
    {
        "name": "ARTISTE V TORREZ", "sex": "Female", "registration_number": "780956",
        "birth_date": "Feb. 22, 1929", "color": "Blk & tn",
        "owner": "Joseph A. Ernst", "owner_location": None,
        "breeder": "Ernest C. Torrez", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Burga v Torrez", "dam_registration_number": "628206",
        "source": meta_l39_c2
    },
    {
        "name": "BARON", "sex": "Male", "registration_number": "782505",
        "birth_date": "Apr. 10, 1930", "color": "Blk & tn",
        "owner": "D. K. Olin", "owner_location": None,
        "breeder": "Arthur Ringbloom", "breeder_location": "Chicago, Ill.",
        "sire": "Benno v d Koernereiche", "sire_registration_number": "561003",
        "dam": "Linda v d Mannerstedt", "dam_registration_number": "697150",
        "source": meta_l39_c2
    },
    {
        "name": "BARON V STRATHMOOR", "sex": "Male", "registration_number": "781987",
        "birth_date": "July 27, 1930", "color": "Blk & tn",
        "owner": "Geo. K. Schuster", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Franco Fra Duncan", "sire_registration_number": "770190",
        "dam": "Rosa of Ballycoreagh", "dam_registration_number": "608807",
        "source": meta_l39_c2
    },
    {
        "name": "BENNO V LOBENSTEIN", "sex": "Male", "registration_number": "782176",
        "birth_date": "Jan. 23, 1931", "color": "Blk & tn",
        "owner": "Francis X. Malley", "owner_location": None,
        "breeder": "Mr. and Mrs. Albert T. Rahner", "breeder_location": "Philadelphia, Pa.",
        "sire": "Redroof Exorcist", "sire_registration_number": "637314",
        "dam": "Gertrud v Burgund", "dam_registration_number": "750713",
        "source": meta_l39_c2
    },
    {
        "name": "BETSY V FREDERICKSBURG", "sex": "Female", "registration_number": "782259",
        "birth_date": "Nov. 25, 1929", "color": "Blk & tn",
        "owner": "George H. Fredericks", "owner_location": None,
        "breeder": "E. J. Carthey", "breeder_location": "Davenport, Iowa",
        "sire": "Gustl v Tannenhaus", "sire_registration_number": "677473",
        "dam": "Lady Sigalsburg", "dam_registration_number": "658780",
        "source": meta_l39_c2
    },
    {
        "name": "BOSKO", "sex": "Male", "registration_number": "781877",
        "birth_date": "Aug. 15, 1930", "color": "Blk & br",
        "owner": "C. J. Burns, M. D.", "owner_location": None,
        "breeder": "Ray E. Brown", "breeder_location": "Washington C. H., Ohio",
        "sire": "Beno v Weidlestadt", "sire_registration_number": "615297",
        "dam": "Almo of Middletown", "dam_registration_number": "665119",
        "source": meta_l39_c2
    },
    {
        "name": "CILA OF BELBERG", "sex": "Female", "registration_number": "780262",
        "birth_date": "May 14, 1927", "color": "Blk, br flsgs",
        "owner": "Albert Vidosh", "owner_location": None,
        "breeder": "Belberg Kennels", "breeder_location": "Port Huron, Mich.",
        "sire": "Graf v Homehill", "sire_registration_number": "531479",
        "dam": "Frieda of Pontchartrain", "dam_registration_number": "511185",
        "source": meta_l39_c2
    },
    {
        "name": "COUNT V LUCKNER OF GOOD HILL", "sex": "Male", "registration_number": "780427",
        "birth_date": "Oct. 13, 1930", "color": "Blk & tn",
        "owner": "Margaret Kinnane", "owner_location": None,
        "breeder": "John Ninger", "breeder_location": "Bloomfield, N. J.",
        "sire": "Arno v Edjo", "sire_registration_number": "689776",
        "dam": "Ella v Roemerhof", "dam_registration_number": "711032",
        "source": meta_l39_c2
    }
]

# Leaf 39, Column 3 (23 dogs)
c2_dogs = [
    {
        "name": "FREYA V D ARLAC", "sex": "Female", "registration_number": "782827",
        "birth_date": "Nov. 27, 1927", "color": "Br & rd",
        "owner": "A. S. Haines", "owner_location": None,
        "breeder": "V. R. Shattuck", "breeder_location": "Pittsburgh, Pa.",
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Cordula v d Hunnenheide", "dam_registration_number": "558647",
        "source": meta_l39_c3
    },
    {
        "name": "FRITZ V VERSTAMME", "sex": "Male", "registration_number": "780834",
        "birth_date": "Nov. 23, 1930", "color": "Blk & rd",
        "owner": "Howard C. Little", "owner_location": None,
        "breeder": "F. R. Kingman", "breeder_location": "N. Y. City",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Mitzie II v Blankenburg", "dam_registration_number": "735682",
        "source": meta_l39_c3
    },
    {
        "name": "GRETCHEN VOSSBURG", "sex": "Female", "registration_number": "781176",
        "birth_date": "Oct. 7, 1929", "color": "Blk & tn",
        "owner": "Ellis U. Harper", "owner_location": None,
        "breeder": "A. W. Schmidt", "breeder_location": "Akron, Ohio",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Laura of Mickburn", "dam_registration_number": "578933",
        "source": meta_l39_c3
    },
    {
        "name": "GYPSY V HAHN", "sex": "Female", "registration_number": "780263",
        "birth_date": "June 7, 1929", "color": "Blk & fn",
        "owner": "Mrs. Leona H. Hahn", "owner_location": None,
        "breeder": "J. N. Millburn", "breeder_location": "Kankakee, Ill.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Zoe v Melrapp", "dam_registration_number": "384020",
        "source": meta_l39_c3
    },
    {
        "name": "HANS V KLOSTERSEE", "sex": "Male", "registration_number": "781448",
        "birth_date": "Dec. 30, 1930", "color": "Blk, rust mkgs",
        "owner": "Carl Choisser", "owner_location": None,
        "breeder": "Mrs. C. A. Bergman", "breeder_location": "Ottumwa, Iowa",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Sigalsberg Kolstree", "dam_registration_number": "778483",
        "source": meta_l39_c3
    },
    {
        "name": "HAPPY V ALLERSHAUSEN", "sex": "Male", "registration_number": "782488",
        "birth_date": "Apr. 5, 1930", "color": "Br & rd",
        "owner": "Mary B. McNamara", "owner_location": None,
        "breeder": "John Ninger", "breeder_location": "Bloomfield, N. J.",
        "sire": "Arno v Edjo", "sire_registration_number": "689776",
        "dam": "Peaches v Allershausen", "dam_registration_number": "764862",
        "source": meta_l39_c3
    },
    {
        "name": "HUNK V CRABBSIDE", "sex": "Male", "registration_number": "782369",
        "birth_date": "Sept. 21, 1929", "color": "Chlte & tn",
        "owner": "Thomas Crumley", "owner_location": None,
        "breeder": "Mrs. A. M. Shafer", "breeder_location": "Cherry Grove, Ohio",
        "sire": "Hansel v Crabbside", "sire_registration_number": "611218",
        "dam": "Mia v Homehill", "dam_registration_number": "692097",
        "source": meta_l39_c3
    },
    {
        "name": "IDA V POPP", "sex": "Female", "registration_number": "781874",
        "birth_date": "Feb. 19, 1930", "color": "Blk & tn",
        "owner": "T. E. Popp", "owner_location": "West Allis, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dortell v Popp", "dam_registration_number": "526001",
        "source": meta_l39_c3
    },
    {
        "name": "INA V POPP", "sex": "Female", "registration_number": "781873",
        "birth_date": "Feb. 19, 1930", "color": "Blk & tn",
        "owner": "T. E. Popp", "owner_location": "West Allis, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Dortell v Popp", "dam_registration_number": "526001",
        "source": meta_l39_c3
    },
    {
        "name": "JUDY OF WICHITA", "sex": "Female", "registration_number": "782047",
        "birth_date": "May 29, 1929", "color": "Blk & rd",
        "owner": "D. R. MacKenzie", "owner_location": None,
        "breeder": "Harry Morris", "breeder_location": "Denver, Colo.",
        "sire": "Barry v Seehagen", "sire_registration_number": "463068",
        "dam": "Gerda v Wiedensahl", "dam_registration_number": "640908",
        "source": meta_l39_c3
    },
    {
        "name": "LEADER OF DAWN", "sex": "Male", "registration_number": "781879",
        "birth_date": "Aug. 26, 1930", "color": "Blk & rd",
        "owner": "Bob McCormack", "owner_location": None,
        "breeder": "Mr. and Mrs. H. S. Newson", "breeder_location": "Wheaton, Ill.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Alicia of Dawn", "dam_registration_number": "737244",
        "source": meta_l39_c3
    },
    {
        "name": "LORRETTO LADDIE", "sex": "Male", "registration_number": "781777",
        "birth_date": "Dec. 10, 1929", "color": "Blk & rd",
        "owner": "Mary C. Lindsley", "owner_location": None,
        "breeder": "Joseph Schmidt", "breeder_location": "Detroit, Mich.",
        "sire": "Alto v Westerholz", "sire_registration_number": None,
        "dam": "Gisela v d Karlsaue", "dam_registration_number": "750699",
        "extended_ancestry": [
            {"role": "sire_of_sire", "name": "Fedor v Butersburg", "registration_number": "539750"},
            {"role": "dam_of_sire", "name": "Cilli v Schutsceneck", "registration_number": "517071"}
        ],
        "source": meta_l39_c3
    },
    {
        "name": "MARKO", "sex": "Male", "registration_number": "783135",
        "birth_date": "May 26, 1930", "color": "Blk & rust",
        "owner": "P. H. Wessel, M. D.", "owner_location": None,
        "breeder": "E. J. Carthey", "breeder_location": "Davenport, Iowa",
        "sire": "Lindy v Forsberg", "sire_registration_number": "670607",
        "dam": "Lady Sigalsburg", "dam_registration_number": "658780",
        "source": meta_l39_c3
    },
    {
        "name": "MIA V POPP", "sex": "Female", "registration_number": "781875",
        "birth_date": "Aug. 29, 1930", "color": "Blk & tn",
        "owner": "T. E. Popp", "owner_location": "West Allis, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Rita v Popp", "dam_registration_number": "707424",
        "source": meta_l39_c3
    },
    {
        "name": "MITZI DIANE", "sex": "Female", "registration_number": "782258",
        "birth_date": "Apr. 23, 1930", "color": "Blk & tn",
        "owner": "Robert B. Shanklin", "owner_location": None,
        "breeder": "D. C. Philipp", "breeder_location": "Wichita, Kans.",
        "sire": "Dietrich v d Barbarossahoehle", "sire_registration_number": "561617",
        "dam": "Ellisa v Nuremberg", "dam_registration_number": "692976",
        "source": meta_l39_c3
    },
    {
        "name": "NICHOLAS V WAGNER", "sex": "Male", "registration_number": "781494",
        "birth_date": "Jan. 6, 1931", "color": "Rd",
        "owner": "Miss Eugenia A. Wagner", "owner_location": None,
        "breeder": "J. F. De Vine", "breeder_location": "Goshen, N. Y.",
        "sire": "Dombachtal's Big Boy", "sire_registration_number": "690228",
        "dam": "Minnel v Prince Leo", "dam_registration_number": "777391",
        "source": meta_l39_c3
    },
    {
        "name": "NIGGER V OXBO", "sex": "Male", "registration_number": "782019",
        "birth_date": "Sept. 20, 1930", "color": "Blk & tn",
        "owner": "F. C. Fuqua", "owner_location": "Seattle, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Carlo v Belger", "sire_registration_number": "533994",
        "dam": "Erda of Oxbo", "dam_registration_number": "679295",
        "source": meta_l39_c3
    },
    {
        "name": "PRINCESS ELLYN V STATEEN", "sex": "Female", "registration_number": "780426",
        "birth_date": "Sept. 14, 1930", "color": "Blk & tn",
        "owner": "George F. Venzke", "owner_location": None,
        "breeder": "F. B. Brewster", "breeder_location": "Palos Park, Ill.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Prinzess B. v Roemerhof", "dam_registration_number": "641312",
        "source": meta_l39_c3
    },
    {
        "name": "PRINCESS FIGRETA V SIGALSBURG", "sex": "Female", "registration_number": "781876",
        "birth_date": "Sept. 16, 1930", "color": "Blk, rust mkgs",
        "owner": "C. C. Whitacre", "owner_location": None,
        "breeder": "W. P. Freyberg", "breeder_location": "Dayton, Ohio",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Greta v Nibelungenhort II", "dam_registration_number": "775154",
        "source": meta_l39_c3
    },
    {
        "name": "PRINCESS PYA O'PONTCHARTRAIN", "sex": "Female", "registration_number": "781716",
        "birth_date": "Apr. 12, 1930", "color": "Blk & rd",
        "owner": "Stanley W. McFarland", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721108",
        "dam": "Hertha of Pontchartrain", "dam_registration_number": "610096",
        "source": meta_l39_c3
    },
    {
        "name": "PRINZ V. SIEGERPARK", "sex": "Male", "registration_number": "783073",
        "birth_date": "Oct. 3, 1930", "color": "Blk & rd",
        "owner": "N. Arthur Gleason, M. D.", "owner_location": None,
        "breeder": "Mr. and Mrs. S. R. Baker", "breeder_location": "Pontiac, Mich.",
        "sire": "Carlo of Rhinegold", "sire_registration_number": "551481",
        "dam": "Zoe v Siegerpark", "dam_registration_number": "749459",
        "source": meta_l39_c3
    },
    {
        "name": "REGO V TANNENHAUS", "sex": "Male", "registration_number": "781250",
        "birth_date": "Nov. 26, 1929", "color": "Blk & rust",
        "owner": "Louis L. Holub", "owner_location": None,
        "breeder": "E. J. Carthey", "breeder_location": "Davenport, Iowa",
        "sire": "Gustl v Tannenhaus", "sire_registration_number": "677473",
        "dam": "Lady Sigalsburg", "dam_registration_number": "658780",
        "source": meta_l39_c3
    },
    {
        "name": "RUDY V BALTI", "sex": "Male", "registration_number": "780308",
        "birth_date": "May 18, 1929", "color": "Blk & tn",
        "owner": "Lawrence C. Holden", "owner_location": None,
        "breeder": "Thos. Spaulding", "breeder_location": "Warren, Ind.",
        "sire": "Kress v Kressenstein", "sire_registration_number": "476479",
        "dam": "Betsy Klostersee", "dam_registration_number": "697787",
        "source": meta_l39_c3
    }
]

# Leaf 40, Column 1 (9 dogs down to PINSCHERS (Miniature))
c3_dogs = [
    {
        "name": "RURITANIA HELGA V TARLENHEIM", "sex": "Female", "registration_number": "782831",
        "birth_date": "May 27, 1929", "color": "Blk & tn",
        "owner": "Nicholas Lovece", "owner_location": "Brooklyn, N. Y.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Edelblut of Arkeden", "sire_registration_number": "619599",
        "dam": "Uriana v Waldeck", "dam_registration_number": "702562",
        "source": meta_l40_c1
    },
    {
        "name": "SALTO V LOCARNO", "sex": "Male", "registration_number": "781878",
        "birth_date": "Sept. 2, 1930", "color": "Blk & rust",
        "owner": "John Cusack", "owner_location": None,
        "breeder": "N. M. Freund", "breeder_location": "St. Louis, Mo.",
        "sire": "Artus v Lenburg", "sire_registration_number": "733269",
        "dam": "Peppy v Nurschan", "dam_registration_number": "755498",
        "source": meta_l40_c1
    },
    {
        "name": "SATIN V BETS", "sex": "Male", "registration_number": "783074",
        "birth_date": "June 15, 1930", "color": "Blk & tn",
        "owner": "William A. Ford", "owner_location": None,
        "breeder": "James Thomson", "breeder_location": "Beverly Hills, Calif.",
        "sire": "Watch", "sire_registration_number": "772458",
        "dam": "Elsa v Bets", "dam_registration_number": "750276",
        "source": meta_l40_c1
    },
    {
        "name": "SONIA V D HOEHEN", "sex": "Female", "registration_number": "782473",
        "birth_date": "Feb. 2, 1930", "color": "Blk, rust mkgs",
        "owner": "Edna Leach", "owner_location": None,
        "breeder": "Mrs. M. von Hoegen", "breeder_location": "Towaco, N. J.",
        "sire": "Prinz Favorit v d Koningstad", "sire_registration_number": "420325",
        "dam": "Baroness Atora v d Hoehen", "dam_registration_number": "554720",
        "source": meta_l40_c1
    },
    {
        "name": "SUSANETTE", "sex": "Female", "registration_number": "781717",
        "birth_date": "July 15, 1930", "color": "Blk & br",
        "owner": "Gertrude C. McFarland", "owner_location": None,
        "breeder": "Joseph F. Elias", "breeder_location": "Lexington, Mich.",
        "sire": "Marko v Siegerpark", "sire_registration_number": "601008",
        "dam": "Dhu Varren's Judy", "dam_registration_number": "649764",
        "source": meta_l40_c1
    },
    {
        "name": "ULTRIX V JAEGERHOF", "sex": "Female", "registration_number": "783264",
        "birth_date": "July 27, 1928", "color": "Blk & tn",
        "owner": "A. M. Bailey", "owner_location": None,
        "breeder": "John Matthiesen", "breeder_location": "Chicago, Ill.",
        "sire": "Akrobat v Goetterfelsen", "sire_registration_number": "522604",
        "dam": "Peggy Sallie v Jaegerhof", "dam_registration_number": "558734",
        "source": meta_l40_c1
    },
    {
        "name": "VONE GEISER", "sex": "Male", "registration_number": "780813",
        "birth_date": "June 13, 1930", "color": "Blk & tn",
        "owner": "Elizabeth Geiser", "owner_location": None,
        "breeder": "Emil Pfeiffer", "breeder_location": "Woodside, L. I., N. Y.",
        "sire": "Cy of Syosset", "sire_registration_number": "558079",
        "dam": "Jill of Jonedith", "dam_registration_number": "595853",
        "source": meta_l40_c1
    },
    {
        "name": "WANDA HARROFIELD", "sex": "Female", "registration_number": "783134",
        "birth_date": "July 25, 1930", "color": "Blk & tn",
        "owner": "Mrs. Joseph F. Field", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Franco Fra Duncan", "sire_registration_number": "770190",
        "dam": "Wanda v d Spree", "dam_registration_number": "620062",
        "source": meta_l40_c1
    },
    {
        "name": "ZIDA OF KENTUCKY", "sex": "Female", "registration_number": "781062",
        "birth_date": "Oct. 20, 1929", "color": "Blk & tn",
        "owner": "Frank Bissman", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Beauty of Kentucky", "dam_registration_number": "517728",
        "source": meta_l40_c1
    }
]

all_31_06 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1931-06 dogs: {len(all_31_06)}")
print(f"  Leaf 39 Col 2: {len(c1_dogs)}")
print(f"  Leaf 39 Col 3: {len(c2_dogs)}")
print(f"  Leaf 40 Col 1: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1931_06.json").write_text(json.dumps(all_31_06, indent=2), encoding="utf-8")
print("Saved verified 1931-06 records.")
