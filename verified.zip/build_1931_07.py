import json
from pathlib import Path

meta_l43_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-07-01_48_7", "date": "1931-07-01", "volume": "48", "issue": "7", "leaf": 43, "column": 2}
meta_l43_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-07-01_48_7", "date": "1931-07-01", "volume": "48", "issue": "7", "leaf": 43, "column": 3}
meta_l44_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-07-01_48_7", "date": "1931-07-01", "volume": "48", "issue": "7", "leaf": 44, "column": 1}

# Leaf 43, Column 2 bottom (Starts under PINSCHERS (Doberman) - 11 dogs)
c1_dogs = [
    {
        "name": "ASTA V LUXEMBURG", "sex": "Female", "registration_number": "785897",
        "birth_date": "May 24, 1930", "color": "Rd & rust",
        "owner": "Geo. H. Jones", "owner_location": "Danville, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prince Claus of Pontchartrain", "sire_registration_number": "710286",
        "dam": "Citti v Wilbrink", "dam_registration_number": "601009",
        "source": meta_l43_c2
    },
    {
        "name": "BAYAN VON WEIGAND", "sex": "Male", "registration_number": "784969",
        "birth_date": "Mar. 31, 1930", "color": "Br & tn",
        "owner": "Mary B. Trelease", "owner_location": None,
        "breeder": "Von Weigand Kennels", "breeder_location": "Altadena, Calif.",
        "sire": "Burschel von Weigand", "sire_registration_number": "652099",
        "dam": "Mia von Weigand", "dam_registration_number": "751122",
        "source": meta_l43_c2
    },
    {
        "name": "BEDA V KRANICHSTEIN", "sex": "Female", "registration_number": "784640",
        "birth_date": "May 22, 1929", "color": "Br",
        "owner": "Edwin A. Phillips", "owner_location": None,
        "breeder": "W. N. McCoy", "breeder_location": "Middletown, Ohio",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Lady Middletown", "dam_registration_number": "704063",
        "source": meta_l43_c2
    },
    {
        "name": "BLACK REX", "sex": "Male", "registration_number": "784505",
        "birth_date": "Jan. 28, 1931", "color": "Blk & tn",
        "owner": "John K. Ahrens", "owner_location": None,
        "breeder": "John P. Ahrens", "breeder_location": "Cincinnati, Ohio",
        "sire": "Von Zwygart", "sire_registration_number": "773967",
        "dam": "Asta v Lueschenhof", "dam_registration_number": "660794",
        "source": meta_l43_c2
    },
    {
        "name": "BLITZ II", "sex": "Female", "registration_number": "784137",
        "birth_date": "Feb. 15, 1930", "color": "Blk, tn mkgs",
        "owner": "A. G. Joseph", "owner_location": None,
        "breeder": "Marshall F. Bidwell", "breeder_location": "South Windsor, Conn.",
        "sire": "Gretchen Flash", "sire_registration_number": "638956",
        "dam": "Rozeta v Baron", "dam_registration_number": "714011",
        "source": meta_l43_c2
    },
    {
        "name": "DEVIL", "sex": "Male", "registration_number": "784621",
        "birth_date": "July 2, 1926", "color": "Blk & tn",
        "owner": "Frederick W. Kincaid, Jr.", "owner_location": None,
        "breeder": "Tom W. Johnson", "breeder_location": "Utica, N. Y.",
        "sire": "Major v Burgwall", "sire_registration_number": "436901",
        "dam": "Fredegonda", "dam_registration_number": "784620",
        "source": meta_l43_c2
    },
    {
        "name": "DOBBY V MENCHENBERG", "sex": "Male", "registration_number": "786588",
        "birth_date": "Oct. 13, 1930", "color": "Blk & tn",
        "owner": "Robert J. Ziehler", "owner_location": None,
        "breeder": "J. P. Porter", "breeder_location": "Short Hills, Dayton, Ohio",
        "sire": "Bodo v Rolandsburg", "sire_registration_number": "583887",
        "dam": "Rowdy Girl", "dam_registration_number": "685589",
        "source": meta_l43_c2
    },
    {
        "name": "DOBY V SIGALSBURG", "sex": "Female", "registration_number": "784699",
        "birth_date": "Sept. 18, 1930", "color": "Blk & tn",
        "owner": "William Rodenberg", "owner_location": None,
        "breeder": "Mrs. Elmer Schweninger", "breeder_location": "Cincinnati, Ohio",
        "sire": "Toro v Hortsburg", "sire_registration_number": "696927",
        "dam": "Trudie v Sigalsburg", "dam_registration_number": "765607",
        "source": meta_l43_c2
    },
    {
        "name": "DOLF V LUXEMBURG", "sex": "Male", "registration_number": "785899",
        "birth_date": "Jan. 17, 1931", "color": "Blk & rd",
        "owner": "Geo. H. Jones", "owner_location": None,
        "breeder": "G. C. Jaco", "breeder_location": "Uniontown, Pa.",
        "sire": "Modern v Simmenau Rhinegold", "sire_registration_number": "768281",
        "dam": "Gilda v d Blankenbrink", "dam_registration_number": "696806",
        "source": meta_l43_c2
    },
    {
        "name": "DOLLY V LUXEMBURG", "sex": "Female", "registration_number": "785898",
        "birth_date": "May 24, 1930", "color": "Rd & rust",
        "owner": "Geo. H. Jones", "owner_location": "Danville, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Prince Claus of Pontchartrain", "sire_registration_number": "710286",
        "dam": "Citti v Wilbrink", "dam_registration_number": "601009",
        "source": meta_l43_c2
    },
    {
        "name": "DUKE V HEIDELBERG", "sex": "Male", "registration_number": "786325",
        "birth_date": "June 13, 1929", "color": "Blk, rd rust",
        "owner": "A. T. Ashton", "owner_location": None,
        "breeder": "Martin Gaus", "breeder_location": "Philadelphia, Pa.",
        "sire": "Duke v Stroheim", "sire_registration_number": "563574",
        "dam": "Bella v Horstburg", "dam_registration_number": "620406",
        "source": meta_l43_c2
    }
]

# Leaf 43, Column 3 (22 dogs)
c2_dogs = [
    {
        "name": "ELTA OF MIDDLETOWN", "sex": "Female", "registration_number": "785734",
        "birth_date": "May 19, 1930", "color": "Blk & tn",
        "owner": "W. N. McCoy", "owner_location": "Middletown, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Jouda v Steigerwald", "dam_registration_number": "686413",
        "source": meta_l43_c3
    },
    {
        "name": "ERDA OF MIDDLETOWN", "sex": "Female", "registration_number": "785735",
        "birth_date": "May 19, 1930", "color": "Blk & tn",
        "owner": "W. N. McCoy", "owner_location": "Middletown, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Jouda v Steigerwald", "dam_registration_number": "686413",
        "source": meta_l43_c3
    },
    {
        "name": "ERTA OF MIDDLETOWN", "sex": "Female", "registration_number": "785736",
        "birth_date": "May 19, 1930", "color": "Blk & tn",
        "owner": "W. N. McCoy", "owner_location": "Middletown, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Jouda v Steigerwald", "dam_registration_number": "686413",
        "source": meta_l43_c3
    },
    {
        "name": "ESTA OF MIDDLETOWN", "sex": "Female", "registration_number": "785737",
        "birth_date": "May 19, 1930", "color": "Blk & tn",
        "owner": "W. N. McCoy", "owner_location": "Middletown, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Jouda v Steigerwald", "dam_registration_number": "686413",
        "source": meta_l43_c3
    },
    {
        "name": "FRANZ V BROCKY", "sex": "Male", "registration_number": "784295",
        "birth_date": "Mar. 4, 1930", "color": "Blk & tn",
        "owner": "Eleanor Brocky", "owner_location": None,
        "breeder": "Mrs. Math Brausch", "breeder_location": "Chicago, Ill.",
        "sire": "Peter v Roemerhof", "sire_registration_number": "616494",
        "dam": "Lady v Wilhelm", "dam_registration_number": "699515",
        "source": meta_l43_c3
    },
    {
        "name": "FREDEGONDA", "sex": "Female", "registration_number": "784620",
        "birth_date": "June 15, 1925", "color": "Bl",
        "owner": "Tom W. Johnson", "owner_location": None,
        "breeder": "William T. Johnson", "breeder_location": "Albany, N. Y.",
        "sire": "Tasso Heyer", "sire_registration_number": "387092",
        "dam": "Pinsch II", "dam_registration_number": "308040",
        "source": meta_l43_c3
    },
    {
        "name": "FRITZIE OF NITTA YUMA", "sex": "Female", "registration_number": "787199",
        "birth_date": "Mar. 25, 1930", "color": "Blk, rust mkgs",
        "owner": "G. M. Trammell", "owner_location": None,
        "breeder": "W. L. Lyons, Jr.", "breeder_location": "Harrods Creek, Ky.",
        "sire": "Prince Alexis of Ardenne", "sire_registration_number": "599344",
        "dam": "Dea v d Reichsburg", "dam_registration_number": "552928",
        "source": meta_l43_c3
    },
    {
        "name": "GRETCHEN VII", "sex": "Female", "registration_number": "785757",
        "birth_date": "Dec. 23, 1926", "color": "Blk & tn",
        "owner": "Albert P. Willis", "owner_location": None,
        "breeder": "H. M. Nuttall", "breeder_location": "Detroit, Mich.",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Robinson's Lily", "dam_registration_number": "516294",
        "source": meta_l43_c3
    },
    {
        "name": "GUSTEL V BURGHOLZ", "sex": "Female", "registration_number": "785336",
        "birth_date": "Mar. 3, 1930", "color": "Blk, rd rust mkgs",
        "owner": "John H. Schlomer", "owner_location": None,
        "breeder": "W. L. Lyons, Jr.", "breeder_location": "Harrods Creek, Ky.",
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Ellen v Friedwald", "dam_registration_number": "574498",
        "source": meta_l43_c3
    },
    {
        "name": "ISKO WILSONA HOF", "sex": "Male", "registration_number": "786454",
        "birth_date": "Aug. 5, 1930", "color": "Blk & tn",
        "owner": "Harriet Weaver", "owner_location": None,
        "breeder": "Georgine Y. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Bodo v Askanierland", "sire_registration_number": "736236",
        "dam": "Eddi v Wilsona", "dam_registration_number": "676235",
        "source": meta_l43_c3
    },
    {
        "name": "JACK V KOENIG", "sex": "Male", "registration_number": "783942",
        "birth_date": "June 2, 1929", "color": "Blk & tn",
        "owner": "H. W. Pilkington and W. S. Rieley", "owner_location": None,
        "breeder": "C. F. Cross", "breeder_location": "Logan, Iowa",
        "sire": "Rudolph v Wiedensahl II", "sire_registration_number": "633802",
        "dam": "Frudie v Koenig", "dam_registration_number": "699805",
        "source": meta_l43_c3
    },
    {
        "name": "KAYO V HAUENSTEIN", "sex": "Male", "registration_number": "783971",
        "birth_date": "Apr. 20, 1930", "color": "Blk & tn",
        "owner": "J. E. Gysin", "owner_location": None,
        "breeder": "Mrs. Elmer Schweninger", "breeder_location": "Cincinnati, Ohio",
        "sire": "Boone v Sigalsburg", "sire_registration_number": "658766",
        "dam": "Lindy v Benno", "dam_registration_number": "710927",
        "source": meta_l43_c3
    },
    {
        "name": "LADY TALLULAH", "sex": "Female", "registration_number": "785108",
        "birth_date": "May 29, 1929", "color": "Blk & tn",
        "owner": "F. Cook", "owner_location": None,
        "breeder": "H. M. Nuttall", "breeder_location": "Detroit, Mich.",
        "sire": "Hektor Plato", "sire_registration_number": "517072",
        "dam": "Nuttall's Tobie", "dam_registration_number": "608303",
        "source": meta_l43_c3
    },
    {
        "name": "LASH OF DAWN", "sex": "Male", "registration_number": "785932",
        "birth_date": "Aug. 26, 1930", "color": "Blk & rd",
        "owner": "Stuart Colnon", "owner_location": None,
        "breeder": "Mr. and Mrs. H. S. Newson", "breeder_location": "Wheaton, Ill.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Alicia of Dawn", "dam_registration_number": "737244",
        "source": meta_l43_c3
    },
    {
        "name": "LUCHS CLAUS V D SPREE", "sex": "Male", "registration_number": "785790",
        "birth_date": "Jan. 6, 1931", "color": "Blk & tn",
        "owner": "Wm. A. Reintanz", "owner_location": None,
        "breeder": "J. F. De Vine", "breeder_location": "Goshen, N. Y.",
        "sire": "Dombachtal's Big Boy", "sire_registration_number": "690228",
        "dam": "Minnel v Prince Leo", "dam_registration_number": "777391",
        "source": meta_l43_c3
    },
    {
        "name": "META V LOCARNO", "sex": "Female", "registration_number": "786481",
        "birth_date": "May 12, 1930", "color": "Blk & tn",
        "owner": "F. R. Winther", "owner_location": "Overland, Mo.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Hindu Prinz", "sire_registration_number": "540803",
        "dam": "Duchess v Nordheim", "dam_registration_number": "731377",
        "source": meta_l43_c3
    },
    {
        "name": "MUENCHEN VON WEIGAND", "sex": "Female", "registration_number": "784968",
        "birth_date": "Mar. 31, 1930", "color": "Br & tn",
        "owner": "H. H. Oesterreich", "owner_location": None,
        "breeder": "Von Weigand Kennels", "breeder_location": "Altadena, Calif.",
        "sire": "Burschel von Weigand", "sire_registration_number": "652099",
        "dam": "Mia von Weigand", "dam_registration_number": "751122",
        "source": meta_l43_c3
    },
    {
        "name": "NITTA YUMA'S WILHELM BURGHOLZ", "sex": "Male", "registration_number": "786472",
        "birth_date": "Mar. 3, 1930", "color": "Blk, rust mkgs",
        "owner": "W. L. Lyons, Jr.", "owner_location": "Harrods Creek, Ky.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Ellen v Friedewald", "dam_registration_number": "574498",
        "source": meta_l43_c3
    },
    {
        "name": "PAL POHLINDORF", "sex": "Female", "registration_number": "786122",
        "birth_date": "Aug. 4, 1927", "color": "Blk & tn",
        "owner": "George Nestra", "owner_location": None,
        "breeder": "Wm. M. Pohl", "breeder_location": "Cedarburg, Wis.",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Zoe v Melrapp", "dam_registration_number": "384020",
        "source": meta_l43_c3
    },
    {
        "name": "PEGGY V SULTZENBERG", "sex": "Female", "registration_number": "786587",
        "birth_date": "Oct. 13, 1930", "color": "Blk & tn",
        "owner": "Mary E. Berghoff", "owner_location": None,
        "breeder": "J. P. Porter", "breeder_location": "Dayton, Ohio",
        "sire": "Bodo v Rolandsburg", "sire_registration_number": "583887",
        "dam": "Rowdy Girl", "dam_registration_number": "685589",
        "source": meta_l43_c3
    },
    {
        "name": "PRINCESS FRIEDA", "sex": "Female", "registration_number": "783720",
        "birth_date": "Jan. 26, 1929", "color": "Blk & tn",
        "owner": "Frank Kusenback", "owner_location": None,
        "breeder": "Edward C. Heil", "breeder_location": "Chicago, Ill.",
        "sire": "Chappie v Bernard", "sire_registration_number": "698451",
        "dam": "Queen Isolde", "dam_registration_number": "709288",
        "source": meta_l43_c3
    },
    {
        "name": "PRINZ ULTO OF PONTCHARTRAIN", "sex": "Male", "registration_number": "784244",
        "birth_date": "July 15, 1930", "color": "Blk rd",
        "owner": "Mrs. Jessie Greene", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Baron v Bohlman", "sire_registration_number": "741281",
        "dam": "Edith of Pontchartrain", "dam_registration_number": "757517",
        "source": meta_l43_c3
    }
]

# Leaf 44, Column 1 (8 dogs down to POINTERS)
c3_dogs = [
    {
        "name": "PRINZ V WALFENBUTTLE", "sex": "Male", "registration_number": "783754",
        "birth_date": "Apr. 1, 1927", "color": "Blk & tn",
        "owner": "Hazel Grittner", "owner_location": None,
        "breeder": "Carl A. Thiemann", "breeder_location": "Omaha, Nebr.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Alma v Waidachgrund", "dam_registration_number": "463069",
        "source": meta_l44_c1
    },
    {
        "name": "REBE OF MIDDLETOWN", "sex": "Female", "registration_number": "785733",
        "birth_date": "June 4, 1929", "color": "Blk & tn",
        "owner": "W. N. McCoy", "owner_location": "Middletown, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Rhea of Middletown", "dam_registration_number": "648661",
        "source": meta_l44_c1
    },
    {
        "name": "RED FOX V KRESSENSTEIN", "sex": "Male", "registration_number": "783978",
        "birth_date": "May 11, 1929", "color": "Rd & tn",
        "owner": "A. W. Herron, Jr.", "owner_location": None,
        "breeder": "Arnold D. Tam", "breeder_location": "Warren, Ind.",
        "sire": "Kress v Kressenstein", "sire_registration_number": "476479",
        "dam": "Betsy Klostersee", "dam_registration_number": "697787",
        "source": meta_l44_c1
    },
    {
        "name": "ROTH'S PAL", "sex": "Male", "registration_number": "783987",
        "birth_date": "Nov. 14, 1930", "color": "Blk & tn",
        "owner": "Mr. and Mrs. John Roth", "owner_location": None,
        "breeder": "Wm. H. Lawson", "breeder_location": "Detroit, Mich.",
        "sire": "Nuttall's Red", "sire_registration_number": "749373",
        "dam": "Lawson's Lily", "dam_registration_number": "587606",
        "source": meta_l44_c1
    },
    {
        "name": "THESSA V LOCARNO", "sex": "Female", "registration_number": "786482",
        "birth_date": "May 12, 1930", "color": "Blk & tn",
        "owner": "F. R. Winther", "owner_location": "Overland, Mo.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Hindu Prinz", "sire_registration_number": "540803",
        "dam": "Duchess v Nordheim", "dam_registration_number": "731377",
        "source": meta_l44_c1
    },
    {
        "name": "VONNITA", "sex": "Female", "registration_number": "787078",
        "birth_date": "Sept. 16, 1930", "color": "Blk & tn",
        "owner": "H. J. Pelstring", "owner_location": None,
        "breeder": "E. E. Carrier", "breeder_location": "Summerville, Pa.",
        "sire": "Rival v Kranichstein", "sire_registration_number": "515099",
        "dam": "Brunhilde v Sigalsburg", "dam_registration_number": "667532",
        "source": meta_l44_c1
    },
    {
        "name": "ZANDA V LOWENBERG", "sex": "Female", "registration_number": "785700",
        "birth_date": "Mar. 6, 1931", "color": "Blk, br mkgs",
        "owner": "A. C. Lowenberg", "owner_location": None,
        "breeder": "S. G. Gonzales", "breeder_location": "El Paso, Tex.",
        "sire": "Zander of Pontchartrain", "sire_registration_number": "559825",
        "dam": "Beda v Bohlman", "dam_registration_number": "715346",
        "source": meta_l44_c1
    },
    {
        "name": "ZEPP OF STARKANHART", "sex": "Female", "registration_number": "785474",
        "birth_date": "Sept. 21, 1930", "color": "Blk & tn",
        "owner": "Tom Primrose", "owner_location": None,
        "breeder": "F. C. Bowles", "breeder_location": "Hartville, Ohio",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Clea v Starkanhart", "dam_registration_number": "769173",
        "source": meta_l44_c1
    }
]

all_31_07 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1931-07 dogs: {len(all_31_07)}")
print(f"  Leaf 43 Col 2: {len(c1_dogs)}")
print(f"  Leaf 43 Col 3: {len(c2_dogs)}")
print(f"  Leaf 44 Col 1: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1931_07.json").write_text(json.dumps(all_31_07, indent=2), encoding="utf-8")
print("Saved verified 1931-07 records.")
