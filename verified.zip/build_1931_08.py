import json
from pathlib import Path

meta_l47_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-08-01_48_8", "date": "1931-08-01", "volume": "48", "issue": "8", "leaf": 47, "column": 3}
meta_l48_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-08-01_48_8", "date": "1931-08-01", "volume": "48", "issue": "8", "leaf": 48, "column": 1}
meta_l48_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-08-01_48_8", "date": "1931-08-01", "volume": "48", "issue": "8", "leaf": 48, "column": 2}

# Leaf 47, Column 3 bottom (Starts under PINSCHERS (Doberman) - 3 dogs)
c1_dogs = [
    {
        "name": "ARGO V RHEINADLER", "sex": "Male", "registration_number": "791021",
        "birth_date": "Aug. 20, 1929", "color": "Blk & tn",
        "owner": "Iver Nintzel", "owner_location": None,
        "breeder": "Fred Hollmann", "breeder_location": "Hoboken, N. J.",
        "sire": "Erco v Rheinadler", "sire_registration_number": "776552",
        "dam": "Caprice v Kioma", "dam_registration_number": "570512",
        "source": meta_l47_c3
    },
    {
        "name": "BABE V D ERSKINEBURG", "sex": "Female", "registration_number": "790865",
        "birth_date": "Aug. 20, 1929", "color": "Blk, rd",
        "owner": "C. T. Erskine", "owner_location": None,
        "breeder": "Francis R. Schuchman", "breeder_location": "Toledo, Ohio",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Diana of Maumee", "dam_registration_number": "628504",
        "source": meta_l47_c3
    },
    {
        "name": "BALTO OF RHINEGOLD", "sex": "Male", "registration_number": "789394",
        "birth_date": "Jan. 20, 1931", "color": "Blk & br",
        "owner": "Ballington C. DuVal", "owner_location": None,
        "breeder": "J. C. Zimmerman", "breeder_location": "Detroit, Mich.",
        "sire": "Modern v Simmenau Rhinegold", "sire_registration_number": "768281",
        "dam": "Alli of Rhinegold", "dam_registration_number": "560310",
        "source": meta_l47_c3
    }
]

# Leaf 48, Column 1 (21 dogs)
c2_dogs = [
    {
        "name": "BAYDEN-BAYDEN", "sex": "Female", "registration_number": "788258",
        "birth_date": "Sept. 14, 1927", "color": "Blk & tn",
        "owner": "Betty Walsh", "owner_location": None,
        "breeder": "Emil Pfeiffer", "breeder_location": "Woodside, L. I., N. Y.",
        "sire": "Cy of Syosset", "sire_registration_number": "558079",
        "dam": "Jill of Jonedith", "dam_registration_number": "595853",
        "source": meta_l48_c1
    },
    {
        "name": "BESSI V BRANDENBURG", "sex": "Female", "registration_number": "787760",
        "birth_date": "Dec. 19, 1928", "color": "Blk rd",
        "owner": "Kettle Cove Kennels", "owner_location": None,
        "breeder": "Kurt Westphal", "breeder_location": "Germany",
        "sire": "Hamlet v Herthasee", "sire_registration_number": None,
        "dam": "Elfe v d Volkerruhe", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Amor v Gotterfelsen", "registration_number": None},
            {"role": "dam_of_dam", "name": "Asta v d Volkerruhe", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Max v Isenburg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Zara v Friedewald", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Melitta v Parthengrund", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Comtess v Steyerberg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Arno v d Weichselburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Ali v Waldloh", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_l48_c1
    },
    {
        "name": "BLITZ III", "sex": "Male", "registration_number": "791052",
        "birth_date": "Nov. 23, 1930", "color": "Blk & rd",
        "owner": "John Chas. Miller", "owner_location": None,
        "breeder": "F. R. Kingman", "breeder_location": "N. Y. City",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Mitzie II v Blankenburg", "dam_registration_number": "735682",
        "source": meta_l48_c1
    },
    {
        "name": "CLARE V LENTES", "sex": "Female", "registration_number": "789531",
        "birth_date": "Jan. 17, 1931", "color": "Blk, tn mkgs",
        "owner": "Valentine V. Milde", "owner_location": None,
        "breeder": "J. Richard Barnes", "breeder_location": "Joliet, Ill.",
        "sire": "Hillacre Rowdy", "sire_registration_number": "778563",
        "dam": "Mina Faithful", "dam_registration_number": "611899",
        "source": meta_l48_c1
    },
    {
        "name": "DEEKA V SCHUESS", "sex": "Male", "registration_number": "791651",
        "birth_date": "Jan. 17, 1931", "color": "Blk & tn",
        "owner": "Edmund C. Jensen", "owner_location": None,
        "breeder": "Edward D. Van Tassel, Jr.", "breeder_location": "Norwich, Conn.",
        "sire": "Von Wedon's Max Schuess", "sire_registration_number": "716479",
        "dam": "Juli v Schuess", "dam_registration_number": "544802",
        "source": meta_l48_c1
    },
    {
        "name": "DELL MARRIE V LOCARNO", "sex": "Female", "registration_number": "788748",
        "birth_date": "May 12, 1930", "color": "Blk & tn",
        "owner": "F. R. Winther", "owner_location": "Overland, Mo.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Hindu Prinz", "sire_registration_number": "540803",
        "dam": "Duchess v Nordheim", "dam_registration_number": "731377",
        "source": meta_l48_c1
    },
    {
        "name": "DHU VARREN'S MARQUITA", "sex": "Female", "registration_number": "789806",
        "birth_date": "July 4, 1930", "color": "Blk & rd",
        "owner": "Edward A. Hunter", "owner_location": "Ann Arbor, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Marko v Siegerpark", "sire_registration_number": "601008",
        "dam": "Anita v Burghofplatz", "dam_registration_number": "649763",
        "source": meta_l48_c1
    },
    {
        "name": "DHU VARREN'S MATE", "sex": "Male", "registration_number": "789807",
        "birth_date": "July 4, 1930", "color": "Blk & rd",
        "owner": "Edward A. Hunter", "owner_location": "Ann Arbor, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Marko v Siegerpark", "sire_registration_number": "601008",
        "dam": "Anita v Burghofplatz", "dam_registration_number": "649763",
        "source": meta_l48_c1
    },
    {
        "name": "DINA V D HORSTBURG", "sex": "Female", "registration_number": "789133",
        "birth_date": "Aug. 1, 1929", "color": "Blk, rd rust mkgs",
        "owner": "Harry B. Lathrop", "owner_location": None,
        "breeder": "Mary Cobb Wilson", "breeder_location": "Springfield, Pa.",
        "sire": "Trail 'Em Adonis", "sire_registration_number": "709104",
        "dam": "Huerta v d Horstburg", "dam_registration_number": "712028",
        "source": meta_l48_c1
    },
    {
        "name": "DOBBIE V STEUBEN", "sex": "Male", "registration_number": "791652",
        "birth_date": "July 5, 1930", "color": "Rd & tn",
        "owner": "William Bartholomew, Jr.", "owner_location": None,
        "breeder": "J. R. Masters", "breeder_location": "Bowerston, Ohio",
        "sire": "Printz Arto v d Spreehort", "sire_registration_number": "559555",
        "dam": "Magelone v Nibelungenhort", "dam_registration_number": "483923",
        "source": meta_l48_c1
    },
    {
        "name": "DOVER V BLANKENBURG", "sex": "Male", "registration_number": "790907",
        "birth_date": "June 20, 1930", "color": "Blk & tn",
        "owner": "Wilhelm Konow", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "Cupertino, Calif.",
        "sire": "Pal v Blankenburg", "sire_registration_number": "635974",
        "dam": "Altara v Riga", "dam_registration_number": "699653",
        "source": meta_l48_c1
    },
    {
        "name": "DUKE V SCHORNDORF", "sex": "Male", "registration_number": "787769",
        "birth_date": "July 22, 1930", "color": "Blk & rd",
        "owner": "J. M. James, M. D.", "owner_location": None,
        "breeder": "G. C. Jaco", "breeder_location": "Uniontown, Pa.",
        "sire": "Peter v Roemerhof", "sire_registration_number": "616494",
        "dam": "Nada v Grossmount", "dam_registration_number": "737077",
        "source": meta_l48_c1
    },
    {
        "name": "FAUST RULUJA", "sex": "Male", "registration_number": "791650",
        "birth_date": "Jan. 23, 1931", "color": "Blk & tn",
        "owner": "Morris Simon", "owner_location": None,
        "breeder": "Mr. and Mrs. Albert T. Rahner", "breeder_location": "Philadelphia, Pa.",
        "sire": "Redroof Exorcist", "sire_registration_number": "637314",
        "dam": "Gertrud v Burgund", "dam_registration_number": "750713",
        "source": meta_l48_c1
    },
    {
        "name": "FRAULEIN MARIE", "sex": "Female", "registration_number": "790609",
        "birth_date": "Sept. 14, 1928", "color": "Blk & tn",
        "owner": "C. B. Duryea", "owner_location": None,
        "breeder": "Herbert Simeral", "breeder_location": "Granville, Ohio",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Lady Gretchen", "dam_registration_number": "574220",
        "source": meta_l48_c1
    },
    {
        "name": "FREDERICKA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "790725",
        "birth_date": "Sept. 25, 1929", "color": "Blk, rd",
        "owner": "E. Mercer Morton", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Hesta of Pontchartrain", "dam_registration_number": "607184",
        "source": meta_l48_c1
    },
    {
        "name": "FRIEDA V ROEMERHOF", "sex": "Female", "registration_number": "787683",
        "birth_date": "Apr. 28, 1930", "color": "Rd & tn",
        "owner": "Mrs. Fanny Schopper", "owner_location": None,
        "breeder": "William Goldbecker", "breeder_location": "New Haven, Conn.",
        "sire": "Binks", "sire_registration_number": "712217",
        "dam": "Zita v Bramberg", "dam_registration_number": "705275",
        "source": meta_l48_c1
    },
    {
        "name": "FRIEDRICH OF PONTCHARTRAIN", "sex": "Male", "registration_number": "791649",
        "birth_date": "Oct. 17, 1930", "color": "Blk & rd",
        "owner": "Paul L. Garver", "owner_location": None,
        "breeder": "Mr. and Mrs. Philip J. Rhein", "breeder_location": "Cincinnati, Ohio",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Pontchartrain's Princess Tora", "dam_registration_number": "753052",
        "source": meta_l48_c1
    },
    {
        "name": "FRITZ V BISMARK", "sex": "Male", "registration_number": "790503",
        "birth_date": "Sept. 25, 1929", "color": "Blk & tn",
        "owner": "W. H. Wilhelm", "owner_location": None,
        "breeder": "Sally G. Chamberlin", "breeder_location": "Ft. Riley, Kans.",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Faustina v d Koningstad", "dam_registration_number": "704007",
        "source": meta_l48_c1
    },
    {
        "name": "GRETEL V HEUSEN", "sex": "Female", "registration_number": "787597",
        "birth_date": "Jan. 4, 1930", "color": "Chestnut br",
        "owner": "Edward Barnes", "owner_location": None,
        "breeder": "Edw. R. Shelmerdine, III", "breeder_location": "Wallingford, Pa.",
        "sire": "Krumm v d Spree", "sire_registration_number": "500610",
        "dam": "Gretchen v Heusen", "dam_registration_number": "636348",
        "source": meta_l48_c1
    },
    {
        "name": "HINDOO V TESSEN", "sex": "Male", "registration_number": "789660",
        "birth_date": "Dec. 17, 1927", "color": "Blk, rust rd mkgs",
        "owner": "Carl J. Bischoff", "owner_location": None,
        "breeder": "E. Arthur Ball", "breeder_location": "Muncie, Ind.",
        "sire": "A Hindoo of Pontchartrain", "sire_registration_number": "440792",
        "dam": "Della K. Tessen", "dam_registration_number": "416876",
        "source": meta_l48_c1
    },
    {
        "name": "IMA OF LAWNWOOD", "sex": "Female", "registration_number": "791223",
        "birth_date": "July 21, 1929", "color": "Blk & tn",
        "owner": "Laura B. Gibson", "owner_location": "Hales Corners, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Adie v Reyem", "dam_registration_number": "517408",
        "source": meta_l48_c1
    },
    {
        "name": "JACKA V WYCK", "sex": "Male", "registration_number": "790608",
        "birth_date": "Mar. 5, 1926", "color": "Blk & tn",
        "owner": "Carl Stear", "owner_location": None,
        "breeder": "C. B. Duryea", "breeder_location": "Columbus, Ohio",
        "sire": "Arnold v Cartenberg", "sire_registration_number": "435139",
        "dam": "Princess Greta of Mapleholm", "dam_registration_number": "523818",
        "source": meta_l48_c1
    }
]

# Leaf 48, Column 2 (21 dogs down to POINTERS)
c3_dogs = [
    {
        "name": "KARL V MIDDLETOWN", "sex": "Male", "registration_number": "790866",
        "birth_date": "Sept. 25, 1928", "color": "Blk, tn mkd",
        "owner": "C. G. Watson", "owner_location": None,
        "breeder": "W. N. McCoy", "breeder_location": "Middletown, Ohio",
        "sire": "Rappo of Middletown", "sire_registration_number": "648659",
        "dam": "Gira v Nibelungenhort", "dam_registration_number": "491924",
        "source": meta_l48_c2
    },
    {
        "name": "KOMET V D RESIDENZ", "sex": "Male", "registration_number": "787761",
        "birth_date": "May 30, 1927", "color": "Blk rd",
        "owner": "Otto C. Beuke", "owner_location": None,
        "breeder": "H. Flach", "breeder_location": "Germany",
        "sire": "Alto v Sigalsburg", "sire_registration_number": None,
        "dam": "Frohgunde v d Residenz", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Rival v Kranichstein", "registration_number": "515099"},
            {"role": "dam_of_dam", "name": "Clare v d Residenz", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Brummer Hoch-Wart", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Eia v Langerode", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Diethelm v Hindendorff", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Agathe v Romerwall", "registration_number": None},
            {"role": "sire_of_sire", "name": "Lux v d Blankenburg", "registration_number": "571492"},
            {"role": "dam_of_sire", "name": "Lotte v Roneckenstein", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Dora v Wiesengrund", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Burschel v Simmenau", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Asta Voss", "registration_number": None}
        ],
        "source": meta_l48_c2
    },
    {
        "name": "LADY OLMA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "791314",
        "birth_date": "Oct. 26, 1929", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Freia v d Buetersburg of Ardwin", "dam_registration_number": "499561",
        "source": meta_l48_c2
    },
    {
        "name": "LINDY V FRIEDENSBURG", "sex": "Male", "registration_number": "790390",
        "birth_date": "Aug. 16, 1927", "color": "Blk, rd rust",
        "owner": "Delbert C. Cox", "owner_location": None,
        "breeder": "C. J. Cline", "breeder_location": "Tulsa, Okla.",
        "sire": "Arno v Burgfried", "sire_registration_number": "426603",
        "dam": "Linda v Friedensdorf", "dam_registration_number": "569829",
        "source": meta_l48_c2
    },
    {
        "name": "MITZI V FRITZLEN", "sex": "Female", "registration_number": "788138",
        "birth_date": "Feb. 3, 1930", "color": "Blk & tn",
        "owner": "D. W. Fritzlen", "owner_location": None,
        "breeder": "Michael S. Morris", "breeder_location": "Philadelphia, Pa.",
        "sire": "Duke v Stroheim", "sire_registration_number": "563574",
        "dam": "Brunhilda", "dam_registration_number": "580969",
        "source": meta_l48_c2
    },
    {
        "name": "OMAR OF PONTCHARTRAIN", "sex": "Male", "registration_number": "791313",
        "birth_date": "Sept. 10, 1928", "color": "Blk & br",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Pontchartrain's Freya v Stresow", "dam_registration_number": "422451",
        "source": meta_l48_c2
    },
    {
        "name": "PILKINGTON'S RAVEN", "sex": "Male", "registration_number": "790683",
        "birth_date": "June 29, 1930", "color": "Blk, rust mkgs",
        "owner": "H. W. Pilkington", "owner_location": None,
        "breeder": "Mrs. C. A. Bergman", "breeder_location": "Ottumwa, Iowa",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Sigalsburg Kolstree", "dam_registration_number": "778483",
        "source": meta_l48_c2
    },
    {
        "name": "PRINCESS PEN O'PONTCHARTRAIN", "sex": "Female", "registration_number": "791315",
        "birth_date": "Apr. 12, 1930", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721108",
        "dam": "Hertha of Pontchartrain", "dam_registration_number": "610096",
        "source": meta_l48_c2
    },
    {
        "name": "PRINZ BENNO V D KONINGSTAD", "sex": "Male", "registration_number": "788003",
        "birth_date": "Feb. 2, 1930", "color": "Blk, rd rust mkgs",
        "owner": "L. McK. Crumrine", "owner_location": None,
        "breeder": "W. L. Lyons, Jr.", "breeder_location": "Harrods Creek, Ky.",
        "sire": "Prince Alexis of Ardene", "sire_registration_number": "599344",
        "dam": "Frieda of Pontchartrain", "dam_registration_number": "511185",
        "source": meta_l48_c2
    },
    {
        "name": "QUEENIE V PRIESKORN", "sex": "Female", "registration_number": "789448",
        "birth_date": "Mar. 27, 1929", "color": "Blk & tn",
        "owner": "Carl C. Prieskorn", "owner_location": None,
        "breeder": "Fred M. Berger", "breeder_location": "Chicago, Ill.",
        "sire": "Caballero v Wassertor", "sire_registration_number": "628898",
        "dam": "Freya v Bergerhof", "dam_registration_number": "578494",
        "source": meta_l48_c2
    },
    {
        "name": "QUEENY MARGARETENAU", "sex": "Female", "registration_number": "788772",
        "birth_date": "Dec. 2, 1928", "color": "Blk & rust tn",
        "owner": "Richard E. Doran", "owner_location": None,
        "breeder": "Sofie Frolich", "breeder_location": "Cincinnati, Ohio",
        "sire": "Cito v d Margaretanau", "sire_registration_number": "685406",
        "dam": "Jouda v Steigerwald", "dam_registration_number": "686413",
        "source": meta_l48_c2
    },
    {
        "name": "RAPPO V DEUTSCHER", "sex": "Male", "registration_number": "790787",
        "birth_date": "July 2, 1930", "color": "Blk, tn mkgs",
        "owner": "Clifford J. Leckliter", "owner_location": None,
        "breeder": "Harry S. Irwin", "breeder_location": "Delaware, Ohio",
        "sire": "Arno v d Blankenburg", "sire_registration_number": "699804",
        "dam": "Gerta v Waldschloss", "dam_registration_number": "762942",
        "source": meta_l48_c2
    },
    {
        "name": "REA OF BORNHOLM", "sex": "Female", "registration_number": "790490",
        "birth_date": "Dec. 4, 1929", "color": "Rd & tn mkgs",
        "owner": "J. Edgar Outcall", "owner_location": None,
        "breeder": "Minnie R. Hansen", "breeder_location": "Manchester, Ohio",
        "sire": "Cito v d Margaretanau", "sire_registration_number": "685406",
        "dam": "Senta of Bornholm", "dam_registration_number": "790489",
        "source": meta_l48_c2
    },
    {
        "name": "REVA V BISMARK", "sex": "Female", "registration_number": "790502",
        "birth_date": "Sept. 25, 1929", "color": "Rd & tn",
        "owner": "W. H. Wilhelm", "owner_location": None,
        "breeder": "Sally G. Chamberlin", "breeder_location": "Ft. Riley, Kans.",
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Faustina v d Koningstad", "dam_registration_number": "704007",
        "source": meta_l48_c2
    },
    {
        "name": "REX V NIBELUNGENHORT", "sex": "Male", "registration_number": "790504",
        "birth_date": "June 3, 1926", "color": "Blk, org mks",
        "owner": "Frank E. Rutherford", "owner_location": None,
        "breeder": "Mrs. A. W. Clem", "breeder_location": "Dallas, Tex.",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Jutta v Walden-Vortrupp", "dam_registration_number": "469914",
        "source": meta_l48_c2
    },
    {
        "name": "ROBINSON'S SIR FLASH", "sex": "Male", "registration_number": "788532",
        "birth_date": "May 18, 1930", "color": "Blk & tn",
        "owner": "Oscar W. Haertlein", "owner_location": None,
        "breeder": "R. L. Gahan", "breeder_location": "Pewaukee, Wis.",
        "sire": "Robinson's Sully", "sire_registration_number": "706298",
        "dam": "Robinson's Diana", "dam_registration_number": "685707",
        "source": meta_l48_c2
    },
    {
        "name": "SACHA V ZEPPELIN", "sex": "Female", "registration_number": "788259",
        "birth_date": "Aug. 6, 1928", "color": "Blk & tn",
        "owner": "Erica M. Rosvold", "owner_location": None,
        "breeder": "Betty Walsh", "breeder_location": "N. Y. City",
        "sire": "Cy of Syosset", "sire_registration_number": "558079",
        "dam": "Bayden-Bayden", "dam_registration_number": "788258",
        "source": meta_l48_c2
    },
    {
        "name": "SENTA OF BORNHOLM", "sex": "Female", "registration_number": "790489",
        "birth_date": "May 7, 1928", "color": "Blk & br mkgs",
        "owner": "Minnie R. Hansen", "owner_location": None,
        "breeder": "Carl N. Hansen", "breeder_location": "Cincinnati, Ohio",
        "sire": "Hamer of Bornholm", "sire_registration_number": "362662",
        "dam": "Flora v d Spree", "dam_registration_number": "606727",
        "source": meta_l48_c2
    },
    {
        "name": "SEVERA OF GONZALA", "sex": "Female", "registration_number": "790477",
        "birth_date": "Mar. 6, 1931", "color": "Blk, br mkgs",
        "owner": "W. M. Reed", "owner_location": None,
        "breeder": "S. G. Gonzales", "breeder_location": "El Paso, Tex.",
        "sire": "Zander of Pontchartrain", "sire_registration_number": "559825",
        "dam": "Beda v Bohlman", "dam_registration_number": "715346",
        "source": meta_l48_c2
    },
    {
        "name": "SIGAL V JUDYGUARD", "sex": "Male", "registration_number": "791444",
        "birth_date": "Oct. 1, 1930", "color": "Blk & tn",
        "owner": "Will Judy", "owner_location": None,
        "breeder": "Ernest C. Torrez", "breeder_location": "Chicago, Ill.",
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Burga v Torrez", "dam_registration_number": "628206",
        "source": meta_l48_c2
    },
    {
        "name": "TAD OF MICKBURN", "sex": "Male", "registration_number": "789460",
        "birth_date": "Nov. 21, 1927", "color": "Blk, rd rust mkgs",
        "owner": "Mickburn Kennels", "owner_location": "Eldorado, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Red Roof Rowdy", "sire_registration_number": "392482",
        "dam": "Francis of Mickburn", "dam_registration_number": "580532",
        "source": meta_l48_c2
    }
]

all_31_08 = c1_dogs + c2_dogs + c3_dogs
print(f"Total compiled 1931-08 dogs: {len(all_31_08)}")
print(f"  Leaf 47 Col 3: {len(c1_dogs)}")
print(f"  Leaf 48 Col 1: {len(c2_dogs)}")
print(f"  Leaf 48 Col 2: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1931_08.json").write_text(json.dumps(all_31_08, indent=2), encoding="utf-8")
print("Saved verified 1931-08 records.")
