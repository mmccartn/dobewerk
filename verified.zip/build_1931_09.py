import json
from pathlib import Path

meta_l33_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-09-01_48_9", "date": "1931-09-01", "volume": "48", "issue": "9", "leaf": 33, "column": 3}
meta_l34_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-09-01_48_9", "date": "1931-09-01", "volume": "48", "issue": "9", "leaf": 34, "column": 1}

# Leaf 33, Column 3 (Starts under PINSCHERS (Doberman) - 21 dogs)
c1_dogs = [
    {
        "name": "APOLLO V SEDREVLA", "sex": "Male", "registration_number": "791848",
        "birth_date": "May 20, 1930", "color": "Blk & tn",
        "owner": "Karl P's Graeuwen", "owner_location": "W. Caldwell, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Otello of Pontchartrain", "sire_registration_number": "667919",
        "dam": "Fay Sedrevla", "dam_registration_number": "695049",
        "source": meta_l33_c3
    },
    {
        "name": "ARNA OF STARKANHART", "sex": "Female", "registration_number": "792088",
        "birth_date": "Sept. 21, 1930", "color": "Blk & tn",
        "owner": "F. C. Bowles", "owner_location": "Hartville, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Hyde of Pontchartrain", "sire_registration_number": "477108",
        "dam": "Clea v Starkanhartt", "dam_registration_number": "769173",
        "source": meta_l33_c3
    },
    {
        "name": "BABETTE V SIGALSBURG", "sex": "Female", "registration_number": "793083",
        "birth_date": "Mar. 30, 1930", "color": "Blk & rust tn",
        "owner": "Mrs. Margaret Schang", "owner_location": "Seattle, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Fritzie v Dombachtal", "sire_registration_number": "703639",
        "dam": "Celia v Sigalsburg", "dam_registration_number": "705091",
        "source": meta_l33_c3
    },
    {
        "name": "BEAU MONDE", "sex": "Male", "registration_number": "794623",
        "birth_date": "Jan. 30, 1931", "color": "Lt & dk tn",
        "owner": "Gustavus A. Pfeiffer", "owner_location": None,
        "breeder": "Philip Jochum", "breeder_location": "Chicago, Ill.",
        "sire": "Kuno v Bergerhof", "sire_registration_number": "685988",
        "dam": "Lucky", "dam_registration_number": "759176",
        "source": meta_l33_c3
    },
    {
        "name": "BEAUTY", "sex": "Female", "registration_number": "794152",
        "birth_date": "Dec. 21, 1929", "color": "Blk & rust rd",
        "owner": "Peter Schultz", "owner_location": None,
        "breeder": "John Hieber", "breeder_location": "Philadelphia, Pa.",
        "sire": "Dando De Haven", "sire_registration_number": "556187",
        "dam": "Senta Rathjen", "dam_registration_number": "518308",
        "source": meta_l33_c3
    },
    {
        "name": "BEAUTY V BRAUSCH", "sex": "Female", "registration_number": "793204",
        "birth_date": "Mar. 4, 1930", "color": "Blk & tn",
        "owner": "George C. Mitacek", "owner_location": None,
        "breeder": "Mrs. Math Brausch", "breeder_location": "Chicago, Ill.",
        "sire": "Peter v Roemerhof", "sire_registration_number": "616494",
        "dam": "Lady v Wilhelm", "dam_registration_number": "699515",
        "source": meta_l33_c3
    },
    {
        "name": "BODO V WILSONA HOF", "sex": "Male", "registration_number": "792635",
        "birth_date": "July 5, 1930", "color": "Blk & tn",
        "owner": "Paul R. Quigg", "owner_location": None,
        "breeder": "Georgine Y. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Bodo v Askanierland", "sire_registration_number": "736236",
        "dam": "Bernie v Wilsona", "dam_registration_number": "672372",
        "source": meta_l33_c3
    },
    {
        "name": "BOY", "sex": "Male", "registration_number": "794501",
        "birth_date": "Apr. 30, 1931", "color": "Blk & tn",
        "owner": "Gene Carroll", "owner_location": None,
        "breeder": "Carl A. Thiemann", "breeder_location": "Omaha, Nebr.",
        "sire": "Favorit v d Wietze", "sire_registration_number": "549017",
        "dam": "Alma v Waidachgrund", "dam_registration_number": "463069",
        "source": meta_l33_c3
    },
    {
        "name": "CAPTAIN GREET OF GONZALA", "sex": "Male", "registration_number": "794680",
        "birth_date": "Mar. 6, 1931", "color": "Blk, br mkgs",
        "owner": "W. M. Reed", "owner_location": "El Paso, Tex.",
        "breeder": "S. G. Gonzales", "breeder_location": "El Paso, Tex.",
        "sire": "Zander of Pontchartrain", "sire_registration_number": "559825",
        "dam": "Beda v Bohlman", "dam_registration_number": "715346",
        "source": meta_l33_c3
    },
    {
        "name": "CHRISTFIELD V HUESFIELD", "sex": "Male", "registration_number": "794365",
        "birth_date": "Mar. 29, 1929", "color": "Blk & tn",
        "owner": "Frank Bissman", "owner_location": None,
        "breeder": "Oscar L. Simpson", "breeder_location": "Nashville, Tenn.",
        "sire": "Ochsner's Son of Rival", "sire_registration_number": "612378",
        "dam": "Asta v Nashville", "dam_registration_number": "675400",
        "source": meta_l33_c3
    },
    {
        "name": "CISSY V SALLIE", "sex": "Female", "registration_number": "793538",
        "birth_date": "Apr. 22, 1931", "color": "Blk, rd",
        "owner": "Harry L. McClellan", "owner_location": None,
        "breeder": "H. B. Juell", "breeder_location": "Glen Ellyn, Ill.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Sallie v Allie", "dam_registration_number": "605877",
        "source": meta_l33_c3
    },
    {
        "name": "CLEO V PERBOCK", "sex": "Female", "registration_number": "791829",
        "birth_date": "Apr. 26, 1930", "color": "Blk, mhgy mkgs",
        "owner": "Margaret E. Bock", "owner_location": "Santa Barbara, Calif.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Duke v Strossen", "sire_registration_number": "500005",
        "dam": "Asta v Tilhagen", "dam_registration_number": "530158",
        "source": meta_l33_c3
    },
    {
        "name": "COUNT BALDO OF PONTCHARTRAIN", "sex": "Male", "registration_number": "793086",
        "birth_date": "Dec. 15, 1930", "color": "Blk & rd",
        "owner": "I. W. Steele", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Benno v Glucksburg", "sire_registration_number": "605000",
        "dam": "Edith of Pontchartrain", "dam_registration_number": "757517",
        "source": meta_l33_c3
    },
    {
        "name": "COUNTESS BELL O'PONTCHARTRAIN", "sex": "Female", "registration_number": "793167",
        "birth_date": "Dec. 15, 1930", "color": "Blk & rd",
        "owner": "Edward I. Hocker", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Benno v Glucksburg", "sire_registration_number": "605000",
        "dam": "Edith of Pontchartrain", "dam_registration_number": "757517",
        "source": meta_l33_c3
    },
    {
        "name": "DEXTER", "sex": "Male", "registration_number": "793660",
        "birth_date": "May 17, 1930", "color": "Blk & tn",
        "owner": "Mrs. Luella Shaffer", "owner_location": None,
        "breeder": "F. H. Helmreich", "breeder_location": "Columbus, Ohio",
        "sire": "Lax v Romer", "sire_registration_number": "762382",
        "dam": "Wirley Euchner", "dam_registration_number": "747753",
        "source": meta_l33_c3
    },
    {
        "name": "DIANA LINDY LOU", "sex": "Female", "registration_number": "794557",
        "birth_date": "May 26, 1931", "color": "Blk, rust mkgs",
        "owner": "J. Clay Williams", "owner_location": None,
        "breeder": "G. W. Hatfield, Jr.", "breeder_location": "Williamson, W. Va.",
        "sire": "Nitta Yuma's Wilhelm Burgholz", "sire_registration_number": "786472",
        "dam": "Prinzess Fidelia v Burgholz", "dam_registration_number": "735298",
        "source": meta_l33_c3
    },
    {
        "name": "DUKE VALDE V ESSWEIN", "sex": "Male", "registration_number": "794595",
        "birth_date": "Nov. 20, 1929", "color": "Blk & tn",
        "owner": "Valentine V. Milde", "owner_location": None,
        "breeder": "Josef Hodina", "breeder_location": "Lyons, Ill.",
        "sire": "Fritz v Duffield", "sire_registration_number": "704573",
        "dam": "Queen Dutch", "dam_registration_number": "605234",
        "source": meta_l33_c3
    },
    {
        "name": "EDDY V WILHELMSRUH", "sex": "Female", "registration_number": "792437",
        "birth_date": "May 6, 1925", "color": "Br & rd",
        "owner": "Artur Mentzel", "owner_location": None,
        "breeder": "Fritz Guttwein", "breeder_location": "Germany",
        "sire": "Manfred v Ostersee", "sire_registration_number": None,
        "dam": "Bella v Baketal", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Harras v Ostersee", "registration_number": None},
            {"role": "dam_of_dam", "name": "Hexe v Augustaburg", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Peter v Baketal", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Betty v Burgwall", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Salto v Rottal", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Freya v Ostersee", "registration_number": None},
            {"role": "sire_of_sire", "name": "Eckewart v Ostersee", "registration_number": None},
            {"role": "dam_of_sire", "name": "Blanka v Ostersee", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Wanda Knoll", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Salto v Rottal", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Eddy v Ostersee", "registration_number": None}
        ],
        "source": meta_l33_c3
    },
    {
        "name": "GABY DESLYS", "sex": "Female", "registration_number": "793220",
        "birth_date": "May 13, 1928", "color": "Rd & tn",
        "owner": "W. W. Overton", "owner_location": None,
        "breeder": "Sally A. Chamberlin", "breeder_location": "Fort Riley, Kans.",
        "sire": "Faust v Deutschen-Eck", "sire_registration_number": "704006",
        "dam": "Lotta v Dowd", "dam_registration_number": "551479",
        "source": meta_l33_c3
    },
    {
        "name": "GENTLEMAN", "sex": "Male", "registration_number": "791780",
        "birth_date": "May 13, 1929", "color": "Blk & tn",
        "owner": "Marjorie B. Stilwell", "owner_location": None,
        "breeder": "E. De L. Fouque", "breeder_location": "Media, Pa.",
        "sire": "Red Roof Rufus", "sire_registration_number": "491422",
        "dam": "Babette v Jagerhof", "dam_registration_number": "521089",
        "source": meta_l33_c3
    },
    {
        "name": "GINGER V RAVINHOFFEN", "sex": "Male", "registration_number": "792089",
        "birth_date": "Jan. 22, 1931", "color": "Blk & rust",
        "owner": "Theodore H. Kapnek", "owner_location": None,
        "breeder": "James A. Humphrys", "breeder_location": "Cynwyd, Pa.",
        "sire": "Redroof Exorcist", "sire_registration_number": "637314",
        "dam": "Bitte", "dam_registration_number": "693898",
        "source": meta_l33_c3
    }
]

# Leaf 34, Column 1 (16 dogs down to PINSCHER (Miniature))
c2_dogs = [
    {
        "name": "GRETCHEN OF HEIDELBERG", "sex": "Female", "registration_number": "792535",
        "birth_date": "May 12, 1929", "color": "Blk & rd",
        "owner": "Anna Kaufer", "owner_location": None,
        "breeder": "G. Evans", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Rolla of Pontchartrain", "dam_registration_number": "613805",
        "source": meta_l34_c1
    },
    {
        "name": "GRIQUA SOPHIA", "sex": "Female", "registration_number": "792701",
        "birth_date": "Dec. 17, 1927", "color": "Blk & tn",
        "owner": "J. A. Collins", "owner_location": None,
        "breeder": "Geo. H. Jones", "breeder_location": "Danville, Ill.",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Princess v Rudolphsburg", "dam_registration_number": "569711",
        "source": meta_l34_c1
    },
    {
        "name": "HAMLET V HERTHASEE", "sex": "Male", "registration_number": "793750",
        "birth_date": "Nov. 29, 1926", "color": "Blk, rd",
        "owner": "C. W. Von Sallet", "owner_location": None,
        "breeder": "Felix Desenick", "breeder_location": "Germany",
        "sire": "Alto v Sigalsburg", "sire_registration_number": None,
        "dam": "Comtess v Steyerberg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Arno v d Weichselburg", "registration_number": None},
            {"role": "dam_of_dam", "name": "Ali v Waldloh", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Danilo v d Krone", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Lady Bittner", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Achim v Langerode", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Asta v d Finohohe", "registration_number": None},
            {"role": "sire_of_sire", "name": "Lux v d Blankenburg", "registration_number": "571492"},
            {"role": "dam_of_sire", "name": "Lotte v Roneckenstein", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Dora v Wiesengrund", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Burschel v Simmenau", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Asta Voss", "registration_number": None}
        ],
        "source": meta_l34_c1
    },
    {
        "name": "ILO V WILSONA HOF", "sex": "Male", "registration_number": "793235",
        "birth_date": "Apr. 6, 1930", "color": "Blk & tn",
        "owner": "Norma E. Drudge", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Astor Gottschalk", "sire_registration_number": "639147",
        "dam": "Ira v d Winterburg", "dam_registration_number": "736237",
        "source": meta_l34_c1
    },
    {
        "name": "KATARINA V EHRENBREITSTEIN", "sex": "Female", "registration_number": "792049",
        "birth_date": "May 24, 1930", "color": "Blk & rust",
        "owner": "C. C. Blanchard", "owner_location": None,
        "breeder": "George Pugh", "breeder_location": "Lawton, Okla.",
        "sire": "Kungs v Riga", "sire_registration_number": "492581",
        "dam": "Sally Dorn of Petershoff", "dam_registration_number": "719921",
        "source": meta_l34_c1
    },
    {
        "name": "LADY V SCHOICK", "sex": "Female", "registration_number": "793205",
        "birth_date": "May 17, 1930", "color": "Rd & tn",
        "owner": "Geo. Stephenson", "owner_location": None,
        "breeder": "F. H. Helmreich", "breeder_location": "Columbus, Ohio",
        "sire": "Lax v Romer", "sire_registration_number": "762382",
        "dam": "Wirley Euchner", "dam_registration_number": "747753",
        "source": meta_l34_c1
    },
    {
        "name": "LU CELIA", "sex": "Female", "registration_number": "793084",
        "birth_date": "Mar. 30, 1930", "color": "Blk & rust tn",
        "owner": "Mrs. Margaret Schang", "owner_location": "Seattle, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Fritzie v Dombachtal", "sire_registration_number": "703639",
        "dam": "Celia v Sigalsburg", "dam_registration_number": "705091",
        "source": meta_l34_c1
    },
    {
        "name": "MITZI V ROGERSCHMIDT", "sex": "Female", "registration_number": "793659",
        "birth_date": "Oct. 13, 1930", "color": "Blk, tn mkgs",
        "owner": "Robert G. Murtoff", "owner_location": None,
        "breeder": "Rogerschmidt Kennels", "breeder_location": "Bloomingburg, Ohio",
        "sire": "Adonis of Pontchartrain", "sire_registration_number": "710287",
        "dam": "Mitzi of Baseline", "dam_registration_number": "756521",
        "source": meta_l34_c1
    },
    {
        "name": "PATRICIAN GIRL", "sex": "Female", "registration_number": "793085",
        "birth_date": "Mar. 30, 1930", "color": "Blk & rust tn",
        "owner": "Mrs. Margaret Schang", "owner_location": "Seattle, Wash.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Fritzie v Dombachtal", "sire_registration_number": "703639",
        "dam": "Celia v Sigalsburg", "dam_registration_number": "705091",
        "source": meta_l34_c1
    },
    {
        "name": "PLATO V LOCARNO", "sex": "Male", "registration_number": "793444",
        "birth_date": "Sept. 2, 1930", "color": "Blk & tn",
        "owner": "F. R. Winther", "owner_location": None,
        "breeder": "N. M. Freund", "breeder_location": "St. Louis, Mo.",
        "sire": "Artus v Lenburg", "sire_registration_number": "733269",
        "dam": "Peppy v Nurschan", "dam_registration_number": "755498",
        "source": meta_l34_c1
    },
    {
        "name": "PRINZ NOAH OF PONTCHARTRAIN", "sex": "Male", "registration_number": "794681",
        "birth_date": "May 24, 1930", "color": "Blk, rd",
        "owner": "Earle C. Bailey", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Ilisa of Pontchartrain", "dam_registration_number": "571491",
        "source": meta_l34_c1
    },
    {
        "name": "PRINZ ZING OF PONTCHARTRAIN", "sex": "Male", "registration_number": "792717",
        "birth_date": "Sept. 4, 1929", "color": "Blk, rd",
        "owner": "Fred A. Wilson", "owner_location": None,
        "breeder": "S. W. Rogers", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Kona of Pontchartrain", "dam_registration_number": "719496",
        "source": meta_l34_c1
    },
    {
        "name": "REX V HINDENDORFF", "sex": "Male", "registration_number": "792636",
        "birth_date": "July 25, 1930", "color": "Blk & tn",
        "owner": "John H. Hook", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Franco Fra Duncan", "sire_registration_number": "770190",
        "dam": "Wanda v d Spree", "dam_registration_number": "620062",
        "source": meta_l34_c1
    },
    {
        "name": "ROBINSON'S MISS SALLY", "sex": "Female", "registration_number": "794451",
        "birth_date": "May 18, 1930", "color": "Blk & tn",
        "owner": "E. J. Robinson", "owner_location": None,
        "breeder": "R. L. Gahan", "breeder_location": "Pewaukee, Wis.",
        "sire": "Robinson's Sully", "sire_registration_number": "706298",
        "dam": "Robinson's Diana", "dam_registration_number": "685707",
        "source": meta_l34_c1
    },
    {
        "name": "RUSTY II", "sex": "Male", "registration_number": "791735",
        "birth_date": "Jan. 28, 1931", "color": "Rusty br & tn",
        "owner": "Alice E. Ferguson", "owner_location": None,
        "breeder": "John P. Ahrens", "breeder_location": "Cincinnati, Ohio",
        "sire": "Von Zwygart", "sire_registration_number": "773967",
        "dam": "Asta v Lueschenhof", "dam_registration_number": "660794",
        "source": meta_l34_c1
    },
    {
        "name": "ZEPP V HUNSTEIN", "sex": "Male", "registration_number": "793987",
        "birth_date": "June 14, 1930", "color": "Blk, tn mkgs",
        "owner": "Mrs. Geo. L. Higgins", "owner_location": None,
        "breeder": "Bert Young", "breeder_location": "Granville, Ohio",
        "sire": "Arno v Hohenburg", "sire_registration_number": "574221",
        "dam": "Asta v Huntstein", "dam_registration_number": "665159",
        "source": meta_l34_c1
    }
]

all_31_09 = c1_dogs + c2_dogs
print(f"Total compiled 1931-09 dogs: {len(all_31_09)}")
print(f"  Leaf 33 Col 3: {len(c1_dogs)}")
print(f"  Leaf 34 Col 1: {len(c2_dogs)}")

Path("stud-scrape/data/verified_1931_09.json").write_text(json.dumps(all_31_09, indent=2), encoding="utf-8")
print("Saved verified 1931-09 records.")
