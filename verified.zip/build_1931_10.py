import json
from pathlib import Path

meta_c2 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-10-01_48_10", "date": "1931-10-01", "volume": "48", "issue": "10", "leaf": 33, "column": 2}
meta_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-10-01_48_10", "date": "1931-10-01", "volume": "48", "issue": "10", "leaf": 33, "column": 3}

# Leaf 33, Column 2 (Starts under PINSCHERS (Doberman) - 13 dogs)
c2_dogs = [
    {
        "name": "ARNO SCHLIEGER", "sex": "Male", "registration_number": "795909",
        "birth_date": "May 28, 1926", "color": "Blk & rd",
        "owner": "Mrs. Winona R. Meeker", "owner_location": None,
        "breeder": "Emil Schlieger", "breeder_location": "Germany",
        "sire": "Axel v Haardtgebirg", "sire_registration_number": None,
        "dam": "Primmel v Ostersee", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Billo v Waldhof", "registration_number": None},
            {"role": "dam_of_dam", "name": "Terri v Ostersee", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Freya v Ostersee", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Klaus v Ostersee", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Nora v Ostersee", "registration_number": None},
            {"role": "sire_of_sire", "name": "Densos v Atlantic", "registration_number": None},
            {"role": "dam_of_sire", "name": "Asta v Pfalzer Rhein", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Edelblut v Jagerhof", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Friedel v Grauenstein", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Banjo v d Goldnen Hohe", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Mignon v Parthengrund", "registration_number": None}
        ],
        "source": meta_c2
    },
    {
        "name": "ASTA V BETTS", "sex": "Female", "registration_number": "794892",
        "birth_date": "Sept. 5, 1928", "color": "Blk & tn",
        "owner": "William Barker", "owner_location": None,
        "breeder": "Mary B. Trelease", "breeder_location": "Inglewood, Calif.",
        "sire": "Burschel v Weigand", "sire_registration_number": "625009",
        "dam": "Asta v Do Barry", "dam_registration_number": "507694",
        "source": meta_c2
    },
    {
        "name": "BESSI V WILSONA HOF", "sex": "Female", "registration_number": "796391",
        "birth_date": "Sept. 3, 1929", "color": "Blk, rd mkgs",
        "owner": "Norma E. Drudge", "owner_location": None,
        "breeder": "Georgine Y. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Astor Gottschalk", "sire_registration_number": "639147",
        "dam": "Eddi v d Wilsona", "dam_registration_number": "676235",
        "source": meta_c2
    },
    {
        "name": "BLATTLER'S NORA", "sex": "Female", "registration_number": "796203",
        "birth_date": "Jan. 4, 1929", "color": "Blk & tn",
        "owner": "Frank Blattler", "owner_location": None,
        "breeder": "H. D. Anderson", "breeder_location": "Cupertino, Calif.",
        "sire": "Burschel v Falkensee", "sire_registration_number": "553217",
        "dam": "Bona v d Deckersburg", "dam_registration_number": "553222",
        "source": meta_c2
    },
    {
        "name": "BOBA V BURGWALL", "sex": "Female", "registration_number": "797172",
        "birth_date": "Oct. 17, 1928", "color": "Blk, tn mkgs",
        "owner": "Ray Brown", "owner_location": None,
        "breeder": "Pete Donovan", "breeder_location": "Erie, Pa.",
        "sire": "Major v Burgwall II", "sire_registration_number": "658840",
        "dam": "Donovan's Gretchen", "dam_registration_number": "538598",
        "source": meta_c2
    },
    {
        "name": "BRUNHILDE'S LADY V SIGALSBURG", "sex": "Female", "registration_number": "795066",
        "birth_date": "Feb. 16, 1930", "color": "Br & tn",
        "owner": "L. F. Smith", "owner_location": None,
        "breeder": "E. E. Carrier", "breeder_location": "Summerville, Pa.",
        "sire": "Hans v Dombachtal", "sire_registration_number": "606668",
        "dam": "Brunhilde v Sigalsburg", "dam_registration_number": "667532",
        "source": meta_c2
    },
    {
        "name": "DELY OF OXBO", "sex": "Female", "registration_number": "797630",
        "birth_date": "Apr. 2, 1931", "color": "Bl & tn",
        "owner": "Frank Blattler", "owner_location": None,
        "breeder": "F. C. Fuqua", "breeder_location": "Seattle, Wash.",
        "sire": "Carlo v Belger", "sire_registration_number": "533994",
        "dam": "Camilla Wuhler", "dam_registration_number": "750695",
        "source": meta_c2
    },
    {
        "name": "DUKE OF WATSEKA", "sex": "Male", "registration_number": "795331",
        "birth_date": "July 28, 1929", "color": "Rd",
        "owner": "J. W. Oltmanns", "owner_location": "Watseka, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Dolf v Taunusblick", "sire_registration_number": "438104",
        "dam": "Rowdy of Watseka", "dam_registration_number": "718482",
        "source": meta_c2
    },
    {
        "name": "ERICH V STOWBURG", "sex": "Male", "registration_number": "795895",
        "birth_date": "Dec. 24, 1928", "color": "Blk & rust",
        "owner": "Roger M. Lovell", "owner_location": None,
        "breeder": "Lillian T. Snow", "breeder_location": "Buzzards Bay, Mass.",
        "sire": "Arko v Telles", "sire_registration_number": "493049",
        "dam": "Serena Katinka", "dam_registration_number": "497119",
        "source": meta_c2
    },
    {
        "name": "ETTA V SCHLOSS OF SEARIGHT", "sex": "Female", "registration_number": "795444",
        "birth_date": "Feb. 6, 1930", "color": "Blk, tn mkgs",
        "owner": "Earl Rogers", "owner_location": None,
        "breeder": "Jacques Blum", "breeder_location": "Pittsburgh, Pa.",
        "sire": "Hans v Dombachtal", "sire_registration_number": "606668",
        "dam": "Adaline v Nibelungenhort", "dam_registration_number": "438103",
        "source": meta_c2
    },
    {
        "name": "GLENNA V ROGERSCHMIDT", "sex": "Female", "registration_number": "795296",
        "birth_date": "July 1, 1929", "color": "Blk & rd",
        "owner": "Rogerschmidt Kennels", "owner_location": None,
        "breeder": "George C. Stokes", "breeder_location": "Detroit, Mich.",
        "sire": "Sept of Pontchartrain", "sire_registration_number": "659620",
        "dam": "Beda of Nordett Farms", "dam_registration_number": "553344",
        "source": meta_c2
    },
    {
        "name": "GRETCHEN SAINT GERMAIN", "sex": "Female", "registration_number": "796976",
        "birth_date": "June 10, 1929", "color": "Blk & rd",
        "owner": "W. D. Bergheim", "owner_location": None,
        "breeder": "Edw. A. Hunter", "breeder_location": "Ann Arbor, Mich.",
        "sire": "Marko v Siegerpark", "sire_registration_number": "601008",
        "dam": "Norma v Streslau", "dam_registration_number": "586734",
        "source": meta_c2
    },
    {
        "name": "GRISELDA OF REVEILLE", "sex": "Female", "registration_number": "759289",
        "birth_date": "Dec. 28, 1930", "color": "Blk & rd",
        "owner": "Edward Reffen", "owner_location": None,
        "breeder": "Arthur James", "breeder_location": "Westport, Conn.",
        "sire": "Benno v Ilsenstein", "sire_registration_number": "620320",
        "dam": "Greta of Reveille", "dam_registration_number": "765670",
        "source": meta_c2
    },
    {
        "name": "HANS III", "sex": "Male", "registration_number": "796192",
        "birth_date": "Oct. 20, 1930", "color": "Rd & tn",
        "owner": "Julian Anhalt", "owner_location": None,
        "breeder": "Clarence O. Lenning", "breeder_location": "West Brighton, S. I., N. Y.",
        "sire": "Ulrich's Hans", "sire_registration_number": "748944",
        "dam": "Black Princess", "dam_registration_number": "749687",
        "source": meta_c2
    },
    {
        "name": "KLARE V BRUNIA", "sex": "Female", "registration_number": "795631",
        "birth_date": "Dec. 8, 1928", "color": "Br rd",
        "owner": "George K. Erb", "owner_location": None,
        "breeder": "Heinz Brunen", "breeder_location": "Germany",
        "sire": "Gerd v Sporthof", "sire_registration_number": None,
        "dam": "Hella v d Winterburg", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Axel v Haardtgebirg", "registration_number": None},
            {"role": "dam_of_dam", "name": "Ferri v d Winterburg", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Benno v d Romerhof", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Lotte v Brennetsried", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Densos v Atlantic", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Asta v Pfalzer Rhein", "registration_number": None},
            {"role": "sire_of_sire", "name": "Claus v d Spree", "registration_number": None},
            {"role": "dam_of_sire", "name": "Bona v Sevira", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Artus v Langerode", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Bona v Hessen", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Burschel v Simmenau", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Adele v Oststern", "registration_number": None}
        ],
        "source": meta_c2
    }
]

# Leaf 33, Column 3 (16 dogs down to PINSCHER (Miniature))
c3_dogs = [
    {
        "name": "LEA V LOBENSTEIN", "sex": "Female", "registration_number": "796579",
        "birth_date": "Jan. 23, 1931", "color": "Blk & tn",
        "owner": "Kintzing B. Thomas", "owner_location": None,
        "breeder": "Mr. and Mrs. Albert T. Rahner", "breeder_location": "Philadelphia, Pa.",
        "sire": "Red Roof Exorcist", "sire_registration_number": "637314",
        "dam": "Gertrud v Burgund", "dam_registration_number": "750713",
        "source": meta_c3
    },
    {
        "name": "LUDWIG OF GREEN MEADOWS", "sex": "Male", "registration_number": "797667",
        "birth_date": "Dec. 12, 1930", "color": "Blk, rust rd",
        "owner": "Irmgard J. Grabbe", "owner_location": None,
        "breeder": "Joseph A. Ernst", "breeder_location": "Chicago, Ill.",
        "sire": "Peter v Roemerhof", "sire_registration_number": "616494",
        "dam": "Artiste v Torrez", "dam_registration_number": "780956",
        "source": meta_c3
    },
    {
        "name": "LUX V REYNO", "sex": "Male", "registration_number": "795198",
        "birth_date": "May 29, 1930", "color": "Blk & dk rust",
        "owner": "Arthur F. Tuttle", "owner_location": "Lake Forest, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Alice v Friedenspark", "dam_registration_number": "432632",
        "source": meta_c3
    },
    {
        "name": "MAGGIE V SIGALSBURG", "sex": "Female", "registration_number": "796550",
        "birth_date": "Feb. 16, 1930", "color": "Blk & tn",
        "owner": "W. R. Yeaney", "owner_location": None,
        "breeder": "E. E. Carrier", "breeder_location": "Summerville, Pa.",
        "sire": "Hans v Dombachtal", "sire_registration_number": "606668",
        "dam": "Brunhilde v Sigalsburg", "dam_registration_number": "667532",
        "source": meta_c3
    },
    {
        "name": "MINKO V KETTERMAN", "sex": "Female", "registration_number": "794881",
        "birth_date": "July 12, 1929", "color": "Blk, tn mkgs",
        "owner": "Ervin A. and Clara E. Smith", "owner_location": None,
        "breeder": "L. J. Ketterman", "breeder_location": "Sacramento, Calif.",
        "sire": "Glock v Bergendorf", "sire_registration_number": "673478",
        "dam": "Asta Foss", "dam_registration_number": "668565",
        "source": meta_c3
    },
    {
        "name": "MITZI V ARONAEL", "sex": "Female", "registration_number": "797265",
        "birth_date": "Dec. 14, 1929", "color": "Blk & tn",
        "owner": "B. H. McGavin", "owner_location": None,
        "breeder": "B. Delacourt", "breeder_location": "Los Angeles, Calif.",
        "sire": "Max v Strossen", "sire_registration_number": "509139",
        "dam": "Betty v Hohenzollernpark", "dam_registration_number": "674822",
        "source": meta_c3
    },
    {
        "name": "MODERN V GROSSMOUNT", "sex": "Male", "registration_number": "794840",
        "birth_date": "Jan. 17, 1931", "color": "Blk & rd",
        "owner": "H. P. Griffith", "owner_location": None,
        "breeder": "G. C. Jaco", "breeder_location": "Uniontown, Pa.",
        "sire": "Modern v Simmenau Rhinegold", "sire_registration_number": "768281",
        "dam": "Gilda v d Blankenbrink", "dam_registration_number": "696806",
        "source": meta_c3
    },
    {
        "name": "NEAL OF PONTCHARTRAIN", "sex": "Male", "registration_number": "795442",
        "birth_date": "May 24, 1930", "color": "Blk & rd",
        "owner": "Francis C. Baker", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Ilisa of Pontchartrain", "dam_registration_number": "571491",
        "source": meta_c3
    },
    {
        "name": "NICK KONIGSTADT GRAMMONT", "sex": "Male", "registration_number": "796903",
        "birth_date": "June 30, 1931", "color": "Blk, tn mkgs",
        "owner": "Jno. M. Richardson", "owner_location": None,
        "breeder": "Jos. C. Morris, Jr.", "breeder_location": "Germantown, Pa.",
        "sire": "Prinz Cuno of Westphalia", "sire_registration_number": "578324",
        "dam": "Pinkerton Patsy", "dam_registration_number": "658358",
        "source": meta_c3
    },
    {
        "name": "NOLA V ELLIS", "sex": "Female", "registration_number": "796825",
        "birth_date": "Mar. 3, 1931", "color": "Blk & tn",
        "owner": "A. K. Ellis", "owner_location": None,
        "breeder": "Frank Kusenback", "breeder_location": "Chicago, Ill.",
        "sire": "Lindy v Forsberg", "sire_registration_number": "670607",
        "dam": "Princess Frieda", "dam_registration_number": "783720",
        "source": meta_c3
    },
    {
        "name": "PRINCE OF MANCHESTER", "sex": "Male", "registration_number": "797617",
        "birth_date": "May 15, 1931", "color": "Blk & tn",
        "owner": "John Coppez", "owner_location": None,
        "breeder": "Joseph S. Treacy", "breeder_location": "Manchester, N. H.",
        "sire": "Kuncanowet Jean v Sporthof", "sire_registration_number": "773862",
        "dam": "Queen of Granite Hills", "dam_registration_number": "665846",
        "source": meta_c3
    },
    {
        "name": "PRINZ ODIN OF PONTCHARTRAIN", "sex": "Male", "registration_number": "796462",
        "birth_date": "Oct. 26, 1929", "color": "Blk & rd",
        "owner": "Richard Kogler", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Lux v d Blankenburg", "sire_registration_number": "571492",
        "dam": "Freia v d Butersburg of Ardwin", "dam_registration_number": "499561",
        "source": meta_c3
    },
    {
        "name": "SALLIE MARIA", "sex": "Female", "registration_number": "796578",
        "birth_date": "Apr. 22, 1931", "color": "Blk & rd",
        "owner": "John H. McEllen", "owner_location": None,
        "breeder": "H. B. Juell", "breeder_location": "Glen Ellyn, Ill.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Sallie v Allie", "dam_registration_number": "605877",
        "source": meta_c3
    },
    {
        "name": "SKIPPY V NIBELUNGENHORT", "sex": "Male", "registration_number": "795209",
        "birth_date": "July 13, 1930", "color": "Bl & tn",
        "owner": "L. C. Boland, Jr.", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Ceralvo Fra Duncan", "sire_registration_number": "589274",
        "dam": "Gilda Fra Duncan", "dam_registration_number": "678513",
        "source": meta_c3
    },
    {
        "name": "WECK V D HOHEN", "sex": "Male", "registration_number": "797141",
        "birth_date": "Aug. 22, 1930", "color": "Br, tn mkgs",
        "owner": "James H. Whelden", "owner_location": None,
        "breeder": "Mrs. M. von Hoegen", "breeder_location": "Towaco, N. J.",
        "sire": "Eros v d Hohen", "sire_registration_number": "663349",
        "dam": "Eloise of Arkeden", "dam_registration_number": "619600",
        "source": meta_c3
    },
    {
        "name": "ZENIA V CLAUSEN", "sex": "Female", "registration_number": "795896",
        "birth_date": "Mar. 27, 1929", "color": "Blk, tn mkgs",
        "owner": "Victoria C. Kendall", "owner_location": None,
        "breeder": "Wayne D. King", "breeder_location": "Bridgeport, Ohio",
        "sire": "Edmund v Nibelungenhort", "sire_registration_number": "419285",
        "dam": "Senta v Lueschenhof", "dam_registration_number": "633072",
        "source": meta_c3
    }
]

all_31_10 = c2_dogs + c3_dogs
print(f"Total compiled 1931-10 dogs: {len(all_31_10)}")
print(f"  Leaf 33 Col 2: {len(c2_dogs)}")
print(f"  Leaf 33 Col 3: {len(c3_dogs)}")

Path("stud-scrape/data/verified_1931_10.json").write_text(json.dumps(all_31_10, indent=2), encoding="utf-8")
print("Saved verified 1931-10 records.")
