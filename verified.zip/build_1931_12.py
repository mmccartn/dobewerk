import json
from pathlib import Path

meta_l35_c3 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-12-01_48_12", "date": "1931-12-01", "volume": "48", "issue": "12", "leaf": 35, "column": 3}
meta_l36_c1 = {"identifier": "sim_american-kennel-club-stud-book-register_1931-12-01_48_12", "date": "1931-12-01", "volume": "48", "issue": "12", "leaf": 36, "column": 1}

# Leaf 35, Column 3 (Starts under PINSCHERS (Doberman) - 21 dogs)
c1_dogs = [
    {
        "name": "CLAUS OF LAWNWOOD", "sex": "Male", "registration_number": "803378",
        "birth_date": "Feb. 28, 1931", "color": "Blk & tn",
        "owner": "Laura B. Gibson", "owner_location": "Hales Corners, Wis.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Rollo v Popp", "sire_registration_number": "747259",
        "dam": "Ima of Lawnwood", "dam_registration_number": "791223",
        "source": meta_l35_c3
    },
    {
        "name": "CLAUS V STRAHL", "sex": "Male", "registration_number": "803625",
        "birth_date": "Jan. 29, 1931", "color": "Blk & tn",
        "owner": "Mr. and Mrs. Edward F. Strahl", "owner_location": "Villa Park, Ill.",
        "breeder": "Owners", "breeder_location": None,
        "sire": "Alto v Torrez", "sire_registration_number": "713439",
        "dam": "Bubbles v Strahl", "dam_registration_number": "762423",
        "source": meta_l35_c3
    },
    {
        "name": "CLEO V STRAHL", "sex": "Female", "registration_number": "803628",
        "birth_date": "Jan. 29, 1931", "color": "Blk & tn",
        "owner": "Mr. and Mrs. Edward F. Strahl", "owner_location": "Villa Park, Ill.",
        "breeder": "Owners", "breeder_location": None,
        "sire": "Alto v Torrez", "sire_registration_number": "713439",
        "dam": "Bubbles v Strahl", "dam_registration_number": "762423",
        "source": meta_l35_c3
    },
    {
        "name": "COUNT FRANZ OF PONTCHARTRAIN", "sex": "Male", "registration_number": "805239",
        "birth_date": "Dec. 15, 1930", "color": "Blk & rd",
        "owner": "Francis M. Sherwin", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Sasha of Pontchartrain", "dam_registration_number": "805238",
        "source": meta_l35_c3
    },
    {
        "name": "DELIGHT V STRAHL", "sex": "Female", "registration_number": "803627",
        "birth_date": "Jan. 29, 1931", "color": "Blk & tn",
        "owner": "Mr. and Mrs. Edward F. Strahl", "owner_location": "Villa Park, Ill.",
        "breeder": "Owners", "breeder_location": None,
        "sire": "Alto v Torrez", "sire_registration_number": "713439",
        "dam": "Bubbles v Strahl", "dam_registration_number": "762423",
        "source": meta_l35_c3
    },
    {
        "name": "DOBE V DUNNERBURG", "sex": "Female", "registration_number": "804010",
        "birth_date": "Mar. 10, 1929", "color": "Blk & tn",
        "owner": "Calvin Held", "owner_location": None,
        "breeder": "K. A. McMasters", "breeder_location": "Hartford, Wis.",
        "sire": "Rowdy v d Koningstadt", "sire_registration_number": "634465",
        "dam": "Irma v d Eckardtsburg", "dam_registration_number": "438105",
        "source": meta_l35_c3
    },
    {
        "name": "ELFE V HOMEHILL", "sex": "Female", "registration_number": "802883",
        "birth_date": "May 25, 1929", "color": "Blk, rust mkgs",
        "owner": "Mrs. Harold Kondolf", "owner_location": None,
        "breeder": "Mrs. G. A. Rentschler", "breeder_location": "Hamilton, Ohio",
        "sire": "Claus v Homehill", "sire_registration_number": "716213",
        "dam": "Dina v Homehill", "dam_registration_number": "581382",
        "source": meta_l35_c3
    },
    {
        "name": "EPHALUSTA", "sex": "Male", "registration_number": "805091",
        "birth_date": "Apr. 23, 1930", "color": "Blk & tn",
        "owner": "Donald C. Philipp", "owner_location": "Wichita, Kans.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Dietrich v d Barbarossahoehle", "sire_registration_number": "561617",
        "dam": "Ellisa v Nuremberg", "dam_registration_number": "692976",
        "source": meta_l35_c3
    },
    {
        "name": "FRAULEIN V JAGERHOF", "sex": "Female", "registration_number": "805704",
        "birth_date": "July 15, 1931", "color": "Blk & rust rd",
        "owner": "Wm. A. Brandt", "owner_location": None,
        "breeder": "John C. Smith", "breeder_location": "Drexel Hill, Pa.",
        "sire": "Redroof Exorcist", "sire_registration_number": "637314",
        "dam": "Sophia v Jagerhof", "dam_registration_number": "715741",
        "source": meta_l35_c3
    },
    {
        "name": "FREIHERR V DRACHENBURG", "sex": "Male", "registration_number": "805661",
        "birth_date": "July 2, 1930", "color": "Rd & tn",
        "owner": "Emil Fitting", "owner_location": None,
        "breeder": "Mrs. Margaret Peters", "breeder_location": "Kanona, N. Y.",
        "sire": "Rex v Wagoner", "sire_registration_number": "578558",
        "dam": "Asta of Florida Petershoff", "dam_registration_number": "660844",
        "source": meta_l35_c3
    },
    {
        "name": "FRIEDA OF ROWDY ALLIE", "sex": "Female", "registration_number": "804735",
        "birth_date": "May 24, 1928", "color": "Blk & tn",
        "owner": "Ray Feeser", "owner_location": None,
        "breeder": "Chester A. Ellis", "breeder_location": "Pottstown, Pa.",
        "sire": "Fedor v Buetersburg", "sire_registration_number": "539750",
        "dam": "Rowdy Allie of Pottstown", "dam_registration_number": "615095",
        "source": meta_l35_c3
    },
    {
        "name": "FRITZ V HEMPEL", "sex": "Male", "registration_number": "803229",
        "birth_date": "May 27, 1930", "color": "Blk & rd",
        "owner": "J. Austin Bucknell", "owner_location": None,
        "breeder": "John H. Whitmore", "breeder_location": "Detroit, Mich.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Gretchen v Grassington", "dam_registration_number": "800407",
        "source": meta_l35_c3
    },
    {
        "name": "FRITZ V KRANICHBURG", "sex": "Male", "registration_number": "805089",
        "birth_date": "Jan. 29, 1931", "color": "Blk, rd mkgs",
        "owner": "Michael J. Harrington", "owner_location": None,
        "breeder": "Paul W. Westfall", "breeder_location": "Eureka, Calif.",
        "sire": "Sig v Sigalsburg", "sire_registration_number": "659175",
        "dam": "Fritzie v d Westfall", "dam_registration_number": "563105",
        "source": meta_l35_c3
    },
    {
        "name": "FRITZ RITTER V DRUDGE", "sex": "Male", "registration_number": "804605",
        "birth_date": "Feb. 28, 1929", "color": "Blk & tn",
        "owner": "Willard E. Drudge", "owner_location": None,
        "breeder": "Henry J. Dwillard", "breeder_location": "Kalamazoo, Mich.",
        "sire": "Printz Negus v Nibelungenhort", "sire_registration_number": "379731",
        "dam": "Presque Isle Zareda", "dam_registration_number": "369303",
        "source": meta_l35_c3
    },
    {
        "name": "GRETCHEN OF WAKERIDGE", "sex": "Female", "registration_number": "803291",
        "birth_date": "July 12, 1930", "color": "Blk & rd",
        "owner": "Otto Mueller", "owner_location": None,
        "breeder": "William L. Pease", "breeder_location": "Wakeman, Ohio",
        "sire": "Gustl v Tannenhaus", "sire_registration_number": "677473",
        "dam": "Tena of Pontchartrain", "dam_registration_number": "715343",
        "source": meta_l35_c3
    },
    {
        "name": "HANS V D AFFAN", "sex": "Male", "registration_number": "805090",
        "birth_date": "Mar. 28, 1931", "color": "Blk & tn",
        "owner": "Mrs. George S. Draffan", "owner_location": None,
        "breeder": "C. A. Duncan", "breeder_location": "Paris, Ky.",
        "sire": "Rogue v Nibelungenhort", "sire_registration_number": "653600",
        "dam": "Beauty Fra Duncan", "dam_registration_number": "798306",
        "source": meta_l35_c3
    },
    {
        "name": "HARRAS V D KARLSHOHE", "sex": "Male", "registration_number": "803452",
        "birth_date": "Feb. 8, 1929", "color": "Blk & rd",
        "owner": "Oscar A. Strobel", "owner_location": None,
        "breeder": "Paul Dumde", "breeder_location": "Germany",
        "sire": "Hamlet v Herthasee", "sire_registration_number": None,
        "dam": "Regina v d Karlshohe", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Detlef v Stresow", "registration_number": None},
            {"role": "dam_of_dam", "name": "Astra v d Schulzenburg", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Troll v d Blankenburg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Hexe v d Eckardtsburg", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Alex v d Finohohe", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Lotte v Stresow", "registration_number": None},
            {"role": "sire_of_sire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_sire", "name": "Comtess v Steyerberg", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Arno v d Weichselburg", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Ali v Waldloh", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None}
        ],
        "source": meta_l35_c3
    },
    {
        "name": "HEINE V HEMPEL", "sex": "Male", "registration_number": "803228",
        "birth_date": "May 27, 1930", "color": "Blk & rd",
        "owner": "Ralph Cuthbert", "owner_location": None,
        "breeder": "John H. Whitmore", "breeder_location": "Detroit, Mich.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Gretchen v Grassington", "dam_registration_number": "800407",
        "source": meta_l35_c3
    },
    {
        "name": "HERR PEDRO OF CHURCH HILL", "sex": "Male", "registration_number": "803184",
        "birth_date": "June 18, 1931", "color": "Blk & tn, rust rd mkgs",
        "owner": "Albert H. Bratt", "owner_location": None,
        "breeder": "McClellan Whipkey", "breeder_location": "Jamestown, N. D.",
        "sire": "Elmcroft King Niko II", "sire_registration_number": "767416",
        "dam": "Moose Jaw Rita", "dam_registration_number": "765242",
        "source": meta_l35_c3
    },
    {
        "name": "LADY LOU", "sex": "Female", "registration_number": "802965",
        "birth_date": "Sept. 19, 1928", "color": "Blk, tn mkgs",
        "owner": "Lulu B. Jordon", "owner_location": None,
        "breeder": "J. A. Finnicum", "breeder_location": "Columbus, Ohio",
        "sire": "Leuthold of Pontchartrain", "sire_registration_number": "629194",
        "dam": "Bella of Pontchartrain", "dam_registration_number": "578596",
        "source": meta_l35_c3
    },
    {
        "name": "LIKELY LADY OF WHITE GATE", "sex": "Female", "registration_number": "803638",
        "birth_date": "Aug. 8, 1931", "color": "Blk, rust mkgs",
        "owner": "White Gate Kennels", "owner_location": None,
        "breeder": "Frank M. Gould", "breeder_location": "N. Y. City",
        "sire": "Big Boy of White Gate", "sire_registration_number": "572868",
        "dam": "Lotte v Simmenau", "dam_registration_number": "762222",
        "source": meta_l35_c3
    }
]

# Leaf 36, Column 1 (14 dogs down to PINSCHER (Miniature))
c2_dogs = [
    {
        "name": "MIDI OF SILVERGATE", "sex": "Female", "registration_number": "803453",
        "birth_date": "Sept. 8, 1930", "color": "Blk & rd",
        "owner": "Jay D. Conner", "owner_location": "San Diego, Calif.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Harras v d Karlshohe", "sire_registration_number": "803452",
        "dam": "Frieda v d Blankenburg", "dam_registration_number": "759077",
        "source": meta_l36_c1
    },
    {
        "name": "MIKE OF PLYMOUTH", "sex": "Male", "registration_number": "803422",
        "birth_date": "Oct. 18, 1930", "color": "Blk rd",
        "owner": "P. B. Gallagher", "owner_location": None,
        "breeder": "Homer W. Ward", "breeder_location": "Macy, Ind.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Pontchartrain Princess Tily", "dam_registration_number": "721782",
        "source": meta_l36_c1
    },
    {
        "name": "MISS BESSIE DE VOE", "sex": "Female", "registration_number": "804210",
        "birth_date": "May 20, 1929", "color": "Blk & tn",
        "owner": "Charles and Pear Scott", "owner_location": None,
        "breeder": "Wm. H. Lawson", "breeder_location": "Detroit, Mich.",
        "sire": "Jockel v Lobenstein", "sire_registration_number": "706937",
        "dam": "Lawson's Lily", "dam_registration_number": "587606",
        "source": meta_l36_c1
    },
    {
        "name": "NOOKEN V BRANDTHOF", "sex": "Female", "registration_number": "803284",
        "birth_date": "Mar. 9, 1929", "color": "Blk & tn",
        "owner": "G. E. von Brandt", "owner_location": "Monmouth, Ill.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Claus v Sigalsburg", "sire_registration_number": "600529",
        "dam": "Thea v Brandthof", "dam_registration_number": "803283",
        "source": meta_l36_c1
    },
    {
        "name": "PRINCESS MARTHA DUFF-GORDON", "sex": "Female", "registration_number": "803555",
        "birth_date": "Apr. 6, 1930", "color": "Blk & rd",
        "owner": "Dorothy B. Glass", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Astor Gottschalk", "sire_registration_number": "639147",
        "dam": "Ira v d Winterburg", "dam_registration_number": "736237",
        "source": meta_l36_c1
    },
    {
        "name": "REDROOF EXORCISTA", "sex": "Female", "registration_number": "804347",
        "birth_date": "Nov. 14, 1930", "color": "Blk & tn",
        "owner": "George H. Earle IV", "owner_location": None,
        "breeder": "John C. Smith", "breeder_location": "Drexel Hill, Pa.",
        "sire": "Redroof Exorcist", "sire_registration_number": "637314",
        "dam": "Sophia v Jagerhof", "dam_registration_number": "715741",
        "source": meta_l36_c1
    },
    {
        "name": "RITA OF LONG BRANCH", "sex": "Female", "registration_number": "805662",
        "birth_date": "Mar. 3, 1931", "color": "Blk & rd",
        "owner": "Mrs. Svend Scharling", "owner_location": None,
        "breeder": "Fred Hollmann", "breeder_location": "Hoboken, N. J.",
        "sire": "Erco v Rheinadler", "sire_registration_number": "776552",
        "dam": "Caprice v Kioma", "dam_registration_number": "570512",
        "source": meta_l36_c1
    },
    {
        "name": "RUSTIG V BLANKENSTRICH", "sex": "Male", "registration_number": "805663",
        "birth_date": "Feb. 22, 1931", "color": "Blk, rust mkgs",
        "owner": "Edward P. Foster", "owner_location": None,
        "breeder": "Mrs. C. A. Bergman", "breeder_location": "Ottumwa, Iowa",
        "sire": "Westphalia Arko v Klostersee", "sire_registration_number": "399998",
        "dam": "Dolly v Jaegershof", "dam_registration_number": "719690",
        "source": meta_l36_c1
    },
    {
        "name": "SASHA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "805238",
        "birth_date": "Dec. 1, 1928", "color": "Blk & rd",
        "owner": "Glenn S. Staines", "owner_location": "Detroit, Mich.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Westphalia Dyno v Wiesengrund", "sire_registration_number": "365520",
        "dam": "Hella of Pontchartrain", "dam_registration_number": "497377",
        "source": meta_l36_c1
    },
    {
        "name": "TELLO V REYNO", "sex": "Male", "registration_number": "803868",
        "birth_date": "June 12, 1930", "color": "Blk, rust mkgs",
        "owner": "Gus F. Thaler", "owner_location": None,
        "breeder": "M. V. Reynolds", "breeder_location": "Lake Villa, Ill.",
        "sire": "Mikosch of Pontchartrain", "sire_registration_number": "721118",
        "dam": "Dina v Reyno", "dam_registration_number": "767190",
        "source": meta_l36_c1
    },
    {
        "name": "THEA V BRANDTHOF", "sex": "Female", "registration_number": "803283",
        "birth_date": "Nov. 28, 1926", "color": "Blk & tn",
        "owner": "G. E. Von Brandt", "owner_location": None,
        "breeder": "J. W. Oltmanns", "breeder_location": "Watseka, Ill.",
        "sire": "Arko v Bottwartal", "sire_registration_number": "620924",
        "dam": "Asta v Dankwarderode", "dam_registration_number": "714983",
        "source": meta_l36_c1
    },
    {
        "name": "TOGA BECKER V PETERSHOFF", "sex": "Male", "registration_number": "805204",
        "birth_date": "July 11, 1931", "color": "Blk & rust",
        "owner": "Mrs. Albert A. Becker", "owner_location": None,
        "breeder": "Mrs. Margaret Peters", "breeder_location": "Kanona, N. Y.",
        "sire": "Rex v Wagoner", "sire_registration_number": "578558",
        "dam": "Asta of Florida Petershoff", "dam_registration_number": "660844",
        "source": meta_l36_c1
    },
    {
        "name": "TOUT'S BLACK KNIGHT", "sex": "Male", "registration_number": "805308",
        "birth_date": "May 7, 1931", "color": "Blk & tn",
        "owner": "E. G. Tout", "owner_location": None,
        "breeder": "Wm. H. Lawson", "breeder_location": "Detroit, Mich.",
        "sire": "Nuttall's Jim", "sire_registration_number": "756889",
        "dam": "Lawson's Lily", "dam_registration_number": "587606",
        "source": meta_l36_c1
    },
    {
        "name": "TRUDIE OF TOPPO", "sex": "Female", "registration_number": "802721",
        "birth_date": "Sept. 13, 1929", "color": "Blk & tn",
        "owner": "Dorothy Bolce", "owner_location": None,
        "breeder": "Chas. Baumgartner", "breeder_location": "Cincinnati, Ohio",
        "sire": "Toppo v Sigalsburg", "sire_registration_number": "670191",
        "dam": "Trudie v d Spree", "dam_registration_number": "541696",
        "source": meta_l36_c1
    },
    {
        "name": "XERXES VON DEN HOHEN", "sex": "Male", "registration_number": "803556",
        "birth_date": "Oct. 26, 1930", "color": "Blk, rd mkgs",
        "owner": "E. W. Kemmerer", "owner_location": None,
        "breeder": "Mrs. M. von Hoegen", "breeder_location": "Towaco, N. J.",
        "sire": "Lenz v Simmenau", "sire_registration_number": "737795",
        "dam": "Coryl v Avonthal", "dam_registration_number": "506373",
        "source": meta_l36_c1
    }
]

all_31_12 = c1_dogs + c2_dogs
print(f"Total compiled 1931-12 dogs: {len(all_31_12)}")
print(f"  Leaf 35 Col 3: {len(c1_dogs)}")
print(f"  Leaf 36 Col 1: {len(c2_dogs)}")

Path("stud-scrape/data/verified_1931_12.json").write_text(json.dumps(all_31_12, indent=2), encoding="utf-8")
print("Saved verified 1931-12 records.")
