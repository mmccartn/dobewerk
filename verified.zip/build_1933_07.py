import json
from pathlib import Path

meta_p82_c_right = {"identifier": "sim_american-kennel-club-stud-book-register_1933-07-01_50_7", "date": "1933-07-01", "volume": "50", "issue": "7", "leaf": 83, "page": 82, "column": "right"}
meta_p83_c_left = {"identifier": "sim_american-kennel-club-stud-book-register_1933-07-01_50_7", "date": "1933-07-01", "volume": "50", "issue": "7", "leaf": 84, "page": 83, "column": "left"}
meta_p83_c_right = {"identifier": "sim_american-kennel-club-stud-book-register_1933-07-01_50_7", "date": "1933-07-01", "volume": "50", "issue": "7", "leaf": 84, "page": 83, "column": "right"}
meta_p84_c_left = {"identifier": "sim_american-kennel-club-stud-book-register_1933-07-01_50_7", "date": "1933-07-01", "volume": "50", "issue": "7", "leaf": 85, "page": 84, "column": "left"}
meta_p84_c_right = {"identifier": "sim_american-kennel-club-stud-book-register_1933-07-01_50_7", "date": "1933-07-01", "volume": "50", "issue": "7", "leaf": 85, "page": 84, "column": "right"}

# 1. Page 82 (Leaf 83), Column Right (3 dogs)
col1_dogs = [
    {
        "name": "ADONIS V D STOECKERSBURG", "sex": "Male", "registration_number": "882067",
        "birth_date": "June 7, 1931", "color": "Blk, rd rust",
        "owner": "Herman G. Paulsen", "owner_location": None,
        "breeder": "Stoeckersburg Kennels", "breeder_location": "Neptune, N. J.",
        "sire": "Henry of Rhinegold", "sire_registration_number": "739668",
        "dam": "Zeppy", "dam_registration_number": "719434",
        "source": meta_p82_c_right
    },
    {
        "name": "ALDO V WILSONA HOF", "sex": "Male", "registration_number": "878920",
        "birth_date": "Aug. 1, 1932", "color": "Blk & tn",
        "owner": "Jas. A. McQuail", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Berndt v Bad Heidelberg", "sire_registration_number": "838386",
        "dam": "Cinder v Gottschalk", "dam_registration_number": "732509",
        "source": meta_p82_c_right
    },
    {
        "name": "ALEX V D KLESSMANNSHOHE", "sex": "Male", "registration_number": "881588",
        "birth_date": "June 21, 1931", "color": "Blk-rd",
        "owner": "Ben H. Wilson", "owner_location": None,
        "breeder": "Robert Wormann", "breeder_location": "Germany",
        "sire": "Lasko v d Leinenstadt", "sire_registration_number": None,
        "dam": "Freya v d Volkerruhe", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_dam", "name": "Elfe v d Volkerruhe", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Amor v Gotterfelsen", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Asta v d Volkerruhe", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Lotte v Roneckenstein", "registration_number": None},
            {"role": "sire_of_sire", "name": "Hamlet v Herthasee", "registration_number": None},
            {"role": "dam_of_sire", "name": "Ires v d Residenz", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Carlo v d Schwanenhohe", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Frohgunde v d Residenz", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Comtess v Steyerberg", "registration_number": None}
        ],
        "source": meta_p82_c_right
    }
]

# 2. Page 83 (Leaf 84), Column Left (19 dogs)
col2_dogs = [
    {
        "name": "ALEX OF REACREST", "sex": "Male", "registration_number": "881518",
        "birth_date": "May 17, 1932", "color": "Blk, br mkgs",
        "owner": "J. Edgar Outcalt", "owner_location": "Worthington, Ohio",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Modern v Simmenau-Rhinegold", "sire_registration_number": "768281",
        "dam": "Rea of Bornholm", "dam_registration_number": "790490",
        "source": meta_p83_c_left
    },
    {
        "name": "BALDER", "sex": "Male", "registration_number": "879699",
        "birth_date": "Sept. 25, 1931", "color": "Blk & tn",
        "owner": "Julius Heilner", "owner_location": None,
        "breeder": "John Justin Conroy", "breeder_location": "N. Y. City",
        "sire": "Artus v Polizei Praesidium Berlin", "sire_registration_number": "421163",
        "dam": "Mitzi v d Rudolfsburg", "dam_registration_number": "426826",
        "source": meta_p83_c_left
    },
    {
        "name": "BOBBY II", "sex": "Male", "registration_number": "879560",
        "birth_date": "Jan. 10, 1930", "color": "Blk & tn",
        "owner": "Josef Glass", "owner_location": None,
        "breeder": "Henry Ulrich", "breeder_location": "N. Y. City",
        "sire": "Ulrich's Hans", "sire_registration_number": "748944",
        "dam": "Asta v Hohenschwanau", "dam_registration_number": "609112",
        "source": meta_p83_c_left
    },
    {
        "name": "BOY V D MASSON", "sex": "Male", "registration_number": "879700",
        "birth_date": "Aug. 25, 1929", "color": "Blk, tn mkgs",
        "owner": "Marc F. Morrison", "owner_location": None,
        "breeder": "Mrs. Evelyn Masson", "breeder_location": "Eureka, Calif.",
        "sire": "Sig v Sigalsburg", "sire_registration_number": "659175",
        "dam": "Mugsy v d Robinson", "dam_registration_number": "425459",
        "source": meta_p83_c_left
    },
    {
        "name": "BRIDGET OF DAWN", "sex": "Female", "registration_number": "879254",
        "birth_date": "Sept. 13, 1931", "color": "Blk & rd",
        "owner": "Mr. & Mrs. H. S. Newsom", "owner_location": None,
        "breeder": "Mr. & Mrs. E. A. Courtney", "breeder_location": "Westchester, Ill.",
        "sire": "Ari of Kettle Cove", "sire_registration_number": "690590",
        "dam": "Ariel v Torrez", "dam_registration_number": "692407",
        "source": meta_p83_c_left
    },
    {
        "name": "BUSTER MUELLER", "sex": "Male", "registration_number": "880442",
        "birth_date": "May 12, 1931", "color": "Blk & rust",
        "owner": "C. J. Malone", "owner_location": "Hagerstown, Md.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Lux Mueller", "sire_registration_number": "540604",
        "dam": "Wanda v Siegestor", "dam_registration_number": "684558",
        "source": meta_p83_c_left
    },
    {
        "name": "CAESAR V LAAR", "sex": "Male", "registration_number": "880319",
        "birth_date": "Jan. 4, 1933", "color": "Rd & tn",
        "owner": "Harold R. Cunning, Jr.", "owner_location": None,
        "breeder": "Harry F. Steffan", "breeder_location": "Indianapolis, Ind.",
        "sire": "Strahl of Smithcourt", "sire_registration_number": "800596",
        "dam": "Schaka v Steubenfeld", "dam_registration_number": "857260",
        "source": meta_p83_c_left
    },
    {
        "name": "CHEE-LO V WAGNER", "sex": "Female", "registration_number": "878996",
        "birth_date": "Nov. 24, 1932", "color": "Blk & tn",
        "owner": "Ray Davies", "owner_location": None,
        "breeder": "Blythe Williams", "breeder_location": "Bellflower, Calif.",
        "sire": "Harrad v Hahn", "sire_registration_number": "836507",
        "dam": "Princess Pan of Pontchartrain", "dam_registration_number": "752818",
        "source": meta_p83_c_left
    },
    {
        "name": "CONNIE OF PLANTATION GROVE", "sex": "Female", "registration_number": "880000",
        "birth_date": "Mar. 12, 1932", "color": "Br & tn",
        "owner": "R. Martin Schurig", "owner_location": None,
        "breeder": "Earle C. Bailey", "breeder_location": "Riverside, Calif.",
        "sire": "Prinz Noah of Pontchartrain", "sire_registration_number": "794681",
        "dam": "Jouda of Middletown", "dam_registration_number": "722204",
        "source": meta_p83_c_left
    },
    {
        "name": "COUNT CARL V PALANKA", "sex": "Male", "registration_number": "882911",
        "birth_date": "Nov. 17, 1932", "color": "Blk & tn",
        "owner": "H. C. Welle", "owner_location": None,
        "breeder": "Mrs. C. A. Roy", "breeder_location": "Richmond, Calif.",
        "sire": "Artus v d Olgahohe", "sire_registration_number": "710297",
        "dam": "Lady of Studena", "dam_registration_number": "855222",
        "source": meta_p83_c_left
    },
    {
        "name": "DER BEUHLER V PETERSHOF", "sex": "Male", "registration_number": "880497",
        "birth_date": "Nov. 25, 1932", "color": "Blk & rust",
        "owner": "Lyman J. Spire", "owner_location": None,
        "breeder": "Mrs. Margaret Peters", "breeder_location": "Bath, N. Y.",
        "sire": "Figaro v Timmenal", "sire_registration_number": "800812",
        "dam": "Asta of Florida Petershoff", "dam_registration_number": "660844",
        "source": meta_p83_c_left
    },
    {
        "name": "DIANA V DEMANTBERGE", "sex": "Female", "registration_number": "883063",
        "birth_date": "July 12, 1931", "color": "Blk & tn",
        "owner": "Father M. Michael", "owner_location": None,
        "breeder": "C. C. Allen", "breeder_location": "Newfane, Vt.",
        "sire": "Peter v Gruenberg", "sire_registration_number": "546412",
        "dam": "Frieda C.", "dam_registration_number": "545525",
        "source": meta_p83_c_left
    },
    {
        "name": "DOBYNA V BELGER", "sex": "Female", "registration_number": "881200",
        "birth_date": "Nov. 10, 1932", "color": "Blk & tn",
        "owner": "Mrs. C. O. Carlson", "owner_location": None,
        "breeder": "Mrs. H. A. Graves", "breeder_location": "Seattle, Wash.",
        "sire": "Carlo v Belger", "sire_registration_number": "533944",
        "dam": "Hilda v Skyel Fisk Oer", "dam_registration_number": "713104",
        "source": meta_p83_c_left
    },
    {
        "name": "DORCAS V SCHEDSENTHAL", "sex": "Female", "registration_number": "881805",
        "birth_date": "Nov. 21, 1929", "color": "Blk & tn",
        "owner": "Howard Cornelison", "owner_location": None,
        "breeder": "Georgia Christman", "breeder_location": "Paris, Ky.",
        "sire": "Rolf v Schendsenthal", "sire_registration_number": "624504",
        "dam": "Patsy v Nibelungenhort", "dam_registration_number": "721247",
        "source": meta_p83_c_left
    },
    {
        "name": "DUNKELFURST", "sex": "Male", "registration_number": "881417",
        "birth_date": "Jan. 13, 1933", "color": "Blk & rust red",
        "owner": "C. L. Pascal Russel", "owner_location": None,
        "breeder": "Jacob Brunner", "breeder_location": "Philadelphia, Pa.",
        "sire": "Redroof Exorcist", "sire_registration_number": "637314",
        "dam": "Gilda", "dam_registration_number": "802695",
        "source": meta_p83_c_left
    },
    {
        "name": "EBLING V PETERSHOFF", "sex": "Male", "registration_number": "883084",
        "birth_date": "Nov. 23, 1932", "color": "Blk & rust",
        "owner": "Bernhard S. Bohland", "owner_location": None,
        "breeder": "Mrs. Margaret Peters", "breeder_location": "Bath, N. Y.",
        "sire": "Armo v d Edelblut", "sire_registration_number": "849421",
        "dam": "Alice v Timmenal", "dam_registration_number": "823835",
        "source": meta_p83_c_left
    },
    {
        "name": "EROS V D STOECKERSBURG", "sex": "Male", "registration_number": "879794",
        "birth_date": "Dec. 11, 1932", "color": "Blk, rd rust",
        "owner": "Ethel M. Melick", "owner_location": None,
        "breeder": "Stoeckersburg Kennels", "breeder_location": "Keansburg, N. J.",
        "sire": "Manfred v Sabina", "sire_registration_number": "723082",
        "dam": "Cita v d Stoeckersburg", "dam_registration_number": "861623",
        "source": meta_p83_c_left
    },
    {
        "name": "FAUROT'S MITZY", "sex": "Female", "registration_number": "879686",
        "birth_date": "Oct. 30, 1928", "color": "Rd",
        "owner": "Vernita E. Faurot", "owner_location": None,
        "breeder": "Seeley N. Levy", "breeder_location": "Johnstown, Pa.",
        "sire": "Claus v d Spree", "sire_registration_number": "412661",
        "dam": "Fraulein Hinder", "dam_registration_number": "767911",
        "source": meta_p83_c_left
    },
    {
        "name": "FRITZ V HIEBER-SCHULTZ", "sex": "Male", "registration_number": "880097",
        "birth_date": "June 3, 1932", "color": "Tn & rust rd",
        "owner": "Martin L. Knodle", "owner_location": None,
        "breeder": "Peter Schultz", "breeder_location": "Philadelphia, Pa.",
        "sire": "Bundash", "sire_registration_number": "798873",
        "dam": "Beauty", "dam_registration_number": "794152",
        "source": meta_p83_c_left
    }
]

# 3. Page 83 (Leaf 84), Column Right (16 dogs)
col3_dogs = [
    {
        "name": "FRITZIE RAAB", "sex": "Female", "registration_number": "879701",
        "birth_date": "June 13, 1929", "color": "Blk & rust",
        "owner": "Chas. H. Raab", "owner_location": None,
        "breeder": "Mignon Preston", "breeder_location": "Fresno, Calif.",
        "sire": "Guard", "sire_registration_number": "700191",
        "dam": "Aimee Semple McPherson", "dam_registration_number": "547816",
        "source": meta_p83_c_right
    },
    {
        "name": "FRITZIE V WEGHORST", "sex": "Male", "registration_number": "883068",
        "birth_date": "Aug. 17, 1931", "color": "Blk & rust",
        "owner": "B. A. Kahler", "owner_location": None,
        "breeder": "Margueritte Morse", "breeder_location": "Chicago, Ill.",
        "sire": "Fritz v d Klooft", "sire_registration_number": "675606",
        "dam": "Alma v d Rheinperle", "dam_registration_number": "807786",
        "source": meta_p83_c_right
    },
    {
        "name": "FRITZ V SCHOICK", "sex": "Male", "registration_number": "882324",
        "birth_date": "Nov. 14, 1932", "color": "Blk & rust",
        "owner": "Mildred Asquith Howell", "owner_location": None,
        "breeder": "Pearle M. Wilson", "breeder_location": "Berwyn, Md.",
        "sire": "Ari of Nashville", "sire_registration_number": "853485",
        "dam": "Jude", "dam_registration_number": "860490",
        "source": meta_p83_c_right
    },
    {
        "name": "GAEA V KERR", "sex": "Female", "registration_number": "880005",
        "birth_date": "June 8, 1928", "color": "Rd, tn mkgs",
        "owner": "Edwin L. Kerr", "owner_location": None,
        "breeder": "Louis E. Moschel", "breeder_location": "Buffalo, N. Y.",
        "sire": "Bruno v d Residenz", "sire_registration_number": "434861",
        "dam": "Gaea v Nibelungenhort", "dam_registration_number": "556027",
        "source": meta_p83_c_right
    },
    {
        "name": "GERD V TIMMENAL", "sex": "Male", "registration_number": "880668",
        "birth_date": "Feb. 12, 1933", "color": "Blk-rust mkgs",
        "owner": "Kenneth Andrew", "owner_location": None,
        "breeder": "Mrs. Alice B. Maloney", "breeder_location": "Onondaga Hill, N. Y.",
        "sire": "Figaro v Timmenal", "sire_registration_number": "800812",
        "dam": "Konnemehrer v Timmenal", "dam_registration_number": "674117",
        "source": meta_p83_c_right
    },
    {
        "name": "GERHARDT V TIMMENAL", "sex": "Male", "registration_number": "880666",
        "birth_date": "Feb. 12, 1933", "color": "Blk-rust mkgs",
        "owner": "Kenneth Andrew", "owner_location": None,
        "breeder": "Mrs. Alice B. Maloney", "breeder_location": "Onondaga Hill, N. Y.",
        "sire": "Figaro v Timmenal", "sire_registration_number": "800812",
        "dam": "Konnemehrer v Timmenal", "dam_registration_number": "674117",
        "source": meta_p83_c_right
    },
    {
        "name": "GILDA V D STRAHLENBURG", "sex": "Female", "registration_number": "880015",
        "birth_date": "May 22, 1932", "color": "Blk & tn",
        "owner": "Henriette Hoens", "owner_location": None,
        "breeder": "Emil Klein", "breeder_location": "N. Y. City",
        "sire": "Fritz v Baedersdorf", "sire_registration_number": "774306",
        "dam": "Gilda v d Molkenkur", "dam_registration_number": "797857",
        "source": meta_p83_c_right
    },
    {
        "name": "GONDA V ANGERHAUS", "sex": "Female", "registration_number": "881643",
        "birth_date": "May 29, 1931", "color": "Blk-rd",
        "owner": "William Hacker", "owner_location": None,
        "breeder": "Franz Schmidt", "breeder_location": "Germany",
        "sire": "Bodo v d Fuggerstadt", "sire_registration_number": None,
        "dam": "Hilde v Tannenhaus", "dam_registration_number": None,
        "extended_ancestry": [
            {"role": "sire_of_dam", "name": "Hamlet v Herthasee", "registration_number": None},
            {"role": "dam_of_dam", "name": "Rita v Luisenheim", "registration_number": None},
            {"role": "sire_of_maternal_granddam", "name": "Lux v d Blankenburg", "registration_number": None},
            {"role": "dam_of_maternal_granddam", "name": "Dita v d staatl Zuchtanstalt fur P. H. (Grunheide)", "registration_number": None},
            {"role": "sire_of_maternal_grandsire", "name": "Alto v Sigalsburg", "registration_number": None},
            {"role": "dam_of_maternal_grandsire", "name": "Comtess v Steyerberg", "registration_number": None},
            {"role": "sire_of_sire", "name": "Gustl v Tannenhaus", "registration_number": None},
            {"role": "dam_of_sire", "name": "Blanka v Radegundis", "registration_number": None},
            {"role": "sire_of_paternal_granddam", "name": "Artus v Siegestor", "registration_number": None},
            {"role": "dam_of_paternal_granddam", "name": "Adela v Weisenfeld", "registration_number": None},
            {"role": "sire_of_paternal_grandsire", "name": "Dechant v Eckardtsburg", "registration_number": None},
            {"role": "dam_of_paternal_grandsire", "name": "Rita v Luisenheim", "registration_number": None}
        ],
        "source": meta_p83_c_right
    },
    {
        "name": "GRETCHEN V D ARLAC", "sex": "Female", "registration_number": "882125",
        "birth_date": "Aug. 6, 1932", "color": "Blk & tn",
        "owner": "A. S. Haines", "owner_location": "Pittsburgh, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Franz v d Arlac", "sire_registration_number": "839157",
        "dam": "Freya v d Arlac", "dam_registration_number": "782827",
        "source": meta_p83_c_right
    },
    {
        "name": "GRETCHEN V D REICHSBURG", "sex": "Female", "registration_number": "879572",
        "birth_date": "Mar. 19, 1931", "color": "Rd, rust mkgs",
        "owner": "George D. Chambers", "owner_location": None,
        "breeder": "W. L. Lyons, Jr.", "breeder_location": "Harrods Creek, Ky.",
        "sire": "Benno v Burgholz", "sire_registration_number": "393913",
        "dam": "Dea v d Reichsburg", "dam_registration_number": "552928",
        "source": meta_p83_c_right
    },
    {
        "name": "GRETCHEN V TIMMENAL", "sex": "Female", "registration_number": "880667",
        "birth_date": "Feb. 12, 1933", "color": "Blk-rust mkgs",
        "owner": "Kenneth Andrew", "owner_location": None,
        "breeder": "Mrs. Alice B. Maloney", "breeder_location": "Onondaga Hill, N. Y.",
        "sire": "Figaro v Timmenal", "sire_registration_number": "800812",
        "dam": "Konnemehrer v Timmenal", "dam_registration_number": "674117",
        "source": meta_p83_c_right
    },
    {
        "name": "GRETEL V TIMMENAL", "sex": "Female", "registration_number": "880669",
        "birth_date": "Feb. 12, 1933", "color": "Blk-rust mkgs",
        "owner": "Kenneth Andrew", "owner_location": None,
        "breeder": "Mrs. Alice B. Maloney", "breeder_location": "Onondaga Hill, N. Y.",
        "sire": "Figaro v Timmenal", "sire_registration_number": "800812",
        "dam": "Konnemehrer v Timmenal", "dam_registration_number": "674117",
        "source": meta_p83_c_right
    },
    {
        "name": "GRUNO V D ARLAC", "sex": "Male", "registration_number": "882126",
        "birth_date": "Aug. 6, 1932", "color": "Blk & tn",
        "owner": "A. S. Haines", "owner_location": "Pittsburgh, Pa.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Franz v d Arlac", "sire_registration_number": "839157",
        "dam": "Freya v d Arlac", "dam_registration_number": "782827",
        "source": meta_p83_c_right
    },
    {
        "name": "HANS VAN METER", "sex": "Male", "registration_number": "881692",
        "birth_date": "Jan. 5, 1933", "color": "Blk & tn",
        "owner": "C. S. Owen", "owner_location": None,
        "breeder": "Edward V. Rawlings", "breeder_location": "Birmingham, Mich.",
        "sire": "Mars v Simmenau Rhinegold", "sire_registration_number": "768282",
        "dam": "Gretchen Van Meter Rhinegold", "dam_registration_number": "845572",
        "source": meta_p83_c_right
    },
    {
        "name": "IMPERIAL LADY", "sex": "Female", "registration_number": "880952",
        "birth_date": "Jan. 12, 1932", "color": "Blk & tn",
        "owner": "Lowery O. Ross", "owner_location": None,
        "breeder": "Cori A. Leach", "breeder_location": "Fairbury, Nebr.",
        "sire": "Bingo Son of Edmund", "sire_registration_number": "655754",
        "dam": "Jerridine Fra Duncan", "dam_registration_number": "841875",
        "source": meta_p83_c_right
    },
    {
        "name": "JATZ V WILSONA HOF", "sex": "Female", "registration_number": "878851",
        "birth_date": "May 2, 1932", "color": "Blk & tn",
        "owner": "Willis L. Dorman, M. D.", "owner_location": None,
        "breeder": "Georgine Y. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Bodo v Askanierland", "sire_registration_number": "736236",
        "dam": "Bernie v Wilsona", "dam_registration_number": "672372",
        "source": meta_p83_c_right
    }
]

# 4. Page 84 (Leaf 85), Column Left (19 dogs)
col4_dogs = [
    {
        "name": "JERRY V NIBELUNGENHORT", "sex": "Female", "registration_number": "880682",
        "birth_date": "Dec. 11, 1930", "color": "Blk & tn",
        "owner": "William J. Mattox", "owner_location": None,
        "breeder": "W. A. Schachinger", "breeder_location": "Dayton, Ohio",
        "sire": "Red Roof Rowdy", "sire_registration_number": "392482",
        "dam": "Ulli v Nibelungenhort", "dam_registration_number": "524280",
        "source": meta_p84_c_left
    },
    {
        "name": "JUDITH", "sex": "Female", "registration_number": "880436",
        "birth_date": "June 19, 1931", "color": "Blk & tn",
        "owner": "Edwin Milke", "owner_location": None,
        "breeder": "Mrs. J. Bechtold", "breeder_location": "Chicago, Ill.",
        "sire": "Jack v Chicago", "sire_registration_number": "641041",
        "dam": "Diana v Schoenfels", "dam_registration_number": "802416",
        "source": meta_p84_c_left
    },
    {
        "name": "KNEIFER TURPIN", "sex": "Male", "registration_number": "878890",
        "birth_date": "Aug. 25, 1932", "color": "Rd & tn",
        "owner": "C. H. Turpin", "owner_location": None,
        "breeder": "Otto Beuke", "breeder_location": "Wichita, Kans.",
        "sire": "Komet v d Residenz", "sire_registration_number": "787761",
        "dam": "Nuja v Streslau", "dam_registration_number": "586735",
        "source": meta_p84_c_left
    },
    {
        "name": "LADY BALA OF PONTCHARTRAIN", "sex": "Female", "registration_number": "880404",
        "birth_date": "July 27, 1931", "color": "Blk & rd",
        "owner": "Grant Rowe", "owner_location": None,
        "breeder": "Glenn S. Staines", "breeder_location": "Detroit, Mich.",
        "sire": "Figaro v Sigalsburg", "sire_registration_number": "647311",
        "dam": "Princess Bel O'Pontchartrain", "dam_registration_number": "724430",
        "source": meta_p84_c_left
    },
    {
        "name": "LADY BYRD V BERG", "sex": "Female", "registration_number": "879400",
        "birth_date": "Sept. 10, 1931", "color": "Br, tn mkgs",
        "owner": "James D. Kerr", "owner_location": None,
        "breeder": "H. G. Hirsh", "breeder_location": "Philadelphia, Pa.",
        "sire": "Carol v Berg", "sire_registration_number": "873723",
        "dam": "Cecelia v Berg", "dam_registration_number": "875985",
        "source": meta_p84_c_left
    },
    {
        "name": "LADY V WILSONA HOF", "sex": "Female", "registration_number": "883227",
        "birth_date": "Apr. 11, 1931", "color": "Blk & tn",
        "owner": "J. M. Carrington", "owner_location": None,
        "breeder": "Ben H. Wilson", "breeder_location": "Rushville, Ind.",
        "sire": "Bodo v Askanierland", "sire_registration_number": "736236",
        "dam": "Etta v Wilsona Hof", "dam_registration_number": "733027",
        "source": meta_p84_c_left
    },
    {
        "name": "LEITCH'S PAL", "sex": "Male", "registration_number": "882150",
        "birth_date": "July 2, 1932", "color": "Blk & tn",
        "owner": "A. M. Helmuth", "owner_location": None,
        "breeder": "E. J. Robinson", "breeder_location": "Milwaukee, Wis.",
        "sire": "Tinker of Rhinegold", "sire_registration_number": "667097",
        "dam": "Robinson's Miss Addie", "dam_registration_number": "695713",
        "source": meta_p84_c_left
    },
    {
        "name": "LINDA II", "sex": "Female", "registration_number": "879737",
        "birth_date": "Dec. 11, 1932", "color": "Blk & tn",
        "owner": "Mrs. B. F. Jones", "owner_location": None,
        "breeder": "Wm. H. Gates", "breeder_location": "Baton Rouge, La.",
        "sire": "Red Roof Buccaneer", "sire_registration_number": "641316",
        "dam": "Peggy of Apna Villa", "dam_registration_number": "779387",
        "source": meta_p84_c_left
    },
    {
        "name": "LUCINDA V DOMBACHTAL", "sex": "Female", "registration_number": "879599",
        "birth_date": "Sept. 12, 1930", "color": "Blk & tn",
        "owner": "E. R. Thomas", "owner_location": None,
        "breeder": "Frank Yahraus", "breeder_location": "Parkman, Ohio",
        "sire": "Egon v Dombachtal", "sire_registration_number": "726317",
        "dam": "Schein's Maichen II", "dam_registration_number": "756925",
        "source": meta_p84_c_left
    },
    {
        "name": "LUDO V SCHOENFELS", "sex": "Male", "registration_number": "882769",
        "birth_date": "June 23, 1932", "color": "Blk & tn",
        "owner": "Frank H. Olbert", "owner_location": None,
        "breeder": "Mrs. J. Bechtold", "breeder_location": "Chicago, Ill.",
        "sire": "Jack v Chicago", "sire_registration_number": "641041",
        "dam": "Diana v Schoenfels", "dam_registration_number": "802416",
        "source": meta_p84_c_left
    },
    {
        "name": "MATT M STRIESEN", "sex": "Male", "registration_number": "879318",
        "birth_date": "Feb. 20, 1930", "color": "Blk, rust mkgs",
        "owner": "J. P. McKnight", "owner_location": None,
        "breeder": "Mrs. C. A. Bergman", "breeder_location": "Ottumwa, Ia.",
        "sire": "Ali Pascha v Striesen", "sire_registration_number": "459899",
        "dam": "Dolly v Jaegershof", "dam_registration_number": "719690",
        "source": meta_p84_c_left
    },
    {
        "name": "MAX V NORDHAUSEN", "sex": "Male", "registration_number": "878894",
        "birth_date": "Sept. 20, 1932", "color": "Blk, rust br",
        "owner": "Miss Mary Cooper", "owner_location": None,
        "breeder": "Joseph Stein", "breeder_location": "Chicago, Ill.",
        "sire": "Dober v Buelow", "sire_registration_number": "761992",
        "dam": "Herta v Stein", "dam_registration_number": "847682",
        "source": meta_p84_c_left
    },
    {
        "name": "MITZI NELLIE", "sex": "Female", "registration_number": "879401",
        "birth_date": "Feb. 3, 1930", "color": "Blk & tn",
        "owner": "Chas. George Baker", "owner_location": None,
        "breeder": "Michael S. Morris", "breeder_location": "Philadelphia, Pa.",
        "sire": "Duke v Stroheim", "sire_registration_number": "563574",
        "dam": "Brunhilda", "dam_registration_number": "580969",
        "source": meta_p84_c_left
    },
    {
        "name": "PRINCE V DUSENBERG", "sex": "Male", "registration_number": "881557",
        "birth_date": "Nov. 26, 1931", "color": "Blk & tn",
        "owner": "John I. Hyde", "owner_location": None,
        "breeder": "R. B. Nunlist", "breeder_location": "Eaton, Ohio",
        "sire": "Prince of Westerled", "sire_registration_number": "466547",
        "dam": "Mickey of Preble", "dam_registration_number": "501187",
        "source": meta_p84_c_left
    },
    {
        "name": "PRINCESS DOREEN", "sex": "Female", "registration_number": "881830",
        "birth_date": "Feb. 15, 1933", "color": "Blk-tn",
        "owner": "Thomas E. Redd", "owner_location": None,
        "breeder": "Otto H. Lensch", "breeder_location": "Dayton, Ohio",
        "sire": "Mort v d Flad", "sire_registration_number": "857494",
        "dam": "Maskette", "dam_registration_number": "838255",
        "source": meta_p84_c_left
    },
    {
        "name": "REA V GEERTSEN", "sex": "Female", "registration_number": "882880",
        "birth_date": "Mar. 2, 1931", "color": "Blk, rust mkgs",
        "owner": "William J. Genge", "owner_location": None,
        "breeder": "Walter Paradowski", "breeder_location": "Chicago, Ill.",
        "sire": "Fritz v Edjo", "sire_registration_number": "605709",
        "dam": "Bella v Hornegg", "dam_registration_number": "776834",
        "source": meta_p84_c_left
    },
    {
        "name": "SATAN V D SCHROTH", "sex": "Male", "registration_number": "879442",
        "birth_date": "Jan. 29, 1933", "color": "Blk, rust rd",
        "owner": "John K. Childs", "owner_location": None,
        "breeder": "Mr. & Mrs. Geo. Schroth", "breeder_location": "San Mateo, Calif.",
        "sire": "Karl v Blankenburg", "sire_registration_number": "722359",
        "dam": "Lady of Schroth Valley", "dam_registration_number": "842299",
        "source": meta_p84_c_left
    },
    {
        "name": "SCHALLER FROM LICHTONSTINE", "sex": "Female", "registration_number": "882226",
        "birth_date": "May 3, 1929", "color": "Blk & tn",
        "owner": "Fred H. Peterson", "owner_location": None,
        "breeder": "Louis Hutter", "breeder_location": "Papillion, Nebr.",
        "sire": "Walter v Hoh", "sire_registration_number": "682033",
        "dam": "Boby v Strusen", "dam_registration_number": "682034",
        "source": meta_p84_c_left
    },
    {
        "name": "SUE OF POCAHONTAS", "sex": "Female", "registration_number": "882385",
        "birth_date": "July 12, 1932", "color": "Br & tn",
        "owner": "Karl Kraus", "owner_location": None,
        "breeder": "J. Christensen", "breeder_location": "Buffalo, N. Y.",
        "sire": "Cyrus v d Rehhutte", "sire_registration_number": "636115",
        "dam": "Salvia of Pocahontas", "dam_registration_number": "834889",
        "source": meta_p84_c_left
    }
]

# 5. Page 84 (Leaf 85), Column Right top (5 dogs down to PINSCHER (Miniature))
col5_dogs = [
    {
        "name": "TINA V REICHSBURG", "sex": "Female", "registration_number": "880688",
        "birth_date": "May 17, 1925", "color": "Blk & rust br",
        "owner": "Marietta Flinn", "owner_location": "Elizabeth, N. J.",
        "breeder": "Owner", "breeder_location": None,
        "sire": "Cyrano v d Reischsburg", "sire_registration_number": "413252",
        "dam": "Ardena v Elbstrom", "dam_registration_number": "380040",
        "source": meta_p84_c_right
    },
    {
        "name": "TINA V TELLI", "sex": "Female", "registration_number": "883229",
        "birth_date": "July 30, 1932", "color": "Br, rd rst mkgs",
        "owner": "Alfred J. Bertelli", "owner_location": None,
        "breeder": "Gladys M. Ward", "breeder_location": "Batavia, Ia.",
        "sire": "Hillacre Rowdy", "sire_registration_number": "778563",
        "dam": "Betty v Burgholz", "dam_registration_number": "840209",
        "source": meta_p84_c_right
    },
    {
        "name": "TYLER'S BROWN LADY", "sex": "Female", "registration_number": "879878",
        "birth_date": "Apr. 24, 1932", "color": "Rd & rust",
        "owner": "Berna S. Tyler", "owner_location": None,
        "breeder": "J. C. Williams", "breeder_location": "Wheeling, W. Va.",
        "sire": "Peter v Romerhof", "sire_registration_number": "616494",
        "dam": "Brunhilde v Sigalsburg", "dam_registration_number": "667532",
        "source": meta_p84_c_right
    },
    {
        "name": "WALLHALLIAN WOTI", "sex": "Male", "registration_number": "883169",
        "birth_date": "May 25, 1932", "color": "Rd & tn",
        "owner": "Geo. E. Mueller, M. D.", "owner_location": None,
        "breeder": "Otto Mueller, M. D.", "breeder_location": "Red Valley City, Ohio",
        "sire": "Rudolph Richthofen", "sire_registration_number": "612479",
        "dam": "Gretchen of Wakeridge", "dam_registration_number": "803291",
        "source": meta_p84_c_right
    },
    {
        "name": "WANDA V KISSINGER", "sex": "Female", "registration_number": "880632",
        "birth_date": "Jan. 10, 1930", "color": "Blk & br",
        "owner": "John D. Kissinger", "owner_location": None,
        "breeder": "Raymond Brown", "breeder_location": "Columbus, Ohio",
        "sire": "Chief Cloud", "sire_registration_number": "807030",
        "dam": "Lady Bella v Blandenburg", "dam_registration_number": "714799",
        "source": meta_p84_c_right
    }
]

all_33_07 = col1_dogs + col2_dogs + col3_dogs + col4_dogs + col5_dogs
print(f"Total compiled 1933-07 dogs: {len(all_33_07)} (Expected: 62)")
print(f"  Page 82 Col Right: {len(col1_dogs)} (Expected: 3)")
print(f"  Page 83 Col Left:  {len(col2_dogs)} (Expected: 19)")
print(f"  Page 83 Col Right: {len(col3_dogs)} (Expected: 16)")
print(f"  Page 84 Col Left:  {len(col4_dogs)} (Expected: 19)")
print(f"  Page 84 Col Right: {len(col5_dogs)} (Expected: 5)")

Path("stud-scrape/data/verified_1933_07.json").write_text(json.dumps(all_33_07, indent=2), encoding="utf-8")
print("Saved verified 1933-07 records to stud-scrape/data/verified_1933_07.json")
